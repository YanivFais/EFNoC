/**
 *
 * @file cost_function.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: cost_function.hh 6 2011-11-23 13:57:28Z lehton87 $
 *
 */

#ifndef SCTG_COST_FUNCTION_HH
#define SCTG_COST_FUNCTION_HH

#define SSS(x) #x
#define SSS_(x) SSS(x)
#define ASE_ERRSTR(x) (#x " in file " __FILE__ ", line " SSS_(__LINE__))      


#include <string>
#include <map>
#include <deque>

namespace sctg
{
   /** Evaluates a function
    *
    * Class parses a function and calculates the result. Function
    * supports four basic operators (+-/*), parenthesis, constants
    * and measured variables.
    *
    */
   class CostFunction
   {
   public:
      
      /** Constructor
       */
      CostFunction();

      /** Destructor
       */
      ~CostFunction();

      /** Adds variable so that it can be used in cost functions
       */
      void addVariable(std::string& str, double value);

      /** Parses the given function and returns its result
       */
      double parse(std::string& function);

   private:
      
      // Enumerates operators and operands
      enum ElementType {	 
	 NEGATE = 1,
	 MULT,
	 DIV,	
	 PLUS,	 
	 MINUS,	 
	 OPEN,
	 CLOSE,
	 NUMBER
      };

      // Holder for stacks
      struct Element {
	 ElementType type;
	 double value;
      };
      
      // Implementation of Dijkstra's shunting-yard algorithm.
      // Converts equation in postfix format to infix format
      //  and stores it to variable postfix_.
      void infix_to_postfix(std::string::iterator begin,
			    std::string::iterator end);

      // Calculates the result of the equation in postfix format.
      double evaluate();

      // Known variables
      std::map<std::string, double> variables_;
      
      // Equation in postfix format
      std::deque<Element> postfix_;

   };
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
