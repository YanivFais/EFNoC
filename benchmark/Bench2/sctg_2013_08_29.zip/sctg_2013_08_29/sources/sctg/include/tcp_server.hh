/**
 *
 * @file tcp_server.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: tcp_server.hh 24 2012-01-23 13:55:08Z lehton87 $
 *
 */


#ifndef SCTG_TCP_SERVER_HH
#define SCTG_TCP_SERVER_HH

#include "tcp_server_if.hh"

#include <string>
#include <boost/asio.hpp>

namespace sctg
{
   /** TCP server for communicating with Execution Monitor
    *
    *
    */
   class TcpServer : public TcpServerIf
   {
   public:
      
      /** Constructor
       */
      TcpServer(unsigned int port);

      /** Destructor
       */
      ~TcpServer();

      /** Blocking wait for one connection
       */
      void waitConnection();

      /** Sends string to client
       */
      void send(std::string& str);

   private:
      boost::asio::io_service        io_;
      boost::asio::ip::tcp::acceptor acceptor_;
      boost::asio::ip::tcp::socket   socket_;
      
   };
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
