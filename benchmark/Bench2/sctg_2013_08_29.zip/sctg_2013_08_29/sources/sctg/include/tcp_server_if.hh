/**
 *
 * @file tcp_server_if.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: tcp_server_if.hh 6 2011-11-23 13:57:28Z lehton87 $
 *
 */


#ifndef SCTG_TCP_SERVER_IF_HH
#define SCTG_TCP_SERVER_IF_HH

#include <string>

namespace sctg
{
   /** Interface class for TcpServer class
    *
    *
    */
   class TcpServerIf
   {
   public:

      /** Destructor
       */
      virtual ~TcpServerIf() {};
     
      /** Blocking wait for one connection
       */
      virtual void waitConnection() = 0;

      /** Sends string to client
       */
      virtual void send(std::string& str) = 0;
      
   };
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
