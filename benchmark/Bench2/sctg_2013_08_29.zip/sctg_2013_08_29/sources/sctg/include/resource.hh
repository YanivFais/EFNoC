/**
 *
 * @file resource.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: resource.hh 75 2012-08-16 10:56:41Z ege $
 *
 */


#ifndef SCTG_RESOURCE_HH
#define SCTG_RESOURCE_HH

#include "buffer.hh"
#include <systemc>
#include <boost/property_tree/ptree.hpp>
#include <string>
#include <vector>
#include <map>

namespace sctg
{
   class Task;

   /** Base class for ProcessingElement and MemoryModel classes
    *
    *
    */
   class Resource : public sc_core::sc_module
   {
   public:
      
      /** Constructor
       */
      Resource(sc_core::sc_module_name name, 
	       const boost::property_tree::ptree& pt,
	       sctg::Configuration& config);
      
      /** Destructor
       */
      virtual ~Resource();
      
      /** Returns name
       */
      const std::string& getName() const;
      
      /** Returns ID
       */
      unsigned long int getId() const;
      
      /** Returns operating frequency
       */
      unsigned long int getFrequency() const;
      
      /** Returns type
       */
      const std::string& getType() const;

      /** Maps task or mem_area to this Resource
       */
      virtual void mapResourceUser(ResourceUser* task) = 0;

   private:
      
      /** Name
       */
      std::string       name_;
      /** Unique ID number
       */
      unsigned long int id_;
      /** Operating frequency
       */
      unsigned long int freq_;
      /** Resources type
       */
      std::string       type_;



   protected:      
            
      /** Pointer to resource's buffer
       */
      std::auto_ptr<Buffer> buffer_;
      /** Maximum size for the packets this resource sends
       */
      unsigned long int packetSize_;


      // Moved here, 13.8.2012, es
      Configuration& config_;
      PeMeasurements measurements_;
      sc_core::sc_time measureStart_;
      sc_core::sc_time measureEnd_;

      /** Print utilization cycles and percentages into summary stream
       */
      int printUtilStats() const;

      /** Print communication volumes and cycles into summary stream
       */
      int printCommStats(int iLineSize, int dLineSize, int missReqSize) const;
      
   };
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
