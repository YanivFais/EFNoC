/**
 *
 * @file non_sc_conf_if.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: non_sc_conf_if.hh 24 2012-01-23 13:55:08Z lehton87 $
 *
 */

#ifndef SCTG_NON_SC_CONF_IF_HH
#define SCTG_NON_SC_CONF_IF_HH

#include "tcp_server_if.hh"

namespace sctg
{
   /** Virtual interface class for funky stuff
    */
   class NonScConfIf
   {
   public:
      
      /** Destructor
       */
      virtual ~NonScConfIf() {}

      /** Sets pointer to TCP server
       */
      virtual void setTcpServer(TcpServerIf* server) = 0;

      /** Return pointer to TCP server
       */
      virtual TcpServerIf* getTcpServer() = 0;
   };
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
