/**
 * @file amount.hh
 * @author Lasse Lehtonen
 * 
 * 
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: amount.hh 81 2012-09-12 06:39:00Z ege $
 *
 */

#ifndef SCTG_AMOUNT_HH
#define SCTG_AMOUNT_HH

#include "configuration.hh"

#include <boost/property_tree/ptree.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/foreach.hpp>
#include <boost/random.hpp>
#include <boost/optional.hpp>

#include <iostream>
#include <vector>
#include <exception>



namespace sctg
{
   /** Class for calculating polynoms and distributions
    *
    * Evaluates the polynom or distribution and returns a value
    */
   template <class Type>
   class Amount
   {
   public:    

      /** Constructor
       *
       *  @param[in] pt Property tree node containing polynomial or
       *  distributional tag
       *
       *  @param[in] config Reference to Configuration object
       */
      Amount(const boost::property_tree::ptree& pt,
	     Configuration& config);
    
      /** Destructor
       */
      virtual ~Amount();

      /** Evaluate distribution or polynom
       *
       * @return Result of distribution or polynom
       *
       * @param[in] x Variable for polynom or mean for distributions
       */
      Type value(Type x=0) const;    

    
    
   private:

      /** One polynomial term
       *
       */
      struct Term_
      {
	 Type coefficient; ///< Term's coefficient
	 Type exponent;    ///< Term's exponent
      };
    
      /** Polynom constructed from terms
       */
      std::vector<Term_> polynom_;

      /** Possible types objects can represent
       */
      enum AmountType_ {POLYNOMIAL, UNIFORM, NORMAL};

      /** What this object represents
       */
      AmountType_ amountType_;

      /** Pointer to uniform distribution object
       */
      boost::uniform_int<>* uniform_;

      /** Pointer to normal distribution object
       */
      boost::normal_distribution<double>* normal_;
      Type  stdDev_;

      /** Reference to random number generator for real numbers
       */
      Configuration::RealEngineType& realEngine_;
      /** Reference to random number generator for integers
       */
      Configuration::IntEngineType&  intEngine_;

   };
}


//
// CLASS IMPLEMENTATION
//



namespace sctg
{  
   template <class Type>
   Amount<Type>::Amount(const boost::property_tree::ptree& pt,
			Configuration& config)
      : polynom_   (),
	amountType_(POLYNOMIAL),
	uniform_   (0),            
	normal_    (0),
	stdDev_    (0),
	realEngine_(config.getRealRNGEngine()),
	intEngine_ (config.getIntRNGEngine())
   {
      using boost::property_tree::ptree;
      ptree tempPTree;
    
      if(pt.find("polynomial") != pt.not_found())
      {
	 // Construct polynomial from property_tree
	 amountType_ = POLYNOMIAL;	
	
	 // Store all terms
	 for(ptree::const_iterator iter = pt.get_child("polynomial").begin(); 
	     iter != pt.get_child("polynomial").end(); ++iter)
	 {      
	    // Ignore all but param tags
	    if((*iter).first == "param")
	    {		
	       std::string val = ((*iter).second.get<std::string>("<xmlattr>.value"));
	       std::string exp = ((*iter).second.get<std::string>("<xmlattr>.exp"));
	       try {
		  Term_ term = {
		     boost::lexical_cast<Type>(val), 
		     boost::lexical_cast<Type>(exp)
		  };		  
		  polynom_.push_back(term);
		  
	       } catch (std::exception& e) {
		  std::string es;// = e.what();
		  es += "<polynomial><param> (" + val + ") *x^(" + exp + ") failed:  ";
		  es += e.what();
		  throw std::runtime_error (es);
	       }

	       // std::cout << "     amount(): poly val&exp ok:" << val << " & " << exp << std::endl; // ES
		  
	    }
	 }
      }
      else if(pt.find("distribution") != pt.not_found())
      {
	 // Create distribution
	 tempPTree = pt.get_child("distribution");
	 if(tempPTree.find("uniform") != tempPTree.not_found())
	 {
	    amountType_ = UNIFORM;
	    std::string mins = (pt.get<std::string>("distribution.uniform.<xmlattr>.min"));
	    std::string maxs = (pt.get<std::string>("distribution.uniform.<xmlattr>.max"));
	    try {
	       Type min = boost::lexical_cast<Type>(mins); // pt.get<Type>("distribution.uniform.<xmlattr>.min");
	       Type max = boost::lexical_cast<Type>(maxs);
	       if (min > max)
	       {
		  std::cout << "Uniform distr (" << min  << " -> " << max << ") converted to ("
			   << min << " -> " << min << ")" << std::endl;
		  max = min;
	       }
	       


	       //(pt.get<std::string>("distribution.uniform.<xmlattr>.max"));
	       uniform_ = new boost::uniform_int<>(min,max);
	    } catch (std::exception& e) {
	       std::string es;// = e.what();
	       es += "<distribution><uniform>";
	       es += mins + " - " + maxs + " is illegal: ";
	       es += e.what();
	       throw std::runtime_error (es);
	    }
	    // std::cout << "     amount(): uni distr min - max ok:" << mins << " - " << maxs << std::endl; // ES
	 }
	 else if(tempPTree.find("normal") != tempPTree.not_found())
	 {
	    try {
	       amountType_ = NORMAL;
	       boost::optional<Type> mean = pt.get_optional<Type>
		  ("distribution.normal.<xmlattr>.mean");
	       stdDev_ = pt.get<Type>
		  ("distribution.normal.<xmlattr>.standard_deviation");
	       if(mean)
	       {
		  normal_ = new boost::normal_distribution<double>
		     (double(*mean), double(stdDev_));
	       }
	    } catch (std::exception& e) {
	       std::string es;// = e.what();
	       es += "<distribution><normal> is illegal:";
	       es += e.what();
	       throw std::runtime_error (es);
	    }
	    // std::cout << "     amount(): distr N mean & std ok" << std::endl; // ES

	 }
	 else
	 {
	    throw std::runtime_error("Did not find valid distribution");
	 }      
      }    
      else
      {
	 throw std::runtime_error("No polynomial or distribution found");
      }      
	 }
  
   //Destructor
   template <class Type>
   Amount<Type>::~Amount()
   {
      if(normal_)    
	 delete normal_;
      if(uniform_)
	 delete uniform_;
   }


   // Calculates the value of polynom or distribution
   template <class Type>
   Type Amount<Type>::value(Type x) const
   {
      Type returnValue = 0;
      Type partialSum  = 0;

      switch(amountType_)
      {
	 case POLYNOMIAL:
	    // Loop over all terms and add them together
	    BOOST_FOREACH(Term_ term, polynom_)
	    {
	       if(term.exponent == 0)
	       {
		  partialSum = 1;
	       }
	       else
	       {
		  // brute force power calculation
		  //  exponents should be small so no need for optimization
		  partialSum = x;		
		  for(Type i = 1; i < term.exponent; ++i)
		  {
		     partialSum *= x;
		  }
	       }	    
	       returnValue += term.coefficient * partialSum;
	    }	
	    break;

	 case UNIFORM:
	    returnValue = (*uniform_)(intEngine_);
	    break;

	 case NORMAL:
	    if(normal_)
	    {
	       // Both mean and sigma were defined in xml
	       double result = normal_->operator () 
		  <Configuration::RealEngineType>(realEngine_);
	       returnValue = result < 1.0 ? 1 : Type(result);
	    }
	    else
	    {	   
	       // Take mean from the parameter 'x'
	       double result =
		  boost::normal_distribution<>(x, stdDev_)(realEngine_);
	       returnValue = result < 1.0 ? 1 : Type(result);
	    }
	    break;
	
	 default:
	    break;
      }    

      return returnValue;
   }
      
} // End of namespace sctg

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
