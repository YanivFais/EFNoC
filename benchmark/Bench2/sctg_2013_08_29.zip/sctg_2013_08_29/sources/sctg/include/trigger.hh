/**
 *
 * @file trigger.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: trigger.hh 154 2013-01-22 13:43:17Z ege $
 *
 */


#ifndef SCTG_TRIGGER_HH
#define SCTG_TRIGGER_HH

#include "amount.hh"
#include "configuration.hh"
#include "tg_token.hh"
#include "task.hh"
#include "common.hh"

#include <boost/property_tree/ptree.hpp>
#include <vector>
#include <queue>

#include <systemc>

namespace sctg
{
   class Task;

   /** Handles the execution of triggers
    */
   class Trigger
   {
   public:
	 /**
	    Trigger keeps track what the task should be do next:
	    execute, send, receive etc.
	 */

        
      /** Constructor
       */
      Trigger(const boost::property_tree::ptree& pt,
	      Configuration& config,
	      Task* ownerTask);
    
      /** Destructor
       */
      virtual ~Trigger();

      /** Returns current operation
       */
      sctg::OperationType getOperation();

      /** True if its new operation (not yet partially consumed)
       */
      bool isNewOperation();

      /** True if its new operation (not yet partially consumed)
       */
      bool isNewTrigger();

      /** Returns current amount what is left from current operation
       */
      unsigned long int getAmount();

      /** Returns burst amount
       */
      unsigned long int getBurstAmount();

      /** Returns read amount
       */
      unsigned long int getReadAmount();

      /** Return current operation's out_id
       */
      unsigned long int getOutPort();

      /** Return current operation's resp_id
       */
      unsigned long int getRespPort();

      /** Consumes amount of operations (or bytes for SENDs)
       * @return How many operations are left
       */
      unsigned long int consume(unsigned long int amount);

      /** True if trigger has in_port with that port_id (pid)
       */
      bool hasInPort(unsigned long int pid);
       
      /** Trigger receives a token
       */
      void receive(tgToken token);

      /** True if trigger is triggered
       */
      bool isActive();

      /** How many times this trigger has been triggered (executed)
       */
      unsigned long int getTimesTriggered() const;

      /** How many bytes trigger has sent
       */
      unsigned long int getBytesSent() const;

      /** How many clock cycles trigger has executed on PE
       */
      unsigned long int getCyclesExecuted() const;

      /** How many bytes trigger has read
       */
      unsigned long int getBytesRead() const;

      /** Returns buffered bytes
       */
      unsigned long int getBufferUsage() const;

      /** Returns Receive time of the current token
       * (or last for AND dependency trigger)
       */
      const sc_core::sc_time& getReceiveTime() const;

   private:

	 /* Own data structures */
	 enum DependenceType_ {AND, OR};
	 enum OpType_ {INT, MEM, FLOAT};
	 
	 // Part of a recipe telling what to do next. Formed
	 // dynamically from an Operation_
	 struct OpQueueItem
	 //struct OperationList_
	 {
	       sctg::OperationType type;      // exec, send, read, waitresp...
	       unsigned long int outPort;     // where to send
	       unsigned long int amount;      // ops, bytes
	       unsigned long int burstLength; // bytes, only for reads
	       unsigned long int readAmount;  // bytes, only for reads
	       unsigned long int respPort;    // outport of a memory, only for reads
	 };
	 
	 // Static info parsed from xml
	 struct Operation_
	 {
	       sctg::OperationType  type;     // exec, send, read... as in OpQueueItem
	       unsigned long int    outPort;  // 
	       unsigned long int    respPort; // 
	       double               prob;     // 0.0-1.0, does not necessarily happen every time
	       std::vector<OpType_> factors;  // PE performance as ops/cycle
	       std::vector<Amount<double>* > amounts;
	       std::vector<Amount<double>* > burstAmounts;
	       std::vector<Amount<double>* > readAmounts;
	 };
	 
	 // Static info parsed from xml
	 struct ExecCount_
	 {
	       std::vector<Operation_*>           operations;
	       boost::optional<unsigned long int> period;
	       boost::optional<unsigned long int> min;
	       boost::optional<unsigned long int> max;      
	       sctg::State nextState;
	 };
   


	 /* Member variables */
	 Configuration&  config_;      // global state of the simulated system
	 Task*           ownerTask_;      
	 sctg::State     nextState_;   //of ownwer task
	 std::vector<unsigned long int> inPorts_;
	 DependenceType_ dependence_;  // AND or OR
    
	 std::vector<ExecCount_*> execCounts_;     // Possible behaviors from xml
	 std::queue<OpQueueItem>  operationQueue_; // What to do next
	 

	 // 
	 bool newOp_;
	 bool newTrigger_;
	 sc_core::sc_time currentReceive_;
	 std::vector<std::queue<tgToken> > receivedTokens_; // tokens per inport
	 unsigned long int bytesInBuffer_; // Sum of currently stored tokens
	 unsigned long int receivedBytes_; // Size of latest token
	 unsigned long int eventBytes_;    // How many have come from event
	 
	 
	 // Cumulative  information
	 unsigned long int triggered_; // Trigger count
	 unsigned long int cyclesExecuted_; // 
	 unsigned long int bytesSent_;
	 unsigned long int bytesRead_;

	 
	 //* Parses exec_count tag
	 void parseExecCount(const boost::property_tree::ptree& pt,
			     ExecCount_* execCount,
			     Configuration& config);
	 
	 //* Builds execution queue 
	 void buildQueue();
	 
	 //* Resolves whether or not trigger should be active and builds queue
	 void resolve();
	 
	 double getFactor(OpType_ optype) const;
	 
	 /*double _intFactor;
	   double _memFactor;
	   double _floatFactor;*/	 
	 
   };
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
