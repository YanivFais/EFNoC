/**
 *
 * @file buffer_if.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: buffer_if.hh 6 2011-11-23 13:57:28Z lehton87 $
 *
 */


#ifndef SCTG_BUFFER_IF_HH
#define SCTG_BUFFER_IF_HH

#include "tg_packet.hh"
#include <systemc>

namespace sctg
{
   /** Interface for network models to communicate with buffers
    *
    *  Interface class which contains all the needed functions to
    *  receive or transfer network packets to or from resources for
    *  network models.
    *
    */
   class BufferInterface
   {
   public:

      /** Virtual destructor
       */
      virtual ~BufferInterface() {};

      // NoC to Agent interface

      /** Puts packet to buffer
       */
      virtual void rxPutPacket(tgPacket* packet) = 0;

      /** Returns amount of bytes left in receive buffer
       */
      virtual unsigned long int rxSpaceLeft() = 0;

      /** Returns the size of receive buffer
       */
      virtual unsigned long int rxBufSize() = 0;

      /** Returns event which notifies when rx buffer has been read by PE
       */
      virtual sc_core::sc_event* rxGetReadEvent() = 0;
    
      // Agent to NoC interface

      /** True if transmit buffer has packet(s) to send through network
       */
      virtual bool txPacketAvailable() = 0;

      /** Returns packet to be sent
       */
      virtual tgPacket* txGetPacket() = 0;

      /** Returns event that indicates when buffer has packets to send
       */
      virtual sc_core::sc_event* txGetPacketAvailableEvent() = 0;

   };

}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
