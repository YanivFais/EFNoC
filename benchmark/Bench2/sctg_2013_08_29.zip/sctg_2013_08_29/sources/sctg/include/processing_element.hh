/**
 *
 * @file processing_element.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: processing_element.hh 75 2012-08-16 10:56:41Z ege $
 *
 */


#ifndef SCTG_PROCESSING_ELEMENT_HH
#define SCTG_PROCESSING_ELEMENT_HH

#include "resource.hh"
#include "amount.hh"
#include "task.hh"
#include "buffer.hh"
#include "common.hh"

#include <systemc>
#include <boost/property_tree/ptree.hpp>
#include <memory>
#include <map>


namespace sctg
{
   /** Models a processor or hardare accelerator
    *
    */
   class ProcessingElement : public Resource
   {
   public:

      
      SC_HAS_PROCESS(ProcessingElement);

      /** Constructor
       */
      ProcessingElement(sc_core::sc_module_name name, 
			const boost::property_tree::ptree& pt,
			const boost::property_tree::ptree& peLib,
			sctg::Configuration& config);
    
      /** Destructor
       */
      virtual ~ProcessingElement();

      /** Main execution thread which consumes simulation time
       */
      void thread();

      /** How many integer operations are excecuted in clock cycle
       */
      double getIntOps();
      /** How many floating point operations are excecuted in clock cycle
       */
      double getFloatOps();
      /** How many memory operations are excecuted in clock cycle
       */
      double getMemOps();

      /** Return receive cost (clock cycles) for intra group communication
       */
      unsigned long int getIntraGroupRxCost();
      /** Return send cost (clock cycles) for intra group communication
       */
      unsigned long int getIntraGroupTxCost();
      /** Return receive cost (clock cycles) for inter group communication
       */
      unsigned long int getInterGroupRxCost();
      /** Return send cost (clock cycles) for inter group communication
       */
      unsigned long int getInterGroupTxCost();
      /** Return receive cost (clock cycles) for inter resource communication
       */
      unsigned long int getInterPeRxCost();
      /** Return send cost (clock cycles) for inter resource communication
       */
      unsigned long int getInterPeTxCost();
    
      /** True if PE has task with this in_port
       */
      bool hasInPort(unsigned long int port);

      /** PE receives a token from event
       */
      void receiveEvent(tgToken token);

      /** Returns measurement information
       */
      const sctg::PeMeasurements& getMeasurements();

      /** Return tokens 
       */
      std::queue<tgToken>& getTokenQueue(); 
      
      /** Returns average utilization from the beginning to this point
       */
      double getAvgUtilization();

      /** Updates latency for tokens that are not completely sent
       */
      void updateUnfinishedTokensLatency();

      /** Assigns Task to this PE
       */
      void mapResourceUser(ResourceUser* task);

   private:

      /** Returns next task to be executed
       */
      sctg::Task* schedule();

      /** Returns next task to be executed
       */
      sctg::Task* scheduleFifo();

      /** Returns next task to be executed
       */
      sctg::Task* scheduleFixedPriority();

      /** Returns next task to be executed
       */
      sctg::Task* scheduleSequence();

      

      /** updates measurements
       */
      void updateMeasurements();

      /** TX DMA handler
       */
      void txDma();

      /** RX DMA handler
       */
      void rxDma();

      /** Handles executing cache misses
       */
      unsigned long int cacheMiss(unsigned long int cycles);

      // Performance factors (operations per clock cycle)
      double intOps_;
      double floatOps_;
      double memOps_;    

      // Communication costs, cycles. Template type used to be
      // unsigned long int
      Amount<double>* intraGroupRxCost_;
      Amount<double>* intraGroupTxCost_;
      Amount<double>* interGroupRxCost_;
      Amount<double>* interGroupTxCost_;
      Amount<double>* interPeRxCost_;
      Amount<double>* interPeTxCost_; 

      // Whether DMA is enabled or not
      bool dmaEnabled_;

      // List of tasks on this PE      
      std::queue<Task*> fifoScheduler_;

      // Maps task_id to data token struct
      std::map<unsigned long int, tgToken> sendTokens_;

      sc_core::sc_time  cycleLength_;

//      Configuration& config_;
//      PeMeasurements measurements_;
//      sc_core::sc_time measureStart_;
//      sc_core::sc_time measureEnd_;

      sc_core::sc_event eventEvent_;

      Task* currentTask_;

      enum PeState {IDLE, EXECUTING, SENDING, READING, INTRA_TX_WAIT,
		    TX_WAIT, RX_WAIT, I_CACHE_MISSING, D_CACHE_MISSING};
      PeState currentState_;
    

      std::queue<tgPacket*> txDmaQueue_;
      sc_core::sc_event     txDmaEvent_;

      std::queue<tgPacket*> rxDmaQueue_;
      sc_core::sc_event     rxDmaEvent_;

      std::queue<tgToken>   tokenQueue_;

      std::vector<Task*>    tasks_;

      Amount<double>* iCacheMissInterval_;  // cycles
      Amount<double>* dCacheMissInterval_;  // cycles
      unsigned long int dLineSize_; // bytes
      unsigned long int iLineSize_; // bytes
      unsigned long int iMemId_;
      unsigned long int dMemId_;
      unsigned long int nextIMiss_; // cycles
      unsigned long int nextDMiss_; // cycles
      unsigned long int missReqSize_; // bytes, ES

      enum Scheduler {FIFO, FIXED_PRIORITY, SEQUENCE};
      Scheduler scheduler_;

      bool firstTime_;
      std::map<int, int>::iterator iter_;
      bool running_;
      std::map<int, int> seq_;
   };
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
