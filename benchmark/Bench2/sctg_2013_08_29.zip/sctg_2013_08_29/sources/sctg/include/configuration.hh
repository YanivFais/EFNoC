/**
 *
 * @file configuration.hh
 * @author Lasse Lehtonen
 *
 * ES: Purpose: Central data holder. Stores the application, 
 * ES: mapping, platform structure etc. Others can conveninetly request 
 * ES: information they need, e.g. "which PE executes task foo?"
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: configuration.hh 81 2012-09-12 06:39:00Z ege $
 *
 */


#ifndef SCTG_CONFIGURATION_HH
#define SCTG_CONFIGURATION_HH

#include "noc_conf_if.hh"
#include "non_sc_conf_if.hh"

#include <boost/property_tree/ptree.hpp>
#include <boost/random.hpp>
#include <boost/optional.hpp>
#include <systemc>
#include <string>
#include <vector>
#include <map>
#include <iostream>
#include <fstream>
#include <queue>

namespace sctg
{
   class ResourceUser;
   class Resource;
   class ProcessingElement;
   class Task;
   class Buffer;
   class BufferInterface;

#ifdef SCTG_USE_EXECMON
   class TcpServerIf;
#endif

   /** Keeps hold of connections between everything and measurements
    */
   class Configuration : public NocConfIf
#ifdef SCTG_USE_EXECMON
		       , public NonScConfIf
#endif
   {
   public :
    
      /** Random number generators for real and integer numbers
       */
      typedef boost::lagged_fibonacci19937 RealEngineType; 
      typedef boost::mt19937               IntEngineType;

      /** Constructor
       */
      Configuration(const boost::property_tree::ptree& pt,
		    std::string& saveDir);

      /** Destructor
       */
      ~Configuration();
    

      /** Time handling
       */
      const sc_core::sc_time& getSimLength() const;
      const sc_core::sc_time& getSimResolution() const;
      const sc_core::sc_time& getMeasurementInterval() const;
      const sc_core::sc_time& getMeasurementIntervalUnit() const;


      /** Returns processing element libs filename
       */
      const std::string& getPeLibFile() const;

      /** Random numbers and a unique id
       */
      RealEngineType& getRealRNGEngine();
      IntEngineType& getIntRNGEngine();
      const unsigned long int getSeed() const;
      double random();
      unsigned int getTokenId();

      /** Task connections
       */
      void addPortConnection(unsigned long int source,
			     unsigned long int destination);
      unsigned long int getDestination(unsigned long int source);
      unsigned long int getSource     (unsigned long int dest);


      /** Map resources and theirs users together
	  rid = resource id, tid = task id, pid = port id
       */
      void addResourceMap              (unsigned long int rid, Resource* pe);
      void addResourceUserMap          (unsigned long int tid, ResourceUser* task);
      void addResourceUserToResourceMap(unsigned long int tid, Resource* pe);
      void addResourceUserToInPortMap  (unsigned long int pid, ResourceUser* task);

      /** Get pointers based on ID (res / task / port)
       */
      Resource*     getResource              (unsigned long int rid);
      ResourceUser* getResourceUser          (unsigned long int tid);
      Resource*     getResourceByResourceUser(unsigned long int tid);
      ResourceUser* getResourceUserByInPort  (unsigned long int pid);


      /** Buffers
       */
      void addBufferToResource(Buffer* buffer, unsigned long int pe);
      Buffer* getBufferByResource(unsigned long int pe);
      BufferInterface* getBufferIf(unsigned long int agent);


      /** Grouping and mapping
       */
      void addTaskToGroup(unsigned long int task,
			  unsigned long int group);
      void addGroupToPe(unsigned long int group,
			unsigned long int pe);
      unsigned long int getGroup(unsigned long int task);
      unsigned long int getPeByGroup(unsigned long int group);
      unsigned long int getPeByInport(unsigned long int pid); //ES


      /** Noc
       */
      void setNocClass(std::string& s);
      void setNocType(std::string& s);
      void setNocSubType(std::string& s);
      const std::string& getNocClass();
      const std::string& getNocType();
      const std::string& getNocSubType();
      /** Returns a reference to a property tree rooting to <noc> tag
       */
      const std::map<std::string, int>& getGenerics();



      /** Get resource/group/task maps' begin and end
       */
      std::map<unsigned long int, Resource*>::iterator getResourceBegin();
      std::map<unsigned long int, Resource*>::iterator getResourceEnd();
      std::map<unsigned long int, unsigned long int>::iterator getGroupPeBegin();
      std::map<unsigned long int, unsigned long int>::iterator getGroupPeEnd();
      std::map<unsigned long int, unsigned long int>::iterator getTaskGroupBegin();
      std::map<unsigned long int, unsigned long int>::iterator getTaskGroupEnd();

      /** Set/request whether Execution Monitor is used or not
       */
      void useExecMon(bool use);
      bool useExecMon();

#ifdef SCTG_USE_EXECMON
      /** Set a pointer to TCP server
       */
      void setTcpServer(TcpServerIf* server);

      /** Return pointer to TCP server
       */
      TcpServerIf* getTcpServer();
#endif



      /** Returns ostreams for logging
       */
      boost::optional<std::ostream*>& getPacketStream();
      boost::optional<std::ostream*>& getTokenStream();
      boost::optional<std::ostream*>& getAppStream();
      boost::optional<std::ostream*>& getPeStream();
      boost::optional<std::ostream*>& getMemStream();
      boost::optional<std::ostream*>& getSummaryStream();
      boost::optional<std::ostream*>& getExecMonStream();
      

      /** Return all cost functions and variables
       */
      std::vector<std::string>& getCostFunctions();
      std::map<std::string, double>& getCostVariables();

      /** Tokens
       */
      void addTokenLatency(unsigned long int src,
			   unsigned long int dst,
			   sc_core::sc_time& latency);
      std::map<unsigned long int, std::map<unsigned long int, sc_core::sc_time> >&
      getTokenLatency();
      std::map<unsigned long int, std::map<unsigned long int, sc_core::sc_time> >&
      getTokenLatencyMax();
      std::map<unsigned long int, std::map<unsigned long int, sc_core::sc_time> >&
      getTokenLatencyMin();
      std::map<unsigned long int, std::map<unsigned long int, unsigned long int> >&
      getTokenCount();

      /** Paths
       */
      std::map<std::string, sc_core::sc_time>&  getTotPathLat();
      std::map<std::string, sc_core::sc_time>&  getMaxPathLat();
      std::map<std::string, sc_core::sc_time>&  getMinPathLat();
      std::map<std::string, unsigned long int>& getPathCount();

      /** Sets send and receive time to port
       */
      void addSendTime(unsigned long int port);
      void addReceiveTime(unsigned long int port);


      /** Set how many times task has triggered
       */
      void taskTriggered(unsigned long int task, unsigned long int times);

      /** Set scheduling sequence number for PEs
       */
      void setScheduleSeq(int pe, int task, int seq);

      /** Get scheduling sequence for PEs
	  Returns empty if sequence scheduling is not used
      */
      const std::map<int, int>& getScheduleSeq(int pe);

      /** Set task's priority
       */
      void setFixedPriority(int pe, int task, int seq);


      /** Get task priorities
       */
      const std::map<int, int>& getFixedPriority(int pe);



      
   private:

      /** Creates sc_time_unit from string
       */
      const sc_core::sc_time_unit parseUnit(std::string unit);

      sc_core::sc_time         simResolution_;
      sc_core::sc_time         simLength_;    
      sc_core::sc_time         measurementInterval_;
      sc_core::sc_time         measurementIntervalUnit_;

      // Static PE properties
      std::string              peLibFile_;

      // RNG engines 
      RealEngineType          realEngine_;
      IntEngineType           intEngine_;
      unsigned long int       seed_;
      boost::uniform_real<double>  random_;
      unsigned int            nextTokenId_;

      bool useExecMon_;
      bool auto_stop_;


      // Main data strcutures. 
      // These map a) two id numbers together, or b) id to a pointer
      std::map<unsigned long int, unsigned long int> portConnections_;
      std::map<unsigned long int, unsigned long int> revPortConnections_;
      std::map<unsigned long int, Resource*>         resourceMap_;
      std::map<unsigned long int, Resource*>         resourceResourceUserMap_;
      std::map<unsigned long int, ResourceUser*>     resourceUserMap_;
      std::map<unsigned long int, ResourceUser*>     resourceUserInPortMap_;
      std::map<unsigned long int, Buffer*>           resourceBufferMap_;
      std::map<unsigned long int, unsigned long int> taskGroupMap_;
      std::map<unsigned long int, unsigned long int> groupPeMap_;

      // Network-on-chip
      std::string nocClass_;
      std::string nocType_;
      std::string nocSubType_;
      std::map<std::string, int> generics_;



      // Write various logs to these files
      boost::optional<std::ostream*> pktOutFile_;
      boost::optional<std::ostream*> tokenOutFile_;
      boost::optional<std::ostream*> peOutFile_;
      boost::optional<std::ostream*> memOutFile_;
      boost::optional<std::ostream*> appOutFile_;
      boost::optional<std::ostream*> summaryOutFile_;
      boost::optional<std::ostream*> execMonOutFile_;



      // Measurements
      std::vector<std::string>      costFunctions_;
      std::map<std::string, double> costVariables_;

      std::map<unsigned long int, std::map<unsigned long int, sc_core::sc_time> >
      tokenLatency_;
      std::map<unsigned long int, std::map<unsigned long int, sc_core::sc_time> >
      tokenLatencyMax_;
      std::map<unsigned long int, std::map<unsigned long int, sc_core::sc_time> >
      tokenLatencyMin_;
      std::map<unsigned long int, std::map<unsigned long int, unsigned long int> >
      tokenCount_;

      std::multimap<unsigned long int, unsigned long int> pathsFwd_;
      // Above:       source port,      destination port
      std::multimap<unsigned long int, unsigned long int> pathsRev_;
      // Above:      destination port,     source port

      // Below: string "src_dst", ...
      std::map<std::string, std::queue<sc_core::sc_time> > portSendTime_;

      std::map<std::string, sc_core::sc_time>  totPathLat_;
      std::map<std::string, sc_core::sc_time>  maxPathLat_;
      std::map<std::string, sc_core::sc_time>  minPathLat_;
      std::map<std::string, unsigned long int> pathCount_;

      std::multimap<unsigned long int, unsigned long int> taskTriggerTimes_;

      std::map<int, std::map<int, int> > scheduleSeqs_;
      std::map<int, std::map<int, int> > fixedPriority_;



#ifdef SCTG_USE_EXECMON
      TcpServerIf* serverIf_;
#endif

   };
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
