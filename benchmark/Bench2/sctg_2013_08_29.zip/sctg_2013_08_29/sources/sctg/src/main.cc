/**
 *
 * @file main.cc
 * @author Lasse Lehtonen
 *
 * Purpose: Transaction Generator (TG) models a multiprocessor SoC. 
 *          System and workload are described in an XML file. 
 *          This is a command line tool but there is option to 
 *          use visualization program called ExecutioMonitor.
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: main.cc 87 2012-09-21 05:48:04Z ege $
 *
 */


#include "amount.hh"
#include "common.hh"
#include "event.hh"
#include "configuration.hh"
#include "resource.hh"
#include "processing_element.hh"
#include "task.hh"
#include "mem_area.hh"
#include "trigger.hh"
#include "measure.hh"
#include "noc_factory.hh"
#include "memory_model.hh"
#include "cost_function.hh"
#include "parse_stp.hh"
#include "parse_rtp.hh"

// TCP connection to Execution Monitor requires that Boost.Asio is
// compiled in your system, and g++ flag SCTG_USE_EXECMON tells that
// it is. Moreover, some parts, like Asio and program options, cannot
// be used in Modelsim. Hence, there are several Ifdef/ifndef in this
// file. Variable MTI_SYSTEMC (as in Model Technology Inc.) is set
// automatically by compiler

#ifndef MTI_SYSTEMC
#include <boost/program_options.hpp>
#ifdef SCTG_USE_EXECMON
#include "non_sc_factory.hh"
#include "tcp_server.hh"
#include <boost/asio.hpp>
#endif
#endif

#include <cstdlib>
#include <iostream>
#include <string>
#include <set>   
#include <exception>
#include <ctime> 
#include <vector>
#include <map> 

#include <boost/foreach.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/random.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <systemc> 


enum FileType {XML, STP, RTP, UNKNOWN};


// Small supporting functions
FileType checkFileType(std::string);

void analyzeModel (sctg::Configuration*                   cfg,
		 std::vector<sctg::ProcessingElement*>* pes,
		 std::vector<sctg::Task*>*              tasks,
		 std::vector<sctg::Event*>*             events,
		 std::vector<sctg::MemoryModel*>*       mems,
		 std::vector<sctg::MemArea*>*           memAreas,
		 boost::property_tree::ptree*           tgModel

   ); 

int replay(std::string playbackFile, int playbackDelay);
std::string configExecMon (sctg::Configuration*                  cfg,
			   std::vector<sctg::MemArea*>           memAreas
   );


void calculateCost (sctg::Configuration* cfg, sctg::CostFunction* costF,
		    std::vector<sctg::ProcessingElement*>* pes,
		    std::vector<sctg::Task*>*              tasks,
		    std::vector<sctg::Event*>*             events
   ); 

void printCost (sctg::Configuration* cfg, sctg::CostFunction* costF);

void printDot (sctg::Configuration* cfg,  std::string srcFile,
	       std::vector<sctg::Task*>* tasks,
	       std::vector<sctg::Event*>* events);



/** Main function: reads input, starts simulation, and reports results
 */
int sc_main(int argc, char* argv[])
{ 
   // Main data structures
   sctg::Configuration*                  conf = 0;
   sctg::CostFunction                    costFunctionParser;
   sctg::Measure*                        measurements = 0;
   NocFactory*                           nocFactory = 0;
   std::vector<sctg::ProcessingElement*> pes;
   std::vector<sctg::MemoryModel*>       mems;
   std::vector<sctg::Task*>              tasks;
   std::vector<sctg::MemArea*>           memAreas;
   std::vector<sctg::Event*>             events;      

#ifdef SCTG_USE_EXECMON
#ifndef MTI_SYSTEMC
   sctg::NonScFactory* nonScFactory = 0; // tcp server for Execmon, does not work in Modelsim
#endif
#endif      

   // File and directory names
   std::string inputFile;      // xml, rtp, stp
   std::string constraintFile; // xml
   std::string outputFile;     // xml
   std::string playbackFile;   // log
   std::string saveDir;
   
   // Temp data structures for parsinfg the inputs
   using boost::property_tree::ptree;
   ptree tgModel;
   ptree tgConstraints;
   ptree peLib;
   enum ProgramMode {NORMAL, PLAYBACK, MIXEDSIM};
   ProgramMode programMode    = NORMAL;
   FileType    fileType       = UNKNOWN;
   unsigned int playbackDelay = 0;       // milliseconds
   bool useExecutionMonitor   = false;
  
   try
   {
      std::cout << std::endl
		<< "\tTransaction Generator" << std::endl << std::endl;

      // There are 2 main phases and few sub-phases

      // 1. Handle command line parameters 
      //    a) with Boost, b) simpler version for Modelsim

      // 2. Execute phase 
      // 2.a) Playback a log file in ExecMon
      // 2.b) Run simulation 
      // 2.b.1) Read and validate XML, and optionally connect to ExecMon 
      // 2.b.2) Run simulation
      // 2.b.3) Report statistics and delete dynamically reserved memory


#ifndef MTI_SYSTEMC
      // Regular SystemC environment
      // -----------
      //  Phase 1.a) Command line option parser using Boost.ProgramOptions
      // -----------
      

      namespace po = boost::program_options;
      po::options_description poDesc("Allowed options");
      poDesc.add_options()
	 ("help,h", "This message")
	 ("input-file,i", po::value<std::string>(), 
	  "Traffic model (.xml, .rtp, .stp)")
	 ("constraint-file,c", po::value<std::string>(), 
	  "Contraints for .rtp and .stp simulations")
	 ("output-file,o", po::value<std::string>(),
	  "Save xml generated from MCSL traces")
	 ("save-directory,s", po::value<std::string>(), 
	  "Directory to save logs")
	 ("execution-monitor,e", "Use Execution Monitor")
	 ("replay-file,r", po::value<std::string>(), 
	  "Recorded log file to replay with Execution Monitor")
	 ("delay,d", po::value<unsigned int>(), 
	  "Delay (ms) to slow down replay");
      
      po::variables_map poVm;
      po::store(po::parse_command_line(argc, argv, poDesc), poVm);
      po::notify(poVm);
      
      if(poVm.count("help"))
      {
	 std::cout << poDesc << std::endl;
	 return EXIT_SUCCESS;
      }

      if(poVm.count("input-file"))
      {
	 std::cout << "input-file:             " 
		   << poVm["input-file"].as<std::string>()
		   << std::endl;
	 inputFile = poVm["input-file"].as<std::string>();
	 programMode = NORMAL;

	 if(poVm.count("execution-monitor"))
	 {
#ifndef SCTG_USE_EXECMON
	    std::cerr << "You need to compile Transaction Generator 2 "
		      << "with SCTG_USE_EXECMON flag to use Execution Monitor"
		      << std::endl;
	    return EXIT_FAILURE;
#endif	    
	    useExecutionMonitor = true;
	 }

	 fileType = checkFileType(inputFile);

	 if(poVm.count("constraint-file"))
	 {
	    constraintFile = poVm["constraint-file"].as<std::string>();
	    if(poVm.count("output-file"))
	    {
	       outputFile = poVm["output-file"].as<std::string>();
	    }
	 }
	 else if(fileType != XML)
	 {
	    std::cerr << "You need to define a constraint file for "
		      << "STP and RTP file types"
		      << std::endl;
	    return EXIT_FAILURE;
	 }
      }      
      else if(poVm.count("replay-file"))
      {
#ifndef SCTG_USE_EXECMON
	 std::cerr << "You need to compile Transaction Generator 2 "
		   << "with SCTG_USE_EXECMON flag to use Execution Monitor"
		   << std::endl;
	 return EXIT_FAILURE;
#endif
	 std::cout << "replay-file:           "
		   << poVm["replay-file"].as<std::string>()
		   << std::endl;
	 playbackFile = poVm["replay-file"].as<std::string>();
	 programMode = PLAYBACK;
      }
      else
      {
	 // Neither input file or replay file defined -> exit
	 std::cout << poDesc << std::endl;
	 return EXIT_FAILURE;
      }
      
      if(poVm.count("delay"))
      {
	 std::cout << "Delay for replay:       "
		   << poVm["delay"].as<unsigned int>()
		   << " ms"
		   << std::endl;
	 playbackDelay = poVm["delay"].as<unsigned int>();
      }
      else
      {
	 std::cout << "Delay for playback:     1ms" << std::endl;
	 playbackDelay = 1;
      }

      if(poVm.count("save-directory"))
      {
	 std::cout << "Directory to save logs: "
		   << poVm["save-directory"].as<std::string>()
		   << std::endl;
	 saveDir = poVm["save-directory"].as<std::string>();
      }
      else
      {
	 std::cout << "Directory to save logs: ." << std::endl;
      }

      std::cout << std::endl;

#else 
      // Modelsim's SystemC environment
      // -----------
      // Phase 1b). Simplified command line parser for Simulation with Modelsim
      // -----------

      if(argc == 2)
      {
	 inputFile.assign(argv[1]);
	 fileType = checkFileType(inputFile);
	 useExecutionMonitor = true; // added 2013-02-22, ES
      }
      else 
      {
	 std::cout << std::endl
		   << "Input file not set" << std::endl
		   << std::endl
		   << "Usage:  vsim -sc_arg <input-file> ..." << std::endl 
		   << std::endl;
	 return EXIT_FAILURE;
      }

      programMode = MIXEDSIM;

#endif      




      // ----------
      // Phase 2a) Visualize previous simulation with ExecutionMonitor 
      // and exit
      // ----------

      if(programMode == PLAYBACK)
      {
	 int lines = replay(playbackFile, playbackDelay);
	 std::cout << "TG sent " << lines << " lines to ExecMon" << std::endl;
	 return EXIT_SUCCESS;
      }


      //-------------
      // Phase 2.b.1) Read in the XML, RTP or STP file 
      //   It defines application and platform model, mapping
      //   constraints etc and store it to a property_tree      
      //-------------

      boost::property_tree::xml_writer_settings<char> w('\t', 1);
      int stp_iterations;
      switch(fileType)
      {
	 case XML:
	    // std::cout << "Start XML parsing"; //ES 
	    read_xml(inputFile, tgModel, 
		     boost::property_tree::xml_parser::trim_whitespace);

	    std::cout << "XML parsing completed" << std::endl; //ES
	    break;

	 case STP:
	    read_xml(constraintFile, tgConstraints,
		     boost::property_tree::xml_parser::trim_whitespace);
	    stp_iterations = tgConstraints.get<int>
	       ("stp_iterations.<xmlattr>.value", 1);
	    tgModel = sctg::parse_stp(inputFile, stp_iterations);	   
	    tgModel.add_child("system.constraints", tgConstraints);
	    if(outputFile.length() != 0) 
	    {
	       write_xml(outputFile.c_str(), tgModel, std::locale(), w);
	       std::cout << "File saved: " << outputFile << std::endl;
	       return EXIT_SUCCESS;
	    }
	    break;

	 case RTP:
	    read_xml(constraintFile, tgConstraints,
		     boost::property_tree::xml_parser::trim_whitespace);
	    tgModel = sctg::parse_rtp(inputFile);
	    tgModel.add_child("system.constraints", tgConstraints);
	    if(outputFile.length() != 0) 
	    {
	       write_xml(outputFile.c_str(), tgModel, std::locale(), w);
	       std::cout << "File saved: " << outputFile << std::endl;
	       return EXIT_SUCCESS;
	    }	    
	    break;

	 default:
	    std::cout << "Unrecognized file: \"" << inputFile << "\"" 
		      << std::endl;
	    return EXIT_FAILURE;
	    break;
      }
      

      
      // Analyze the system settings and store necessary data into Configuration object
      ptree node = tgModel.get_child("system");      
      conf = new sctg::Configuration(node, saveDir);
      conf->useExecMon(useExecutionMonitor);

      // Analyze the model and instantiate necessary pes, memories and events. 
      // All info goes to Configuration to allow easy access later.
      analyzeModel (conf,
		  &pes, 
		  &tasks, 
		  &events, 
		  &mems, 
		  &memAreas, 
		  &tgModel);
      if(conf->getSummaryStream())
      {	 
	 // Write the input file names into log
	 **(conf->getSummaryStream()) << "Input file   " << inputFile
				      << std::endl; 
	 if (!constraintFile.empty()) {
	    **(conf->getSummaryStream()) << "Constaint file   " << constraintFile
					 << std::endl; 
	 }
	 **(conf->getSummaryStream()) << "Sim length   " << conf->getSimLength() 
				      << std::endl; 

	 **(conf->getSummaryStream()) << "NoC          " << conf->getNocClass()
				      << ", "            << conf->getNocType()
				      << ", "            << conf->getNocSubType()
				      << std::endl << std::endl; 
      }   

      // Create a figure from task graph. 
      // Then user must run graphviz from cmd line: dot -Tpng kuva.dot -o kuva.png
      printDot (conf, inputFile, &tasks, &events);

   
      // Create NoC (which starts 1 or more threads)
      nocFactory = new NocFactory(conf);


      // Create measurement thread
      measurements = new sctg::Measure("measurer", *conf, pes, tasks, mems, 
				       memAreas);



      // Create configuration XML for ExecutionMonitor which can
      // visualize the results
      std::string cfgXml = configExecMon(conf, memAreas);

      if(conf->useExecMon())
      {

#ifdef SCTG_USE_EXECMON
#ifndef MTI_SYSTEMC
	 // These do not work in Modelsim
	 // Create TCPserver (via NonScFactory) and connect to ExecMon. 
	 nonScFactory = new sctg::NonScFactory(*conf);

	 std::cout << "Waiting for Execution Monitor to connect" << std::endl;
	 conf->getTcpServer()->waitConnection();
	 std::cout << "Execution Monitor connected" << std::endl;
	 conf->getTcpServer()->send(cfgXml);
#endif
#endif // USE_EXECMON     
      }



      
      // ------------
      // Phase 2.b.2) RUN THE SIMULATION
      // ------------
      std::cout << "Starting simulation with seed " 
		<< conf->getSeed() << std::endl;

#ifdef MTI_SYSTEMC
      sc_core::sc_start();
#else
      std::cout << "Sim length " << conf->getSimLength() << std::endl;
      sc_core::sc_start(conf->getSimLength());
      sc_core::sc_start(sc_core::SC_ZERO_TIME);
#endif


      std::cout << "Simulation ends at " 
		<< sc_core::sc_time_stamp() << std::endl << std::endl;
      



      // ------------
      // Phase 2.b.3) Report statistics
      // ------------
      calculateCost (conf, &costFunctionParser, &pes, &tasks, &events);
      printCost     (conf, &costFunctionParser);
   
   }
   catch(std::exception& e)
   {
      std::cerr << "EXCEPTION: "
		<< e.what() << std::endl;
   }
   catch(...)
   {
      std::cerr << "EXCEPTION: unknown source (not std::exception)."
		<< std::endl;
   }
   



  
   // CLEAN UP: 
   // Destroy all processing elements, tasks, events, NoC, and measurements
   // They will print statistics in their destructors.
   if(conf->getSummaryStream())
   {
      if (sc_core::sc_time_stamp()
	  != conf->getSimLength() ) {
	 **(conf->getSummaryStream()) 
	    << "Simulation stopped  at " << sc_core::sc_time_stamp()
	    << "!" << std::endl;
      }

      
      **(conf->getSummaryStream()) << std::endl
				   << "-- Processing elements and memories -- " 
				   << std::endl << std::endl;
	 
   }
  
   for(unsigned int i = 0; i < pes.size(); ++i)
   {
      delete pes.at(i); 
      pes.at(i) = 0;
   }
   for(unsigned int i = 0; i < mems.size(); ++i)
   {
      delete mems.at(i);
      mems.at(i) = 0;
   }

   if(conf->getSummaryStream())
   {
      **(conf->getSummaryStream()) 
	 << std::endl
	 << "-- Tasks and timer events -- " << std::endl
	 << "   Type;            Name;  Id; #Completed; Exec cycles; Tx token bytes;     Read bytes;"
	 << std::endl; 
	 
   }
   for(unsigned int i = 0; i < events.size(); ++i)
   {
      delete events.at(i);
      events.at(i) = 0;
   }  
   for(unsigned int i = 0; i < tasks.size(); ++i)
   {
      delete tasks.at(i);
      tasks.at(i) = 0;
   }
   
   delete nocFactory;   nocFactory   = 0;
   delete measurements; measurements = 0;


#ifdef SCTG_USE_EXECMON
#ifndef MTI_SYSTEMC
   // Destroy the tcp server
   if(nonScFactory) {delete nonScFactory; nonScFactory = 0;}
#endif
#endif
   

   // Destroy configuration
   delete conf; conf = 0;



   return EXIT_SUCCESS;


} // main(...)












/**
 *
 * Determines the filetype by checking the last four  characters,
 *  e.g. ".xml"
 */
FileType checkFileType(std::string s)
{
   if(s.length() >= 5)
   {
      // Check the file type from the last 4 chars
      std::string ending(s.substr(s.length()-4, 4));
      if(ending == ".xml")
      {
	 return XML;
      } 
      else if(ending == ".rtp") 
      {
	 return RTP;
      }
      else if(ending == ".stp")
      {
	 return STP;
      }
      else
      {
	 return UNKNOWN;
      }	 
   }
   else
   {
      return UNKNOWN;
   }
}



/**
 * Analyzes the TgModel and stores necessary information into Configuration object. 
 * Moreover, there are separate lists for pes, tasks, events, memories and memory areas.
 * New objects will be created into them. 
 * This is a huge function
 */ 

void analyzeModel (sctg::Configuration* cfg,
		 std::vector<sctg::ProcessingElement*>* pes,
		 std::vector<sctg::Task*>*              tasks,
		 std::vector<sctg::Event*>*             events,
		 std::vector<sctg::MemoryModel*>*       mems,
		 std::vector<sctg::MemArea*>*           memAreas,
		 boost::property_tree::ptree*           tgModel
   )
{
   using boost::property_tree::ptree;
   
      ptree peLib;
      
      std::cout << "Start XML analysis" << std::endl; //ES 

      // Read in processing element library
      read_xml(tgModel->get<std::string>
	       ("system.constraints.pe_lib.<xmlattr>.file"), peLib);
      

      //std::cout << " m a) PE lib XML parsed" << std::endl; //ES 

      // Parse platform -> resource_list
      // ptree node = tgModel->get_child("system.platform.resource_list"); // orig

      // This should work even if resource_list is omitted, as
      // resources are directly underneath the platform
      ptree node = tgModel->get_child("system.platform");
      if (node.begin()->first == "resource_list")
      {
	 std::cout << "Note: obsolete tag <resource_list> is skipped" << std::endl;
	 node = node.begin()->second;
      }

      
      for(ptree::const_iterator iter = node.begin(); iter != node.end(); 
	  ++iter)
      {
	 // Confirm this is a resource tag
	 if((*iter).first == "resource")
	 {

	    unsigned long int rid = 0;

	    // Read and check resource id
	    rid = sctg::convToInt (iter, "<xmlattr>.id");

	    // Check that its class: pe or memory. Assume "pe" if not defined
	    std::string resourceClass = (*iter).second.get<std::string>
	       ("<xmlattr>.class", "pe");
	    // Read name or give a default name of "<class> <rid>"
	    std::string name = (*iter).second.get<std::string>
	       ("<xmlattr>.name", resourceClass + " " + 
		boost::lexical_cast<std::string>(rid));	      

	    if(resourceClass == "pe")
	    {
	       // Create new PE (which is a thread)
	       sctg::ProcessingElement* pe = new 
		  sctg::ProcessingElement(name.c_str(), 
					  (*iter).second, peLib, *cfg);
	       cfg->addResourceMap(pe->getId(), pe);
	       pes->push_back(pe);
	    }
	    else if(resourceClass == "memory")
	    {
	       // Create new memory (which is a thread)
	       sctg::MemoryModel* me = new
		  sctg::MemoryModel(name.c_str(), (*iter).second, *cfg);
	       cfg->addResourceMap(me->getId(), me);
	       mems->push_back(me);
	    }
	    else
	    {
	       std::string err = "Unknown resource class " + resourceClass;
	       throw std::runtime_error(err.c_str());
	    }
	 }
      }
      //std::cout << " m b) PEs' XML parsed" << std::endl; //ES 



      // Parse Tasks and task connections
      node = tgModel->get_child("system.application.task_graph");
      for(ptree::const_iterator iter = node.begin(); iter != node.end(); 
	  ++iter)
      {
// 	 std::cout << " m c) app next task " 
// 		   << (*iter).first
// 		   << node.size() << " , "
// 		   << (*iter).first.size()  << " , "
// 		   << (*iter).second.size()  
// 		   << std::endl; //ES 

	 if((*iter).first == "task")
	 {
	    // std::cout << " m c) app: new task "<< std::endl; //ES 
	    sctg::Task* task = new sctg::Task((*iter).second, *cfg);
	    cfg->addResourceUserMap(task->getId(), task);
	    tasks->push_back(task);
	    // std::cout << " m c) task "<< task ->getName() << " created" << std::endl; //ES 
	 }
	 else if((*iter).first == "mem_area")
	 {
	    // std::cout << " m c) app: new mem_area " << std::endl; //ES 
	    sctg::MemArea* memArea = new sctg::MemArea((*iter).second, *cfg);
	    cfg->addResourceUserMap(memArea->getId(), memArea);
	    memAreas->push_back(memArea);
	 }
	 else if((*iter).first == "port_connection")
	 {
	    // std::cout << " m c) app: new connection " << std::endl; //ES 
	    unsigned long int src =  sctg::convToInt (iter, "<xmlattr>.src");
	    unsigned long int dst =  sctg::convToInt (iter, "<xmlattr>.dst");

	    cfg->addPortConnection(src, dst);
	 }
	 //std::cout << " m c) app task end " << std::endl  << std::endl; //ES 

      }

      // std::cout << " m c) App tasks parsed, connections next" << std::endl; //ES 


      // Connections between task graphs
      node = tgModel->get_child("system.application");
      for(ptree::const_iterator iter = node.begin(); iter != node.end(); 
	  ++iter)
      {
	 if((*iter).first == "port_connection")
	 {
	    unsigned long int src =  sctg::convToInt (iter, "<xmlattr>.src");
	    unsigned long int dst =  sctg::convToInt (iter, "<xmlattr>.dst");
	    cfg->addPortConnection(src, dst);
	 }
      }

      std::cout << std::endl;
      //std::cout << " m c) App XML parsed" << std::endl; //ES 


      // Parse events
      node = tgModel->get_child("system.application.task_graph.event_list");
      for(ptree::const_iterator iter = node.begin(); iter != node.end(); 
	  ++iter)
      {
	 if((*iter).first == "event")
	 {
	    // Read in ID
	    unsigned long int eid =  sctg::convToInt (iter, "<xmlattr>.id");

	    // Read name or give a default name of "Event <eid>"
	    std::string name = (*iter).second.get<std::string>
	       ("<xmlattr>.name", "Event " + 
		boost::lexical_cast<std::string>(eid));	      
	    // Create new event (which is a thread)
	    sctg::Event* event = new sctg::Event(name.c_str(),
						 *cfg,
						 (*iter).second);	    
	    events->push_back(event);
	 }
      }


      // Map tasks to PEs and mem_areas to memories
      node = tgModel->get_child("system.mapping");
      for(ptree::const_iterator iter = node.begin(); iter != node.end(); 
	  ++iter)
      {
	 if((*iter).first == "resource")
	 {
	    unsigned long int resourceId = sctg::convToInt (iter, "<xmlattr>.id");


	    // See if an obsolete sw_platform tag has been defined. If
	    // yes, search for groups under it, otherwise search them
	    // under "resource", i.e. default parameter (*iter).second
	    if ((*iter).second.count("sw_platform"))
	    {
	       std::cout << "Note: obsolete tag <sw_platform> is skipped" 
			 << std::endl;
	    }

	    ptree groupNode = 
	       (*iter).second.get_child("sw_platform", (*iter).second);



	    // Loop through all groups and then through all tasks
	    for(ptree::const_iterator iter2 = groupNode.begin();
		iter2 != groupNode.end(); ++iter2)
	    {

	       if((*iter2).first == "group")
	       {
		  unsigned long int groupId = sctg::convToInt (iter2, "<xmlattr>.id");

		  for(ptree::const_iterator iter3 = (*iter2).second.begin();
		      iter3 != (*iter2).second.end(); ++iter3)
		  {		     
		     if((*iter3).first == "task")
		     {
			unsigned long int taskId = sctg::convToInt (iter3, "<xmlattr>.id");
			cfg->getResource
			   (resourceId)->mapResourceUser
			   (cfg->getResourceUser(taskId));
			cfg->addResourceUserToResourceMap
			   (taskId, cfg->getResource(resourceId));
			cfg->addTaskToGroup(taskId, groupId);
			cfg->addGroupToPe(groupId, resourceId);

			// Check for scheduling styles
			boost::optional<std::string> seq =
			   (*iter3).second.get_optional<std::string>
			   ("<xmlattr>.schedule_seq");
			boost::optional<int> fixed_priority =
			   (*iter3).second.get_optional<int>
			   ("<xmlattr>.fixed_priority");
			if(seq)
			{
			   std::istringstream iss(*seq);
			   int ss;
			   char cc;
			   iss >> ss;
			   cfg->setScheduleSeq(resourceId, taskId, ss);
			   while(!iss.eof())
			   {
			      iss >> cc >> ss;
			      cfg->setScheduleSeq(resourceId, taskId, ss);
			   }
			}
			if(fixed_priority)
			{
			   cfg->setFixedPriority(resourceId, taskId, 
						 *fixed_priority);
			}
		     }
		  }
	       }
	       else if((*iter2).first == "mem_area")
	       {
		  // MemArea is mapped like a task
		  unsigned long int tid = sctg::convToInt (iter2, "<xmlattr>.id");

		  cfg->getResource(resourceId)->mapResourceUser
		     (cfg->getResourceUser(tid));
		  cfg->addResourceUserToResourceMap
		     (tid, cfg->getResource(resourceId));
	       }
	    }
	 }
      }   

      // Map events to resources
      for(unsigned int i = 0; i < events->size(); ++i)
      {
	 for(unsigned int j = 0; j < pes->size(); ++j)
	 {	      
	    if(pes->at(j)->hasInPort
	       (cfg->getDestination(events->at(i)->getOutPort())))
	    {	
	       events->at(i)->mapPe(pes->at(j));
	    }
	 }
      }


      std::cout << std::endl;

      // Noc information
      std::string nocClass;
      std::string nocType;
      std::string nocSubType;
      node = tgModel->get_child("system.constraints.noc");	 
      nocClass   = node.get<std::string>("<xmlattr>.class", "UNKNOWN");
      nocType    = node.get<std::string>("<xmlattr>.type", "UNKNOWN");
      nocSubType = node.get<std::string>("<xmlattr>.subtype", "UNKNOWN");

      cfg->setNocClass(nocClass);
      cfg->setNocType(nocType);
      cfg->setNocSubType(nocSubType);       

      //std::cout << " m d) All XML parsed" << std::endl; //ES 


      // Basic validation for xml model. Methods of cfg will throw exception 
      // if something goes wrong
      
      for(std::vector<sctg::Task*>::iterator iter = tasks->begin();
	  iter != tasks->end(); ++iter)
      {
	 std::vector<unsigned long int> outs = (*iter)->getOutPorts();
	 for(int i = 0; i < outs.size(); ++i)
	 {
	    unsigned long int oport = outs.at(i);
	    unsigned long int iport = cfg->getDestination(oport);
	    sctg::Task* target = dynamic_cast<sctg::Task*>
	       (cfg->getResourceUserByInPort(iport));
	 }
	 std::vector<unsigned long int> ins = (*iter)->getInPorts();
	 for(int i = 0; i < ins.size(); ++i)
	 {
	    unsigned long int iport = ins.at(i);
	    unsigned long int oport = cfg->getSource(iport);
	 }
      }


} // analyzeModel(...)


// Reads log file and sends it to ExecutionMonitor via TCP socket.
// Replay does nothing in Modelsim because TCP connection cannot be made.
int replay(std::string playbackFile, int playbackDelay) {
   
   std::cout << "Replay mode" << std::endl;
   std::cout << "Note! ExecMon assumes DOS-like newlines. Run:" << std::endl
	     << "      unix2dos " << playbackFile.c_str() << std::endl;
   int n_lines =0;

#ifdef SCTG_USE_EXECMON
#ifndef MTI_SYSTEMC
   
   // Establish connection
   sctg::TcpServer server(9990);   
   std::cout << "Waiting for Execution Monitor to connect" << std::endl;
   server.waitConnection();
   std::cout << "Execution Monitor connected" << std::endl;
   

   // Read the log and send it
   std::ifstream inFile(playbackFile.c_str());
   std::string line;
   boost::asio::io_service io;
   boost::asio::deadline_timer 
      delay(io, boost::posix_time::milliseconds(playbackDelay));   
  
   while(std::getline(inFile, line))
   {
      server.send(line);
      delay.wait();
      delay.expires_at(delay.expires_at() + 
		       boost::posix_time::milliseconds(playbackDelay));
      n_lines++;
   }
   
   std::cout << "Done" << std::endl;

#endif
#endif

   return n_lines;


}



// Collects the static information about cpus, threads, processes and
// services (to be sent to ExecMon via TCP socket)
std::string configExecMon(sctg::Configuration*        cfg,
			  std::vector<sctg::MemArea*> memAreas
   ){
   std::cout << " <configure> the ExecMon" << std::endl;

   // Config is an xml string (actually just 1 line): 
   // <configuration>
   //    <cpu><thread><process/>...</thread></cpu> 
   //    <cpu>...
   //    <services>
   //        <service><process/>...</service>
   //        <service>...
   //        <connection/><connection/>...
   //    </services>
   // <configuration>

   std::string str;              // Combines all of configuration information   
   std::ostringstream oss;       // Main config, incl. cpus, threads and processes
   std::ostringstream oss2;      // Services and their processes
   std::ostringstream oss3;      // Service connections
   oss.str("");
   oss << "<configuration>";
   
   oss2.str("");
   oss2 << "<services>";
   oss3.str("");

   for(std::map<unsigned long int, sctg::Resource*>::iterator cpuIter = 
		cfg->getResourceBegin(); 
       cpuIter != cfg->getResourceEnd(); 
       ++cpuIter)
   {

      // Cpus (memories look like cpus in execmon also)
      std::string cpuName = (*cpuIter).second->getName();
      unsigned long int cpuId = (*cpuIter).first;
      oss << "<cpu name=\"" << cpuName
	  << "\" id=\"" << cpuId << "\">";


      // Threads, processes, services
      for(std::map<unsigned long int, unsigned long int>::iterator groupIter = 
	     cfg->getGroupPeBegin(); 
	  groupIter != cfg->getGroupPeEnd();
	  ++groupIter)
      {
	 unsigned long int group = (*groupIter).first;
	 unsigned long int pe    = (*groupIter).second;
	 
	 if(cpuId == pe)
	 {
	    oss << "<thread name=\"Thread_" << group << "\" id=\"" 
		<< group << "\" " << "priority=\"0\">";
	    for(std::map<unsigned long int, unsigned long int>::iterator
		   taskIter = cfg->getTaskGroupBegin(); 
		taskIter != cfg->getTaskGroupEnd(); ++taskIter)
	    {
	       unsigned long int task = (*taskIter).first;
	       unsigned long int gr   = (*taskIter).second;
	       if(group == gr)
	       {
		  oss << "<process name=\"" 
		      << cfg->getResourceUser(task)->getName()
		      << "\" id=\"" << task << "\"/>";
		  
		  
		  
		  // Create also one service per process, with identical id and name.
		  oss2 << "<service name=\"" 
		       << cfg->getResourceUser(task)->getName()
		       << "\" id=\"" << task << "\">";
		  oss2 << "<process name=\"" 
		       << cfg->getResourceUser(task)->getName()
		       << "\" id=\"" << task << "\"/>";

		  // Create also the connections leaving this service. Some connections might go to mem areas
		  sctg::Task* st = dynamic_cast<sctg::Task*>(cfg->getResourceUser (task));
		  std::vector<unsigned long int> outs = st->getOutPorts();
		  //std::cout << "Task " << task << " has " << outs.size() << " outports" << std::endl;
		  
		  for(int i = 0; i < outs.size(); ++i)
		  {
		     unsigned long int oport = outs.at(i);
		     unsigned long int iport = cfg->getDestination(oport);
		     sctg::ResourceUser* target = 
			(cfg->getResourceUserByInPort(iport));
		     
		     oss3 << "<connection id=\"" 
			  << task << i
			  << "\" src=\"" 
			  << task 
			  << "\" dest=\"" << target->getId() << "\" />";
		  }
		  oss2 << "</service>";
		  
		  
	       }
	    }
	    
	    oss << "</thread>";
	 }
	 
      }
	    

      // Memory areas (will look like processes but do not appear in service view)
      bool ismem = false;
      for(unsigned long int memi = 0; memi < memAreas.size(); ++memi)
      {
	 
	 if(cfg->getResourceByResourceUser(memAreas.at(memi)->getId())
	    ->getId() == cpuId)
	 {
	    if(!ismem)
	    {
	       ismem = true;
	       oss << "<thread name=\"Mem_areas\" "
		   << "id=\"999\" priority=\"0\">";
	    }
	    oss << "<process name=\"" << memAreas.at(memi)->getName()
		<< "\" id=\"" << memAreas.at(memi)->getId() 
		<< "\"/>";
	 }
      }
      if(ismem)
      {
	 oss << "</thread>";
      }
      
      oss << "</cpu>";
   }      




   // Append the service config stuff at the end of main config and close the xml
   oss2 << oss3.str();
   oss2 << "</services>";
   oss << oss2.str();
   oss << "</configuration>" << std::endl;     
   str = oss.str();
   
   
   
   // Write to file
   if(cfg->getExecMonStream())
   {
      **cfg->getExecMonStream() << str;
      (**cfg->getExecMonStream()).flush();
      //std::cout << "wrote exec_mon log";
   }
   
   
   // Return the whole config information
   return str;

}


// Creates a file which Graphviz Dot can convert to png image.
// Currently, it includes the tasks, events and connections. 
// Memory areas are partially supported (connections task->mem_area
// are shown, but not vice versa.
// 
void printDot (sctg::Configuration* cfg, std::string srcFile,
	       std::vector<sctg::Task*>* tasks,
	       std::vector<sctg::Event*>* events){

   std::cout << " Print XML structure into dot-file" << std::endl;
   std::ofstream dotFile;
   dotFile.open("task_graph.dot");

   // Write header information to dot file
   dotFile << "// " << std::endl;
   dotFile << "// This file has been auto-generated by Transaction Generator " << std::endl;
   dotFile << "// based on file " << srcFile << std::endl;
   dotFile << "// " << boost::posix_time::second_clock::local_time() << std::endl;
   dotFile << "// Usage from cmd line: dot -Tpng -o task_graph.png task_graph.dot " << std::endl;
   dotFile << "// See also: http://www.graphviz.org/" << std::endl;
   dotFile << "// " << std::endl  << std::endl  << std::endl;

   //std::string fileName (srcFile.substr(0, srcFile.length()-4));
   //std::cout << "f: " << fileName << std::endl;
   dotFile << "digraph \"" << srcFile <<"\" {" << std::endl;


   
   // Go through all the tasks. Each task is drawn as a box with
   // multiple fields which denote the ports
   for ( std::vector<sctg::Task*>::iterator iter = tasks->begin();
	 iter != tasks->end(); 
	 ++iter){

      // Create new node with name and id
      dotFile  << "  "
	       << (*iter)->getName() 
	       << "[shape=Mrecord, label=\"{"
	       << (*iter)->getName() << " | "
	       << "id " << (*iter)->getId() << "} ";




      // Add ports to the node, upper row for inputs, bottom row for outputs
      // The resulting dot code line will be for example
      // 'dct [shape=Mrecord, label="{dct|0} | { 5 | 6}"];'
      // where 0 = task id, 5 inport id, 6 outport id
      std::vector<unsigned long int> ins = (*iter)->getInPorts();
      std::vector<unsigned long int> outs = (*iter)->getOutPorts();

      int n_io = 0;
      if (ins.size() > outs.size() ) { 
	 n_io = ins.size();
      } else {
	 n_io = outs.size();
      };
      
      for(int i = 0; i < n_io; ++i)
      {
	 dotFile << " | { ";
	 if (i < ins.size()) {
	    dotFile << " <f" << ins.at(i) << ">" << ins.at(i);
	 }
	 dotFile << " | ";

	 if (i < outs.size()) {
	    dotFile << " <f" << outs.at(i) << ">" << outs.at(i) ;
	 }

	 dotFile << " } ";
      }
      // Close the node
      dotFile  << "\"];"
	       << std::endl;

      // Go through all outgoing connections
      // The resulting dot code line will be for example
      // dct:<f6> -> vlc:<f7>
      // where <f6> is field id for outport 6, <f7> similarly for inport
      for(int i = 0; i < outs.size(); ++i)
	 {
	    unsigned long int oport = outs.at(i);
	    unsigned long int iport = cfg->getDestination(oport);
	    //sctg::Task* target = dynamic_cast<sctg::Task*>
	    sctg::ResourceUser* target = dynamic_cast<sctg::ResourceUser*>
	       (cfg->getResourceUserByInPort(iport));

	    dotFile << "  "
		    << (*iter)->getName() 
		    << ":<f" << oport << ">"
		    << " -> " 
		    << target->getName() 
		    << ":<f" << iport << ">"
		    << ";" << std::endl;	    
	 }
    
      dotFile << std::endl;
   } // end for ( std::vector<sctg::Task*>::iterator iter = tasks->begin();






   // Go through all the events. They look like tasks but are gray.
   for ( std::vector<sctg::Event*>::iterator iter = events->begin();
	 iter != events->end(); 
	 ++iter){


      // Create new event node with name and id, with 1 outport and 0 inports
      // For example 'event0 [shape=Mrecord, label="{event0|0} | { 
      // | 60}"];' where 0 = event id, " " means no inport id, 60 outport id
      dotFile  << "  "
	       << (*iter)->getName() 
	       << "[shape=Mrecord, color=\"grey\" style=\"filled\" label=\"{"
	       << (*iter)->getName() << " | "
	       << "eid " << (*iter)->getId() << "} ";

      unsigned long int outp = (*iter)->getOutPort();
      dotFile << " | { | ";
      dotFile << " <f" << outp << ">" << outp << "}";
      dotFile << " } ";

      // Close the node
      dotFile  << "\"];"
	       << std::endl;
      
      // Make the single connection: event -> task
      unsigned long int oport = outp;
      unsigned long int iport = cfg->getDestination(oport);
      sctg::Task* target = dynamic_cast<sctg::Task*>
	 (cfg->getResourceUserByInPort(iport));
      
      dotFile << "  "
	      << (*iter)->getName() 
	      << ":<f" << oport << ">"
	      << " -> " 
	      << target->getName() 
	      << ":<f" << iport << ">"
	      << ";" << std::endl;	    

      dotFile << std::endl;

   }  // end for iter=events.start()



   dotFile << "}";
   dotFile.close();
   return;
}





/**
 * Gather costs, such as PE utilization, execution counts, and transfer latencies. 
 * They are stored into CostFunction object.
 */
void calculateCost (sctg::Configuration* cfg, sctg::CostFunction* costF,
		    std::vector<sctg::ProcessingElement*>* pes,
		    std::vector<sctg::Task*>*              tasks,
		    std::vector<sctg::Event*>*             events
//   std::vector<sctg::MemArea*>           memAreas,
//   std::vector<sctg::MemoryModel*>       mems,

   )
{

      std::ostringstream oss;
      std::string str; // costFunc variable's name

      // PEs: utilization and frequency
      double avgPeUtil = 0.0;
      for(unsigned int i = 0; i < pes->size(); ++i)
      {
	 oss.str("");
	 oss << "pu_" << pes->at(i)->getId();
	 double util = pes->at(i)->getAvgUtilization();
	 avgPeUtil += util;
	 str = oss.str();
	 costF->addVariable(str, util); //stores a name-value pair
	 oss.str("");
	 oss << "pu_" << pes->at(i)->getName();
	 str = oss.str();
	 costF->addVariable(str, util);

	 oss.str("");
	 oss << "pf_" << pes->at(i)->getId();
	 str = oss.str();
	 costF->addVariable(str, pes->at(i)->getFrequency());
      }
      str = "pu_avg";
      avgPeUtil /= pes->size();
      costF->addVariable(str, avgPeUtil);


      // Tasks and events: execution count
      double totalCount = 0.0;
      for(unsigned int i = 0; i < tasks->size(); ++i)
      {
	 oss.str("");
	 oss << "tc_" << tasks->at(i)->getId();
	 double count = tasks->at(i)->getTimesTriggered();
	 totalCount += count;
	 str = oss.str();
	 costF->addVariable(str, count);
	 oss.str("");
	 oss << "tc_" << tasks->at(i)->getName();
	 str = oss.str();
	 costF->addVariable(str, count);
      }
      str = "tc_tot";
      costF->addVariable(str, totalCount);

      totalCount = 0.0;
      for(unsigned int i = 0; i < events->size(); ++i)
      {
	 oss.str("");
	 oss << "ec_" << events->at(i)->getId();
	 double count = events->at(i)->getTimesHappened();
	 totalCount += count;
	 str = oss.str();
	 costF->addVariable(str, count);
	 oss.str("");
	 oss << "ec_" << events->at(i)->getName();
	 str = oss.str();
	 costF->addVariable(str, count);
      }
      str = "ec_tot";
      costF->addVariable(str, totalCount);

      
      // Tokens: latencies
      std::map<unsigned long int, 
	    std::map<unsigned long int, sc_core::sc_time> >::iterator outer;
      std::map<unsigned long int, sc_core::sc_time>::iterator inner;
      
      unsigned long int latcount = 0;
      double latavg = 0.0;
      
      for(outer = cfg->getTokenLatency().begin(); 
	  outer != cfg->getTokenLatency().end(); ++outer)
      {
	 for(inner = (*outer).second.begin(); 
	     inner != (*outer).second.end(); ++inner)
	 {
	    oss.str("");
	    oss << "latf_" << (*outer).first << "_" << (*inner).first << "_avg";
	    double val = 
	       ((*inner).second / sc_core::sc_time(1000.0, sc_core::SC_MS)) 
	       / cfg->getTokenCount()[(*outer).first][(*inner).first];
	    latcount++;
	    latavg += val;
	    str = oss.str();
	    costF->addVariable(str, val);
	    oss.str("");
	    oss << "latf_" << (*outer).first << "_" << (*inner).first << "_max";
	    val = cfg->getTokenLatencyMax()[(*outer).first][(*inner).first] / 
	       sc_core::sc_time(1000.0, sc_core::SC_MS);
	    str = oss.str();
	    costF->addVariable(str, val);
	    oss.str("");
	    oss << "latf_" << (*outer).first << "_" << (*inner).first << "_min";
	    val = cfg->getTokenLatencyMin()[(*outer).first][(*inner).first] / 
	       sc_core::sc_time(1000.0, sc_core::SC_MS);
	    str = oss.str();
	    costF->addVariable(str, val);
	 }
      }
      
      oss.str("");
      oss << "latf_tot_avg";
      str = oss.str();
      latavg /= latcount;
      costF->addVariable(str, latavg);
      
      // Calculate latencies with unsent tokens      
      latcount = 0;
      latavg = 0.0;
      
      for(unsigned int i = 0; i < pes->size(); ++i)
      {
	 pes->at(i)->updateUnfinishedTokensLatency();
      }
      
      for(outer = cfg->getTokenLatency().begin(); 
	  outer != cfg->getTokenLatency().end(); ++outer)
      {
	 for(inner = (*outer).second.begin(); 
	     inner != (*outer).second.end(); ++inner)
	 {
	    oss.str("");
	    oss << "lat_" << (*outer).first << "_" << (*inner).first << "_avg";
	    double val = 
	       ((*inner).second / sc_core::sc_time(1000.0, sc_core::SC_MS)) 
	       / cfg->getTokenCount()[(*outer).first][(*inner).first];
	    latcount++;
	    latavg += val;
	    str = oss.str();
	    costF->addVariable(str, val);
	    oss.str("");
	    oss << "lat_" << (*outer).first << "_" << (*inner).first << "_max";
	    val = cfg->getTokenLatencyMax()[(*outer).first][(*inner).first] / 
	       sc_core::sc_time(1000.0, sc_core::SC_MS);
	    str = oss.str();
	    costF->addVariable(str, val);
	    oss.str("");
	    oss << "lat_" << (*outer).first << "_" << (*inner).first << "_min";
	    val = cfg->getTokenLatencyMin()[(*outer).first][(*inner).first] / 
	       sc_core::sc_time(1000.0, sc_core::SC_MS);
	    str = oss.str();
	    costF->addVariable(str, val);
	 }
      }
      
      oss.str("");
      oss << "lat_tot_avg";
      str = oss.str();
      latavg /= latcount;
      costF->addVariable(str, latavg);
      
      // Path measurements: latencies
      for(std::map<std::string, sc_core::sc_time>::iterator iter =
	     cfg->getTotPathLat().begin(); iter != cfg->getTotPathLat().end();
	  ++ iter )
      {
	 oss.str("");
	 oss << "path_" << (*iter).first << "_avg";
	 str = oss.str();
	 double val = ((*iter).second / sc_core::sc_time(1000.0, sc_core::SC_MS)) /
	    cfg->getPathCount()[(*iter).first];
	 costF->addVariable(str, val);
	 oss.str("");
	 oss << "path_" << (*iter).first << "_count";
	 str = oss.str();
	 val = cfg->getPathCount()[(*iter).first];
	 costF->addVariable(str, val);
      }
      for(std::map<std::string, sc_core::sc_time>::iterator iter =
	     cfg->getMaxPathLat().begin(); iter != cfg->getMaxPathLat().end();
	  ++ iter )
      {
	 oss.str("");
	 oss << "path_" << (*iter).first << "_max";
	 str = oss.str();
	 double val = ((*iter).second / sc_core::sc_time(1000.0, sc_core::SC_MS));
	 costF->addVariable(str, val);
      }
      for(std::map<std::string, sc_core::sc_time>::iterator iter =
	     cfg->getMinPathLat().begin(); iter != cfg->getMinPathLat().end();
	  ++ iter )
      {
	 oss.str("");
	 oss << "path_" << (*iter).first << "_min";
	 str = oss.str();
	 double val = ((*iter).second / sc_core::sc_time(1000.0, sc_core::SC_MS));
	 costF->addVariable(str, val);
      }
      
      // Add misc cost function variables
      for(std::map<std::string, double>::iterator iter = 
	     cfg->getCostVariables().begin(); 
	  iter != cfg->getCostVariables().end(); ++iter)
      {
	 std::string ss((*iter).first);
	 double dd = (*iter).second;
	 costF->addVariable(ss, dd);
      }

      
} // calculateCost(...)


/** How many decimals to print in a nice looking log E.g. <<
    std::setprecision(defPrecicion(v)) << v 
    The magic numbers were
    derived experimentally and seem nice enough in most cases.
 */ 
int defPrecision (double val)
{
   if (val < 1)
   {
      return 3;
   }
   else if (val < 1e4)
   {
      return 4;
   }
   else
   {
      return 7;
   }

}


/** 
 * Print cost values to stdout and a file 
 */
void printCost (sctg::Configuration* cfg, sctg::CostFunction* costF)
{

      unsigned int n = 1;

      for(std::vector<std::string>::iterator iter = 
	     cfg->getCostFunctions().begin(); 
	  iter != cfg->getCostFunctions().end(); ++iter)
      {
	 double answer = costF->parse((*iter));
	 int prec = defPrecision(answer);

	 // 1) To screen (one value)
	 std::cout 
	    << "Cost " << std::setw(3) << n << " ; ";
	 std::cout << "\"" 
		   << std::resetiosflags(std::ios::left) 
		   << std::setw(24)
		   << (*iter)
		   << "\" ;";

	 // Print values so that decimal points are aligned
	 if ((int)answer)
	 {
	    std::cout << std::setw(9);
	 }
	 else
	 {
	    std::cout << std::setw(8) << " ";
	 }
	 std::cout 
	    << std::setprecision(prec)
	    << answer
	    << std::endl;
	 if(n % 5 == 0) {std::cout << std::endl;} // empty line after 5 values


	 
	 // 2) To summary log file (two values: regular and scientific notation)
	 if(cfg->getSummaryStream())
	 {
	    **(cfg->getSummaryStream())
	       << std::setiosflags(std::ios::fixed)
	       << "Cost " << std::setw(3) << n << " ; " 
	       << std::setprecision(prec) //6) 
	       << std::setw(16) << answer
	       << std::resetiosflags(std::ios::fixed)
	       << std::setiosflags(std::ios::scientific)
	       << " ; " << std::setprecision(16) 
	       << std::setw(26) << answer
	       << "   ; \"" << (*iter)
	       << "\"" << std::endl;    
	 }
	 ++n;
      }
      
} // printCost(...)




// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
