/**
 *
 * @file cost_function.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: cost_function.cc 6 2011-11-23 13:57:28Z lehton87 $
 *
 */


#include "cost_function.hh"

#include <iostream>
#include <string>
#include <algorithm>
#include <exception>
#include <stdexcept>
#include <cstdlib>

namespace sctg
{

   CostFunction::CostFunction()
   {
      variables_.insert(std::pair<std::string, double>("the_answer", 42));
   }

   CostFunction::~CostFunction()
   {
   }

   void CostFunction::addVariable(std::string& str, double value)
   {
      variables_.insert(std::pair<std::string, double>(str, value));
   }

   double CostFunction::parse(std::string& function)
   {

      // Remove valid not-needed chars
      std::string::iterator it = function.begin();
      while(it != function.end())
      {
	 if(*it == ' ') // Remove spaces
	 {
	    it = function.erase(it);
	 }
	 else
	 {
	    ++it;
	 }
      }

      // Convert from infix to postfix format and evaluate
      double retval = 0.0;
      try {
	 infix_to_postfix(function.begin(), function.end());
	 retval = evaluate();
	 postfix_.clear();
      } catch (std::runtime_error& e) {
	 std::cerr << "Error while parsing cost function \""
		   << function << "\", reason: " << e.what() << std::endl;
      }

      return retval;
   }

   void CostFunction::infix_to_postfix(std::string::iterator begin,
				       std::string::iterator end)
   {
      const char operators[] = {'(', ')', '*', '/', '+', '-'};
      const int num_of_operators = 6;
      std::deque<Element> stack;

      std::string::iterator it = begin;
      std::string::iterator loc;

      Element cur = {MULT, 0.0};
      // Remember last operator for handling negation
      Element prev = {MULT, 0.0}; 

      while(it != end) {
      
	 // Find the first operator
	 loc = std::find_first_of(it, end, operators, 
				  operators + num_of_operators);
	 
	 // std::cout << "Figuring out \"" << std::string(it, loc) << "\" "
	 // 	   << *it << std::endl;	 

	 // Check if it's a known variable
	 if(variables_.find(std::string(it, loc)) != variables_.end()) {
	    cur.type = NUMBER;
	    cur.value = variables_[std::string(it, loc)];
	    prev = cur;
	    postfix_.push_back(cur);
	    it = loc;
	    continue;
	 }

	 // Check if it's a constant     
	 char* end_ptr;
	 double result = std::strtod(std::string(it, loc).c_str(), &end_ptr);
	 if(*end_ptr == 0 && it != loc) {
	    cur.type = NUMBER;
	    cur.value = result;
	    prev = cur;
	    postfix_.push_back(cur);
	    it = loc;
	    continue;
	 }
	 // Special case for constants like "7e-2"
	 // Scans past first operator for the second one,
	 //  otherwise the negative sign in E form numbers wouldn't work
	 if(*loc == '-' && it != loc) {	    
	    std::string::iterator tmp = find_first_of
	       (loc+1, end, operators, operators + num_of_operators);
	    result = std::strtod(std::string(it, tmp).c_str(), &end_ptr);
	    if(*end_ptr == 0) {
	       cur.type = NUMBER;
	       cur.value = result;
	       prev = cur;
	       postfix_.push_back(cur);
	       it = tmp;
	       continue;
	    }
	 }

	 // Check for operators
	 if(*it == '*' || *it == '/' || *it == '+' || *it == '-') {
	    switch(*it) {
	       case '*': cur.type = MULT; break;
	       case '/': cur.type = DIV; break;
	       case '+': cur.type = PLUS; break;
	       case '-': 
	       {	
		  if(postfix_.empty()) {
		     cur.type =  NEGATE; 
		  } else if(prev.type != NUMBER) {
		     cur.type =  NEGATE; 		     
		     }  else {
		     cur.type = MINUS;		     
		  }
		  break;
	       }
	    }
	    // Push all operators with equal or greater precedence
	    //  from stack to postfix form
	    while(!stack.empty() && stack.back().type <= cur.type) {
	       postfix_.push_back(stack.back());
	       stack.pop_back();	       
	    }
	    stack.push_back(cur);
	    prev = cur;
	    it = loc+1;
	    continue;
	 }
	 
	 // Check for opening bracket
	 if(*it == '(') {
	    cur.type = OPEN;
	    stack.push_back(cur);
	    it = loc+1;
	    continue;
	 }

	 // Check for closing bracket
	 if(*it == ')') {
	    if(stack.empty()) {
	       throw std::runtime_error
		  (ASE_ERRSTR("Couldn't find matching brackets"));
	    }
	    while(stack.back().type != OPEN) {	       
	       postfix_.push_back(stack.back());
	       stack.pop_back();
	       if(stack.empty()) {
		  throw std::runtime_error
		     (ASE_ERRSTR("Couldn't find matching brackets"));
	    }
	    }
	    if(stack.empty()) {
	       throw std::runtime_error
		  (ASE_ERRSTR("Couldn't find matching brackets 2"));
	    }	    
	    stack.pop_back(); // Pop the opening bracket
	    it = loc+1;
	    continue;
	 }
	 
	 std::cerr << "Error: Couldn't parse \"" << std::string(it, loc) 
		   << "\"" << std::endl;
	 throw std::runtime_error(ASE_ERRSTR("Parsing failed"));
      }
      
      // Pop all leftover operators
      while(!stack.empty()) {
	 postfix_.push_back(stack.back());
	 stack.pop_back();
      }
      
   }


   double CostFunction::evaluate()
   {
      std::deque<double> stack;

      for(std::deque<Element>::iterator it = postfix_.begin();
	  it != postfix_.end(); ++it) {
	 double tmp = 0.0;
	 double result = 0.0;

	 switch((*it).type) {
	    case NUMBER: 
	       stack.push_back((*it).value); 
	       break;
	    case NEGATE:
	       tmp =  stack.back();
	       stack.pop_back();	       
	       stack.push_back(-tmp);
	       break;
	    case MULT:
	    case DIV:
	    case PLUS:
	    case MINUS:
	    {
	       tmp =  stack.back();
	       stack.pop_back();	       
	       if(stack.empty())
		  throw std::runtime_error(ASE_ERRSTR("Missing second operand"));
	       switch((*it).type) {
		  case MULT:  result = stack.back() * tmp; break;
		  case DIV:   result = stack.back() / tmp; break;
		  case PLUS:  result = stack.back() + tmp; break;
		  case MINUS: result = stack.back() - tmp; break;
		  
		  case NUMBER: // these can't happen
		  case OPEN:
		  case CLOSE:
		  case NEGATE:
		     break;
	       }
	       if(!stack.empty()) 
		  stack.pop_back();
	       stack.push_back(result);
	       break;
	    }
	    case OPEN: // these can't happen
	    case CLOSE:
	       break;
	 }
      }
      if(stack.empty())
	 throw std::runtime_error(ASE_ERRSTR("Couldn't calculate the answer"));
      return stack.back();
   }

}

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
