/**
 *
 * @file resource.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: resource.cc 207 2013-08-28 13:00:38Z ege $
 *
 */

#include "resource.hh"
#include "common.hh"
#include "task.hh"
#include <boost/lexical_cast.hpp>
#include <iostream>
#include <iomanip> //Es, setw()

namespace sctg
{
   /**
    * Resource is a base class for processing elements and memories.
    */
   Resource::Resource(sc_core::sc_module_name name, 
		      const boost::property_tree::ptree& pt,
		      sctg::Configuration& config)
      : sc_core::sc_module(name),
	config_           (config), //es
	measureStart_     (), //es
	measureEnd_       () //es
   {

      // pt is the attribute list of a <resource ...>
      boost::property_tree::ptree::const_iterator iter = pt.begin(); //es

      name_ = name;
      id_   = sctg::convToInt (iter, "id");
      type_ = pt.get<std::string>("<xmlattr>.type", "not-defined");      
      freq_ = sctg::convToInt (iter, "frequency");

      // Create buffers for communicating tokens
      unsigned long int txBuffSize = 16;
      unsigned long int rxBuffSize = 16;
      try {
	 txBuffSize = sctg::convToInt (iter, "tx_buffer_size");
	 rxBuffSize = sctg::convToInt (iter, "rx_buffer_size");
      } catch (std::exception& e) {
	 
	 std::string err ("<resource ");
	 err += name;
	 err += " >";
	 err += e.what();
	 throw std::runtime_error (err);	 
      } // ES, end catch

      packetSize_ = sctg::convToInt (iter, "packet_size");
      packetSize_ = roundTo4n (packetSize_);

      if (txBuffSize > 0 
	  && packetSize_ > txBuffSize) {
	 packetSize_ = txBuffSize;
	 std::cout << "Resource " << id_ 
		   << ": pkt size truncated to " << packetSize_
		   << "B = tx buffer size"
		   << std::endl;
      }


      Buffer* buff = new Buffer(id_, rxBuffSize, txBuffSize, config);
      buffer_ = std::auto_ptr<Buffer>(buff);

      config.addBufferToResource(buff, id_);

   }
   
   /** Destructor
    */

   Resource::~Resource()
   {

   }
   
   const std::string& Resource::getName() const
   { return name_; }
   
   unsigned long int Resource::getId() const
   { return id_; }
   
   unsigned long int Resource::getFrequency() const
   { return freq_; }
   
   const std::string& Resource::getType() const
   { return type_; }


   /** Print utilization cycles and percentages into summary stream


    */
   int Resource::printUtilStats() const
   {
      // Get utilization. Avoid divide-by-0.
      double util = 0.0;
      if(measurements_.busyCycles != 0.0)
      {
	 util = double(measurements_.busyCycles) / 
	    double(measurements_.idleCycles + measurements_.busyCycles);
      }

      // Print statistics
      /*
	Something like:

	---
	Resource cpu0, id=0,freq=100
	           cycles;         %;     Mcycles;
         idle     3498410;     100%;         3.5;
         busy        1590;  0.0454%;     0.00159;
	------------------------------------------
	total     3500000;    100.0%         3.5;

      */



      if(config_.getSummaryStream())
      {
	 sc_core::sc_time cycleLength = measurements_.cycleLength; 
	 
	 **config_.getSummaryStream()
	    << "  ---" << std::endl
	    << "  Resource " << getName() <<", id=" << id_ << ",freq=" << freq_ << std::endl
	    << "                  cycles;         %;     Mcycles;" << std::endl
	    << "        idle" 
	    << std::setw(12) << measurements_.idleCycles << ";"
	    << std::setiosflags(std::ios::fixed)
	    << std::setw(9)  << std::setprecision (3) 
	    << 100*(1-util) << "%;" 
    	    << std::setw(12) << measurements_.idleCycles /1e6 << ";"
	    << std::endl
	    << "        busy" 
	    << std::setw(12) << measurements_.busyCycles << ";"
	    << std::setw(9)  << std::setprecision (3) 
	    << 100*util << "%;" 
    	    << std::setw(12) << measurements_.busyCycles /1e6 << ";"
	    << std::endl
	    << "       ------------------------------------------" << std::endl
	    << "       total" << std::setw(12)
	    << (measurements_.idleCycles + measurements_.busyCycles) << ";"
	    << std::setw(11) << "100.0%;" 
	    << std::setw(12) << (measurements_.idleCycles + measurements_.busyCycles) / 1e6 << ";"
	    << std::endl << std::endl << std::endl;

	 return 0;
      }
      else
      {
	 return 1;
      }
   }


   /** Print communication volumes and cycles into summary stream
       and list of unfinished tokens to token stream

    */
   int Resource::printCommStats(int iLineSize, int dLineSize, int missReqSize) const
   {
      if(config_.getSummaryStream())
      {

	 sc_core::sc_time cycleLength = measurements_.cycleLength; 
	 int totalCycles = measurements_.idleCycles + measurements_.busyCycles;
	 

	 // Print stats in 4 columns, 
	 /*
	   Something like:

	     Operation;    Cycles;     Bytes;   Comment;
	     Task exec;     21700;         -; 
	   Intra PE TX;        76;       300;   0 MB/s;
	   Inter PE TX;         0;         0;   0 MB/s;
	   Inter PE RX;         0;      1200;   0 MB/s;

	    Instr miss;         0;         0;   Tx + Rx = 0 * (8 +   4) bytes;
	    Data  miss;         0;         0;   Tx + Rx = 0 * (8 +   4) bytes;
	   -----------; ---------; ---------;   -----------
	           Sum;     21776;      1500;   Intra + Tx + Rx = 300 + 0 + 1200 bytes;
	              ;     21  k;      1 kB;
	 */


	 // First the header
	 **config_.getSummaryStream()
	    << "    Operation;    Cycles;     Bytes;   Comment;" << std::endl;

	 // Then one line per operation
	 sctg::BufferMeasurements bufMeas = buffer_->getMeasurements();
	 **config_.getSummaryStream()
	    << "    Task exec;"  << std::setw(10) << (int)(measurements_.execTime/cycleLength)
	    << ";         -; " 
	    << std::endl
	    
	    << "  Intra PE TX;" 
	    << std::setw(10) << (int)(measurements_.intraTxWait/cycleLength) << ";" 
	    << std::setw(10) << bufMeas.intraBytes << ";   "
	    << (freq_ * bufMeas.intraBytes) /  totalCycles << " MB/s;"
	    << std::endl; 

	 int interPeTx = (bufMeas.txBytes 
			  - measurements_.iCacheMisses * missReqSize
			  - measurements_.dCacheMisses * missReqSize);
	 **config_.getSummaryStream()
	    << "  Inter PE TX;" 
	    << std::setw(10) << (int)(measurements_.sendingTime/cycleLength) << ";" 
	    << std::setw(10) << interPeTx << ";   " 
	    << (freq_ * interPeTx) / totalCycles << " MB/s;"
	    << std::endl;


	 int interPeRx = (bufMeas.rxBytes // includes intra bytes
			  - bufMeas.intraBytes // 2013-08-14
			  - measurements_.iCacheMisses * roundTo4n (iLineSize)		     
			  - measurements_.dCacheMisses * roundTo4n (dLineSize));
	 **config_.getSummaryStream()
	    << "  Inter PE RX;" 
	    << std::setw(10) << (int)(measurements_.readingTime/cycleLength) << ";" 
	    << std::setw(10) << interPeRx << ";   " 
	    <<  (freq_ * interPeRx) / totalCycles << " MB/s;"
	    << std::endl	    
	    << std::endl; 


	 // Cache info makes sense only with processing_elements, but printed always
	 if (missReqSize > 0)
	 {
	    **config_.getSummaryStream() 
	       << "   Instr miss;" 
	       << std::setw(10) << (int)(measurements_.iCacheTime / cycleLength) << ";" 
	       << std::setw(10)  << measurements_.iCacheMisses * (roundTo4n (iLineSize) + missReqSize)
	       << ";   Tx + Rx = "
	       << measurements_.iCacheMisses
	       << " * (" << missReqSize << " + " 
	       << std::setw(3) << roundTo4n (iLineSize) << ") bytes;" 
	       << std::endl
	       
	       << "   Data  miss;" 
	       << std::setw(10) << (int)(measurements_.dCacheTime / cycleLength) << ";" 
	       << std::setw(10)  << measurements_.dCacheMisses * (roundTo4n (dLineSize) + missReqSize)
	       << ";   Tx + Rx = "
	       << measurements_.dCacheMisses
	       << " * (" << missReqSize << " + " 
	       << std::setw(3) << roundTo4n (dLineSize) << ") bytes;" 
	       << std::endl;
	       
	 }
	 else
	 {
	    // Memories don't cause cache misses, but spend time serving them
	    **config_.getSummaryStream() 
	       << "  I+D  misses;" 
	       << std::setw(10) << (int)(measurements_.cacheTime / cycleLength) 
	       << ";       N/A;   Cycles for reading data upon misses " 
	       << std::endl;

	 }

	 // Finally, print the sum of busy cycles and communicated bytes 
	 int totBytes = bufMeas.txBytes  + bufMeas.rxBytes; //Rx includes intra-PE data

	 **config_.getSummaryStream() 

	    << "  -----------; ---------; ---------;   -----------" << std::endl
	    << "          Sum;"
	    << std::setw(10) << measurements_.busyCycles << ";"
	    << std::setw(10) << totBytes //  2013-08-16
	    << ";   Intra + Tx + Rx = "
	    << bufMeas.intraBytes << " + " <<  bufMeas.txBytes 
	    << " + " << bufMeas.rxBytes - bufMeas.intraBytes //last term added 2013-08-14
	    << " bytes;" << std::endl 

	    << std::setw(14) << ";"
	    << std::setw(7) << measurements_.busyCycles/1000 << "  k;"
	    << std::setw(7) << totBytes /1000 << " kB;" << std::endl
	    << std::endl

	    << "Buffer usages;   Max [Bytes];       Max [%];  Size [Bytes];" << std::endl
	    << "           Tx;" << std::setw(14) << buffer_->getTxMaxUsage() 
	    << ";" << std::setw(14) 
	    << (100.0*buffer_->getTxMaxUsage()/  (bufMeas.txUsed + buffer_->txSpaceLeft()))
	    << ";" << std::setw(14) 
	    << (bufMeas.txUsed + buffer_->txSpaceLeft()) << ";"
	    << std::endl

	    << "           Rx:" << std::setw(14) << buffer_->getRxMaxUsage()  << ";"
	    << std::setw(14) 
	    << (100.0*buffer_->getRxMaxUsage() / (bufMeas.txUsed + buffer_->rxSpaceLeft()))
	     << ";" << std::setw(14) 
	    << (bufMeas.txUsed + buffer_->rxSpaceLeft()) << ";"
	    << std::endl << std::endl << std::endl;






	 // Print also the unfinished tokens to log file
	 if(config_.getTokenStream())
	 {	    
	    sc_core::sc_time cycleLength = measurements_.cycleLength; 
	    int totalCycles = measurements_.idleCycles + measurements_.busyCycles;
	    
	    
	    // Print the header row
	    **config_.getTokenStream()
	       << std::endl
	       << "Resource " << getId() << " is still expecting the following tokens"
	       << std::endl;

	    // Print token stats
	    int unfinishedTokensLeft = 1;


	    while (unfinishedTokensLeft) {
	       try {
		  tgToken tok = buffer_->rxPopExpToken();

		  Task* srcTask          = (Task*)(config_.getResourceUser(tok.srcTask));
		  unsigned int dstTaskId = (config_.getResourceUserByInPort(tok.dstPort))->getId();

		  **config_.getTokenStream() 
		     << std::setw(7)  << tok.id             << ";" 
		     << std::setw(17) << tok.timeSent.value() << ";" 
		     << "              -;"   //rx time undefined because incomplete
		     << "  > " << std::setw(10) << (sc_core::sc_time_stamp() - tok.timeSent).value() << ";"// min bound for latency  
		     << std::setw(5)  << buffer_->getReceivedBytes(tok.id)  << " / " 
		     << std::setw(5)  << tok.bytes          << ";" 
		     << std::setw(5)  << tok.packets        << ";" 

		     << std::setw(13) << srcTask->getName() << ";" 
		     << std::setw(15) << (config_.getResourceUser(dstTaskId))->getName()   << ";" 

		     << "     N/A;" // src resource might be already deleted! Cannot always get its name 
		     << std::setw(8) << (config_.getResourceByResourceUser(dstTaskId))->getName() << ";"
 		     << std::setw(9) << tok.srcPort << ";" 
		     << std::setw(9) << tok.dstPort << ";" 

		     << " lat = " << sc_core::sc_time_stamp() << " - " << tok.timeSent << ";" //dbg

		     << std::endl;


	       } catch  (std::exception& e){
		  unfinishedTokensLeft = 0;
	       }
	    } // end while
	 } // end if	 


	 return 0;
      }
      else
      {
	 return 1;
      }
   }
     
}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
