/**
 *
 * @file parse_stp.cc
 * @author Lasse Lehtonen
 *
 *
 * Parser for .stp files. Converts to native xml format.
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: parse_stp.cc 24 2012-01-23 13:55:08Z lehton87 $
 *
 */


#include "parse_stp.hh"
#include <fstream>
#include <map>
#include <vector>
#include <sstream>
#include <iostream>
#include <boost/lexical_cast.hpp> //ES

namespace sctg
{
   struct main_info {
      int type;
      int num_pe;
      int num_task;
      int num_edge;
   };
   
   struct task_info {
      int task_id;
      int pe_id;
      int seq_num;
      float exec_mean;
      float exec_dev;
      std::vector<int> in_ports;
      std::vector<int> out_ports;
      std::vector<float> out_mean;
      std::vector<float> out_dev;
   };

   struct port_conn {
      int src;
      int dst;
   };

   boost::property_tree::ptree parse_stp(std::string filename,
					 int iterations)
   {
      boost::property_tree::ptree tree;
      tree.put("system.xsm_version.<xmlattr>.value", 4);

      std::fstream ifs(filename.c_str(), std::fstream::in);
      
      std::string s;
      main_info m;
      
      std::map<int, task_info*> exec_map;
      std::vector<port_conn> ports;

      /* STP file structure in MCLS v1.5
        --14 lines of header comments in the beginning, file name, version, authos...

	-- Then one line with trace type 0=STP, 1=RTP(for example Fpppp.stp)
	0

	-- topology   #PEs    #rows  #cols
	0	       16	4	4

	-- #tasks  #edges
	334	   1145
	
	-- #start_tasks  id    id       ...   id      last id
	             52	  0	1	...   212	333	

	--#end tasks   id       id      ...   id      last id
	          14	320	321	...   332	333	

	-- Then one line per task (334 in this case)
        --id   @PE     sched    avg cycles      stddev cycles
	 0	(0,0)	0	1440	        180
	 ...
	 333	(0,0)	2	1280	160


	-- Then one line per edge (1145 in this case)
	-- id src_task dst_task mem_addr  wrmem_bytes avg size  stddev size    rate
	    0	0	3	 0x0	   0x200	51.20	6.40	     0.004861
	    ...

	TG will skip many parameters from edges, e.g. PEs, mem addr and sizes, and rate (=avg_size(pkt_size*avg_cycles)


      */




      // Ignore first 14 lines (comments)
      std::string dummys;
      for(int i = 0; i < 14; ++i)
	 //ifs.ignore(999, '\n');
	 std::getline(ifs, dummys);

      // One line for trace type, 0=STP, 1=RTP
      ifs >> m.type;

      // One line with general infos
      float dummy;
      char dummyc; // removes chars: (,)x
      int topology;
      int rows;
      int cols;
      ifs >> topology >> m.num_pe >> rows >> cols;
      std::cout << "top:" << topology << ", n_pe:"  << m.num_pe 
		<< ", rows:" <<  rows << ", cols" << cols << std::endl;


      // One line with task graph stats
      ifs >> m.num_task >> m.num_edge;
      std::cout << "G(V,E) = G(" << m.num_task << ", " << m.num_edge << ")" << std::endl;

      // One line with start tasks - these should be converted to events...
      ifs >> dummy;
      std::cout << "Start tasks:" << dummy;
	 //ifs.ignore(999, '\n');
	 std::getline(ifs, dummys);
      
      // One line with end tasks
      ifs >> dummy;
      std::cout << "End tasks:" << dummy << std::endl;
      //ifs.ignore(999, '\n');
      std::getline(ifs, dummys);


      // Task execution stuff
      for(int i = 0; i < m.num_task; ++i)
      {
	 int r =0;    
	 int c =0;
	 task_info* ei = new task_info;
	 ifs >> ei->task_id ;
	 if (topology == 2) {
	    // fattree stores PE ID as running number
	    ifs >> ei->pe_id ;
	 } else {
	    // mesh an torus PE ID as coordinates (0,0), (0,1)...
	    ifs >> dummyc >> r >> dummyc >> c >> dummyc;
	    ei->pe_id = r*cols + c;
	 }

	 // Scheduling priority and exec cycles
	 std::string exme;
	 //ifs >> ei->seq_num >> exme >> ei->exec_dev;
	 //ei->exec_mean = boost::lexical_cast<float>(exme);
	 ifs >> ei->seq_num >> ei->exec_mean >> ei->exec_dev;
	 
	 std::cout << "id:" << ei->task_id << ", pe:" << ei->pe_id << ", seq:" 
	 	   << ei->seq_num << ", avg_cyc:" << ei->exec_mean << ", stddev_cyc:" << ei->exec_dev << std::endl;



	 // Check that task id is unique
	 if(exec_map.find(ei->task_id) == exec_map.end()) {
	    exec_map[ei->task_id] = ei;
	 } else {
	    std::ostringstream oss;
	    oss << "STP: Task ID \"" << ei->task_id<< "\" not unique (" 
		<< ei->task_id << "," << ei->pe_id << ", " 
		<< ei->seq_num << ", " << ei->exec_mean << ", " << ei->exec_dev << ")" ;
	    throw std::runtime_error(oss.str().c_str());
	 }
      }


      // Communication stuff
      for(int i = 0; i < m.num_edge; ++i)
      {
	 // float dummy;
	 int id;
	 int src;
	 int dst;
	 float mean;
	 float dev;
//	 std::string dummys;
	 ifs >> id >> src >> dst 
	     >> dummys >> dummys;
	    //>> dummy >> dummyc >> dummy;
	 //std::cout << dummyc << " " << dummy;
	 //ifs    >> dummy >> dummyc >> dummy;
	 //std::cout << dummyc << " " << dummy << std::endl;
	 ifs >> mean >> dev 
	     >> dummy;
	 //ifs.ignore (50, '\n');
	 std::getline(ifs, dummys);

	 task_info* sender = (*exec_map.find(src)).second;
	 task_info* receiver = (*exec_map.find(dst)).second;

	 // Store port connection
	 port_conn pc;
	 pc.src = 2*id;
	 pc.dst = 2*id+1;
	 ports.push_back(pc);

	 std::cout << "con" << id << " " << src << " -> " << dst << "(" 
		   << pc.src << "->" << pc.dst << ") avg:" << mean << " bytes, " 
		   << dummy << std::endl;

	 // Store send/receive information for tasks
	 sender->out_ports.push_back(pc.src);
	 sender->out_mean.push_back(mean);
	 sender->out_dev.push_back(dev);
	 receiver->in_ports.push_back(pc.dst);
      }




      // Generate the property_tree
      // Tasks
      int event_id = 0;
      int port     = (m.num_edge + 1) * 2;
      for(std::map<int, task_info*>::iterator iter = exec_map.begin();
	  iter != exec_map.end(); ++iter)
      {
	 boost::property_tree::ptree task;
	 boost::property_tree::ptree trigger;	 

	 std::ostringstream oss;
	 oss << "task_" << (*iter).second->task_id;
	 task.put("<xmlattr>.name", oss.str());
	 task.put("<xmlattr>.id", (*iter).second->task_id);
	 task.put("<xmlattr>.class", "general");
	 trigger.put("<xmlattr>.dependence_type", "and");

	 // in_port tags
	 std::vector<int>& ins = (*iter).second->in_ports;
	 for(int i = 0; i < ins.size(); ++i)
	 {
	    boost::property_tree::ptree tr;
	    tr.put("<xmlattr>.id", ins.at(i));
	    task.add_child("in_port", tr);
	    trigger.add_child("in_port", tr);
	 }

	 // Generate event and ports for tasks without input ports
	 // MCLS lists such tasks as "Start tasks", but this works even witout that list
	 if((*iter).second->in_ports.size() == 0)
	 {	    
	    port_conn c;
	    c.src = port;
	    c.dst = port + 1;
	    ports.push_back(c);
	    boost::property_tree::ptree tr;
	    tr.put("<xmlattr>.id", event_id);
	    std::ostringstream oss;
	    oss << "Event_" << event_id;
	    tr.put("<xmlattr>.name", oss.str());
	    tr.put("<xmlattr>.amount", 1);
	    tr.put("<xmlattr>.prob", 1);
//	    tr.put("<xmlattr>.period", "0.001");
	    tr.put("<xmlattr>.count", iterations);
	    tr.put("<xmlattr>.out_port_id", c.src);

	    tree.add_child("system.application.task_graph.event_list.event",tr);
	    boost::property_tree::ptree tp;
	    tp.put("<xmlattr>.id", c.dst);
	    task.add_child("in_port", tp);
	    trigger.add_child("in_port", tp);
	    event_id++;
	    port += 2;
	    
	 }

	 // out_port
	 std::vector<int>& outs = (*iter).second->out_ports;
	 for(int i = 0; i < outs.size(); ++i)
	 {
	    boost::property_tree::ptree tr;
	    tr.put("<xmlattr>.id", outs.at(i));
	    task.add_child("out_port", tr);
	 }
	 
	 // exec_count
	 trigger.put("exec_count.op_count.int_ops.distribution.normal.<xmlattr>.mean", (*iter).second->exec_mean);
	 trigger.put("exec_count.op_count.int_ops.distribution.normal.<xmlattr>.standard_deviation", (*iter).second->exec_dev);
	 
	 
	 // send
	 std::vector<float>& out_mean = (*iter).second->out_mean;
	 std::vector<float>& out_dev = (*iter).second->out_dev;
	 for(int i = 0; i < outs.size(); ++i)
	 {
	    boost::property_tree::ptree tr;
	    tr.put("<xmlattr>.out_id", outs.at(i));
	    tr.put("<xmlattr>.prob", 1.0);
	    tr.put("byte_amount.distribution.normal.<xmlattr>.mean", out_mean.at(i));
	    tr.put("byte_amount.distribution.normal.<xmlattr>.standard_deviation", out_dev.at(i));
	    trigger.add_child("exec_count.send", tr);
	 }

	 task.add_child("trigger", trigger);
	 tree.add_child("system.application.task_graph.task", task );
	 
	 
      }
            

      // port connections
      for(int i = 0; i < ports.size(); ++i)
      {
	 boost::property_tree::ptree tr;
	 tr.put("<xmlattr>.src", ports.at(i).src);
	 tr.put("<xmlattr>.dst", ports.at(i).dst);
	 tree.add_child("system.application.task_graph.port_connection", tr);
      }

      // Mapping and platform
      for(int i = 0; i < m.num_pe; ++i)
      {
	 boost::property_tree::ptree tr; // resource
	 boost::property_tree::ptree tg; // task group
	 boost::property_tree::ptree pl; // platform
	 std::ostringstream oss;
	 oss << "cpu" <<  i;
	 tr.put("<xmlattr>.name", oss.str());
	 tr.put("<xmlattr>.id", i);

	 pl.put("<xmlattr>.name", oss.str());
	 pl.put("<xmlattr>.id", i);
	 pl.put("<xmlattr>.frequency", 100);
	 pl.put("<xmlattr>.type", "CPU_TYPE_1");
	 pl.put("<xmlattr>.scheduler", "sequence");
	 pl.put("<xmlattr>.packet_size", 16);
	 pl.put("<xmlattr>.rx_buffer_size", 0 );
	 pl.put("<xmlattr>.tx_buffer_size", 0 );

	 oss.str("");
	 oss << "group" << i;
	 tg.put("<xmlattr>.name", oss.str());
	 tg.put("<xmlattr>.id", i);

	 for(std::map<int, task_info*>::iterator iter = exec_map.begin();
	     iter != exec_map.end(); ++iter)
	 {
	    if((*iter).second->pe_id == i)
	    {
	       boost::property_tree::ptree tt;
	       oss.str("");
	       oss << "task_" << (*iter).second->task_id;
	       tt.put("<xmlattr>.name", oss.str());
	       tt.put("<xmlattr>.id", (*iter).second->task_id);
	       tt.put("<xmlattr>.schedule_seq", (*iter).second->seq_num);
	       tg.add_child("task", tt);
	    }
	 }
	 tr.add_child("group", tg);
	 tree.add_child("system.mapping.resource", tr);
	 tree.add_child("system.platform.resource", pl);	 
	 //tree.add_child("system.platform.resource_list.resource", pl);	 
      }
      
      ifs.close();
      return tree;
   }

}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
