

/**
 * @file memory_model.hh
 * @author Lasse Lehtonen
 * 
 * @brief Integrates Accurate DRAM model to SCTG2
 *
 * Functions nb_transport_bw(), burstWrite(), burstRead(),
 * handleResponse() and calculateBurstLength() are copied with little
 * modifications from Accurate DRAM Model (LGPL, test_gen.h/.cpp) by
 * Nan Li (KTH).
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: memory_model.cc 131 2012-11-06 08:14:04Z ege $
 *
 */

#include "buffer.hh"
#include "common.hh"
#include "configuration.hh"
#include "memory_model.hh"
#include <boost/lexical_cast.hpp>
#include <string>

namespace sctg
{

   /** Constructor
    */ 
   MemoryModel::MemoryModel(sc_core::sc_module_name name,
			    const boost::property_tree::ptree& pt,
			    sctg::Configuration& config)
      : Resource(name, pt, config),
	req_(0),
	resp_(0),
	currentState_(IDLE)
   {    
      
      std::string ocpParam = pt.get<std::string>("<xmlattr>.ocp_param");
      std::string admParam = pt.get<std::string>("<xmlattr>.adm_param");      

      boost::property_tree::ptree::const_iterator iter = pt.begin();
      reqSize_ = sctg::convToInt (iter, "request_size");

      // Set cycle length    
      cycleLength_ =  sc_core::sc_time(1.0 / getFrequency(), sc_core::SC_US);
      
      
      // Create OCP port
      ocpMaster_ = new ocpip::ocp_master_socket_tl1<sizeof(Dt)*8>
      ("master_port", 
       ocpip::ocp_master_socket_tl1<sizeof(Dt)*8>::mm_txn_with_data());
      
      ocpMaster_->register_nb_transport_bw(this, &MemoryModel::nb_transport_bw);
      ocpMaster_->activate_synchronization_protection();
    

      std::cout << getName() << ":" << std::endl;

      // Create Accurate DRAM model
      dram_ = new adm_model<MEM_BUSWIDTH>
	 ("adm", ocpParam.c_str(), admParam.c_str());
      
      map_string_type  ocpParamMap;
      readMapFromFile(ocpParam, ocpParamMap);
      ocpip::ocp_parameters params = 
	 create_ocp_configuration_from_map("sl", ocpParamMap);
      ocpMaster_->set_ocp_config(params);
      (*ocpMaster_)(dram_->ocpPort);
      


      // Launch thread
      clkgen_ = new sc_core::sc_clock("clkgen", cycleLength_);
      dram_->clk(*clkgen_);
      clk_(*clkgen_);
      
      SC_METHOD(handleResponse);
      sensitive << clk_.pos();
      dont_initialize();
      
      SC_THREAD(thread);
      //sensitive << clk_.pos();
      //dont_initialize();
      

      buffer_->usePackets(true);
  }

   /** Destructor
    */
   MemoryModel::~MemoryModel()
   {    
      updateMeasurements();


      // Print statistics
      printUtilStats();
      printCommStats(0, 0, 0); // 0,0,0= no cache information available

   }


   unsigned long int MemoryModel::getReqSize() const
   {
      return reqSize_;
   }


   const sctg::PeMeasurements& MemoryModel::getMeasurements()
   {
      updateMeasurements();

      return measurements_;
   }

   
   void MemoryModel::updateMeasurements()
   {
      measureEnd_   = sc_core::sc_time_stamp();

      switch(currentState_)
      {
	 case IDLE:
	    measurements_.idleTime += 
	       measureEnd_ - measureStart_;	
	    break;
	 case EXECUTING:	
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.execTime += 
	       measureEnd_ - measureStart_;
	    break;
	 case READING:
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.readingTime +=
	       measureEnd_ - measureStart_;
	    break;
	 case CACHE_READ:
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.readingTime +=
	       measureEnd_ - measureStart_;
	    measurements_.cacheTime +=
	       measureEnd_ - measureStart_;
	    break;
	 case WRITING:
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.writingTime +=
	       measureEnd_ - measureStart_;
	    break;
	 case SENDING:
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.sendingTime +=
	       measureEnd_ - measureStart_;
	    break;
	 default:
	    break;
      }

      measurements_.cycleLength = cycleLength_;

      measurements_.idleCycles = 
	 static_cast<unsigned long int>(measurements_.idleTime/cycleLength_);
      measurements_.busyCycles = 
	 static_cast<unsigned long int>(measurements_.busyTime/cycleLength_);
    
      measureStart_ = measureEnd_;

   }



  tlm::tlm_sync_enum MemoryModel::nb_transport_bw(tlm::tlm_generic_payload& tx, 
						  tlm::tlm_phase& phase, 
						  sc_core::sc_time& time)
  {
    if (phase == tlm::BEGIN_RESP) 
      {
	resp_ = &tx;
	phase = tlm::END_RESP;
	return tlm::TLM_UPDATED;
      } 
    else if ((phase == tlm::END_REQ) || (phase == ocpip::END_DATA)) 
      {
	req_ = 0;
      } 
    else 
      {
	sc_assert(false);
      }
    
    return tlm::TLM_ACCEPTED;
  }


   /** The main functionality
    */ 
   void MemoryModel::thread()
   {
      sc_core::sc_time startTime;
      sc_core::sc_time endTime;

      while(true)
      {
	 // Wait until some data arrives
	 if(!buffer_->rxPacketAvailable())
	 {
	    currentState_ = IDLE;
 	    // std::cout << "MEM " << getName() << " waiting" << std::endl;
	    wait(*(buffer_->rxGetPacketAvailableEvent()));
	    updateMeasurements();
	 }
	 tgPacket* packet = buffer_->rxGetPacket();
	 buffer_->removeToken(packet->size);
	 

	 // Check to which memory area to access and
	 // calculate the starting address for that memory area
	 unsigned long int area = 0;
	 unsigned long int startAddr = 0;
	 for(unsigned int i = 0; i < memAreas_.size(); ++i)
	 {
	    if((packet->type == CACHE_MISS && memAreas_.at(i)->getId() ==
		packet->dstPort)
	       || 
	       (packet->type != CACHE_MISS && memAreas_.at(i)->getId() == 
		config_.getResourceUserByInPort(packet->dstPort)->getId()))
	    {
// 	       std::cout << "Memory access to area " 
// 			 << memAreas_.at(i)->getName() << std::endl;
	       
	       area = i;
	       break;	       
	    }
	    startAddr += memAreas_.at(i)->getSize();
	 }



	 unsigned long int bytesLeft = packet->size; //ES
	 unsigned long int burstBytes = packet->burstSize; //ES

	 if (packet->type == WRITE_CMD) 
	 {
	    // Too small packet cannot utilize the max write burst 
	    // supported by memory
	    burstBytes = bytesLeft < burstBytes ? bytesLeft : burstBytes; // take smaller
	 }

	 unsigned long int burstWords = roundTo4n (burstBytes) / 4;
	 unsigned long int maxSize = burstWords * 4;
	 
/*
 	 std::cout  << std::endl
		    << "Mem at " << sc_core::sc_time_stamp()
		    << "incoming pkt Size   " << packet->size
		    << " bytes " << std::endl
		    << "max BurstSize       " << packet->burstSize
		    << " bytes, use " << burstWords << " words or less" << std::endl
		    << "RespSize            " << packet->respSize << std::endl;
*/

	 if(packet->type == WRITE_CMD)
	 {
	    currentState_ = WRITING;
	    startTime = sc_core::sc_time_stamp();

	    // Write the data using max-burst-sized chunks. Put data randomly somewhere
	    // between area's start and end address

	    while(bytesLeft > 0)
	    {
	       
	       unsigned long int addr = startAddr + 
		  (rand()%(memAreas_.at(area)->getSize()-maxSize));

	       // Handle also the non-power-of-2 bursts
	       unsigned long int words = roundTo4n (bytesLeft) / 4;
	       words = words <= burstWords ? words : burstWords;


	       burstWrite(addr, 0, words); // Actual memory access, 0 is just an arbitrary id

	       if (bytesLeft > burstBytes) 
	       {
		  bytesLeft -= burstBytes;
	       } else 
	       {
		  bytesLeft = 0;
	       }
/*
	       std::cout << "wr mem, a=" << addr << ", #words=" << words
			 << "( " << packet->burstSize<< " )"
			 << ", and there are "
			 << bytesLeft << " bytes left."
			 << std::endl; //ES
*/
	    }

	    endTime =  sc_core::sc_time_stamp();
	    // std::cout << "Mem access completed at " << endTime;
				  

	    // Write log
	    if(config_.getMemStream())
	    {
	       **config_.getMemStream()
		  << std::setw(10) << startTime.value() << "; " 
		  << std::setw(10) << endTime.value() << "; "
		  << std::setw(6)  << (endTime.value() - startTime.value()) / cycleLength_.value() // es
		  << ";          Wr;"
		  << std::setw(7)  << packet->size  << ";"
		  << std::setw(9)  << this->getName()  << ";"
		  << std::setw(5)  << this->getId()  << ";"
		  << std::setw(10) << memAreas_.at(area)->getName() << ";"
		  << std::setw(5)  << memAreas_.at(area)->getId()   << ";"
		  << std::setw(9)  << packet->srcPort << ";"
		  << "        -"
		  // << std::setw(9)  << packet->dstPort
		  << std::endl;
	    }
	    updateMeasurements();
	 }
	 else // READ or CACHE_MISS
	 {	    
	    // Prepare a responce
	    tgToken token;
	    unsigned long int port;
	    unsigned long int task;
	    unsigned long int size;	 
	    unsigned long int dataLeft = packet->respSize;
	    Resource* pe;

	    token.bytes = packet->respSize;	    
	    token.type = packet->type;
	    token.srcPort = packet->retPort;
	    token.timeSent = sc_core::sc_time_stamp();
	    
	    startTime = sc_core::sc_time_stamp();

	    if(packet->type == CACHE_MISS)
	    {
	       currentState_ = CACHE_READ;
	       token.dstPort = 
		  config_.getResource(packet->srcPort)->getId();
	    }
	    else // READ
	    {
	       currentState_ = READING;
	       token.dstPort = 
		  config_.getDestination(packet->retPort);
	       task = config_.getResourceUserByInPort(token.dstPort)->
		  getId();
	    }	       


	    if(respMap_.find(packet->id) == respMap_.end())
	    {	       	       
	       Resp r = {token.bytes, packet->packets, config_.getTokenId()};
	       respMap_[packet->id] = r;
	       token.id = respMap_[packet->id].tokenId;

	       if(packet->type == CACHE_MISS)
	       {
		  config_.getBufferByResource
		     (config_.getResource(packet->srcPort)->getId())
		     ->expectToken(token);
	       }
	       else // READ
	       {
		  config_.getBufferByResource
		     (config_.getResourceByResourceUser(task)->getId())
		     ->expectToken(token);	    

		  std::cout << "mem sends token " << token.id << std::endl; //ES
		  config_.addSendTime(token.srcPort);
	       }	       
	       	       
	    }

	    token.id = respMap_[packet->id].tokenId;

	    if(respMap_[packet->id].respLeft > 1)
	    {
	       dataLeft = packet->respSize / packet->packets;
	       respMap_[packet->id].dataLeft -= dataLeft;
	       respMap_[packet->id].respLeft--;
	    }
	    else
	    {
	       dataLeft = respMap_[packet->id].dataLeft;
	       respMap_.erase(respMap_.find(packet->id));
	    }
	    /*
 	    std::cout << "MEM " << getName() << " sending token with size "
 		      << dataLeft << std::endl;
	    */

	    unsigned long int bytesLeft = dataLeft; //ES


	    // Read the memory, many times if needed 
	    while(bytesLeft > 0) // ES
	    {

	       unsigned long int addr = startAddr + 
		  (rand()%(memAreas_.at(area)->getSize()-maxSize));

	       // Handle also the non-power-of-2 bursts
	       unsigned long int words = roundTo4n (bytesLeft) / 4;
	       words = words <= burstWords ? words : burstWords;

	       burstRead(addr, words, true); // actual read operation

	       if (bytesLeft > packet->burstSize) 
	       {
		  bytesLeft -= packet->burstSize; // ES
	       } else 
	       {
		  bytesLeft = 0;
	       }
/*
	       std::cout << "rd mem, a=" << addr << ", #words=" << words
			 << ", and there are "<< bytesLeft << " bytes left" << std::endl; //ES
*/
	    }

	    wait(readDone_);


	    // Send the read data to the requesting task
	    while(dataLeft > 0)
	    {
	       

	       // Create packet
	       tgPacket* pkt = new tgPacket;
	       if(packetSize_ > 0) // Zero packet_size means "don't cut tokens"
	       {
		  size = dataLeft < packetSize_ ? dataLeft : packetSize_;
	       }
	       else
	       {
		  size = dataLeft;
	       }
	       dataLeft -= size;
 	       // std::cout << "dataLeft " << dataLeft << std::endl;


	       size = roundTo4n (size); // 13.8.2012, es
	       pkt->size = size;
	       
	       
	       if(packet->type == CACHE_MISS)
	       {
		  pkt->address = token.dstPort;
	       }
	       else // READ
	       {
		  port = token.dstPort;
		  task = config_.getResourceUserByInPort(port)->getId();
		  pe = config_.getResourceByResourceUser(task);
		  pkt->address = pe->getId();
	       }
	       pkt->id   = token.id;
	       /*
		 std::cout << "MEM response to port " << port << " task "
		 << task << " in address " << std::hex
		 << pkt->address << std::dec 
		 << " with size " << size 
		 << " and packetSize_ " << packetSize_ << std::endl;
	       */
	       
	       updateMeasurements();
	       while(buffer_->txSpaceLeft() < pkt->size)
	       {			
		  currentState_ = SENDING;
		  wait(*(buffer_->txGetReadEvent()));
		  updateMeasurements();
	       }
	    
	       buffer_->txPutPacket(pkt);
	    } // end while (dataLeft >)...




	    // Update log
	    endTime =  sc_core::sc_time_stamp();

	    if(config_.getMemStream())
	    {
	       **config_.getMemStream()
		  << std::setw(10) << startTime.value() << "; " 
		  << std::setw(10) << endTime.value() << "; "
		  << std::setw(6)  << (endTime.value() - startTime.value()) / cycleLength_.value(); // es

	       if(packet->type == CACHE_MISS)
	       {
		  **config_.getMemStream()
		     << ";           $;";
	       }
	       else
	       {
		  **config_.getMemStream()		  
		     << ";          Rd;";
	       }

	       **config_.getMemStream()		  
		  << std::setw(7)  << token.bytes << ";" 
		  << std::setw(9)  << this->getName()  << ";"
		  << std::setw(5)  << this->getId()  << ";"
		  << std::setw(10) << memAreas_.at(area)->getName() << ";" 
		  << std::setw(5)  << memAreas_.at(area)->getId()<< ";" 
		  << "        -;"
		  // << std::setw(9)  << token.srcPort<< ";" 

		  << std::setw(9)  << token.dstPort
		  << std::endl;

	       // Commanding task would be useful, but it is hard to
	       // figure out which one it is for cache misees and
	       // writes.  It's simple with reads: << std::setw(7) <<
	       // (config_.getResourceUserByInPort
	       // (token.dstPort))->getName()

	    }


  	    // std::cout << " DONE READING" << std::endl;
	 }
	 
	 delete packet->data;
	 delete packet;
      }

   }


   
  void MemoryModel::burstWrite(uint64 address, unsigned int threadId, 
			       unsigned int length, bool posted, 
			       bool srmd)
  {
    tlm::tlm_generic_payload *txn = ocpMaster_->get_transaction();
    ocpMaster_->reserve_data_size(*txn, sizeof(Dt) * length);
    txn->set_address(address);
    txn->set_byte_enable_ptr(NULL);
    txn->set_streaming_width(sizeof(Dt));
    txn->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
    txn->set_command(tlm::TLM_WRITE_COMMAND);

    /* set extension for posted */
    if (posted) ocpMaster_->validate_extension<ocpip::posted>(*txn);

    /* set extension for srmd */
    if (srmd) ocpMaster_->validate_extension<ocpip::srmd>(*txn);

    /* set extension burst_length */
    ocpip::burst_length *bLen;
    ocpMaster_->get_extension(bLen, *txn);
    bLen->value = length;
    ocpMaster_->validate_extension<ocpip::burst_length>(*txn);

    /* set extension thread_id */
    ocpip::thread_id *tId;
    ocpMaster_->get_extension(tId, *txn);
    tId->value = threadId;
    ocpMaster_->validate_extension<ocpip::thread_id>(*txn);

    if (srmd) {
      tlm::tlm_phase phase = tlm::BEGIN_REQ;
      sc_time time = SC_ZERO_TIME;
      req_ = txn;

      cout << "[REQ @ " << sc_time_stamp() << "] [WRITE] BURST(" << length << ") - SRMD : request sent." << endl;
      (*ocpMaster_)->nb_transport_fw(*req_, phase, time);
      
      while (req_) wait(clkgen_->posedge_event());

    }


    /* send data */
    for (unsigned i = 0; i < length; ++i) {
      *((Dt *)txn->get_data_ptr() + i) = 1234;	/* data does not matter */
      
      tlm::tlm_phase phase;
      if (srmd)
	phase = ocpip::BEGIN_DATA;
      else
	phase = tlm::BEGIN_REQ;
      sc_time time = SC_ZERO_TIME;

      req_ = txn;

      if ((*ocpMaster_)->nb_transport_fw(*req_, phase, time) == tlm::TLM_UPDATED)
	{
	  req_ = 0;
	  wait(clkgen_->posedge_event());
	} 
      else 
	{
	  while (req_) wait(clkgen_->posedge_event());
	}
      
    }

    if (posted)
      ocpMaster_->release_transaction(txn);
  }

  void MemoryModel::burstRead(uint64 address, unsigned int threadId, 
			      unsigned int length, bool srmd)
  {
    tlm::tlm_generic_payload *txn = ocpMaster_->get_transaction();
    ocpMaster_->reserve_data_size(*txn, length * sizeof(Dt));
    txn->set_address(address);
    txn->set_byte_enable_ptr(0);
    txn->set_streaming_width(sizeof(Dt));
    txn->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
    txn->set_command(tlm::TLM_READ_COMMAND);

    /* set extension for srmd */
    if (srmd) ocpMaster_->validate_extension<ocpip::srmd>(*txn);

    /* set extension burst_length */
    ocpip::burst_length *bLen;
    ocpMaster_->get_extension(bLen, *txn);
    bLen->value = length;
    ocpMaster_->validate_extension<ocpip::burst_length>(*txn);

    /* set extension thread_id */
    ocpip::thread_id *tId;
    ocpMaster_->get_extension(tId, *txn);
    tId->value = threadId;
    ocpMaster_->validate_extension<ocpip::thread_id>(*txn);

    if (srmd) {
      tlm::tlm_phase phase = tlm::BEGIN_REQ;
      sc_time time = SC_ZERO_TIME;
      req_ = txn;


      (*ocpMaster_)->nb_transport_fw(*req_, phase, time);

      while (req_) wait(clkgen_->posedge_event());
      
    } 
    else 
      {
	for (unsigned i = 0; i < length; ++i) {
	  tlm::tlm_phase phase = tlm::BEGIN_REQ;
	  sc_time time = SC_ZERO_TIME;
	  req_ = txn;

	  (*ocpMaster_)->nb_transport_fw(*req_, phase, time);

	  while (req_) wait(clkgen_->posedge_event());

      }
    }
  }

  void MemoryModel::handleResponse()
  {
    if (!resp_) return;
    static std::map<tlm::tlm_generic_payload *, unsigned int> 
      burstLengthMap, burstCountMap;

    if (!burstLengthMap[resp_]) {
      /* first response */
      burstLengthMap[resp_] = calculateBurstLength(*resp_);
      burstCountMap[resp_] = 0;
    }


    if (resp_->get_command() == tlm::TLM_WRITE_COMMAND) {
      if (ocpMaster_->get_extension<ocpip::srmd>(*resp_)) {
	cout << "[RESP @ " << sc_time_stamp() << "] [WRITE] BURST(" 
	     << burstLengthMap[resp_] << ") - SRMD : response received." << endl;
	ocpMaster_->release_transaction(resp_);
	burstLengthMap.erase(resp_);
	burstCountMap.erase(resp_);

	cout << "[TXN " << "] [WRITE] [END @ " << "]" << endl;
	txnIdMap.erase(resp_);
      } else {
// 	cout << "[RESP @ " << sc_time_stamp() << "] [WRITE] BURST(" 
// 	     << burstLengthMap[resp_] << ") : DATA[" << burstCountMap[resp_] 
// 	     << "] response received." << endl;
	if (burstCountMap[resp_] == burstLengthMap[resp_] - 1) {
// 	  cout << "[FIN @ " << sc_time_stamp() << "] [WRITE] BURST(" 
// 	       << burstLengthMap[resp_] << ") : finished." << endl;
	  burstLengthMap.erase(resp_);
	  burstCountMap.erase(resp_);
	  ocpMaster_->release_transaction(resp_);
	}
      }

    } else {
      // Td data = *((Td *)resp_->get_data_ptr() + burstCountMap[resp_]);
//       cout << "[RESP @ " << sc_time_stamp() << "] [READ] BURST(" << burstLengthMap[resp_] << ") : DATA[" << burstCountMap[resp_] << "] = " << endl;

      if (burstCountMap[resp_] == burstLengthMap[resp_] - 1) {
// 	cout << "[FIN @ " << sc_time_stamp() << "] [READ] BURST(" << burstLengthMap[resp] << ") : finished." << endl;
	burstLengthMap.erase(resp_);
	burstCountMap.erase(resp_);
	ocpMaster_->release_transaction(resp_);
	
	txnIdMap.erase(resp_);
	readDone_.notify(sc_core::SC_ZERO_TIME);
      }
    }

    if (burstCountMap.count(resp_))
      burstCountMap[resp_]++;
    resp_ = 0;
  }

  unsigned int MemoryModel::calculateBurstLength(tlm::tlm_generic_payload &txn)
  {
    ocpip::burst_length *bLen;
    if (ocpip::extension_api::get_extension<ocpip::burst_length>(bLen, txn))
      return bLen->value;
    else {
      SC_REPORT_WARNING(SC_ID_WITHOUT_MESSAGE_, 
			"burst_length extension is not used. "
			"Calculating burst length from data length.");
      return txn.get_data_length() / sizeof(Dt);
    }
  }

   void MemoryModel::mapResourceUser(ResourceUser* task)
   {
      std::cout << "MemArea "   << std::resetiosflags(std::ios::left) << std::setw(9) 
		<< task->getName() << " mapped to Mem "
		<< getName() << std::endl;
      memAreas_.push_back(dynamic_cast<MemArea*>(task));
   }
  
}

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:


