/**
 *
 * @file event.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: event.cc 81 2012-09-12 06:39:00Z ege $
 *
 */

#include "event.hh"

#include <iostream>
#include <iomanip>

#include <systemc>


namespace sctg
{
   /** Constrcutor
    */
   Event::Event(sc_core::sc_module_name name, 
		Configuration& config,
		const boost::property_tree::ptree& pt)
      :
      sc_core::sc_module(name),
      name_(name),
      timesHappened_(0),
      totAmount_(0),
      config_(config)
   {
      SC_THREAD(thread);

      boost::property_tree::ptree::const_iterator iter = pt.begin();
      port_   = sctg::convToInt (iter, "out_port_id");
      amount_ = sctg::convToInt (iter, "amount");
      id_     = sctg::convToInt (iter, "id");
      count_  = pt.get<unsigned long int>("<xmlattr>.count", 0);
      prob_   = pt.get<double>("<xmlattr>.prob", 1.0);      
      period_ = pt.get<double>("<xmlattr>.period", 0.0);
      offset_ = pt.get_optional<double>("<xmlattr>.offset");
   }


   /** Destrcutor
    */
   Event::~Event()
   {
      if(config_.getSummaryStream())
      {
	 **config_.getSummaryStream()
	    << "- Event;"
	    << std::setw(16) << name_          << ";"
	    << std::setw(4)  << id_            << ";"
	    << std::setw(11) << timesHappened_ << ";"
	    << "           -;"
	    << std::setw(15) << totAmount_     << ";"	    
	    << "              -;"
	    << std::endl;
      }
   }
  
   /** Main functionality
    */
   void Event::thread()
   {
      // Wait offset once at the beginning, if such time present
      if(offset_)
      {
	 sc_core::wait(*offset_, sc_core::SC_SEC);
      }
    


      if(count_ != 0)
      {
	 // Generate exactly certain number of events
	 for(;count_ > 0; --count_)
	 {
	    if(config_.random() < prob_)
	    {
	       timesHappened_++;
	       send();
	    }
	    sc_core::wait(period_, sc_core::SC_SEC);
	 }
      }
      else
      {
	 // Keep on generating forever (count==0)
	 while(true)
	 {
	    if(config_.random() < prob_)
	    {
	       timesHappened_++;
	       send();	  
	    }  
	    sc_core::wait(period_, sc_core::SC_SEC);
	 }
      }
   }

   void Event::mapPe(ProcessingElement* pe)
   {
      std::cout << "Event "
		<< std::setw(11) << id_  << " mapped to PE  "
		<< pe->getName()
		<< std::endl;
      /* std::cout << "PE " << pe->getName() << " mapped to event "
		<< id_ << std::endl;
      */
      owners_.push_back(pe);
   }

   /** Send token to all owner resources
    */
   void Event::send()
   {
      tgToken token;
      token.srcPort  = 0;
      token.dstPort  = config_.getDestination(port_);
      token.bytes    = amount_;
      token.isEvent  = true;
      token.timeSent = sc_core::sc_time_stamp();
      totAmount_    += amount_; //ES
      for(unsigned int i = 0; i < owners_.size(); ++i)
      {
	 owners_.at(i)->receiveEvent(token);
      }
   }

   unsigned long int Event::getOutPort()
   { return port_; }

   unsigned long int Event::getTimesHappened()
   { return timesHappened_; }

   unsigned long int Event::getId()
   { return id_; }

   std::string& Event::getName()
   { return name_; }
}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
