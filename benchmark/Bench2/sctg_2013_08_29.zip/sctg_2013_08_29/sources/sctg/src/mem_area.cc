/**
 *
 * @file resource_user.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: mem_area.cc 81 2012-09-12 06:39:00Z ege $
 *
 */

#include "mem_area.hh"
#include "common.hh"

namespace sctg
{
   MemArea::MemArea(const boost::property_tree::ptree& pt,
		    Configuration& config)
      :
      ResourceUser(pt, config)
   {
      
      boost::property_tree::ptree::const_iterator iter = pt.begin();
      size_ = sctg::convToInt (iter, "size");

   }

   MemArea::~MemArea()
   {


   }


   unsigned long int MemArea::getSize() const
   {
      return size_;
   }

}

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
