/**
 *
 * @file common.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: common.cc 81 2012-09-12 06:39:00Z ege $
 *
 */

#include "common.hh"

namespace sctg
{
  
   std::string stateToString(State state)
   {
      switch(state)
      {
	 case RUN: return "RUN"; break;
	 case WAIT: return "WAIT"; break;
	 case FREE: return "FREE"; break;
	 case READY: return "READY"; break;
	 default: return "SOMETHING IS WRONG"; break;
      }
   }

   /** Rounds upto next positive multiple of four
       ES 9.8.2012
    */
   int roundTo4n (const int val)
   {
      int tmp = val;
      // std::cout << "round ( " << val
      //	<< "). Its mod 4 = " << val %4 << " ==" << tmp % 4;
      if (val < 1) 
      {
       tmp = 4;
      }
      if(tmp % 4 != 0)
      {
	 tmp += 4 - (tmp % 4);
	 // std::cout << " mod+ ";
      }
      // std::cout << " -> " << tmp << std::endl;
      return tmp;
   }




// Reads one attribute's value from property_tree (=string in
// xml). Foremost, this function reports nicely if something goes
// wrong in conversion, e.g. -1 and kk2 are not valid integers.
unsigned long int convToInt (boost::property_tree::ptree::const_iterator iter,
			     std::string attrib) 
{
   unsigned long int value = 660;

   try 
   {
      // Read the attribute, e.g. task id
      value = (*iter).second.get<unsigned long int> (attrib);
   } 
   catch (std::exception& e) {
      // Report the error
      
      std::string err ("<");
      err += (*iter).first + " ... "; // tag

      size_t pos = attrib.find("."); // split the string, e.g. "<xmlattr>.id"
      err += attrib.substr (pos+1)+ " = ";

      err += (*iter).second.get<std::string>(attrib); // erroneus value
      err += "> is not unsigned integer";
      //  += e.what();
      throw std::runtime_error (err);      
   }

   return value;
}


// Reads one attribute's value from property_tree (=string in
// xml). Foremost, this function reports nicely if something goes
// wrong in conversion, e.g. -1 and kk2 are not valid integers.
double convToDouble (boost::property_tree::ptree::const_iterator iter,
			     std::string attrib) 
{
   double value = 66.6;

   try 
   {
      // Read the attribute, e.g. task id
      value = (*iter).second.get<double> (attrib);
   } 
   catch (std::exception& e) {
      // Report the error
      
      std::string err ("<");
      err += (*iter).first + " ... "; // tag

      size_t pos = attrib.find("."); // split the string, e.g. "<xmlattr>.id"
      err += attrib.substr (pos+1)+ " = ";

      err += (*iter).second.get<std::string>(attrib); // erroneus value
      err += "> is not double";
      //  += e.what();
      throw std::runtime_error (err);      
   }

   return value;
}



}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
