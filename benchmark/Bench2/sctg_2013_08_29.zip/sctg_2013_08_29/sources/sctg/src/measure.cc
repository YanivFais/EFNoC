/**
 *
 * @file measure.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: measure.cc 81 2012-09-12 06:39:00Z ege $
 *
 */


#include "measure.hh"

#ifdef SCTG_USE_EXECMON
#ifndef MTI_SYSTEMC
#include "tcp_server_if.hh"
#endif
#endif

#include <vector>
#include <iomanip>
#include <boost/date_time.hpp>
#include <sstream>

namespace sctg
{

   Measure::Measure(sc_core::sc_module_name name, sctg::Configuration& config,
		    std::vector<sctg::ProcessingElement*> pes,
		    std::vector<sctg::Task*> tasks,
		    std::vector<sctg::MemoryModel*> memories,
		    std::vector<sctg::MemArea*> memAreas)
      : sc_core::sc_module(name),
	config_(config),
	pes_(pes),
	tasks_(tasks),
	memories_(memories),
	memAreas_(memAreas)
   {

      // Launch threads
      SC_THREAD(measureThread);
#ifdef SCTG_USE_EXECMON      
      if(config_.useExecMon() || config_.getExecMonStream())
      {
	 SC_THREAD(execMonThread);      
      }
#endif      

      std::ostringstream oss;
      oss << "Log created ; "
	  << boost::posix_time::second_clock::local_time() 
	  << std::endl << std::endl;
      
      measure_start_time_ = oss.str();

   }
  
  
   Measure::~Measure()
   {
    
   }
  

   /* Gets statistics periodically and prints them to files
    */
   void Measure::measureThread()
   { 
      sc_core::sc_time interval = config_.getMeasurementInterval();
      if(interval == sc_core::SC_ZERO_TIME)
      { 
	 std::cout << " No snapshot statistics, "
		   << "since <measurements time = corrupted>" << std::endl;
	 return; 
      }

      std::cout << "Measuring snapshot statistics with " << interval
		<< " interval" << std::endl;

      std::vector<PeMeasurements> oldPeData;
      std::vector<PeMeasurements> newPeData;
      std::vector<BufferMeasurements> oldBufferData;
      std::vector<BufferMeasurements> newBufferData;
      oldPeData.resize(pes_.size());
      newPeData.resize(pes_.size());
      oldBufferData.resize(pes_.size());
      newBufferData.resize(pes_.size());

      // Print headers to log files, there are 6 possible logs
      if(config_.getSummaryStream())
      {
	 **config_.getSummaryStream() 
	    << Measure::measure_start_time_;
      }

      if(config_.getPacketStream())
      {
	 **config_.getPacketStream() 
	    << Measure::measure_start_time_
	    << "Packet size is always a multiple of 4 bytes, e.g. 4, 8, 12..." << std::endl
	    << "Note that cache miss packets are not logged" << std::endl << std::endl
	    << " Rx Time[" << sc_get_time_resolution()
	    << "]; Token #;  Bytes; Token begin; Token end; Time interval; Src port; Dst port;" 
	    << std::endl;
      }

      if(config_.getTokenStream())
      {
	 **config_.getTokenStream() 
	    << Measure::measure_start_time_
	    << "Note that cache miss tokens are not logged." << std::endl 
	    << "Lat [cyc] means latency measured as the cycles of the receiver PE."    << std::endl
	    << "Dst task name is left empty when task sends to itself (self-loop). "   << std::endl
	    << "Dst resource name is left empty for intra-PE transfers."  << std::endl << std::endl
	    << "Token #; Time sent [" << sc_get_time_resolution()
	    << "]; Time completed;       Latency;  Lat [cyc];  Bytes; #packets;       Src task;       Dst task;" 
	    << " Src res; Dst res; Src port; Dst port;"
	    << std::endl;
      }    

      if(config_.getMemStream())
      {
	 **config_.getMemStream()
	    << Measure::measure_start_time_
	    << "Start Time;   End Time; Cycles; Wr/Rd/$miss;  Bytes; " 
	    << "Res name;  rID; Area Name;  aID; SRC port; DST port;"
	    << std::endl;
      }
		  
      if(config_.getPeStream())
	 {
	    **config_.getPeStream()
	       << Measure::measure_start_time_
	       << " Time[" << sc_get_time_resolution()
	       << "];  Name; Id; Utilization; Rx bytes; Tx bytes; "
	       << "Rx buffer usage; Tx buffer usage; Idle cycles;"
	       << " Busy cycles;"
	       << " Exec cycles; Reading cycles; Sending cycles;"
	       << " RX wait cycles; TX wait cycles; Intra PE comm cycles;"
/*	       << " I-cache cycles; I-cache misses;"
	       << " D-cache cycles; D-cache misses"
*/	       << std::endl;
	 }

      if(config_.getAppStream())
	 {
	    **config_.getAppStream()
	       << Measure::measure_start_time_
	       << "Time[" << sc_get_time_resolution()
	       << "];Name;Buffer usage;State"
	       << std::endl;
	 }


      // Print PE and APP statistics periodically. 
      //
      // Token and packet statistics are handled by buffer.cc,
      // mem stats by memory_model.cc, 
      // and summary by main/processing_element/task/event.cc
      while(true)
      {
	 wait(interval);

	 std::cout << " measuring. Curr sim time is "
		   << sc_core::sc_time_stamp() << std::endl; 
	 
	 // Iterate over all processing elements
	 for(unsigned int i = 0; i < pes_.size(); ++i)
	 {
	    // Calculate the difference to previous measurement, i.e.
	    // what happened since.

	    // Transmitted and received (tx,rx) bytes
	    oldBufferData.at(i) = newBufferData.at(i);
	    newBufferData.at(i) = 
	       config_.getBufferByResource
	       (pes_.at(i)->getId())->getMeasurements();

	    unsigned long int rxBytes = 
	       newBufferData.at(i).rxBytes - oldBufferData.at(i).rxBytes;
	    unsigned long int txBytes = 
	       newBufferData.at(i).txBytes - oldBufferData.at(i).txBytes;
	    unsigned long int intBytes = 
	       newBufferData.at(i).intraBytes - 
	       oldBufferData.at(i).intraBytes;

	    // Calculate utilization and other PE related stuff
	    oldPeData.at(i) = newPeData.at(i);
	    newPeData.at(i) = pes_.at(i)->getMeasurements();
	    sc_core::sc_time idle = 
	       newPeData.at(i).idleTime - oldPeData.at(i).idleTime;
	    sc_core::sc_time busy = 
	       newPeData.at(i).busyTime - oldPeData.at(i).busyTime;
	    //sc_core::sc_time exec = 
		//   newPeData.at(i).execTime - oldPeData.at(i).execTime;
	    
	    unsigned long int iCacheMisses = 
	       newPeData.at(i).iCacheMisses -
	       oldPeData.at(i).iCacheMisses;
	    unsigned long int dCacheMisses = 
	       newPeData.at(i).dCacheMisses -
	       oldPeData.at(i).dCacheMisses;

	    double util = (busy / (busy + idle));	    
//	    double util = (exec / (exec + idle));	    

	    unsigned long int idleCycles = 0;
	    unsigned long int busyCycles = 0;
	    unsigned long int execCycles = 0;
	    unsigned long int readCycles = 0;
	    unsigned long int sendCycles = 0;
	    unsigned long int rxCycles = 0;
	    unsigned long int txCycles = 0;
	    unsigned long int intraCycles = 0;
	    unsigned long int iCacheCycles = 0;
	    unsigned long int dCacheCycles = 0;

	    idleCycles = newPeData.at(i).idleCycles - 
	       oldPeData.at(i).idleCycles;
	    busyCycles = newPeData.at(i).busyCycles - 
	       oldPeData.at(i).busyCycles;
	    
	    execCycles = (newPeData.at(i).execTime - 
			  oldPeData.at(i).execTime) /
	       newPeData.at(i).cycleLength;
	    readCycles = (newPeData.at(i).readingTime - 
			  oldPeData.at(i).readingTime) /
	       newPeData.at(i).cycleLength;
	    sendCycles = (newPeData.at(i).sendingTime - 
			  oldPeData.at(i).sendingTime) / 
	       newPeData.at(i).cycleLength;
	    rxCycles = (newPeData.at(i).rxWaitTime - 
			oldPeData.at(i).rxWaitTime) / 
	       newPeData.at(i).cycleLength;
	    txCycles = (newPeData.at(i).txWaitTime - 
			oldPeData.at(i).txWaitTime) / 
	       newPeData.at(i).cycleLength;
	    intraCycles = (newPeData.at(i).intraTxWait - 
			    oldPeData.at(i).intraTxWait) / 
	       newPeData.at(i).cycleLength;
	    iCacheCycles = (newPeData.at(i).iCacheTime - 
			   oldPeData.at(i).iCacheTime) / 
	       newPeData.at(i).cycleLength;
	    dCacheCycles = (newPeData.at(i).dCacheTime - 
			   oldPeData.at(i).dCacheTime) / 
	       newPeData.at(i).cycleLength;



	    if(config_.getPeStream())
	    {

	       **config_.getPeStream()
		  << std::setw(11) << sc_core::sc_time_stamp().value() << ";"
		  << std::setw(6)  << pes_.at(i)->getName()<< ";"
		  << std::setw(3)  << pes_.at(i)->getId()<< ";"
		  << std::setw(12) << util << ";"
		  << std::setw(9)  << rxBytes - intBytes << ";"
		  << std::setw(9)  << txBytes << ";"
		  << std::setw(16) << newBufferData.at(i).rxUsed  << ";"
		  << std::setw(16) << newBufferData.at(i).txUsed << ";"
		  << std::setw(12) << idleCycles << ";"
		  << std::setw(12) << busyCycles << ";"
		  << std::setw(12) << execCycles << ";"
		  << std::setw(15) << readCycles << ";"
		  << std::setw(15) << sendCycles << ";"
		  << std::setw(15) << rxCycles << ";"
		  << std::setw(15) << txCycles << ";"
		  << std::setw(21) << intraCycles << ";"
/*		  << std::setw(15) << iCacheCycles << ";"
		  << std::setw(15) << iCacheMisses << ";"
		  << std::setw(15) << dCacheCycles << ";"
		  << std::setw(15) << dCacheMisses << ";"
*/
		  << std::endl;
	    }

	 }
	 **config_.getPeStream() << std::endl; //dbg


	 if(config_.getAppStream())
	 {
	    for(unsigned int i = 0; i < tasks_.size(); ++i)
	    {
	       **config_.getAppStream()
		  << sc_core::sc_time_stamp().value()
		  << ";" << tasks_.at(i)->getName() 
		  << ";" << tasks_.at(i)->getBufferUsage()
		  << ";" << stateToString(tasks_.at(i)->getState())
		  << std::endl;
	       (**config_.getAppStream()).flush();
	    }
	 }	 
      }
      
   }

#ifdef SCTG_USE_EXECMON
   void Measure::execMonThread()
   {
      sc_core::sc_time interval = config_.getMeasurementInterval(); //es
      //sc_core::sc_time interval = sc_core::sc_time(1, sc_core::SC_MS);
      unsigned long int currentTime = 0;

      std::ostringstream oss;

      std::vector<PeMeasurements> oldPeData;
      std::vector<PeMeasurements> newPeData;
      std::vector<BufferMeasurements> oldBufferData;
      std::vector<BufferMeasurements> newBufferData;
      oldPeData.resize(pes_.size());
      newPeData.resize(pes_.size());
      oldBufferData.resize(pes_.size()+memories_.size());
      newBufferData.resize(pes_.size()+memories_.size());

      std::vector<PeMeasurements> oldMemData;
      std::vector<PeMeasurements> newMemData;
      oldMemData.resize(memories_.size());
      newMemData.resize(memories_.size());
    
      while(true)
      {	 
	 oss.str("");
	 // !!! This is not current "time" but running number!
	 oss << "<measurement time=\"" 
	     << (1.0* currentTime * interval / config_.getMeasurementIntervalUnit() ) 
	     << "\">";
	 // For example, 1 * 2ms / 1 ms = 2, 
	 //              2 * 2ms / 1 ms = 4 and so on instead of older 1,2,3...

	 for(unsigned int i = 0; i < pes_.size(); ++i)
	 {
	    // Calculate tx/rx bytes
	    oldBufferData.at(i) = newBufferData.at(i);
	    newBufferData.at(i) = 
	       config_.getBufferByResource
	       (pes_.at(i)->getId())->getMeasurements();
	       

	    unsigned long int rxBytes = 
	       newBufferData.at(i).rxBytes - oldBufferData.at(i).rxBytes;
	    unsigned long int txBytes = 
	       newBufferData.at(i).txBytes - oldBufferData.at(i).txBytes;
	    unsigned long int intBytes = 
	       newBufferData.at(i).intraBytes - 
	       oldBufferData.at(i).intraBytes;

	    // Calculate utilization
	    oldPeData.at(i) = newPeData.at(i);
	    newPeData.at(i) = pes_.at(i)->getMeasurements();
	    sc_core::sc_time idle = 
	       newPeData.at(i).idleTime - oldPeData.at(i).idleTime;
	    sc_core::sc_time exec = 
	       newPeData.at(i).execTime - oldPeData.at(i).execTime;

	    double util = (exec / (exec + idle));

	    if((exec + idle) == sc_core::SC_ZERO_TIME)
	    {
	       util = 0.0;
	    }

	    oss << "<graph cpu_id=\"" << pes_.at(i)->getId() << "\" value=\""
		<< (100.0 * util) << "\" id=\"0\"/>";

	 }

	 for(unsigned int i = 0; i < memories_.size(); ++i)
	 {
	    // Calculate tx/rx bytes
	    oldBufferData.at(i+pes_.size()) = newBufferData.at(i+pes_.size());
	    newBufferData.at(i+pes_.size()) = 
	       config_.getBufferByResource
	       (memories_.at(i)->getId())->getMeasurements();
	       

	    unsigned long int rxBytes = 
	       newBufferData.at(i+pes_.size()).rxBytes 
	       - oldBufferData.at(i+pes_.size()).rxBytes;
	    unsigned long int txBytes = 
	       newBufferData.at(i+pes_.size()).txBytes 
	       - oldBufferData.at(i+pes_.size()).txBytes;
	    unsigned long int intBytes = 
	       newBufferData.at(i+pes_.size()).intraBytes - 
	       oldBufferData.at(i+pes_.size()).intraBytes;

	    // Calculate utilization
	    oldMemData.at(i) = newMemData.at(i);
	    newMemData.at(i) = memories_.at(i)->getMeasurements();
	    sc_core::sc_time idle = 
	       newMemData.at(i).idleTime - oldMemData.at(i).idleTime;
	    sc_core::sc_time exec = 
	       newMemData.at(i).busyTime - oldMemData.at(i).busyTime;

	    double util = (exec / (exec + idle));

	    if((exec + idle) == sc_core::SC_ZERO_TIME)
	    {
	       util = 0.0;
	    }

	    oss << "<graph cpu_id=\"" << memories_.at(i)->getId() 
		<< "\" value=\""
		<< (100.0 * util) << "\" id=\"0\"/>";
	    
	 }

	 for(unsigned int i = 0; i < pes_.size(); ++i)
	 {
	    while(!(pes_.at(i)->getTokenQueue().empty()))
	    {
	       
	       oss << "<signal " 
		   << "dest_pid=\"" << 
		  config_.getResourceUserByInPort
		  (pes_.at(i)->getTokenQueue().front().dstPort)->getId() 
		   << "\" "
		   << "value=\"" << pes_.at(i)->getTokenQueue().front().bytes 
		   << "\" " << "source_pid=\"";
	       bool f1 = false;
	       unsigned long int src = pes_.at(i)->getTokenQueue().front().srcPort;
	       for(unsigned int j = 0; j < tasks_.size(); ++j)
	       {
		  if(tasks_.at(j)->hasOutPort(src))
		  {
		     oss << tasks_.at(j)->getId() << "\"/>";
		     f1 = true;
		     break;
		  }
	       }	       
	       if(!f1) oss << "0\"/>";
	       pes_.at(i)->getTokenQueue().pop();
	    }
	 }

	 for(unsigned int i = 0; i < tasks_.size(); ++i)
	 {
	    double latency = tasks_.at(i)->getLastLatency() /
	       sc_core::sc_time(1.0, sc_core::SC_US);
	    double response = tasks_.at(i)->getLastResponse() /
	       sc_core::sc_time(1.0, sc_core::SC_US);
	    oss << "<process_exec " 
		<< "latency=\"" << latency << "\" "
		<< "local_comm_bytes=\"" << tasks_.at(i)->getLocalBytesSent() 
		<< "\" local_comm_time=\"" << 0 << "\" "
		<< "response_time=\"" << response << "\" "
		<< "remote_comm_bytes=\"" << tasks_.at(i)->getRemoteBytesSent()
		<< "\" remote_comm_time=\"" << 0 << "\" "
		<< "count=\"" << tasks_.at(i)->getTimesTriggered() << "\" "
		<< "pid=\"" << tasks_.at(i)->getId() << "\" "
		<< "signal_queue=\"" << tasks_.at(i)->getBufferUsage() << "\" "
		<< "exec_time=\"" << tasks_.at(i)->getCyclesExecuted() 
		<< "\"/>";
	    	       
	 }

	 oss << "</measurement>" << std::endl;

	 std::string str = oss.str();
#ifndef MTI_SYSTEMC
	 if(config_.useExecMon())
	 {
	    config_.getTcpServer()->send(str);
	 }
#endif
	 if(config_.getExecMonStream())
	 {
	    **config_.getExecMonStream()
	       << oss.str();
	    (**config_.getExecMonStream()).flush();
	 }

	 wait(interval);
	 currentTime++;

      }
   }
#endif
   

}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
