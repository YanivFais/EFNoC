/**
 *
 * @file non_sc_factory.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: non_sc_factory.cc 24 2012-01-23 13:55:08Z lehton87 $
 *
 */

#include "non_sc_factory.hh"
#include "tcp_server.hh"

namespace sctg
{
   NonScFactory::NonScFactory(sctg::NonScConfIf& conf)
      :
      conf_(conf),
      tcpServerIf_(0)
   {
      tcpServerIf_ = new TcpServer(9990);
      conf_.setTcpServer(tcpServerIf_);
  }
   
   NonScFactory::~NonScFactory()
   {
      delete tcpServerIf_; tcpServerIf_ = 0;
   }
      
}

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
