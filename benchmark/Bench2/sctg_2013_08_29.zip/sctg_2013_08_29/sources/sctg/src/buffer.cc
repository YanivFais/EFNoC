/**
 *
 * @file buffer.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: buffer.cc 207 2013-08-28 13:00:38Z ege $
 *
 *
 */


#include "buffer.hh"

#include "resource.hh" //es
#include "resource_user.hh" //es

#include <stdexcept>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <climits>

namespace sctg
{

   /**
    * Constructor
    */
   Buffer::Buffer(unsigned long int owner,
		  unsigned long int rxBufferSize,
		  unsigned long int txBufferSize,
		  sctg::Configuration& config)
      :
      rxBufferSize_(rxBufferSize),
      txBufferSize_(txBufferSize),
      rxBufferUsed_(0),
      txBufferUsed_(0),
      rxMaxUsage_(0),
      txMaxUsage_(0),
      config_(config),
      usePackets_(false),
      owner_(owner)
   {      

      //if (!rxBufferSize) {std::cout << "rxbuf(" << owner_ << ") =0 bytes" <<std::endl;}

      saturationFlag =0;
   }


   /**
    * Destructor
    */  
   Buffer::~Buffer()
   {
//       for(std::map<unsigned long int, tgToken>::iterator iter = 
// 	     expectedTokens_.begin();
// 	  iter != expectedTokens_.end(); ++iter)
//       {
// 	 std::cout << "Unreceived token " << (*iter).second.id << std::endl;
//       }

      while(!txQueue_.empty())
      {
	 if(txQueue_.front()->data) { delete txQueue_.front()->data; }
	 delete txQueue_.front();
	 txQueue_.pop();
      }
   }


   void Buffer::usePackets(bool use)
   {
      usePackets_ = use;
   }



   //
   // Functions related to tokens (transfer units between tasks)
   //


   // Tells dst to wait for this token, a kind of todo-list
   void Buffer::expectToken(tgToken token)
   {
      /*
	std::cout << std::setw(14) << sc_core::sc_time_stamp() 
	<< " rxbuf" << owner_ << "->expectToken (id =" << token.id
	<< ", src =" << token.srcPort
	<< ", dst =" << token.dstPort
	<< ", size =" << token.bytes << ")"
	<< std::endl;
      */
      expectedTokens_[token.id] = token;
   }

   void Buffer::removeToken(unsigned long int size)
   {    
      rxBufferUsed_ -= size;
//       std::cout << "Token (" << size << " B) removed, rx buffer used " 
// 		<< rxBufferUsed_ << " bytes" << std::endl;
      
      rxReadEvent_.notify(sc_core::SC_ZERO_TIME);
   }


   // Gives token from RX buffer to the receiving PE
   tgToken Buffer::rxGetToken()
   {
      if(receivedTokens_.empty())
      {
	 throw std::runtime_error("rxGetToken: no tokens to get");
      }
      tgToken token = receivedTokens_.front();
      receivedTokens_.pop();
      return token;
   }





   //
   // Functions related to packets (transfer units between PEs, one
   // token is split into one or multiple packets)
   //

   // Puts new packet from sending PE to the TX buffer
   void Buffer::txPutPacket(tgPacket* packet)
   {
      /*std::cout << owner_ << "->buf->TxPutPacket "
		<< sc_core::sc_time_stamp() << " "
		 << packet->size << " B, space left " << txSpaceLeft() << " B"
		 << std::endl;
      */

      // Sanity check
      if(txBufferSize_ > 0
	 && packet->size > txBufferSize_)
      {
	 std::ostringstream oss;
	 oss << "Error! Buf "<< owner_
	     << ": txPutPacket(): Packet is larger than tx  Buffer"
	     << packet->size << "B > " << txBufferSize_ << " B";
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());

	 //throw std::runtime_error
	 //   ("txPutPacket(): Packet is larger than tx  Buffer");
      }



      // Confirm that there is enough space in queue
      if(txBufferSize_ > 0
	 && packet->size > txSpaceLeft())
      {
	 throw std::runtime_error
	    ("txPutPacket(): Packet doesn't fit to Buffer");
      }
      // Put packet to fifo, update space left counter, and notify NoC
      // (or its adapter)
      txQueue_.push(packet);
      txBufferUsed_ += packet->size;
      if ( txBufferUsed_ > txMaxUsage_) {
	 txMaxUsage_ = txBufferUsed_;
	 //std::cout << "tx buf (" << owner_ << " max u is now " << txMaxUsage_ << std::endl;

      }
      txPacketEvent_.notify(sc_core::SC_ZERO_TIME);



      // Warn the user about possible satuation = excess growth of tx
      // buffer
      int warningLimit = 10e6; // 10e6 = 10 MB
      if (txBufferUsed_ > warningLimit
	 && saturationFlag==0) {

	 saturationFlag = 1; // Give warning only once
	 std::cout << "Potential NoC saturation. TxBuffer " << owner_ << " usage exceeds " << warningLimit << " B" << std::endl;
      }
      if (txBufferUsed_ < warningLimit/2
	 && saturationFlag ==1 ) {
	 
	 saturationFlag = 0;
	 std::cout << "Potential NoC saturation over. TxBuffer " << owner_ << " usage has dropped below " << warningLimit/2 << " B" << std::endl;
      }




   }

   // Gives one packet from TX queue to NoC
   tgPacket* Buffer::txGetPacket()
   {
      /*std::cout << "NoC takes TX Packet from buf " << owner_
 		<< " at " << sc_core::sc_time_stamp()
 		<< std::endl;
      */

      // Check that fifo is not empty, update space left counter and notify
      // event
      tgPacket* retval;
      if(txQueue_.empty())
      {
	 throw std::runtime_error
	    ("txGetPacket(): Tried to read from empty buffer");
      }
      retval = txQueue_.front();
      txQueue_.pop();

      // Fill the data field with token id
      retval->data = new unsigned char[retval->size];
      unsigned int* ptr = (reinterpret_cast<unsigned int*>(retval->data));
      for(unsigned int i = 0; i < retval->size / 4; ++i)
      {
	 *ptr = retval->id;
	 ptr++;
      }

      //       std::cout << "packet to " << std::hex << retval->address << std::dec
      // 		<< " id  " << retval->id << std::endl;

      txBufferUsed_ -= retval->size;
      measurements_.txBytes += retval->size;
      txReadEvent_.notify(sc_core::SC_ZERO_TIME);
      return retval;
   }





   /** Puts a packet arriving from NoC into buffer, writes log, 
       and notifies receiver if a token becomes complete
    */    
   void Buffer::rxPutPacket(tgPacket* packet)
   {
      //       std::cout << "CH Got packet to receive side "
      // 		<< sc_core::sc_time_stamp().value()
      // 		<< std::endl;

      

      // Minimun packet size is four bytes
      if(packet->size < 4)
      {
	 std::cout << "rxPutPacket(buffer at resource " << owner_
		   << "): got under four byte packet" << std::endl;
	 throw std::runtime_error("rxPutPacket: got under four byte packet");
      }
           

      // Get then token id from packet, used to identify packet's target
      unsigned int id = *(reinterpret_cast<unsigned int*>(packet->data));      
 

      // Check that we're really expecting this packet
      if(expectedTokens_.find(id) == expectedTokens_.end())
      {
	 std::ostringstream oss;
	 oss << "Error! Buffer (at resource " << owner_
	     << ").rxPutPacket(): received unexpected packet with token id "
	     << id << " and size " << packet->size << std::endl
	     << "dst resouze =" << packet->address  << std::endl
	     << "src port =" << packet->srcPort  << std::endl      
	     << "dst port =" << packet->dstPort  << std::endl   
	     << "ret port =" << packet->retPort  << std::endl
	     << "respsize =" << packet->respSize  << std::endl   
	     << "burstsize =" << packet->burstSize  << std::endl
	     << "#pkts =" << packet->packets  << std::endl
	     << "type =" <<        packet->type  << std::endl
	     << " at time " << sc_core::sc_time_stamp();
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }
 

      // Check if packet does not fit into buffer
      if(packet->size > rxSpaceLeft())
      {
	 std::cout << "rxPutPacket(" << owner_
		   << "): Packet (id" << id << ", " << packet->size
		   << " Bytes) doesn't fit to receive buffer. Only" 
		   << rxSpaceLeft() << " Bytes space left"
		   << std::endl;
	 throw std::runtime_error
	    ("rxPutPacket: Packet doesn't fit to receive buffer");
      }                  
     
      // Add its size to incoming buffer
      if(incomingData_.find(id) == incomingData_.end())
      {
	 incomingData_[id] = packet->size;
      }
      else
      {
	 incomingData_[id] += packet->size;
      }

      // Update the used space counter and statistics
      rxBufferUsed_ += packet->size;    
      measurements_.rxBytes += packet->size;      
      if ( rxBufferUsed_ > rxMaxUsage_) {
	 rxMaxUsage_ = rxBufferUsed_;
      }

      packet->srcPort     = expectedTokens_[id].srcPort;
      packet->retPort     = expectedTokens_[id].retPort;
      packet->dstPort     = expectedTokens_[id].dstPort;
      packet->type        = expectedTokens_[id].type;
      packet->packets     = expectedTokens_[id].packets;
      packet->respSize    = expectedTokens_[id].respBytes;
      packet->burstSize   = expectedTokens_[id].burstBytes;


      // Packets related to cache misses have their own "bypass lane"
      if(packet->type == CACHE_MISS && !usePackets_)
      {
 	 //std::cout << "got CACHE packet size " << packet->size 
	 //	   << " respSize " << packet->respSize << std::endl;
	 receivedCaches_.push(packet);
	 rxCacheEvent_.notify(sc_core::SC_ZERO_TIME);
      }      
      else if(usePackets_)
      {	 
	 receivedPackets_.push(packet);
	 rxPacketEvent_.notify(sc_core::SC_ZERO_TIME);
      }


      // Write log about regular write and read packets
      if(config_.getPacketStream() && packet->type != CACHE_MISS)
      {
	 **config_.getPacketStream() 
	    << std::setw(14) << sc_core::sc_time_stamp().value() << ";" 
	    << std::setw(8)  << expectedTokens_[id].id  << ";" 
	    << std::setw(7)  << packet->size  << ";"; 

	 
	 sc_core::sc_time pktInterval;

	 // Mark the beginning and end of token, and calculate the
	 // time interval after previous packet
	 if(incomingData_[id] == packet->size)
	 {
	    // 1st packet of a token
	    pktInterval = sc_core::sc_time_stamp() - expectedTokens_[id].timeSent;
	    **config_.getPacketStream() 
	       << std::setw(13) << "b;";
	 } else {
	    pktInterval = sc_core::sc_time_stamp() - lastRxTime_[id];
	    **config_.getPacketStream() << "            ;";
	 }
	 lastRxTime_[id] = sc_core::sc_time_stamp(); 

	 if(incomingData_[id] >= expectedTokens_[id].bytes)
	 {
	    // End of a token
	    **config_.getPacketStream() 
	       << std::setw(11) << "e;"; 
	 } else {
	    **config_.getPacketStream() << "          ;";
	 }

	 **config_.getPacketStream() 
	    << std::setw(14) << pktInterval.value() << ";"
	    << std::setw(9)  << expectedTokens_[id].srcPort << ";" 
	    << std::setw(9)  << expectedTokens_[id].dstPort << ";" 
	    << std::endl;

      }



      // Delete packet
      if(!usePackets_ && packet->type != CACHE_MISS)
      {
	 delete packet->data;
	 delete packet;
      }


      // If the a full token has been now received, remove temps and
      // notify receiver with an event
      if(incomingData_[id] >= expectedTokens_[id].bytes)
      {
	 // Update free space counter if received more than expected
	 //  Some networks migh give us more bytes than needed if
	 //  using for example fixed size packets and network
	 //  interface doesn't remove extra bytes... just to be sure.
	 rxBufferUsed_ -= (incomingData_[id] - expectedTokens_[id].bytes);
	 expectedTokens_[id].timeReceived = sc_core::sc_time_stamp();
	 

	 // Write log about regular write and read tokens
	 if(config_.getTokenStream() && expectedTokens_[id].type != CACHE_MISS)
	 {
	    // New info, 2013-08-19 es
	    unsigned int srcTaskId  = expectedTokens_[id].srcTask;
	    std::string srcTaskName = (config_.getResourceUser(srcTaskId))->getName();
	    Resource* srcRes        = (config_.getResourceByResourceUser(srcTaskId));
	    std::string srcResName  = srcRes->getName(); 

	    unsigned int dstTaskId  = (config_.getResourceUserByInPort(expectedTokens_[id].dstPort))->getId();
	    std::string dstTaskName = (config_.getResourceUserByInPort(expectedTokens_[id].dstPort))->getName();
	    Resource* dstRes        = (config_.getResourceByResourceUser(dstTaskId));
	    std::string dstResName  = dstRes->getName();

	    sc_core::sc_time  lat   = (expectedTokens_[id].timeReceived -  expectedTokens_[id].timeSent); 
	    sc_core::sc_time  t_cycle_rx_ = sc_core::sc_time (1000.0/dstRes->getFrequency(), sc_core::SC_NS);



	    if (dstTaskId == srcTaskId) {
	       dstTaskName = std::string(" "); //left empty for a self-loop
	    }
	    if (dstRes->getId() == srcRes->getId()) {
	       dstResName = std::string(" "); //left empty for an intra-PE transfer
	    }


	    **config_.getTokenStream() 
	       << std::setw(7)  << expectedTokens_[id].id << ";" 
	       << std::setw(17) << expectedTokens_[id].timeSent.value() << ";" 
	       << std::setw(15) << expectedTokens_[id].timeReceived.value() << ";" 
	       << std::setw(14) << lat.value() << ";" 
	       << std::setw(11) << lat / t_cycle_rx_ << ";" 
	       //<< std::setw(11) << round(lat / t_cycle_rx_) << ";" 
	       << std::setw(7)  << expectedTokens_[id].bytes << ";" 
	       << std::setw(9)  << expectedTokens_[id].packets << ";" 
	       << std::setw(15) << srcTaskName << ";"  //ES
	       << std::setw(15) << dstTaskName << ";" 
	       << std::setw(8)  << srcResName  << ";"
	       << std::setw(8)  << dstResName  << ";" 
	       << std::setw(9)  << expectedTokens_[id].srcPort << ";" 
	       << std::setw(9)  << expectedTokens_[id].dstPort << ";" 
	       << std::endl;
	 }

	 if(usePackets_ && expectedTokens_[id].type != CACHE_MISS) 
	 {
	    config_.addReceiveTime(expectedTokens_[id].dstPort);
	 }
	 
	 if(!usePackets_ && expectedTokens_[id].type != CACHE_MISS)
	 {
	    receivedTokens_.push(expectedTokens_[id]);
	    rxTokenEvent_.notify(sc_core::SC_ZERO_TIME);
	 }

	 expectedTokens_.erase(expectedTokens_.find(id));
	 incomingData_.erase(incomingData_.find(id));	 
	 lastRxTime_.erase(lastRxTime_.find(id));	 //ES

      }


      // Check if rx buffers gets too full
      int nTokensCannotGetFull = 0;
      std::ostringstream oss; // error message
      oss << "Resource " << owner_ 
	  << ". Buffer usage " << rxBufferUsed_
	  << " /  " << rxBufferSize_
	  << " Bytes, space left: " << rxSpaceLeft() << std::endl	
	  << "Following tokens are partially received but some (*) cannot be completed:" << std::endl;

      // Go through all partially received tokens
      for(std::map<unsigned long int, unsigned long int>::iterator iter = 
	     incomingData_.begin(); iter != incomingData_.end(); 
	  ++iter)
      {
	 int rx = iter->second; // bytes received so far
	 int exp = (expectedTokens_ [iter->first]).bytes; //total byte count coming
	 oss << " :: token ID " << iter->first << ", received "
	     << rx << " /"
	     << exp
	     << " Bytes";
	    
	    // Buffer has too little space to complete this token
	    if ((exp-rx) > rxSpaceLeft()
		|| rxSpaceLeft() < 4 ) {
	       nTokensCannotGetFull++;
	       oss << "  * ";
	    }
	 oss << std::endl;		 
      }
      // There's at least one token which cannot complete
      if (nTokensCannotGetFull > 0) {
	 std::cout << "Error at " << sc_core::sc_time_stamp() << std::endl
		   << oss.str();
	 sc_core::sc_stop();
      }

      /*std::cout << "Packet received, rx buffer capacity " 
	<< _rxBufferLeft << " bytes" << std::endl;
      */

      return;
   }  




   tgPacket* Buffer::rxGetPacket()
   {
//       std::cout << "CH RX packet taken "
// 		<< sc_core::sc_time_stamp().value()
// 		<< std::endl;


      if(receivedPackets_.empty())
      {
	 throw std::runtime_error("rxGetToken: no packets to get");
      }
      tgPacket* packet = receivedPackets_.front();
      receivedPackets_.pop();
      return packet;
   }

   tgPacket* Buffer::rxGetCache()
   {
      if(receivedCaches_.empty())
      {
	 throw std::runtime_error("rxGetCache: no cache packets to get");
      }
      tgPacket* packet = receivedCaches_.front();
      receivedCaches_.pop();
      return packet;
   }




   //
   // Methods related to state
   //

   unsigned long int Buffer::txSpaceLeft()
   {
      return txBufferSize_ != 0 ? txBufferSize_ - txBufferUsed_ : UINT_MAX;
   }

   bool Buffer::txPacketAvailable()
   {
      return !txQueue_.empty();
   }

   sc_core::sc_event* Buffer::txGetPacketAvailableEvent()
   {
      return &txPacketEvent_;
   }

   sc_core::sc_event* Buffer::txGetReadEvent()
   {
      return &txReadEvent_;
   }


   void Buffer::rxReserveSpace(unsigned long int bytes)
   {
//       std::cout << "RX reserve " << bytes << " bytes, used "
// 		<< rxBufferUsed_ << std::endl;
      rxBufferUsed_ += bytes;
   }

   void Buffer::rxFreeSpace(unsigned long int bytes)
   {
//       std::cout << "RX free " << bytes << " bytes, used "
// 		<< rxBufferUsed_ << std::endl;
      rxBufferUsed_ -= bytes;
   }

   void Buffer::txReserveSpace(unsigned long int bytes)
   {
      txBufferUsed_ += bytes;
   }

   void Buffer::txFreeSpace(unsigned long int bytes)
   {
      txBufferUsed_ -= bytes;
   }


   unsigned long int Buffer::rxSpaceLeft()
   {
      return rxBufferSize_ != 0 ? rxBufferSize_ - rxBufferUsed_ : UINT_MAX;
   }

   // 
   unsigned long int Buffer::rxBufSize()
   {
      return rxBufferSize_;
   }

   unsigned long int Buffer::txBufSize()
   {
      return txBufferSize_;
   }


   bool Buffer::rxTokenAvailable()
   {
      return !receivedTokens_.empty();
   }

   bool Buffer::rxPacketAvailable()
   {
      return !receivedPackets_.empty();
   }

   bool Buffer::rxCacheAvailable()
   {
      return !receivedCaches_.empty();
   }

   unsigned long int Buffer::getRxMaxUsage () {
      return rxMaxUsage_;
   }

   unsigned long int Buffer::getTxMaxUsage () {
      return txMaxUsage_;
   }

   sc_core::sc_event* Buffer::rxGetReadEvent()
   {
      return &rxReadEvent_;
   }

   sc_core::sc_event* Buffer::rxGetTokenAvailableEvent()
   {
      return &rxTokenEvent_;
   }

   sc_core::sc_event* Buffer::rxGetPacketAvailableEvent()
   {
      usePackets_ = true;
      return &rxPacketEvent_;
   }

   sc_core::sc_event* Buffer::rxGetCacheAvailableEvent()
   {
      return &rxCacheEvent_;
   }



   //
   // Functions related to statistics
   //

   const BufferMeasurements& Buffer::getMeasurements()
   {
      measurements_.rxUsed = rxBufferUsed_;
      measurements_.txUsed = txBufferUsed_;
      return measurements_;
   }


   // Return how many bytes have been received so far.
   unsigned long int Buffer::getReceivedBytes (unsigned int token_id) 
   {
      unsigned long int bytes = 0;

      if(incomingData_.count(token_id) > 0)
      {
	 bytes = incomingData_[token_id];
      }

      return bytes;
   }

   // Takes one expected, but infinished - token 
   // This function is used for finalizting the token log
   tgToken Buffer::rxPopExpToken()
   {
      if(expectedTokens_.empty())
      {
	 throw std::runtime_error("rxGetToken: no tokens to get");
      }
      
      std::map<unsigned long int, tgToken>::iterator it = expectedTokens_.begin();
      //std::cout << "Found incomplete token " << it->first 
      //		<< ", " << it->second.bytes << " B of data" 
      //		<< std::endl;
      tgToken token = it->second;
      expectedTokens_.erase(it);
      return token; // struct is returned-by-value
   }



   void Buffer::addIntraBytes(unsigned long int bytes)
   {
//       std::cout << "RX internal " << bytes << " bytes, used "
// 		<< rxBufferUsed_ << std::endl;
      measurements_.intraBytes += bytes;
   }

 
   void Buffer::updateUnfinishedTokensLatency()
   {
      for(std::map<unsigned long int, tgToken>::iterator 
	     iter = expectedTokens_.begin(); 
	  iter != expectedTokens_.end(); ++iter)
      {
	 // Update receive time
	 sc_core::sc_time lat = 
	    sc_core::sc_time_stamp() - (*iter).second.timeSent;
	 config_.addTokenLatency((*iter).second.srcPort, 
				 (*iter).second.dstPort, lat);
      }
   }



  
}

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
