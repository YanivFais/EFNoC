/**
 *
 * @file configuration.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: configuration.cc 81 2012-09-12 06:39:00Z ege $
 *
 */


#include "configuration.hh"
#include "buffer.hh"
#include "resource_user.hh" //Es
#include "resource.hh" //Es

#include <boost/lexical_cast.hpp>
#include <boost/interprocess/sync/file_lock.hpp> //ES
#include <iostream>
#include <sstream>
#include <exception>
#include <ctime>
#include <iostream>

#include <systemc>

namespace sctg
{

   /** Constructor. Lots of stuff, very important function for the whole TG
    */
   Configuration::Configuration(const boost::property_tree::ptree& ptroot,
				std::string& saveDir)
   {
      // Read simulation constraints from test case XML
      //using boost::property_tree::ptree;
      boost::property_tree::ptree pt = ptroot.get_child("constraints");
      boost::property_tree::ptree nocTree = 
	 ptroot.get_child("constraints.noc.<xmlattr>");


      // std::cout << "config()" << std::endl; // dbg, ES

      // Parse NoC generics
      for(boost::property_tree::ptree::const_iterator iter = nocTree.begin();
 	  iter != nocTree.end(); ++iter)
      {	 
	 try
	 {
	    generics_[(*iter).first] = 
	       boost::lexical_cast<int>((*iter).second.data());
	 }
	 catch(boost::bad_lexical_cast &e)
	 {
	    //std::cout << "config:catch!" << e.what() << std::endl; // ES
	 }
      }
      
      // Parse and set simulation's resolution, default is "1 ns"
      double time = pt.get<double>("sim_resolution.<xmlattr>.time", 1.0);
      std::string unit = pt.get<std::string>("sim_resolution.<xmlattr>.unit", "ns");
      sc_core::sc_set_time_resolution(time, parseUnit(unit));
      simResolution_ = sc_core::sc_time(time, parseUnit(unit));

      // Parse simulation's length, default is "0 ns"
      time = pt.get<double>("sim_length.<xmlattr>.time", 0.0);
      unit = pt.get<std::string>("sim_length.<xmlattr>.unit", "ns");
      simLength_ = sc_core::sc_time(time, parseUnit(unit));
      if (time < 0)
      {
	 throw std::runtime_error("Negative <sim_length>");
      }
    
      // Parse measurement interval, default is "0 ms"
      time = pt.get<double>("measurements.<xmlattr>.time", 0.0);
      unit = pt.get<std::string>("measurements.<xmlattr>.unit", "ms");
      measurementInterval_ = sc_core::sc_time(time, parseUnit(unit));
      measurementIntervalUnit_ = sc_core::sc_time(1.0, parseUnit(unit)); //ES
      if (time < 0)
      {
	 throw std::runtime_error("Negative time in <measurements>");
      }


      if(pt.get<std::string>("auto_stop.<xmlattr>.value", "false") == "true") {
	 auto_stop_ = true;
      } else {
	 auto_stop_ = false;
      }

      // Parse processing element's filename
      peLibFile_ = pt.get<std::string>("pe_lib.<xmlattr>.file");

      // Parse cost functions, just put them into stringvector
      for(boost::property_tree::ptree::const_iterator iter = pt.begin();
	  iter != pt.end(); ++iter)
      {
	 if((*iter).first == "cost_function")
	 {
	    costFunctions_.push_back((*iter).second.
				     get<std::string>("<xmlattr>.func"));
	 }
      }


      // Create path  measurements
      // Find all instances of "path_" from cost function strings
      //  and parse those
      for(size_t index = 0; index < costFunctions_.size(); ++index)
      {
	 size_t pos1 = 0;
	 size_t pos2 = 0;	 	 	 
	 std::string func = costFunctions_.at(index);
	 std::string dst;
	 std::string src;

	 while(true)
	 {
	    if((pos1 = func.find("path_", pos1)) != std::string::npos)
	    {
	       if((pos2 = func.find('_', pos1+5)) != std::string::npos)
	       {
		  src = func.substr(pos1+5, pos2-(pos1+5));
	       }	       
	       if((pos1 = func.find('_', pos2+1)) != std::string::npos)
	       {
		  dst = func.substr(pos2+1, pos1-pos2-1);
	       }
  	       //std::cout << "Measuring path from port '" << src
	       //	 << "' to port '" << dst << "'" << std::endl;
	       std::pair<unsigned long int, unsigned long int> sd = 
		  std::pair<unsigned long int, unsigned long int>
		  (boost::lexical_cast<long>(src), 
		   boost::lexical_cast<long>(dst));
	       std::pair<unsigned long int, unsigned long int> ds = 
		  std::pair<long int, unsigned long int>
		  (boost::lexical_cast<long>(dst), 
		   boost::lexical_cast<long>(src));
	       pathsFwd_.insert(sd);
	       pathsRev_.insert(ds);
	    }
	    else
	    {
	       break; // stop while(true)
	    }
	 }
      }

      // Create task exec time  measurements
      // Find all instances of "tt_" from cost function strings
      //  and parse those
      for(size_t index = 0; index < costFunctions_.size(); ++index)
      {
	 size_t pos1 = 0;
	 size_t pos2 = 0;	 	 	 
	 std::string func = costFunctions_.at(index);
	 std::string id;
	 unsigned long int count;

	 while(true)
	 {
	    if((pos1 = func.find("tt_", pos1)) != std::string::npos)
	    {
	       if((pos2 = func.find('_', pos1+3)) != std::string::npos)
	       {
		  id = func.substr(pos1+3, pos2-(pos1+3));
	       }
	       std::istringstream iss(func.substr(pos2+1, std::string::npos));
	       iss >> count;
	       pos1 = pos2;

  	       //std::cout << "Measuring exec time for task '" << id
	       //	 << "' at count '" << count << "'" << std::endl;
	       std::pair<unsigned long int, unsigned long int> pair = 
		  std::pair<unsigned long int, unsigned long int>
		  (boost::lexical_cast<long>(id), count);
	       taskTriggerTimes_.insert(pair);
	    }
	    else
	    {
	       break; // stop while(true)
	    }
	 }
      }


      // Parse RNG seed. Use current time as seed, if not defined in xml
      boost::optional<unsigned long int> seed = 
	 pt.get_optional<unsigned long int>("rng_seed.<xmlattr>.value");
    
      if(seed)
      { seed_ = *seed; }
      else
      { seed_ = static_cast<unsigned long int>(std::time(0)); }
    
      intEngine_.seed(seed_);
      realEngine_.seed(seed_);

      nextTokenId_ = 0;
    
      useExecMon_ = false;

    
      // Parse log file names and open them if available
      boost::optional<std::string> pktFile =
	 pt.get_optional<std::string>("log_packet.<xmlattr>.file");
      boost::optional<std::string> tokenFile =
	 pt.get_optional<std::string>("log_token.<xmlattr>.file");
      boost::optional<std::string> summaryFile =
	 pt.get_optional<std::string>("log_summary.<xmlattr>.file");
      boost::optional<std::string> peFile =
	 pt.get_optional<std::string>("log_pe.<xmlattr>.file");
      boost::optional<std::string> memFile =
	 pt.get_optional<std::string>("log_mem.<xmlattr>.file");
      boost::optional<std::string> appFile =
	 pt.get_optional<std::string>("log_app.<xmlattr>.file");
      boost::optional<std::string> execMonFile =
	 pt.get_optional<std::string>("log_exec_mon.<xmlattr>.file");

      if(saveDir.size() > 0 
	 && saveDir.at(saveDir.size()-1) != '/'
	 && saveDir.at(saveDir.size()-1) != '\\')
      {
	 saveDir.append("/");
      }

      if(pktFile)     
      {
	 (*pktFile) = saveDir + (*pktFile);
	 pktOutFile_ = boost::optional<std::ostream*>
	    (new std::ofstream((*pktFile).c_str())); 
      }
      if(tokenFile)   
      {
	 (*tokenFile) = saveDir + (*tokenFile);
	 tokenOutFile_ = boost::optional<std::ostream*>
	    (new std::ofstream((*tokenFile).c_str()));
      }
      if(summaryFile) 
      {
	 (*summaryFile) = saveDir + (*summaryFile);

	 // If some program (e.g. Excel) has opened log_summary.csv, 
	 // it cannot be updated. Check this and warn the user. 
	 // std::cout << "check if summary log is locked" << std::endl;
	 try {
	    boost::interprocess::file_lock flock((*summaryFile).c_str());
	 } catch (...){
	    std::cout << (*summaryFile).c_str() << "is locked and cannot be written" << std::endl;
	 }
	 summaryOutFile_ = boost::optional<std::ostream*>
	    (new std::ofstream((*summaryFile).c_str()));

      }
      if(peFile)      
      {
	 (*peFile) = saveDir + (*peFile);
	 peOutFile_ = boost::optional<std::ostream*>
	    (new std::ofstream((*peFile).c_str()));
      }
      if(memFile)      
      {
	 (*memFile) = saveDir + (*memFile);
	 memOutFile_ = boost::optional<std::ostream*>
	    (new std::ofstream((*memFile).c_str()));
      }
      if(appFile)
      {
	 (*appFile) = saveDir + (*appFile);
	 appOutFile_ = boost::optional<std::ostream*>
	    (new std::ofstream((*appFile).c_str()));
      }
      if(execMonFile)
      {
	 (*execMonFile) = saveDir + (*execMonFile);
	 execMonOutFile_ = boost::optional<std::ostream*>
	    (new std::ofstream((*execMonFile).c_str()));
	 std::cout << "execMon file = " << (*execMonFile).c_str() << std::endl;
      } else {
	 std::cout << "execMon file = not defined" << std::endl;
      }

#ifdef SCTG_USE_EXECMON
      serverIf_ = 0;
#endif
    
   }


   /** Destructor
    */
   Configuration::~Configuration()
   {
      if(pktOutFile_)     {delete (*pktOutFile_);     *pktOutFile_     = 0;}
      if(tokenOutFile_)   {delete (*tokenOutFile_);   *tokenOutFile_   = 0;}
      if(summaryOutFile_) {delete (*summaryOutFile_); *summaryOutFile_ = 0;}
      if(peOutFile_)      {delete (*peOutFile_);      *peOutFile_      = 0;}
      if(appOutFile_)     {delete (*appOutFile_);     *appOutFile_     = 0;}
   }



  
   /** Time
    */
   const sc_core::sc_time& Configuration::getSimLength() const
   { return simLength_; }

   const sc_core::sc_time& Configuration::getSimResolution() const
   { return simResolution_; }

   const std::string& Configuration::getPeLibFile() const
   { return peLibFile_; }

   const sc_core::sc_time_unit Configuration::parseUnit(std::string unit)
   {
      if(unit == "ns")
      {	return sc_core::SC_NS; }
      else if(unit == "ps")
      {	return sc_core::SC_PS; }
      else if(unit == "us")
      {	return sc_core::SC_US; }
      else if(unit == "ms")
      {	return sc_core::SC_MS; }
      else if(unit == "fs")
      {	return sc_core::SC_FS; }
      else if(unit == "s")
      {	return sc_core::SC_SEC;}
      else
      {
	 std::string errstr = "Unrecognized time unit " 
	    + unit
	    + ". Remenber to use lowercase letters: fs, ns, ps, us, ms, or s";
	 throw std::runtime_error(errstr.c_str());
      }
   }




   /** Random numbers and a unique token id
    */
   Configuration::RealEngineType& Configuration::getRealRNGEngine()
   { return realEngine_; }

   Configuration::IntEngineType& Configuration::getIntRNGEngine()
   { return intEngine_; }

   const unsigned long int Configuration::getSeed() const
   { return seed_; }

   double Configuration::random()
   { return random_(realEngine_); }

   unsigned int Configuration::getTokenId()
   {
      return nextTokenId_++;
   }
      



   /** Task connections
    */
   void Configuration::addPortConnection(unsigned long int source,
					 unsigned long int destination)
   {
      // Sanity check to prevent duplicate connections
      if (portConnections_.count(source))
      {
	 std::ostringstream oss;
	 oss << "Cannot overwrite port connection (" 
	     << source << " -> " << portConnections_[source] 
	     << ") with (" 
	     << source << " -> " << destination << ")"
	     << std::endl << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }



      if (revPortConnections_.count(source))
      {
	 std::ostringstream oss;
	 oss << "Srx Port id " 
	     << source << " is used both as inport_id and outport_id "
	     << std::endl << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }

      if (portConnections_.count(destination))
      {
	 std::ostringstream oss;
	 oss << "Dst Port id " 
	     << destination << " is used both as inport_id and outport_id "
	     << std::endl << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }






      // Actual operation is easier than checking the validity
      portConnections_[source] = destination;
      revPortConnections_[destination] = source;
   }

   // Returns the end point (inport id) of a conncetion
   unsigned long int Configuration::getDestination(unsigned long int source)
   {
      if(portConnections_.find(source) == portConnections_.end())
      {
	 std::ostringstream oss;
	 oss << "There's no destination for out_port " << source;
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }

      return portConnections_[source];// returns inport id
   }

   // Returns the start point (outport id) of a conncetion
   unsigned long int Configuration::getSource(unsigned long int dest)
   {
      if(revPortConnections_.find(dest) == revPortConnections_.end())
      {
	 std::ostringstream oss;
	 oss << "There's no source for in_port " << dest;
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }

      return revPortConnections_[dest]; // returns outport id
   }


   
   /** Map resources with their ids and users (tasks /mem_areas) together
    */
   void Configuration::addResourceMap(unsigned long int rid, Resource* pe)
   {
      // Sanity check
      if (resourceMap_.count(rid))
      {
	 std::ostringstream oss;
	 oss << "Resource id " << rid << " used by two resources: " 
	     << resourceMap_[rid]->getName()
	     << " and " 
	     << pe->getName()
	     << std::endl << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }

      resourceMap_[rid] = pe;
   }
      
   void Configuration::addResourceUserMap(unsigned long int tid, 
					  ResourceUser* task)
   {
      // Sanity check
      if (resourceUserMap_.count(tid))
      {
	 std::ostringstream oss;
	 oss << "Task/Mem_area id " << tid << " used by two: " 
	     << resourceUserMap_[tid]->getName()
	     << " and " 
	     << task->getName()
	     << std::endl << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }


      resourceUserMap_[tid] = task;
   }
   
   void Configuration::addResourceUserToResourceMap(unsigned long int tid, 
						    Resource* pe)
   {
      // Sanity check
      if (resourceResourceUserMap_.count(tid))
      {
	 std::ostringstream oss;
	 oss << "Task/Mem_area id " << tid << " is mapped to 2 resources: " 
	     << resourceResourceUserMap_[tid]->getName()
	     << " and " 
	     << pe->getName()
	     << std::endl << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }

      resourceResourceUserMap_[tid] = pe;
   }
    
    
   void Configuration::addResourceUserToInPortMap(unsigned long int pid, 
						  ResourceUser* task)
   {

      // Sanity check
      if (resourceUserInPortMap_.count(pid))
      {
	 std::ostringstream oss;
	 oss << "Inport " << pid << " used by two tasks: " 
	     << resourceUserInPortMap_[pid]->getName() << "(id " << resourceUserInPortMap_[pid]->getId() <<")"
	     << " and " 
	     << task->getName() << "(id " << task->getId() <<")"
	     << std::endl << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }

      resourceUserInPortMap_[pid] = task; 
   }
  



   /** Get pointers based on ID (res / task / port)
    */
   Resource* Configuration::getResource(unsigned long int rid)
   {
      if(resourceMap_.find(rid) == resourceMap_.end())
      {
	 std::ostringstream oss;
	 oss << "There's no resource with id " << rid;
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }
      return resourceMap_[rid];
   }

   ResourceUser* Configuration::getResourceUser(unsigned long int tid)
   {
      if(resourceUserMap_.find(tid) == resourceUserMap_.end())
      {
	 std::ostringstream oss;
	 oss << "There's no task or mem_area with id " << tid;
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }
      return resourceUserMap_[tid];
   }


   Resource* Configuration::getResourceByResourceUser(unsigned long int tid)
   {
      if(resourceResourceUserMap_.find(tid) == resourceResourceUserMap_.end())
      {
	 std::ostringstream oss;
	 oss << "Task (or mem_area) with  id:" << tid << " is not mapped to any resource";
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }
      return resourceResourceUserMap_[tid];
   }


   // ES
   unsigned long int Configuration::getPeByInport(unsigned long int pid)
   {

      ResourceUser* ru  = getResourceUserByInPort (pid);                          
      Resource*     r   = getResourceByResourceUser (ru->getId());
  
      return r->getId();
   }


   ResourceUser* Configuration::getResourceUserByInPort(unsigned long int pid)
   {
      if(resourceUserInPortMap_.find(pid) == resourceUserInPortMap_.end())
      {
	 std::ostringstream oss;
	 oss << "There's no task or mem_area with in_port " << pid;
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }
      return resourceUserInPortMap_[pid];
   }



   /** Buffers
    */
   void Configuration::addBufferToResource(Buffer* buffer, unsigned long int pe)
   {
      resourceBufferMap_[pe] = buffer;
   }

   Buffer* Configuration::getBufferByResource(unsigned long int pe)
   {
      if(resourceBufferMap_.find(pe) == resourceBufferMap_.end())
      {
	 std::ostringstream oss;
	 oss << "No buffer found for resource " << pe;
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }
      return resourceBufferMap_[pe];
   }

   BufferInterface* Configuration::getBufferIf(unsigned long int agent)
   {
      if(resourceBufferMap_.find(agent) == resourceBufferMap_.end())
      {
	 std::ostringstream oss;
	 oss << "No buffer found for agent " << agent;
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }
      return resourceBufferMap_[agent];
   }

 


   /** Grouping and mapping
    */
   void Configuration::addTaskToGroup(unsigned long int task,
				      unsigned long int group)
   {
      // Duplicate mapping of the same task should be detected already
      // in addResourceUserToResourceMap()
      taskGroupMap_[task] = group;
   }
   
   void Configuration::addGroupToPe(unsigned long int group,
				    unsigned long int pe)
   {

      // Sanity check
      if (groupPeMap_.count(group))
      {
	 if (groupPeMap_[group] != pe)
	 {
	    std::ostringstream oss;
	    oss << "Group " << group  << " is mapped to 2 resources: " 
		<< groupPeMap_[group] << " and " << pe << std::endl << std::endl;
	    throw std::runtime_error(oss.str().c_str());
	 }
      }


      groupPeMap_[group] = pe;
   }

   unsigned long int Configuration::getGroup(unsigned long int task)
   {
      if(taskGroupMap_.find(task) == taskGroupMap_.end())
      {
	 std::ostringstream oss;
	 oss << "No group found for task " << task;
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }
      return taskGroupMap_[task];
   }

   unsigned long int Configuration::getPeByGroup(unsigned long int group)
   {
      if(groupPeMap_.find(group) == groupPeMap_.end())
      {
	 std::ostringstream oss;
	 oss << "No PE found for group " << group;
	 std::cout << oss.str() << std::endl;
	 throw std::runtime_error(oss.str().c_str());
      }
      return groupPeMap_[group];
   }



   const sc_core::sc_time& Configuration::getMeasurementInterval() const
   {
      return measurementInterval_;
   }

   const sc_core::sc_time& Configuration::getMeasurementIntervalUnit() const
   {
      return measurementIntervalUnit_;
   }

   boost::optional<std::ostream*>& Configuration::getPacketStream()
   {
      return pktOutFile_;
   }

   boost::optional<std::ostream*>& Configuration::getTokenStream()
   {
      return tokenOutFile_;
   }

   boost::optional<std::ostream*>& Configuration::getSummaryStream()
   {
      return summaryOutFile_;
   }

   boost::optional<std::ostream*>& Configuration::getPeStream()
   {
      return peOutFile_;
   }

   boost::optional<std::ostream*>& Configuration::getMemStream()
   {
      return memOutFile_;
   }
   
   boost::optional<std::ostream*>& Configuration::getAppStream()
   {
      return appOutFile_;
   }

   boost::optional<std::ostream*>& Configuration::getExecMonStream()
   {
      return execMonOutFile_;
   }

   /** Noc
    */
   const std::string& Configuration::getNocClass()
   {
      return nocClass_;
   }
   
   const std::string& Configuration::getNocType()
   {
      return nocType_;
   }

   const std::string& Configuration::getNocSubType()
   {
      return nocSubType_;
   }

   void Configuration::setNocClass(std::string& s)
   {
      nocClass_ = s;
   }
   
   void Configuration::setNocType(std::string& s)
   {
      nocType_ = s;
   }

   void Configuration::setNocSubType(std::string& s)
   {
      nocSubType_ = s;
   }


   /** Returns a reference to a property tree rooting to <noc> tag
    */
   const std::map<std::string, int>& Configuration::getGenerics()
   {
      return generics_;
   }


   /** Get resource/group/task maps' begin and end
    */
   std::map<unsigned long int, Resource*>::iterator 
   Configuration::getResourceBegin()
   {
      return resourceMap_.begin();
   }

   std::map<unsigned long int, Resource*>::iterator 
   Configuration::getResourceEnd()
   {
      return resourceMap_.end();
   }

   std::map<unsigned long int, unsigned long int>::iterator 
   Configuration::getGroupPeBegin()
   {
      return groupPeMap_.begin();
   }

   std::map<unsigned long int, unsigned long int>::iterator 
   Configuration::getGroupPeEnd()
   {
      return groupPeMap_.end();
   }

   std::map<unsigned long int, unsigned long int>::iterator 
   Configuration::getTaskGroupBegin()
   {
      return taskGroupMap_.begin();
   }

   std::map<unsigned long int, unsigned long int>::iterator 
   Configuration::getTaskGroupEnd()
   {
      return taskGroupMap_.end();
   }



   /** Set/request whether Execution Monitor is used or not
    */
   void Configuration::useExecMon(bool use)
   {
      useExecMon_ = use;
   }
   
   bool Configuration::useExecMon()
   {
      return useExecMon_;
   }

#ifdef SCTG_USE_EXECMON      
   void Configuration::setTcpServer(TcpServerIf* server)
   {
      serverIf_ = server;
   }

   TcpServerIf* Configuration::getTcpServer()
   {
      return serverIf_;
   }
#endif




   /** Return all cost functions and variables
    */
   std::vector<std::string>& Configuration::getCostFunctions()
   {
      return costFunctions_;
   }
   std::map<std::string, double>& Configuration::getCostVariables()
   { 
      return costVariables_;
   }



   /** Tokens
    */
   void Configuration::addTokenLatency(unsigned long int src,
				       unsigned long int dst,
				       sc_core::sc_time& latency)
   {
      std::map<unsigned long int, 
	       std::map<unsigned long int, sc_core::sc_time> >::iterator outer;
      std::map<unsigned long int, sc_core::sc_time>::iterator inner;

      tokenLatency_[src][dst] += latency;
      tokenCount_[src][dst]   += 1;
      if(tokenLatencyMax_[src][dst] < latency)
      {
	 tokenLatencyMax_[src][dst] = latency;
      }
      
      if(tokenLatencyMin_.find(src) != tokenLatencyMin_.end() &&
	 tokenLatencyMin_[src].find(dst) != tokenLatencyMin_[src].end())
      {
	 if(tokenLatencyMin_[src][dst] > latency)
	 {
	    tokenLatencyMin_[src][dst] = latency;
	 }
      }
      else
      {
	 tokenLatencyMin_[src][dst] = latency;
      }

   }

   std::map<unsigned long int, std::map<unsigned long int, sc_core::sc_time> >&
   Configuration::getTokenLatency()
   {
      return tokenLatency_;
   }

   std::map<unsigned long int, std::map<unsigned long int, sc_core::sc_time> >&
   Configuration::getTokenLatencyMax()
   {
      return tokenLatencyMax_;
   }

   std::map<unsigned long int, std::map<unsigned long int, sc_core::sc_time> >&
   Configuration::getTokenLatencyMin()
   {
      return tokenLatencyMin_;
   }

   std::map<unsigned long int, std::map<unsigned long int, unsigned long int> >&
   Configuration::getTokenCount()
   {
      return tokenCount_;
   }

   void Configuration::addSendTime(unsigned long int port)
   {
      // if(pathsFwd_.find(port) == pathsFwd_.end())
      // {
      // 	 return; // No path declared
      // }

      for(std::multimap<unsigned long int, unsigned long int>::iterator iter =
	     pathsFwd_.lower_bound(port); iter != pathsFwd_.upper_bound(port); 
	  ++iter)
      {
	 std::ostringstream oss;
	 oss << port << "_" << (*iter).second;
	 portSendTime_[oss.str()].push(sc_core::sc_time_stamp());      
      }
      
   }

   void Configuration::addReceiveTime(unsigned long int port)
   {
      if(pathsRev_.find(port) == pathsRev_.end())
      {
	 return; // NO path declared
      }
      
      for(std::multimap<unsigned long int, unsigned long int>::iterator iter =
	     pathsRev_.lower_bound(port); iter != pathsRev_.upper_bound(port);
	  ++iter)
      {
	 std::ostringstream oss;
	 oss << (*iter).second << "_" << port;

	 if(portSendTime_[oss.str()].empty())
	 {
	    std::ostringstream ossi;
	    ossi << "Path measurements: destination port"
		 << " reached but no send time for source port for path " 
		 << oss.str()
		 << " (check that there's only one token received per"
		 << " every sent one)";
	    std::cout << ossi.str() << std::endl;
	    throw std::runtime_error(ossi.str().c_str());
	 }

	 sc_core::sc_time lat = sc_core::sc_time_stamp() - 
	    portSendTime_[oss.str()].front();
      
	 portSendTime_[oss.str()].pop();

	 pathCount_[oss.str()] += 1;
	 totPathLat_[oss.str()] += lat;

	 if(maxPathLat_[oss.str()] < lat)
	 { maxPathLat_[oss.str()] = lat; }
      
	 if(minPathLat_.find(oss.str()) == minPathLat_.end() ||
	    minPathLat_[oss.str()] > lat)
	 { minPathLat_[oss.str()] = lat; }


      }


      // unsigned long int source = pathsRev_[port];

      // if(portSendTime_[source].empty())
      // {
      // 	 std::ostringstream oss;
      // 	 oss << "Path measurements: destination port with id " << port
      // 	     << " reached but no send time for source port " << source
      // 	     << " (check that there's only one token received per"
      // 	     << " every sent one)";
      // 	 std::cout << oss.str() << std::endl;
      // 	 throw std::runtime_error(oss.str().c_str());
      // }

      // sc_core::sc_time lat = sc_core::sc_time_stamp() - 
      // 	 portSendTime_[source].front();
      
      // portSendTime_[source].pop();

      // pathCount_[port] += 1;
      // totPathLat_[port] += lat;

      // if(maxPathLat_[port] < lat)
      // { maxPathLat_[port] = lat; }
      
      // if(minPathLat_.find(port) == minPathLat_.end() ||
      // 	 minPathLat_[port] > lat)
      // { minPathLat_[port] = lat; }

   }



   /** Paths
    */   
   std::map<std::string, sc_core::sc_time>& 
   Configuration::getTotPathLat()
   {
      return totPathLat_;
   }

   std::map<std::string, sc_core::sc_time>& 
   Configuration::getMaxPathLat()
   {
      return maxPathLat_;
   }

   std::map<std::string, sc_core::sc_time>& 
   Configuration::getMinPathLat()
   {
      return minPathLat_;
   }

   std::map<std::string, unsigned long int>& 
   Configuration::getPathCount()
   {
      return pathCount_;
   }




   void Configuration::taskTriggered
   (unsigned long int task, unsigned long int times)
   {
      for(std::multimap<unsigned long int, unsigned long int>::iterator iter =
	     taskTriggerTimes_.lower_bound(task); 
	  iter != taskTriggerTimes_.upper_bound(task); ++iter)
      {

	 if((*iter).second == times)
	 {
	    std::ostringstream oss;
	    oss << "tt_" << task << "_" << times;
	    costVariables_[oss.str()] = sc_core::sc_time_stamp() / 
	       sc_core::sc_time(1000.0, sc_core::SC_MS);
	 
	    if(auto_stop_)
	    {
	       // Remove used task trigger times and
	       // stop simulation after all have been compeleted.
	       taskTriggerTimes_.erase(iter);
	       if(taskTriggerTimes_.empty())
	       {
		  throw std::runtime_error(std::string("Auto-stop due to ") + oss.str());
		  //sc_core::sc_stop(); // Stop simulation
	       }
	    }
	    
	 }

	 
      }
   }
   

   void Configuration::setScheduleSeq(int pe, int task, int seq)
   {
      // std::cout << "Adding to PE " << pe << " seq " << seq
      //	<< " task " << task << std::endl;
      scheduleSeqs_[pe][seq] = task;
   }

   const std::map<int, int>& Configuration::getScheduleSeq(int pe)
   {      
      return scheduleSeqs_[pe];
   }

   void Configuration::setFixedPriority(int pe, int task, int priority)
   {
      fixedPriority_[pe][priority] = task;
   }

   const std::map<int, int>& Configuration::getFixedPriority(int pe)
   {
      return fixedPriority_[pe];
   }

}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
