/**
 *
 * @file resource_user.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: resource_user.cc 81 2012-09-12 06:39:00Z ege $
 *
 */

#include "resource_user.hh"
#include "common.hh" // es

#include <boost/lexical_cast.hpp>

#include <systemc>


namespace sctg
{
   ResourceUser::ResourceUser(const boost::property_tree::ptree& pt,
			      Configuration& config)
      :
      config_(config)
   {
      using boost::property_tree::ptree;

    
      // std::cout << "  res_user() "<< std::endl; //ES 
      

      // Read in task's id and other attributes from XML
      // pt is the attribute list of a <resource ...>
      boost::property_tree::ptree::const_iterator iter = pt.begin(); //es
      id_ = sctg::convToInt (iter, "id");
	       

      // Default name is "Task <id>", if name is not defined in XML
      name_ = pt.get<std::string>
	 ("<xmlattr>.name", "Task " + boost::lexical_cast<std::string>(id_));

      // Class must be present, ES added the default value "general" 2012-05-28
      class_ = pt.get<std::string>("<xmlattr>.class", "general");
      // Read in all in_ports and out_ports

      for(ptree::const_iterator iter = pt.begin(); iter != pt.end(); ++iter)
      {

	 if((*iter).first == "in_port")
	 {
	    // std::cout << "  r inport "; //<< std::endl; //ES 
	       	       
	    unsigned long int in_port = sctg::convToInt (iter, "<xmlattr>.id");
	    inPorts_.push_back(in_port);
	    config.addResourceUserToInPortMap(in_port, this);	    
	    
	    // 	    std::cout << "ResourceUser " << getName() << " has in_port " 
	    // 		      << in_port << std::endl;
	    // std::cout << in_port << std::endl; // ES
	 }
	 else if((*iter).first == "out_port")
	 {
	    // std::cout << "  r outport "; //ES 
	    unsigned long int out_port =  sctg::convToInt (iter, "<xmlattr>.id");
	    outPorts_.push_back(out_port);

	    // 	    std::cout << "ResourceUser " << getName() << " has out_port " 
	    // 		      << out_port << std::endl;
	    // std::cout << out_port << std::endl; // ES
	    }
      }
   }
   
   ResourceUser::~ResourceUser()
   {
   }

   const std::string& ResourceUser::getName()
   { return name_; }

   const std::string& ResourceUser::getClass()
   { return class_; }

   unsigned long int ResourceUser::getId()
   { return id_; }

   std::vector<unsigned long int>& ResourceUser::getOutPorts()
   { return outPorts_; }

   std::vector<unsigned long int>& ResourceUser::getInPorts()
   { return inPorts_;  }
}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
