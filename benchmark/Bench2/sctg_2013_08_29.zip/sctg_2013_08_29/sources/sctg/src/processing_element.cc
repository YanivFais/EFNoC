/**
 *
 * @file processing_element.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: processing_element.cc 207 2013-08-28 13:00:38Z ege $
 *
 */

#include "common.hh"
#include "processing_element.hh"
#include "memory_model.hh"
#include <iostream>
#include <exception>
#include <algorithm>

namespace sctg
{
   /** Constructor
    */
   ProcessingElement::ProcessingElement(sc_core::sc_module_name name, 
					const boost::property_tree::ptree& pt,
					const boost::property_tree::ptree& peLib,
					sctg::Configuration& config)
      : sctg::Resource(name, pt, config),
	//Moved to resource: config_(config), measureStart_(),measureEnd_(),
	iCacheMissInterval_(0),
	dCacheMissInterval_(0),
	iLineSize_         (0),
	dLineSize_         (0),
	iMemId_            (0),
	dMemId_            (0),
	nextIMiss_         (0),
	nextDMiss_         (0),
	firstTime_         (true),
	running_           (false)
   {
      currentTask_ = 0;
      currentState_ = IDLE;

      intraGroupRxCost_ = 0;
      intraGroupTxCost_ = 0;
      interGroupRxCost_ = 0;
      interGroupTxCost_ = 0;
      interPeRxCost_    = 0;
      interPeTxCost_    = 0;
      cycleLength_      = sc_core::sc_time(1.0 / getFrequency(), sc_core::SC_US);


      // Read the PE's static properties from PE_lib XML
      using boost::property_tree::ptree;
      ptree node = peLib.get_child("processing_element_lib");
      // Search for correct pe type
      ptree::const_iterator iter;
      for(iter = node.begin(); iter != node.end(); ++iter)
      {	
	 if((*iter).first == "processing_element" &&
	    (*iter).second.get<std::string>("<xmlattr>.type") == getType() )
	 {
	    break; // Found, stop search
	 }
      }
      if(iter == node.end())
      {
	 // Did not find
	 std::string err = "Did not find processing element \"" + getType() +
	    "\" from pe_lib";
	 throw std::runtime_error(err.c_str());
      }
      intOps_   = sctg::convToDouble (iter, "<xmlattr>.int_ops");
      floatOps_ = sctg::convToDouble (iter, "<xmlattr>.float_ops");
      memOps_   = sctg::convToDouble (iter, "<xmlattr>.mem_ops");

      // Add communication costs if they exists
      boost::optional<const ptree&> costs = (*iter).second.get_child_optional
	 ("communication_costs");
    
      boost::optional<const ptree&> temp;
      if(costs)
      {
	 for(ptree::const_iterator i = (*costs).begin(); i != (*costs).end(); ++i)
	 {
	    if((*i).first == "intragroup")
	    {
	       temp = (*i).second.get_child_optional("receive");
	       if(temp) {intraGroupRxCost_ = 
		     new Amount<double>((*temp), config_);}
	       temp = (*i).second.get_child_optional("send");
	       if(temp) {intraGroupTxCost_ = 
		     new Amount<double>((*temp), config_);}
	    }
	    else if((*i).first == "intergroup")
	    {
	       temp = (*i).second.get_child_optional("receive");
	       if(temp) {interGroupRxCost_ = 
		     new Amount<double>((*temp), config_);}
	       temp = (*i).second.get_child_optional("send");
	       if(temp) {interGroupTxCost_ = 
		     new Amount<double>((*temp), config_);}
	    }
	    else if((*i).first == "interpe")
	    {
	       temp = (*i).second.get_child_optional("receive");
	       if(temp) {interPeRxCost_ = 
		     new Amount<double>((*temp), config_);}
	       temp = (*i).second.get_child_optional("send");
	       if(temp) {interPeTxCost_ = 
		     new Amount<double>((*temp), config_);}
	    }
	 }
      }
          
      // Parse DMA enable and cache misses from test case XML where PE is instantiated    
      dmaEnabled_ = false; // default if attribute missing/corrupt
      using boost::property_tree::ptree;
      for(ptree::const_iterator iter = pt.begin(); iter != pt.end(); ++iter)
      {

	 try {
	    dmaEnabled_ = (*iter).second.get<bool> ("dma");
	    //std::cout << "  DMA is ON = " << dmaEnabled_ << std::endl;
	 }
	 catch (std::exception& e) {	
	    // std::cout << "  dma setting of PE " << getName() << "is corrupted  " << dmaEnabled_ << std::endl;
	 }

	 if((*iter).first == "cache")
	 {	    
	    for(ptree::const_iterator iter2 = (*iter).second.begin(); 
		iter2 != (*iter).second.end(); ++iter2)
	    {
	       if((*iter2).first == "i_miss")
	       {
		  iLineSize_ = sctg::convToInt (iter2, "<xmlattr>.line_size");
		  iMemId_    = sctg::convToInt (iter2, "<xmlattr>.mem_area_id");
		  iCacheMissInterval_ = new Amount<double>((*iter2).second,
							   config);
	       }
	       
	       if((*iter2).first == "d_miss")
	       {
		  dLineSize_ = sctg::convToInt (iter2, "<xmlattr>.line_size");
		  dMemId_    = sctg::convToInt (iter2, "<xmlattr>.mem_area_id");
		  dCacheMissInterval_ = new Amount<double>((*iter2).second,
							   config);
	       }
	    }  
	 }
      }

      // Read requests after cache miss cannot be larger than 1 packet
      if (packetSize_ > 7) 
      {
	 missReqSize_ = 8; // bytes
      }
      else 
      {
	 missReqSize_ = roundTo4n (packetSize_);
      }
      // std::cout << "missreqsize = " << missReqSize_ << std::endl;
      
      // Check scheduling algorithm
      boost::optional<std::string> sch = 
	 pt.get_optional<std::string>("<xmlattr>.scheduler");

      scheduler_ = FIFO;
      if(sch)
      {
	 if(*sch == "fifo")
	 {
	    scheduler_ = FIFO;
	 }
	 else if(*sch == "fixed_priority")
	 {
	    scheduler_ = FIXED_PRIORITY;
	 }
	 else if(*sch == "sequence")
	 {
	    scheduler_ = SEQUENCE;
	 }
	 else
	 {
	    std::cerr << "Unkown scheduling algorithm \"" << *sch
		      << "\". Defaulting to FIFO" << std::endl;
	    scheduler_ = FIFO;
	 }
      }


      std::cout << "PE " << std::setw(8) << getName() << ": int (" << intOps_ << ") float (" << floatOps_
		<< ") mem (" << memOps_ << ")" 
		<< ", f:" << getFrequency() << " MHz" 
		<< ", dma " << dmaEnabled_;
      if (iLineSize_) {
	 std::cout << ", I+D $";
      }

      if(costs) {
	 std::cout << ", comm costs";
      }
      std::cout << std::endl;


      // Start threads
      SC_THREAD(thread);

      if(dmaEnabled_)
      {
	 SC_THREAD(txDma);
	 SC_THREAD(rxDma);
      }
   }



   /** Destructor
    */
   ProcessingElement::~ProcessingElement()
   {
      if(intraGroupRxCost_) { delete intraGroupRxCost_; intraGroupRxCost_ = 0; }
      if(intraGroupTxCost_) { delete intraGroupTxCost_; intraGroupTxCost_ = 0; }
      if(interGroupRxCost_) { delete interGroupRxCost_; interGroupRxCost_ = 0; }
      if(interGroupTxCost_) { delete interGroupTxCost_; interGroupTxCost_ = 0; }
      if(interPeRxCost_) { delete interPeRxCost_; interPeRxCost_ = 0; }
      if(interPeTxCost_) { delete interPeTxCost_; interPeTxCost_ = 0; }

      updateMeasurements();


      // Print statistics
      printUtilStats();
      printCommStats(iLineSize_, dLineSize_, missReqSize_);
   }



   /*
    * The main operation
    */
   void ProcessingElement::thread()
   {
      double waitTime = 1.0;

      // Schedule first task
      bool sched       = true;
      bool sendStalled = false;
    
      while(true)
      {

	 // Schedule a new task for execution
	 if(currentTask_ == 0 || sched || currentTask_->getState() != READY)
	 {
	    Task* old    = currentTask_;
	    currentTask_ = schedule();    
	    sched        = false;
	    if(old != currentTask_)
	    {
	       sendStalled = false;
	    }
	 }
	

	 /*
	  * 1. If some token is coming, handle it
	  * 2. Otherwise execute task
	  */
	 if(buffer_->rxTokenAvailable())
	 {
  	    //std::cout << "token available " 
	    //		    << getName() << std::endl;
	    tgToken tokenIn = buffer_->rxGetToken();


	    // 2013-08-14 I decided not to model any delay for token
	    // reception. (ES) At least not here. The reason is that
	    // it pre-empts other operations, which does work
	    // functionally but complicates time measurements for
	    // operations. (E.g. rx time would be summed to exec
	    // cycles if great care is not taken). If it's modeled
	    // at execution stage, things might be simpler...
	    

	    config_.addReceiveTime(tokenIn.dstPort);
	    
	    Task* receiver = dynamic_cast<Task*>
	       (config_.getResourceUserByInPort(tokenIn.dstPort));

	    // Sanity check
	    if(!receiver)
	    {
	       std::ostringstream oss;
	       oss << "No task with in_port " << tokenIn.dstPort
		   << " found on PE " << getName();
	       std::cout << oss.str() << std::endl;
	       throw std::runtime_error(oss.str().c_str());
	    }
	    

	    // Task handles the completion of read operation differently from other operations
	    if(currentTask_ && currentTask_->getOperation() == WAIT_RESP 
	       && currentTask_ == receiver)
	    {
	       /*  std::cout << "WAIT_RESP consuming token" << tokenIn.id
	       	 << " which has " << tokenIn.bytes 
	       	 << " bytes" << std::endl;
	       */
	       currentTask_->consume(tokenIn.bytes);
	       buffer_->removeToken(tokenIn.bytes);
	    }
	    else
	    {
	       /* std::cout << "OTHERS consuming token "  << tokenIn.id
	       	 << " which has " << tokenIn.bytes 
	       	 << " bytes" << std::endl;
	       */
	       receiver->receive(tokenIn);
	       fifoScheduler_.push(receiver);
	    }


#ifdef SCTG_USE_EXECMON	    
	    if(!tokenIn.isEvent)
	    {
	       tokenQueue_.push(tokenIn);
	    }
#endif

	 }
	 else if(currentTask_ == 0 || sendStalled) // No tasks to execute
	 {
  	    //std::cout << "nothing to execute " 
	    //		    << getName() << std::endl;
	    sendStalled   = false;
	    currentState_ = IDLE;
	    //measureStart_ = sc_core::sc_time_stamp();
	    wait(eventEvent_ 
		 | *(buffer_->rxGetTokenAvailableEvent())
		 | *(buffer_->txGetReadEvent()));
	    updateMeasurements();	    
	 }
	 else
	 {
	    // Check what is current operation
	    /*
	     * 1. If sending, send packets one by one
	     * 2. Otherwise, execute until all executed or incoming packet
	     */
	    tgToken token;
	    tgPacket* packet;
	    unsigned long int port;
	    unsigned long int task;
	    unsigned long int size;
	    Resource* pe;
	    unsigned long int execcycles = currentTask_->getAmount();

	    // Debug print when something starts, ES 2012-05-31
	    if (currentTask_->isNewOperation()) 
	    {
	       sc_time us1 (1, SC_US);
	       sc_time def_tu = sc_get_time_resolution();
	       double k = us1 / def_tu;
	       sc_time tnow = sc_time_stamp()/k;

	       //std::cout << getName() << " in state "
	       //	 << sctg::OperationType_str[currentTask_->getOperation()] 
	       //	 << " for "
	       //	 << execcycles << " clk cycles, starting at " // << std::endl; // ES
	       //	 << tnow.to_double() << " us." << std::endl; //;
	    }




	    /* Perform the task's action */
	    switch(currentTask_->getOperation())
	    {
	       case DONE:
		  // This state is entered after task has executed its current
		  // trigger
		  currentTask_->consume(1); // consume the dummy cycle
		  if(scheduler_ == SEQUENCE)
		  {
		     ++iter_;		     
		  }
		  sched = true;
		  break;

	       case EXECUTE:		  		  
		  
		  // If caches are enabled, handle cache misses, 
		  // i.e. read memory and calculate when the next miss occurs
		  if(iCacheMissInterval_ && dCacheMissInterval_)
		  {		     
		     // If there's cache miss, this function consumes
		     // time, otherwise returns immediately
		     execcycles = cacheMiss(execcycles);
		  }

		  // Model the execution delay by waiting
		  currentState_ = EXECUTING;
		  currentTask_->changeState(RUN);
		  wait(cycleLength_ * execcycles);
		  updateMeasurements();

		  currentTask_->consume(execcycles);	    
		  currentTask_->changeState(WAIT);
 		  //std::cout << "At " << sc_core::sc_time_stamp() 
		  //	    << " Task " << currentTask_->getName()
		  //	    << " executes " << execcycles
		  //	    << " cycles, and has still " << currentTask_->getAmount()
		  //	    << " clock cycles left to execute" << std::endl;

		  

		  break;

	       case WAIT_RESP:
		  // Wait for a responce for READ command
		  currentState_ = READING;
		  wait(eventEvent_ 
		       | *(buffer_->rxGetTokenAvailableEvent())
		       | *(buffer_->txGetReadEvent()));
		  updateMeasurements();
		  break;



	       case SEND:
	       case READ:
		  currentTask_->changeState(RUN);
		  if(currentTask_->getOperation() == SEND)
		  { 
		     currentState_ = SENDING; 
 		     /* std::cout << "PE " << getName() << " sending" << std::endl;
		     std::cout << "At " << sc_core::sc_time_stamp() 
			       << " Task " << currentTask_->getName()
			       << " has " << currentTask_->getAmount()
			       << " bytes left to send" << std::endl;
		     */
		  
		  }
		  else
		  { 
		     currentState_ = READING; 
//  		     std::cout << "PE " << getName() << " reading" << std::endl;
//		     std::cout << "At " << sc_core::sc_time_stamp() 
//			       << " Task " << currentTask_->getName()
//			       << " has " << currentTask_->getAmount()
//			       << " bytes of req left to send" << std::endl;

		  }


		  
		  // Construct a token if this is first time for this send/read
		  if(currentTask_->isNewOperation())
		  {

		     token.id       = config_.getTokenId();
		     token.timeSent = sc_core::sc_time_stamp(); // Creation time
		     token.srcPort  = currentTask_->getOutPort();
		     token.dstPort  = config_.getDestination(currentTask_->getOutPort());		    
		     token.srcTask  = currentTask_->getId(); //ES

		     // Mem operations operate in bursts, 
		     // =certain num of consecutive addresses.
		     token.burstBytes  = currentTask_->getBurstAmount();
		     // std::cout << "Burst size [bytes] = " << token.burstBytes << std::endl; // ES		     
		     
		     if(currentTask_->getOperation() == SEND)
		     { 
			token.type = WRITE_CMD; 
			token.bytes = currentTask_->getAmount();
		     }
		     else
		     { 
			// READ.(needs more parameters than write)
			token.type      = READ_CMD; 
			token.retPort   = currentTask_->getRespPort();
			token.respBytes = currentTask_->getReadAmount();

			// Determine the size of read request 
			// token that the mem requires.			
			token.bytes = dynamic_cast<MemoryModel*>
			(config_.getResourceByResourceUser
			 (config_.getResourceUserByInPort
			  (token.dstPort)->getId())
			   )->getReqSize();

			// 13.8 moved here from below, es
			// Each burst needs a new req, which are grouped 
			// into one large token
			unsigned int reqs = 
			   ((token.respBytes - 1) / token.burstBytes) + 1;
			token.bytes *= reqs;
			
			// However, request token must fit into 1 packet.
			if (token.bytes > packetSize_)
			{
			   token.bytes = packetSize_;
			}

			// std::cout << "Reading= " << token.respBytes << " bytes, which means" << std::endl; // ES		     
			// std::cout << reqs
			//	  << " req pkts, hence req token's total size = " << token.bytes << std::endl; //ES
		     }				  

		     // How many packets are needed for the token
		     if(packetSize_ > 0)
		     {
			token.packets = ((token.bytes - 1) / packetSize_) + 1;
		     }
		     else
		     {
			token.packets = 1;
		     }

		     //std::cout << token.bytes << "-byte token will need " 
		     //	       << token.packets << " packets." 
		     //	       << "(max size = " << packetSize_ << " bytes)" << std::endl; // ES
		     

		     // Check the type: inter-PE, inter-group or intra-group
		     bool interPeTx    = true;
		     bool interGroupTx = true;
		     if (config_.getPeByInport(token.dstPort) == getId()) {
			// Both src and dst task mapped on the same CPU
			interPeTx = false;

			if (config_.getGroup(currentTask_->getId())
			    == config_.getGroup(config_.getResourceUserByInPort(token.dstPort)->getId())
			   ) {
			   // Tasks belong to the same group also
			   interGroupTx = false;
			}
		     }

		     // Calculate fixed TX initiation cost and
		     // wait. The delays can akso be left undefined
		     // defines as zero. In addition to these, there
		     // is 1 cycle delay per 4-byte word when sending
		     // each packet
		     double waitCycles = 0.0;		     
		     if (interPeTx) {
			//std::cout << "PE-PE ";
			//waitCycles 10;
			if (interPeTxCost_) {
			   waitCycles = interPeTxCost_->value(token.bytes);
			}
		     } else if(interGroupTx) {
			//std::cout << "Gro-Gro ";
			//waitCycles = 4;
			currentState_ = INTRA_TX_WAIT; //es 13.8.
			if (interGroupTxCost_) {
			   waitCycles = interGroupTxCost_->value(token.bytes);
			}
		     } else {
			//std::cout << "in-Gro ";
			//waitCycles = 2;
			currentState_ = INTRA_TX_WAIT; //es 13.8.
			if (intraGroupTxCost_) {
			   waitCycles = intraGroupTxCost_->value(token.bytes);
			}
		     }
		     
		     //std::cout << sc_core::sc_time_stamp() << " pe " << getId() << ": tok " << token.id;
		     //std::cout << ", wait for "<< waitCycles << " cycles" << std::endl;
		     wait(waitCycles / getFrequency(), sc_core::SC_US);
		     updateMeasurements();





		     // Add token to queue and notify dst task about coming token.
		     sendTokens_[currentTask_->getId()] = token;

		     task = config_.getResourceUserByInPort(token.dstPort)->getId();
		     config_.getBufferByResource(
			config_.getResourceByResourceUser(task)->getId())->expectToken(token);
		     
		     config_.addSendTime(token.srcPort);
		     //std::cout << "Task " << currentTask_->getId()<< " sends to task " << task << std::endl;

		  } // ends if isNewOperation
		  




		    
		  // Create packet
		  packet = new tgPacket;

		  if(packetSize_ > 0) 
		  {
		     // Normal case. Ensure that packet is not larger than data amount
		     size = 
			sendTokens_[currentTask_->getId()].bytes < packetSize_ ?
			sendTokens_[currentTask_->getId()].bytes : packetSize_;
		  }
		  else
		  {
		     // Zero packet_size means "don't cut tokens" = send everything in 1 pkt
		     size = sendTokens_[currentTask_->getId()].bytes;
		  }

		  // Packet size must be a multiple of four bytes, and four is minimum
		  size         = roundTo4n(size);
		  packet->size = size;
		  //std::cout << "packet size " << packet->size << " bytes"
		  // << std::endl;

		  
		  port = sendTokens_[currentTask_->getId()].dstPort;
		  task = config_.getResourceUserByInPort(port)->getId();
		  pe   = config_.getResourceByResourceUser(task);
		  packet->address = pe->getId();
		  packet->id      = sendTokens_[currentTask_->getId()].id;

		  // std::cout << "inport at packet's dst " << port << std::endl;
		  // std::cout << "packet's dst task " << task << std::endl;
		  // std::cout << "packet's dst resource id " << std::hex 
		  //	      << packet->address << std::dec << std::endl;
		  // std::cout << "packet belongs to token" << packet->id << std::endl;



		  // Check where packet is going
		  if(pe->getId() == getId())
		  {		       
		     // Packet is for this PE, so called "intra PE tx"


		     // Sanity check
		     if (buffer_->rxBufSize() > 0 
			 && buffer_->rxBufSize() < packet->size) {
			std::ostringstream oss;
			oss << "Deadlock at " << sc_core::sc_time_stamp()
			    << ". Rx buf " << getId() << " is too small for a intra-PE pkt: " 
			    << buffer_->rxBufSize() << " B < " 
			    << packet->size << " B. "
			    << std::endl;
			std::cout << oss.str() << std::endl; // for Modelsim which does not support expections
			throw std::runtime_error(oss.str().c_str());
		     }



		     // Check if receive buffer (of this same PE) has
		     // enough space
		     if(buffer_->rxSpaceLeft() < packet->size)
		     {
			// Problems!
			std::cout << "PE " << getId() << ": No space for intra_tx " 
				  << "(Token " << packet->id 
				  << ", pkt size:" << size 
				  << " Bytes, space left " << buffer_->rxSpaceLeft() 
				  << " Bytes, Dst port: " << port
				  << ", Dst task:"<< task <<  ")" 
				  << std::endl;
			sched = true;
			currentTask_->changeState(WAIT);
			fifoScheduler_.push(currentTask_);
			delete packet->data; packet->data = 0;
			delete packet; packet = 0;

			/* testi� */
			wait (100, sc_core::SC_US);

			/* orig */
			break;

			/* !!!
			   With small rxBuffer this might livelock: delete token + packet, 
			   and then try resending them immediately. 
			*/
		     }
		     
		     // 2013-08-14 This while-loop looks like dead
		     // code because if-clause above calls break
		     //while(buffer_->rxSpaceLeft() < packet->size)
		     //{
		     //	currentState_ = INTRA_TX_WAIT;
		     //	wait(*(buffer_->rxGetReadEvent()));
		     //	updateMeasurements();
		     //}

		     
		     // Sends the packet
		     currentTask_->addLocalBytesSent(packet->size);
		     packet->data = new unsigned char[packet->size]; //dyn. mem allocation
		     *(reinterpret_cast<unsigned int*>(packet->data)) =
		        sendTokens_[currentTask_->getId()].id;

		     if(!dmaEnabled_)
		     {
			// a) CPU copies the data
			buffer_->rxReserveSpace(packet->size);
			currentState_ = INTRA_TX_WAIT; //es 13.8.
			//currentState_ = SENDING; //orig

			waitTime     = (size / 4.0); // send 4Bytes per cycle
			//std::cout << " send takes " << waitTime << std::endl;
			waitTime /= getFrequency(); // Convert to us. Freq given in MHz			
			wait(waitTime, sc_core::SC_US);
			updateMeasurements();

			sendTokens_[currentTask_->getId()].bytes -= packet->size; //must be before buf->rxPutPkt

			buffer_->rxFreeSpace(packet->size);
			buffer_->addIntraBytes(packet->size);
			buffer_->rxPutPacket(packet); //this also deletes the pkt
		     }
		     else
		     {	
			// b) DMA transfer (happens in separate thread)
			updateMeasurements(); //ES
			sendTokens_[currentTask_->getId()].bytes -= packet->size;
			rxDmaQueue_.push(packet);
			rxDmaEvent_.notify(sc_core::SC_ZERO_TIME);
		     }		     

		  }
		  else
		  {
		     // Packet is heading for another PE, so called "inter PE tx"

		     // Check if tx buffer has enough space
		     if(buffer_->txSpaceLeft() < packet->size)
		     {
			// Problems!
			std::cout << sc_core::sc_time_stamp() 
				  << " Not enough space in tx buf " << getId() 
				  << ", " << packet->size << " B > "
				  << buffer_->txSpaceLeft()  << " B" 
				  << std::endl;
			sched       = true;
			sendStalled = true;
			fifoScheduler_.push(currentTask_);
			//delete packet->data; packet->data = 0;
			delete packet; packet = 0;

			currentTask_->changeState(WAIT); //ES 2013-08-21
			// Otherwise the task stopped everythign if tx
			// buf got full and simulation deadlocked!

			/* testi� */
			wait (100, sc_core::SC_US);

			break;




		     }

		     // while(buffer_->txSpaceLeft() < packet->size)
		     // {			
		     // 	currentState_ = TX_WAIT;
		     // 	wait(*(buffer_->txGetReadEvent()));			
		     // 	updateMeasurements();
		     // }

		     currentTask_->addRemoteBytesSent(packet->size);
		
		     if(!dmaEnabled_)
		     {
			// CPU copies the data, takes 1 cycle per 4 bytes
			// std::cout << " - copy word-by-word" << std::endl;
			buffer_->txReserveSpace(packet->size);
			currentState_ = SENDING;

			waitTime = (size / 4.0);        // #cycles, send 4B per cycle
			//std::cout << sc_core::sc_time_stamp() << " " << getId() << " send takes " << waitTime << std::endl;
			waitTime /= getFrequency(); // Convert to us. Freq given in MHz			
			wait(waitTime, sc_core::SC_US);
			updateMeasurements();

			buffer_->txFreeSpace(packet->size);
			buffer_->txPutPacket(packet);
		     }
		     else
		     {
			// DMA transfer (happens in separate thread)
			// std::cout << " - Notify tx dma" << std::endl;
			txDmaQueue_.push(packet);
			txDmaEvent_.notify(sc_core::SC_ZERO_TIME);
		     }

       		     sendTokens_[currentTask_->getId()].bytes -= packet->size;		     

		  } // end if(pe->getId() == getId())-else



		  //std::cout << sc_core::sc_time_stamp() 
		  //	    << " task consumes " << size << " bytes" << std::endl;
		  // Byte amount might underflow, e.g. 14B - 16B, but
		  // that is only printed, not used in any condition
		  /* std::cout << getId() << " remaining size of  cur token " 
		  	    << sendTokens_[currentTask_->getId()].id << " is " 
		  	    << sendTokens_[currentTask_->getId()].bytes 
		  	    << " bytes"<< std::endl;
		  */
		    		  
		  currentTask_->consume(size);
		  currentTask_->changeState(WAIT);	
		  break;

	       default:
		  std::cout << "At " << sc_core::sc_time_stamp() 
			    << " Task " << currentTask_->getName()
			    << " operation " << currentTask_->getOperation()
			    << " FAILURE" << std::endl;
		  sc_core::sc_stop();
		  wait(10, sc_core::SC_NS);
		  break;
	    }		
	 }	    	    
      }
    
   }

   double ProcessingElement::getIntOps()
   { return intOps_; }
  
   double ProcessingElement::getFloatOps()
   { return floatOps_; }

   double ProcessingElement::getMemOps()
   { return memOps_; }

   unsigned long int ProcessingElement::getIntraGroupRxCost()
   { return (intraGroupRxCost_ == 0 ? 0 : intraGroupRxCost_->value()); }

   unsigned long int ProcessingElement::getIntraGroupTxCost()
   { return (intraGroupTxCost_ == 0 ? 0 : intraGroupTxCost_->value()); }

   unsigned long int ProcessingElement::getInterGroupRxCost()
   { return (interGroupRxCost_ == 0 ? 0 : interGroupRxCost_->value()); }

   unsigned long int ProcessingElement::getInterGroupTxCost()
   { return (interGroupTxCost_ == 0 ? 0 : interGroupTxCost_->value()); }

   unsigned long int ProcessingElement::getInterPeRxCost()
   { return (interPeRxCost_ == 0 ? 0 : interPeRxCost_->value()); }

   unsigned long int ProcessingElement::getInterPeTxCost()
   { return (interPeTxCost_ == 0 ? 0 : interPeTxCost_->value()); }

   sctg::Task* ProcessingElement::schedule()
   {
      switch(scheduler_)
      {
	 case FIFO:
	    return scheduleFifo();
	    break;

	 case FIXED_PRIORITY:
	    return scheduleFixedPriority();
	    break;

	 case SEQUENCE:
	    return scheduleSequence();
	    break;

	 default:
	    std::cerr << "Unknown scheduler, PE " << getId() << std::endl;
	    break;
      }
      return 0;
   }
   
   sctg::Task* ProcessingElement::scheduleFifo()
   {
      Task* retval = 0;
      while(!fifoScheduler_.empty())
      {
	 retval = fifoScheduler_.front();
	 fifoScheduler_.pop();
	 if(retval->getState() == READY || retval->getState() == RUN)
	 {	    
	    return retval;
	 }
      }

      // // loop over all tasks
//       for(unsigned int i = 0; i < tasks_.size(); ++i)
//       {
// 	 /*std::cout << "At " << sc_core::sc_time_stamp() 
// 	   << " Task (" << i << ") " << tasks_.at(i)->getName()
// 	   << "'s state is " 
// 	   << stateToString(tasks_.at(i)->getState())
// 	   << std::endl;*/
// 	 if(tasks_.at(i)->getState() == READY || tasks_.at(i)->getState() == RUN)
// 	 { return tasks_.at(i); }
//       }
      return 0;
   }

   sctg::Task* ProcessingElement::scheduleFixedPriority()
   {
      std::map<int, int> prio = config_.getFixedPriority(getId());
      for(std::map<int, int>::iterator iter = prio.begin();
	  iter != prio.end(); ++iter)
      {
	 int tid    = (*iter).second;
	 Task* task = dynamic_cast<Task*>(config_.getResourceUser(tid));
	 if(task->getState() == READY || task->getState() == RUN)
	    return task;
      }
      return 0;
   }

   sctg::Task* ProcessingElement::scheduleSequence()
   {     
      if(firstTime_)
      {
	 firstTime_ = false;
	 seq_       = config_.getScheduleSeq(getId());
	 iter_      = seq_.begin();
      }
      
      if(seq_.size() == 0)
	 return 0;
           
      if(iter_ == seq_.end()) iter_ = seq_.begin();      
      int tid = (*iter_).second;
      Task* task = dynamic_cast<Task*>(config_.getResourceUser(tid));
      
      if(task->getState() == READY || task->getState() == RUN)
      {	 
	 running_ = true;	 
	 return task;
      }

      // Task wasn't ready
      return 0;

   }

   bool ProcessingElement::hasInPort(unsigned long int port)
   {
      for(unsigned int i = 0; i < tasks_.size(); ++i)
      {
	 if(tasks_.at(i)->hasInPort(port)) {return true;}
      }
      return false;
   }
  
   void ProcessingElement::receiveEvent(tgToken token)
   {
      /*std::cout << "PE " << getName() << " got token from event to port "
	<< token.dstPort << std::endl;*/
      // Forward token to all tasks with correct in_port

      config_.addSendTime(token.srcPort);

      for(unsigned int i = 0; i < tasks_.size(); ++i)
      {
	 if(tasks_.at(i)->hasInPort(token.dstPort))
	 {
	    tasks_.at(i)->receive(token);
	    fifoScheduler_.push(tasks_.at(i));
	 }
      }
      eventEvent_.notify(sc_core::SC_ZERO_TIME);
   }

   const sctg::PeMeasurements& ProcessingElement::getMeasurements()
   {
      updateMeasurements();

      return measurements_;
   }

   void ProcessingElement::updateMeasurements()
   {
      measureEnd_   = sc_core::sc_time_stamp();

      switch(currentState_)
      {
	 case IDLE:	
	    measurements_.idleTime += 
	       measureEnd_ - measureStart_;	
	    break;
	 case EXECUTING:	
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.execTime += 
	       measureEnd_ - measureStart_;
	    break;

	 case I_CACHE_MISSING:
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.iCacheTime +=
	       measureEnd_ - measureStart_;
	    break;
	 case D_CACHE_MISSING:
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.dCacheTime +=
	       measureEnd_ - measureStart_;
	    break;

	 case READING:
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.readingTime +=
	       measureEnd_ - measureStart_;
	    break;
	 case SENDING:
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.sendingTime +=
	       measureEnd_ - measureStart_;
	    break;
	 case INTRA_TX_WAIT:
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.intraTxWait +=
	       measureEnd_ - measureStart_;
	    break;
	 case TX_WAIT: // obsolete??	    
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.txWaitTime +=
	       measureEnd_ - measureStart_;
	    break;
	 case RX_WAIT: // obsolete??
	    measurements_.busyTime += 
	       measureEnd_ - measureStart_;
	    measurements_.rxWaitTime +=
	       measureEnd_ - measureStart_;
	    break;
	 default:
	    break;
      }

      measurements_.cycleLength = cycleLength_;

      measurements_.idleCycles = 
	 static_cast<unsigned long int>(measurements_.idleTime/cycleLength_);
      measurements_.busyCycles = 
	 static_cast<unsigned long int>(measurements_.busyTime/cycleLength_);
    
      measureStart_ = measureEnd_;

   }


   double ProcessingElement::getAvgUtilization()
   {
      if(measurements_.busyTime+measurements_.idleTime != sc_core::SC_ZERO_TIME)
      {
	 return (measurements_.busyTime / 
		 (measurements_.busyTime + measurements_.idleTime));
      }
      else
      {
	 return 0.0;
      }
   }

   // Own thread for sending data
   void ProcessingElement::txDma()
   {
      tgPacket* packet = 0;
      double waitTime  = 0.0;

      while(true)
      {
	 if(txDmaQueue_.empty())
	 {
	    wait(txDmaEvent_);
	 }

	 while(!txDmaQueue_.empty())
	 {
	    packet = txDmaQueue_.front();
	    txDmaQueue_.pop();

	    while(buffer_->txSpaceLeft() < packet->size)
	    {				       
	       wait(*(buffer_->txGetReadEvent()));			
	    }	    	    

	    buffer_->txReserveSpace(packet->size);

	    // Copying takes 1 cycle per 4 bytes but CPU is not busy
	    // during that
	    waitTime = (1.0 / getFrequency()) * (packet->size / 4.0);	    
	    wait(waitTime, sc_core::SC_US);

	    buffer_->txFreeSpace(packet->size);
	    buffer_->txPutPacket(packet);
	    
	 }
      }
   }

   // Own thread for receiving data
   void ProcessingElement::rxDma()
   {
      tgPacket* packet = 0;
      double waitTime  = 0.0;

      while(true)
      {
	 if(rxDmaQueue_.empty())
	 {
	    wait(rxDmaEvent_);
	 }

	 while(!rxDmaQueue_.empty())
	 {
	    packet = rxDmaQueue_.front();
	    rxDmaQueue_.pop();
	    
	    while(buffer_->rxSpaceLeft() < packet->size)
	    {
	       wait(*(buffer_->rxGetReadEvent()));
	    }

	    //std::cout << "rxDma" << std::endl;
	    
	    buffer_->rxReserveSpace(packet->size);
	    
	    // Copying takes 1 cycle per 4 bytes but CPU is not busy
	    // during that
	    waitTime = (1.0 / getFrequency()) * (packet->size / 4.0);	    
	    wait(waitTime, sc_core::SC_US);
	    
	    buffer_->rxFreeSpace(packet->size);
	       
	    buffer_->addIntraBytes(packet->size);
	    buffer_->rxPutPacket(packet); // also deletes the packet
	    
	 }
      }
   }

   std::queue<tgToken>& ProcessingElement::getTokenQueue()
   {
      return tokenQueue_;
   }

   void ProcessingElement::updateUnfinishedTokensLatency()
   {
      buffer_->updateUnfinishedTokensLatency();
   }

   void ProcessingElement::mapResourceUser(ResourceUser* task)
   {
      const int prLen = 12;
      std::string taskNameForPrint = task->getName().substr(0,prLen-1);
      while (taskNameForPrint.length() < prLen) {
	 taskNameForPrint.append(" ");
      }

      std::cout << "Task " // << std::resetiosflags(std::ios::left) 
		<< std::setw(12) 
		<< task->getName() << " mapped to PE  "
	        //<< taskNameForPrint << " mapped to PE  "
		<< getName() << std::endl;
      tasks_.push_back(dynamic_cast<Task*>(task));
   }


   /**
    * Check if a cache miss occurs, and waits until it gets served. 
    * Calculate the number of executed cycles before the next miss.
    **/
   unsigned long int ProcessingElement::cacheMiss(unsigned long int cycles)
   {
      tgToken token;
      tgPacket* packet;
      Resource* pe;


      if(nextIMiss_ < 1)
      {
	 measurements_.iCacheMisses++;
	 currentState_ = I_CACHE_MISSING;

	 // Calculate cycles before the next I-cache miss occurs
	 nextIMiss_ = iCacheMissInterval_->value();


	 // Create the instruction cache miss read token
	 // Note that is always <=8 bytes and just 1 packet, regardless of XML
	 token.bytes      = missReqSize_;
	 token.srcPort    = getId();
	 token.dstPort    = iMemId_;
	 token.retPort    = 0;
	 token.respBytes  = iLineSize_;
	 token.burstBytes = iLineSize_;
	 token.id         = config_.getTokenId();
	 token.isEvent    = false;
	 token.type       = CACHE_MISS;
	
	 // Tell dst to expect this token
	 config_.getBufferByResource
	    (config_.getResourceByResourceUser(iMemId_)->getId())
	    ->expectToken(token);
			
	 // Create and send exactly 1 packet
	 packet = new tgPacket;
	 packet->size    = missReqSize_; // 8; 
	 packet->id      = token.id;
	 pe              = config_.getResourceByResourceUser(iMemId_);
	 packet->address = pe->getId();
	 
	 while(buffer_->txSpaceLeft() < packet->size)
	 {			
	    wait(*(buffer_->txGetReadEvent()));
	 }
			
	 buffer_->txPutPacket(packet);
	 
	 // Wait for response to come back
	 long int waitBytes = iLineSize_;
	 sc_core::sc_time t = sc_core::sc_time_stamp();
//  			std::cout << "EXECUTING I-CACHE MISS, WAITING FOR "
//  				  << waitBytes << " BYTES " 
//  				  << sc_core::sc_time_stamp().value()
//  				  << std::endl;
	 while(waitBytes > 0)
	 {
	    
	    wait(*(buffer_->rxGetCacheAvailableEvent()));
	    tgPacket* rcv = buffer_->rxGetCache();   
	    waitBytes -= rcv->size;
	    buffer_->removeToken(rcv->size);
	    delete rcv->data;
	    delete rcv;			   
	 }
//  			std::cout << "CACHE READ in "
//  				  << (sc_core::sc_time_stamp() - t).value()
//  				  << std::endl;
	 updateMeasurements();
      } // end  if(nextIMiss_ < 1)



      
      if(nextDMiss_ < 1)
      {
	 measurements_.dCacheMisses++;
	 currentState_ = D_CACHE_MISSING;
	 // Calculate next time I-cache misses
	 nextDMiss_ = dCacheMissInterval_->value();
	 
	 // Send data cache miss read packet
	 // Note that is always <=8 bytes and just 1 packet, regardless of XML
	 token.bytes      = missReqSize_;
	 token.srcPort    = getId();
	 token.dstPort    = dMemId_;
	 token.retPort    = 0;
	 token.respBytes  = dLineSize_;
	 token.burstBytes = dLineSize_;
	 token.id         = config_.getTokenId();
	 token.isEvent    = false;
	 token.type       = CACHE_MISS;
	 
	 config_.getBufferByResource
	    (config_.getResourceByResourceUser(dMemId_)->getId())
	    ->expectToken(token);
	 
	 // Create and send exactly 1 packet
	 packet = new tgPacket;
	 packet->size = missReqSize_; //8;
	 packet->id = token.id;
	 pe = config_.getResourceByResourceUser(dMemId_);
	 packet->address = pe->getId();			
	 
	 while(buffer_->txSpaceLeft() < packet->size)
	 {			
	    wait(*(buffer_->txGetReadEvent()));
	 }
	 
	 buffer_->txPutPacket(packet);
	 
	 // Wait for it to come back
	 long int waitBytes = dLineSize_;
	 
// 			std::cout << "EXECUTING D-CACHE MISS, WAITING FOR "
//  				  << waitBytes << " BYTES " 
//  				  << sc_core::sc_time_stamp().value()
//  				  << std::endl;

	 while(waitBytes > 0)
	 {
	    wait(*(buffer_->rxGetCacheAvailableEvent()));
	    tgPacket* rcv = buffer_->rxGetCache();
	    waitBytes -= rcv->size;
	    buffer_->removeToken(rcv->size);
	    delete rcv->data;
	    delete rcv;
	 }
	 updateMeasurements();
      } // end  if(nextDMiss_ < 1)


      // Calculate how many cycles it takes before the next miss occurs
      cycles = std::min(cycles, nextIMiss_);
      cycles = std::min(cycles, nextDMiss_);
      
      nextIMiss_ -= cycles;
      nextDMiss_ -= cycles;

      return cycles;
   }
   


}



// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
