/**
 *
 * @file trigger.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: trigger.cc 87 2012-09-21 05:48:04Z ege $
 *
 */

#include "trigger.hh"

#include "processing_element.hh"

#include <iostream>
#include <exception>
#include <algorithm>

namespace sctg
{
   /* Constrcutor
    */
   Trigger::Trigger(const boost::property_tree::ptree& pt, 
		    Configuration& config,
		    Task* ownerTask)    
      :
      config_        (config),
      receivedBytes_ (0),      
      bytesInBuffer_ (0),
      currentReceive_(sc_core::SC_ZERO_TIME),
      newTrigger_    (false),
      // cumulative stats
      triggered_     (0),
      bytesSent_     (0),
      bytesRead_     (0),
      cyclesExecuted_(0)
   {
      using boost::property_tree::ptree;
      //std::cout << "  trigger()";


      ownerTask_ = ownerTask;
      nextState_ = READY;

      // Read trigger's parameters from XML
      std::string dep = pt.get<std::string>("<xmlattr>.dependence_type", "or");
      if(dep == "or")
      {	dependence_ = OR; }
      else if(dep == "and")
      { dependence_ = AND; }
      else
      {
	 std::string err = "Unknown dependence_type " + dep
	    + " Choices are \'and\' and \'or\'"; 
	 throw std::runtime_error(err.c_str()); 
      }

      for(ptree::const_iterator iter = pt.begin(); iter != pt.end(); ++iter)
      {
	 try {

	    if((*iter).first == "exec_count")
	    {
	       // These settings are optional, and hence convToInt cannot be used
	       ExecCount_* execCount = new ExecCount_;
	       execCount->period = (*iter).second.get_optional<unsigned long int>
	         ("<xmlattr>.mod_period");
	       execCount->min = (*iter).second.get_optional<unsigned long int>
		  ("<xmlattr>.min");
	       execCount->max = (*iter).second.get_optional<unsigned long int>
		  ("<xmlattr>.max");
	       boost::optional<unsigned long int> phase = 
		  (*iter).second.get_optional<unsigned long int>
		  ("<xmlattr>.mod_phase");

	       if(phase)
	       {
		  execCount->min = *phase;
		  execCount->max = *phase;
	       }
	       if(execCount->period && !execCount->min)
	       {	execCount->min = 0; }
	       if(execCount->period && !execCount->max)
	       {	execCount->max = execCount->period; }

	       parseExecCount((*iter).second, execCount, config);
	       execCounts_.push_back(execCount);
	       
	       //std::cout  << "    tri: exec_count (period=" 
	       //	  << execCount->period  << ", min-max=" 
	       //	  << execCount->min << " - " << execCount->max
	       //	  << " ) added" << std::endl; //Es
	    }
	    else if((*iter).first == "in_port")
	    {
	       unsigned long int pid = sctg::convToInt (iter, "<xmlattr>.id");
	       inPorts_.push_back(pid);
	       // std::cout  << "    tri: port " << pid << " added" << std::endl; //Es
	       
	       // Add empty token queue for this port
	       receivedTokens_.push_back(std::queue<tgToken>());

	       // Sanity check
	       if (!ownerTask_->hasInPort(pid))
	       {
		  std::ostringstream oss;
		  oss << "Warning: trigger will not be activated ever since it's ownwer task "
		      << ownerTask_->getName()
		      << " does not have inport " << pid << std::endl;
		  // std::cout << oss.str() << std::endl;
		  throw std::runtime_error(oss.str().c_str());
	       }

	    }
	 } catch (std::exception& e) {
	    
	    std::string err ("<task ");
	    err += ownerTask_->getName();
	    err +="><trigger><";
	    err += (*iter).first;
	    err += ">...";
	    err += e.what();
	    throw std::runtime_error (err);
	 
	 } // ES, end catch

      }
    

      newOp_ = true;
      //std::cout << " for " << ownerTask_->getName() << " created "<< std::endl; // ES
    
   }



   /* Destructor
    */
   Trigger::~Trigger()
   {
      for(unsigned int i = 0; i < execCounts_.size(); ++i)
      {	
	 for(unsigned int j = 0; j < execCounts_.at(i)->operations.size(); ++j)
	 {
	    for(unsigned int k = 0; 
		k < execCounts_.at(i)->operations.at(j)->amounts.size(); ++k)
	    {
	       delete execCounts_.at(i)->operations.at(j)->amounts.at(k);
	       execCounts_.at(i)->operations.at(j)->amounts.at(k) = 0;
	    }
	    delete execCounts_.at(i)->operations.at(j);
	    execCounts_.at(i)->operations.at(j) = 0;
	 }
	 delete execCounts_.at(i);
	 execCounts_.at(i) = 0;
      }
   }



   /* Notify that full token has arrived
    */
   void Trigger::receive(tgToken token)
   {
      // Check that packet really was for this token
      if(!hasInPort(token.dstPort))
      {	throw std::runtime_error("Token to a wrong trigger"); }

      // Add token to its queue
      for(unsigned int i = 0; i < inPorts_.size(); ++i)
      {
	 if(inPorts_.at(i) == token.dstPort)
	 {
	    receivedTokens_.at(i).push(token);
	    bytesInBuffer_ += token.bytes;
	 }
      }

      // Check if this token makes this trigger active
      resolve();
   }



   /* Decide what to do next
    */
   void Trigger::resolve()
   {
      if(operationQueue_.empty())
      {
	 if(dependence_ == AND)
	 {
	    // Build new queue only if all ports have received a token
	    for(unsigned int i = 0; i < receivedTokens_.size(); ++i)
	    {
	       if(receivedTokens_.at(i).empty()) {return;}
	    }

	    // Calculate new byte amount by adding all tokens together
	    //  and remove packets from queue
	    receivedBytes_ = 0;
	    eventBytes_    = 0;
	    sc_core::sc_time latestArrival = sc_core::SC_ZERO_TIME;
	    for(unsigned int i = 0; i < receivedTokens_.size(); ++i)
	    {
	       receivedBytes_ += receivedTokens_.at(i).front().bytes;
	       if(receivedTokens_.at(i).front().isEvent)
	       {
		  eventBytes_ += receivedTokens_.at(i).front().bytes;
	       }
	       if(receivedTokens_.at(i).front().timeReceived > latestArrival)
	       {
		  latestArrival = receivedTokens_.at(i).front().timeReceived;
	       }
	       currentReceive_ = latestArrival;
	       receivedTokens_.at(i).pop();
	    }

	    // Build queue again
	    buildQueue();
	 }

	 else // i.e. dependence_ is OR
	 {
	    // Determine the send amount based on the oldest token
	    bool found = false;
	    unsigned int index = 0; // idx of the oldest token
	    sc_core::sc_time time;
	    for(unsigned int i = 0; i < receivedTokens_.size(); ++i)
	    {
	       if(!receivedTokens_.at(i).empty()) 
	       {
		  if(found == false)
		  {
		     found = true;
		     index = i;
		     time  = receivedTokens_.at(i).front().timeReceived;
		  }
		  else
		  {
		     if(time > receivedTokens_.at(i).front().timeReceived)
		     {
			index = i;
			time  = receivedTokens_.at(i).front().timeReceived;
		     }
		  }
	       }
	    }
	    
	    if(found == true)
	    {
	       // Store byte amount and remove token from queue
	       eventBytes_ = 0;
	       receivedBytes_ = receivedTokens_.at(index).front().bytes;
	       if(receivedTokens_.at(index).front().isEvent)
	       {
		  eventBytes_ += receivedTokens_.at(index).front().bytes;
	       }
	       currentReceive_ = 
		  receivedTokens_.at(index).front().timeReceived;
	       receivedTokens_.at(index).pop();

	       // Build queue again
	       buildQueue();
	    }
	 }

      } // if opqueue.empty()

      return;
   }


   /* Create a new queue of operations to be executed,
      e.g. (execute,  send, send)
    */
   void Trigger::buildQueue()
   {
      // Do not overwrite the old queue.
      if(operationQueue_.empty())
      {
	 for(unsigned int i = 0; i < execCounts_.size(); ++i)
	 {
	    // Go throuhg the list ExecCounts_ which stores the
	    // possible behaviors and select the mathing ones.  
	    // Select the exec_count i, if 
	    // it has no period, no min and no max, 
	    // or it's periodical and (min <= triggered_%period <= max), 
	    // or not periodical and triggered_ >= min, 
	    // or not periodical and triggered_ <= max
	    if((!execCounts_.at(i)->period && !execCounts_.at(i)->min &&
		!execCounts_.at(i)->max) 
	       || (execCounts_.at(i)->period && 
		*execCounts_.at(i)->min <= 
		(triggered_ % *execCounts_.at(i)->period) &&
		*execCounts_.at(i)->max >= 
		(triggered_ % *execCounts_.at(i)->period)) 
	       ||(!execCounts_.at(i)->period && execCounts_.at(i)->min &&
		*execCounts_.at(i)->min <= triggered_) 
	       ||(!execCounts_.at(i)->period && execCounts_.at(i)->max &&
		*execCounts_.at(i)->max >= triggered_)
	       )
	    {		
	       for(unsigned int j = 0; j < execCounts_.at(i)->operations.size();
		   ++j)
	       {
		  nextState_ = execCounts_.at(i)->nextState;

		  // Add current operation if random < probability
		  if(execCounts_.at(i)->operations.at(j)->prob == 1.0 ||
		     config_.random() < 
		     execCounts_.at(i)->operations.at(j)->prob)
		  {
		     OpQueueItem      op;
		     op.type        = execCounts_.at(i)->operations.at(j)->type;
		     op.outPort     = execCounts_.at(i)->operations.at(j)->outPort;
		     op.amount      = 0;	
		     op.respPort    = 0;
		     op.readAmount  = 0;
		     op.burstLength = 0;
		     for(unsigned int k = 0; 
			 k < execCounts_.at(i)->operations.at(j)->
			    amounts.size(); ++k)
		     {
			if(op.type == EXECUTE)
			{			  
			   op.amount += execCounts_.at(i)->
			      operations.at(j)->amounts.at(k)->
			      value(receivedBytes_) / 
			      getFactor(execCounts_.at(i)->
					operations.at(j)->factors.at(k));
// 			   std::cout << "## EXECUTE" << std::endl;
			}
			else if(op.type == READ)
			{
//  			   op.amount += execCounts_.at(i)->
//  			      operations.at(j)->amounts.at(k)->
//  			      value(receivedBytes_);
			   op.respPort = execCounts_.at(i)->operations.at(j)
			      ->respPort;
			   op.burstLength += execCounts_.at(i)->
			      operations.at(j)->burstAmounts.at(k)->
			      value(receivedBytes_);
			   op.readAmount += execCounts_.at(i)->
			      operations.at(j)->readAmounts.at(k)->
			      value(receivedBytes_);
// 			   std::cout << "## READ resp port " << op.respPort
// 				     << " burst len " << op.burstLength
// 				     << " read amount " << op.readAmount
// 				     << std::endl;
			}
			else if(op.type == SEND)
			{
			   op.amount += execCounts_.at(i)->
			      operations.at(j)->amounts.at(k)->
			      value(receivedBytes_);
			   if(execCounts_.at(i)->
			      operations.at(j)->burstAmounts.size() > 0)
			   {
			      op.burstLength += execCounts_.at(i)->
				 operations.at(j)->burstAmounts.at(k)->
				 value(receivedBytes_);
			   }
// 			   std::cout << "## SEND" << std::endl;
			}
			else if(op.type == WAIT_RESP)
			{
// 			   std::cout << "## WAIT_RESP" << std::endl;
			   op.amount += execCounts_.at(i)->
			      operations.at(j)->amounts.at(k)->
			      value(receivedBytes_);
			}
			else
			{
			   std::cout << " ANOTHER OP TYPE " << std::endl;
			}
		     }
		     operationQueue_.push(op);
		     /*std::cout << "Operation type " << op.type
		       << " outPort " << op.outPort
		       << " amount " << op.amount << std::endl;*/
		  }
	       }
	    }
	 }


	 if(operationQueue_.empty())
	 {
	    OpQueueItem  op;
	    op.type    = EXECUTE;
	    op.amount  = 0;
	    op.outPort = 0;
	    operationQueue_.push(op);
	 }
	 OpQueueItem  op;
	 op.type    = DONE;
	 op.amount  = 1;
	 op.outPort = 0;
	 operationQueue_.push(op);
      }

      if(operationQueue_.empty())
      {
	 throw std::runtime_error
	    ("Trigger::buildQueue: operationQueue is empty");
      }
   }





   /* Performs some action: consumes a number of clk cycles or
      sends/receives a number of bytes.
      First item in operation queue determines what to do.
    */
   unsigned long int Trigger::consume(unsigned long int amount)
   {

      if(operationQueue_.empty())
      {	throw std::runtime_error("trigger::consume(): queue is empty"); }


      // Update statistics
      switch(operationQueue_.front().type)
      {
	 case EXECUTE:
	    cyclesExecuted_ += amount;
	    break;
	 case SEND:
	    bytesSent_ += amount;
	    break;
	 case WAIT_RESP:
	    bytesRead_ += amount;
	    /* std::cout << sc_core::sc_time_stamp() << "  " << bytesRead_
		      << " bytes in total have been read by trigger of task" 
		      << ownerTask_->getName() 
		      << std::endl << std::endl;
	    */
	    break;
	 default:
	    break;
      }


      // 2012-01-21 ES Moved this piece here from above to get bytesRead_ working correctly
      // Avoid underflow (e.g. if amount was rounded upwards to 4*N)
      //
      if(amount > operationQueue_.front().amount
	 )
      {
	 amount = operationQueue_.front().amount;
      }

      newTrigger_ = false;
      operationQueue_.front().amount -= amount;



      // When no ops or bytes are left, the operation was completed and will
      // be removed from queue
      if(operationQueue_.front().amount == 0)
      {
	 operationQueue_.pop();
	 // std::cout << "trig.opqueu.pop() "<<  std::endl;

	 newOp_ = true;
	 
	 // Trigger is completed, if no more operations are left
	 if(operationQueue_.empty())
	 { 	  
	    newTrigger_ = true;
	    // Remove used memory from buffer (bytes from event are not counted)
	    config_.getBufferByResource
	       (config_.getResourceByResourceUser(ownerTask_->getId())->getId())
	       ->removeToken(receivedBytes_ - eventBytes_);
	    bytesInBuffer_ -= receivedBytes_;
	    ++triggered_; 	    
	    ownerTask_->incTriggered();
	    ownerTask_->changeState(nextState_); 	    
	 }
	 ownerTask_->setLastResponse(sc_core::sc_time_stamp()-currentReceive_);
	 return 0;
      }
      else
      {
	 newOp_ = false;	 
	 return operationQueue_.front().amount;
      }
   }





   /** Parses the XML tags defined inside "exec_count", namely op_count, send amount, 
       and read amount 
    */
   void Trigger::parseExecCount(const boost::property_tree::ptree& pt,
				ExecCount_* execCount, 
				Configuration& config)
   {
      execCount->nextState = READY;

      using boost::property_tree::ptree;
      for(ptree::const_iterator iter = pt.begin(); iter != pt.end(); ++iter)
      {

	 try { //ES

	    if((*iter).first == "op_count")
	    {
	       // std::cout << "    tri:op_count " << std::endl; //ES
	       
	       Operation_* oper = new Operation_;
	       oper->type       = EXECUTE;	    
	       oper->outPort    = 0;
	       oper->prob       = 1.0; // execution happens always 

	       
	       for(ptree::const_iterator iter2 = (*iter).second.begin(); 
		   iter2 != (*iter).second.end(); ++iter2)
	       {		
		  
		  if((*iter2).first == "int_ops")
		  {
		     oper->factors.push_back(INT);
		     //(config.getPeByTask(ownerTask_->getId())->getIntOps());
		     oper->amounts.push_back(new Amount<double>
					     ((*iter2).second, config)); 
		     // std::cout << "    tri: int_ops set" << std::endl; //ES
		  
		  }
		  else if((*iter2).first == "float_ops")
		  {
		     oper->factors.push_back(FLOAT);
		     //(config.getPeByTask(ownerTask_->getId())->getFloatOps());
		     oper->amounts.push_back(new Amount<double>
					     ((*iter2).second, config)); 
		  }
		  else if((*iter2).first == "mem_ops")
		  {		    
		     oper->factors.push_back(MEM);
		     //(config.getPeByTask(ownerTask_->getId())->getMemOps());
		     oper->amounts.push_back(new Amount<double>
					     ((*iter2).second, config)); 
		  }
	       }
	       execCount->operations.push_back(oper);
	    }
	    else if((*iter).first == "send")
	    {
	       // A task send to another task or to a memory
	       Operation_* oper = new Operation_;
	       oper->type       = SEND;	    
	       oper->outPort    = sctg::convToInt (iter, "<xmlattr>.out_id");
	       oper->prob       = sctg::convToDouble (iter, "<xmlattr>.prob");

	       for(ptree::const_iterator iter2 = (*iter).second.begin(); 
		   iter2 != (*iter).second.end(); ++iter2)
	       {
		  if((*iter2).first == "byte_amount")
		  {
		     oper->amounts.push_back(new Amount<double>
					     ((*iter2).second, config)); 
		  }
		  if((*iter2).first == "burst_length")
		  {
		     oper->burstAmounts.push_back(new Amount<double>
						  ((*iter2).second, config)); 
		  }
	       }
	       execCount->operations.push_back(oper);

	       // Sanity check
	       if (!ownerTask_->hasOutPort(oper->outPort))
	       {
		  std::ostringstream oss;
		  oss << "Warning: trigger cannot send since it's ownwer task "
		      << ownerTask_->getName()
		      << " does not have outport " << oper->outPort << std::endl;
		  // std::cout << oss.str() << std::endl;
		  throw std::runtime_error(oss.str().c_str());
	       }




	    }
	    else if((*iter).first == "read")
	    {
	       // A task read only from  memory, not from another task
	       // Creates two operations: reqest (READ) and response (WAIT_RESP)
	       Operation_* oper = new Operation_;
	       oper->type       = READ;	    
	       oper->outPort    = sctg::convToInt    (iter, "<xmlattr>.out_id");
	       oper->respPort   = sctg::convToInt    (iter, "<xmlattr>.resp_id");
	       oper->prob       = sctg::convToDouble (iter, "<xmlattr>.prob");

	       for(ptree::const_iterator iter2 = (*iter).second.begin(); 
		   iter2 != (*iter).second.end(); ++iter2)
	       {
		  if((*iter2).first == "burst_length")
		  {
		     oper->burstAmounts.push_back(new Amount<double>
						  ((*iter2).second, config)); 
		  }
		  if((*iter2).first == "byte_amount")
		  {
		     oper->readAmounts.push_back(new Amount<double>
						 ((*iter2).second, config)); 
		     oper->amounts.push_back(new Amount<double>
					     ((*iter2).second, config)); 
		  }
	       }
	       execCount->operations.push_back(oper);

	       // Sanity check
	       if (!ownerTask_->hasOutPort(oper->outPort))
	       {
		  std::ostringstream oss;
		  oss << "Warning: trigger cannot read since it's ownwer task "
		      << ownerTask_->getName()
		      << " does not have outport " << oper->outPort << std::endl;
		  // std::cout << oss.str() << std::endl;
		  throw std::runtime_error(oss.str().c_str());
	       }
	       // Cannot check that respPort really exists because
	       // connections between tasks are not necessarily parsed
	       // yet. RespPort is the outport of the memory being
	       // read.
	       

	       // Prepare for the response (=data that was read from mem)
	       oper = new Operation_;
	       oper->type = WAIT_RESP;	    
	       for(ptree::const_iterator iter2 = (*iter).second.begin(); 
		   iter2 != (*iter).second.end(); ++iter2)
	       {	       
	       if((*iter2).first == "read_amount")
	       {
		  oper->amounts.push_back(new Amount<double>
					  ((*iter2).second, config)); 
	       }
	       }
	       execCount->operations.push_back(oper);



	    }
	    else if((*iter).first == "poll")
	    {
	       //Not implemented yet
	    }

	    else if((*iter).first == "next_state")
	    {
	       if((*iter).second.get<std::string>("<xmlattr>.value") == "FREE")
	       {
		  execCount->nextState = FREE;
		  // No need to parse after this
		  break;
	       }
	    }
	 } catch (std::exception& e) {
	    std::string err ("<");
	    err += (*iter).first + ">:";
	    err += e.what();
	    throw std::runtime_error (err);
	    //throw std::range_error (err);
	    
	 } // ES
      }
   }


   // Returns current operation, e.g. execute, send, send...
   OperationType Trigger::getOperation()
   {
      // Don't ask if there is nothing
      if(operationQueue_.empty())
      {
	 throw std::runtime_error
	    ("Trigger::getOperation: Can't get operation from empty queue");
      }
      return operationQueue_.front().type;
   }

   bool Trigger::isNewOperation()
   {
      return newOp_;
   }

   bool Trigger::isNewTrigger()
   {
      return newTrigger_;
   }

   unsigned long int Trigger::getAmount()
   {
      if(operationQueue_.empty())
      {	throw std::runtime_error("getAmount(): queue is empty"); }
      return operationQueue_.front().amount;
   }

   unsigned long int Trigger::getBurstAmount()
   {
      if(operationQueue_.empty())
      {	throw std::runtime_error("geBurstAmount(): queue is empty"); }
      return operationQueue_.front().burstLength;
   }

   unsigned long int Trigger::getReadAmount()
   {
      if(operationQueue_.empty())
      {	throw std::runtime_error("getReadAmount(): queue is empty"); }
      return operationQueue_.front().readAmount;
   }

   bool Trigger::hasInPort(unsigned long int pid)
   {
      if(std::find(inPorts_.begin(), inPorts_.end(), pid) != inPorts_.end())
      { return true; }
      else
      { return false; }
   }

   unsigned long int Trigger::getOutPort()
   {
      if(operationQueue_.empty())
      {	throw std::runtime_error("getOutPort(): queue is empty"); }
      if(operationQueue_.front().type == EXECUTE )
      {	throw std::runtime_error("getOutPort(): EXECUTE has no outPort"); }
      return operationQueue_.front().outPort;
   }

   unsigned long int Trigger::getRespPort()
   {
      if(operationQueue_.empty())
      {	throw std::runtime_error("getRespPort(): queue is empty"); }
      if(operationQueue_.front().type != READ )
      {	throw std::runtime_error("getRespPort(): respPort only in READ"); }
      return operationQueue_.front().respPort;
   }


   bool Trigger::isActive()
   {
      if(operationQueue_.empty()) {newTrigger_ = true;}
      resolve();
      if(operationQueue_.empty()) {newTrigger_ = false;}

      return !operationQueue_.empty();
   }

   unsigned long int Trigger::getTimesTriggered() const
   {
      return triggered_;
   }

   unsigned long int Trigger::getBytesSent() const
   {
      return bytesSent_;
   }

   unsigned long int Trigger::getCyclesExecuted() const
   {
      return cyclesExecuted_;
   }
  
   unsigned long int Trigger::getBytesRead() const
   {
      return bytesRead_;
   }

   // Returns the number of operations per cycle that PE can execute
   double Trigger::getFactor(OpType_ optype) const
   {
      switch(optype)
      {
	 case INT:
	    return 
	       dynamic_cast<ProcessingElement*>
	       (config_.getResourceByResourceUser
		(ownerTask_->getId()))->getIntOps(); 
	    break;
	 case MEM: 
	    return 
	       dynamic_cast<ProcessingElement*>
	       (config_.getResourceByResourceUser
		(ownerTask_->getId()))->getMemOps(); 
	    break;
	 case FLOAT: 	    
	    return 
	       dynamic_cast<ProcessingElement*>
	       (config_.getResourceByResourceUser
		(ownerTask_->getId()))->getFloatOps(); 
	    break;
	 default: 
	    return 0.0;
      }
   }

   unsigned long int Trigger::getBufferUsage() const
   {
      return bytesInBuffer_;
   }

   const sc_core::sc_time& Trigger::getReceiveTime() const
   {
      return currentReceive_;
   }

}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
