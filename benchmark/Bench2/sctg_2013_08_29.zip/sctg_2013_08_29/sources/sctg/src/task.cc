/**
 *
 * @file task.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: task.cc 81 2012-09-12 06:39:00Z ege $
 *
 */

#include "task.hh"

#include <algorithm>
#include <exception>
#include <iomanip>
#include <iostream>

namespace sctg
{
   Task::Task(const boost::property_tree::ptree& pt,
	      Configuration& config)
      : 
      ResourceUser     (pt, config),      
      localBytesSent_  (0),
      remoteBytesSent_ (0),
      lastLatency_     (sc_core::SC_ZERO_TIME),
      lastDelay_       (sc_core::SC_ZERO_TIME),
      lastResponseTime_(sc_core::SC_ZERO_TIME),
      timesTriggered_  (0)
   {
      using boost::property_tree::ptree;
    
      // std::cout << "  task() "<< std::endl; //ES 
      
      
    
      // All tasks start in WAIT state
      state_ = WAIT;
    
      // Read in all triggers from XML
      for(ptree::const_iterator iter = pt.begin(); iter != pt.end(); ++iter)
      {
	 // std::cout << "   ta " << (*iter).first << std::endl;; //ES

	 if((*iter).first == "trigger")
	 {
	    Trigger* trigger = new Trigger((*iter).second, config, this);
	    triggers_.push_back(trigger);
	 }
	 // std::cout << "   ta end "<< std::endl; //ES 
      }
    
      // Confirm that there are triggers for this task
      if(triggers_.size() == 0)
      {
	 std::string err = "Task " + getName() + " has no triggers";
	 throw std::runtime_error(err.c_str());
      }
      currentTrigger_ = 0;
   }  

   Task::~Task()
   {
      unsigned long int timesTriggered = 0;
      unsigned long int bytesSent = 0;
      unsigned long int cyclesExecuted = 0;
      unsigned long int bytesRead = 0;

      // Clean triggers
      for(unsigned int i = 0; i < triggers_.size(); ++i)
      {
	 timesTriggered += triggers_.at(i)->getTimesTriggered();
	 bytesSent      += triggers_.at(i)->getBytesSent();
	 cyclesExecuted += triggers_.at(i)->getCyclesExecuted();
	 bytesRead      += triggers_.at(i)->getBytesRead();
	 delete triggers_.at(i);
	 triggers_.at(i) = 0;
      }
      
      if(config_.getSummaryStream())
      {
	 **config_.getSummaryStream()
	    << "-  Task;" 
	    << std::setw(16) << getName() << ";"
	    << std::setw(4)  << id_            << ";"
	    << std::setw(11) << timesTriggered << ";"
	    << std::setw(12) << cyclesExecuted << ";"
	    << std::setw(15) << bytesSent << ";"
	    << std::setw(15) << bytesRead << ";"
	    << std::endl;
      }
   }
   

   // Notify that task has a full token available now
   void Task::receive(tgToken token)
   {

      // Check that token really was for this task
      if(!hasInPort(token.dstPort))
      {
	 std::string err = "Task " + getName() + 
	    " got token to a wrong destination";
	 throw std::runtime_error(err.c_str());
      }

      // Update receive time
      token.timeReceived = sc_core::sc_time_stamp();
      sc_core::sc_time lat = token.timeReceived - token.timeSent;
      config_.addTokenLatency(token.srcPort, token.dstPort, lat);


      // Add token to those triggers that monitor this port
      for(unsigned int i = 0; i < triggers_.size(); ++i)
      {
	 if(triggers_.at(i)->hasInPort(token.dstPort))
	 {
	    triggers_.at(i)->receive(token);
	 }
      }

      // See if task's status changes
      if(state_ == WAIT)
      {
	 // Task state is READY if any of triggers is active
	 for(unsigned int i = 0; i < triggers_.size(); ++i)
	 {
	    if(triggers_.at(i)->isActive())
	    {
	       changeState(READY);
	    }
	 }
      }
      else if(state_ == FREE) // FREE task cannot receive tokens
      {
	 std::string err = "Task " + getName() + 
	    " was already FREE but received a token";
	 throw std::runtime_error(err.c_str());
      }
   }



   void Task::changeState(State newState)
   {
      // std::cout << "Task " << getName() << " changing state from "
      // 	      << stateToString(state_) << " to " 
      //      << stateToString(newState) << std::endl;
      if(state_ == FREE)
      {
	 std::string err = "Task " + getName() + 
	    " was already FREE but tried to change its state";
	 throw std::runtime_error(err.c_str());
      }

      if(newState == FREE)
      {
	 state_ = FREE;
      }
      else if(newState == WAIT || newState == READY)
      {
	 state_ = WAIT;
	 // Task state is READY if any of its triggers is active
	 if(triggers_.at(currentTrigger_)->isActive())
	 {
	    state_ = READY;
	 }
	 else
	 {
	    for(unsigned int i = currentTrigger_; 
		i < triggers_.size() + currentTrigger_; ++i)
	    {
	       if(triggers_.at(i % triggers_.size())->isActive())
	       {
		  currentTrigger_ = i % triggers_.size();
		  state_ = READY;
		  break;
	       }
	    }
	 }
      }
      else if(newState == RUN)
      {
	 state_ = RUN;
	 if(isNewOperation())
	 {
	    lastDelay_ = sc_core::sc_time_stamp() - 
	       triggers_.at(currentTrigger_)->getReceiveTime();
	 }
      }
      //std::cout << " new state is " << stateToString(state_) << std::endl;
   }



   bool Task::hasInPort(unsigned long int pid)
   {
      if(std::find(inPorts_.begin(), inPorts_.end(), pid) != inPorts_.end())
      {	return true; }
      else
      { return false; }
   }

   bool Task::hasOutPort(unsigned long int pid)
   {
      if(std::find(outPorts_.begin(), outPorts_.end(), pid) != outPorts_.end())
      {	return true; }
      else
      { return false; }
   }

   OperationType Task::getOperation()
   {    
      return triggers_.at(currentTrigger_)->getOperation();
   }
  
   bool Task::isNewOperation()
   {
      return triggers_.at(currentTrigger_)->isNewOperation();
   }

   bool Task::isNewTrigger()
   {
      return triggers_.at(currentTrigger_)->isNewTrigger();
   }

   unsigned long int Task::getAmount()
   {
      return triggers_.at(currentTrigger_)->getAmount();
   }

   unsigned long int Task::getBurstAmount()
   {
      return triggers_.at(currentTrigger_)->getBurstAmount();
   }

   unsigned long int Task::getReadAmount()
   {
      return triggers_.at(currentTrigger_)->getReadAmount();
   }
  
   unsigned long int Task::getOutPort()
   {
      return triggers_.at(currentTrigger_)->getOutPort();
   }

   unsigned long int Task::getRespPort()
   {
      return triggers_.at(currentTrigger_)->getRespPort();
   }

   unsigned long int Task::consume(unsigned long int amount)
   {
//      std::cout << sc_core::sc_time_stamp() << " task " << id_ << " consuymes " << amount;
      return triggers_.at(currentTrigger_)->consume(amount);
   }

   State Task::getState()
   {
      return state_;
   }

   unsigned long int Task::getBufferUsage() const
   {
      unsigned long int retval = 0;
      for(unsigned int i = 0; i < triggers_.size(); ++i)
      {
	 retval += triggers_.at(i)->getBufferUsage();
      }
      return retval;
   }

   unsigned long int Task::getTimesTriggered()
   {
      unsigned long int timesTriggered = 0;            
      for(unsigned int i = 0; i < triggers_.size(); ++i)
      {
	 timesTriggered += triggers_.at(i)->getTimesTriggered();
      }      
      return timesTriggered;
   }

   unsigned long int Task::getLocalBytesSent()
   {    
      return localBytesSent_;
   }

   void Task::addLocalBytesSent(unsigned long int b)
   {
      localBytesSent_ += b;
   }

   unsigned long int Task::getRemoteBytesSent()
   {    
      return remoteBytesSent_;
   }

   void Task::addRemoteBytesSent(unsigned long int b)
   {
      remoteBytesSent_ += b;
   }

   unsigned long int Task::getCyclesExecuted()
   {      
      unsigned long int cyclesExecuted = 0;
      for(unsigned int i = 0; i < triggers_.size(); ++i)
      {
	 cyclesExecuted += triggers_.at(i)->getCyclesExecuted();
      }    
      return cyclesExecuted;
   }

   const sc_core::sc_time& Task::getLastLatency() const
   {
      return lastLatency_;
   }

   const sc_core::sc_time& Task::getLastDelay() const
   {
      return lastDelay_;
   }

   const sc_core::sc_time& Task::getLastResponse() const
   {
      return lastResponseTime_;
   }

   void Task::setLastResponse(const sc_core::sc_time& resp)
   {
      lastLatency_      = resp - lastDelay_;
      lastResponseTime_ = resp;
   }

   void Task::incTriggered(void)
   {
      ++timesTriggered_;
      
      config_.taskTriggered(id_, timesTriggered_);
   }
   

}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
