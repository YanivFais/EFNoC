/**
 *
 * @file parse_rtp.cc
 * @author Lasse Lehtonen
 *
 * Parser for .rtp files.
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it
 *  and/or modify it under the terms of the Lesser GNU General Public
 *  License as published by the Free Software Foundation, either
 *  version 3 of the License, or (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be
 *  useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public
 *  License along with Transaction Generator.  If not, see
 *  <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: parse_rtp.cc 24 2012-01-23 13:55:08Z lehton87 $
 *
 */


#include "parse_rtp.hh"
#include <fstream>
#include <map>
#include <vector>
#include <sstream>
#include <iostream>

namespace sctg
{
   
   struct main_info {
      int type;
      int num_pe;
      int num_task;
      int num_edge;
      int num_iter;
   };

   struct task_info {
      int task_id;
      int pe_id;
      std::vector<int> seq_nums;
      std::vector<int> execs;
      std::vector<int> in_ports;
      std::vector<int> out_ports;
      std::vector<int> sends;
   };
   
   struct port_conn {
      int src;
      int dst;      
   };
   
   boost::property_tree::ptree parse_rtp(std::string filename)
   {
      boost::property_tree::ptree tree;
      tree.put("system.xsm_version.<xmlattr>.value", 4);
      
      std::fstream ifs(filename.c_str(), std::fstream::in);
      
      main_info m;
      
      std::map<int, task_info*> exec_map;
      std::vector<port_conn> ports;
      
      // Ignore first 14 lines (comments)
      for(int i = 0; i < 14; ++i)
	 ifs.ignore(999, '\n');
      
      // First line general infos
      ifs >> m.type >> m.num_pe >> m.num_task >> m.num_edge >> m.num_iter;
      

      // Task execution stuff
      for(int i = 0; i < m.num_task; ++i)
      {
	 task_info* ei = new task_info;
	 ifs >> ei->task_id >> ei->pe_id;
	 
	 for(int j = 0; j < m.num_iter; ++j)
	 {
	    int d;
	    ifs >> d;
	    ei->seq_nums.push_back(d);
	 }
	 
	 for(int j = 0; j < m.num_iter; ++j)
	 {
	    int d;
	    ifs >> d;
	    ei->execs.push_back(d);
	 }
	 
	 // Check that task id is unique
	 if(exec_map.find(ei->task_id) == exec_map.end()) {
	    exec_map[ei->task_id] = ei;
	 } else {
	    std::ostringstream oss;
	    oss << "STP: Task ID \"" << ei->task_id<< "\" not unique";
	    throw std::runtime_error(oss.str().c_str());
	 }
      }
      

      // Communication stuff
      for(int i = 0; i < m.num_edge; ++i)
      {
	 float dummy;
	 int id;
	 int src;
	 int dst;
	 float mean;
	 float dev;
	 ifs >> id >> src >> dst >> dummy >> dummy;
	 
	 // write mem addresses - junk
	 for(int j = 0; j < m.num_iter; ++j)
	 {
	    int d;
	    ifs >> d;
	 }
	 
	 // read mem addresses - junk
	 for(int j = 0; j < m.num_iter; ++j)
	 {
	    int d;
	    ifs >> d;
	 }
	 
	 task_info* sender = (*exec_map.find(src)).second;
	 task_info* receiver = (*exec_map.find(dst)).second;
	 
	 // Store port connection
	 port_conn pc;
	 pc.src = 2*id;
	 pc.dst = 2*id+1;
	 bool found = false;
	 for(int j = 0; j <ports.size(); ++j)
	 {
	    if(ports.at(j).src == pc.src) 
	    {
	       found = true;
	       break;
	    }
	 }
	 if(!found) ports.push_back(pc);
	 
	 // message sizes
	 for(int j = 0; j < m.num_iter; ++j)
	 {
	    int d;
	    ifs >> d;
	    sender->sends.push_back(d);
	    if(find(sender->out_ports.begin(), sender->out_ports.end(), pc.src)
	       == sender->out_ports.end())
	       sender->out_ports.push_back(pc.src);
	 }	 
	 
	 receiver->in_ports.push_back(pc.dst);
      }
      

      // Generate the property_tree
      // Tasks
      int event_id = 0;
      int port     = (m.num_edge + 1) * 2;
      for(std::map<int, task_info*>::iterator iter = exec_map.begin();
	  iter != exec_map.end(); ++iter)
      {
	 boost::property_tree::ptree task;
	 boost::property_tree::ptree trigger;	 
	 
	 std::ostringstream oss;
	 oss << "task_" << (*iter).second->task_id;
	 task.put("<xmlattr>.name", oss.str());
	 task.put("<xmlattr>.id", (*iter).second->task_id);
	 task.put("<xmlattr>.class", "general");
	 trigger.put("<xmlattr>.dependence_type", "and");
	 
	 // in_port tags
	 std::vector<int>& ins = (*iter).second->in_ports;
	 for(int i = 0; i < ins.size(); ++i)
	 {
	    boost::property_tree::ptree tr;
	    tr.put("<xmlattr>.id", ins.at(i));
	    task.add_child("in_port", tr);
	    trigger.add_child("in_port", tr);
	 }
	 
	 // Generate event and ports for tasks without input ports
	 if((*iter).second->in_ports.size() == 0)
	 {	    
	    port_conn c;
	    c.src = port;
	    c.dst = port + 1;
	    ports.push_back(c);
	    boost::property_tree::ptree tr;
	    tr.put("<xmlattr>.id", event_id);
	    std::ostringstream oss;
	    oss << "Event_" << event_id;
	    tr.put("<xmlattr>.name", oss.str());
	    tr.put("<xmlattr>.amount", 1);
	    tr.put("<xmlattr>.prob", 1);
	    tr.put("<xmlattr>.count", m.num_iter);
	    tr.put("<xmlattr>.out_port_id", c.src);
	    tree.add_child("system.application.task_graph.event_list.event",tr);
	    boost::property_tree::ptree tp;
	    tp.put("<xmlattr>.id", c.dst);
	    task.add_child("in_port", tp);
	    trigger.add_child("in_port", tp);
	    event_id++;
	    port += 2;
	    
	 }
	 
	 // out_port
	 std::vector<int>& outs = (*iter).second->out_ports;
	 for(int i = 0; i < outs.size(); ++i)
	 {
	    boost::property_tree::ptree tr;
	    tr.put("<xmlattr>.id", outs.at(i));
	    task.add_child("out_port", tr);
	 }
	 

	 std::vector<int>& execs = (*iter).second->execs;
	 for(int j = 0; j < execs.size(); ++j)
	 {
	    // exec_count
	    boost::property_tree::ptree te;
	    te.put("<xmlattr>.mod_phase", j);
	    te.put("<xmlattr>.mod_period", m.num_iter);
	    te.put("op_count.int_ops.polynomial.param.<xmlattr>.value",
			execs.at(j));
	    te.put("op_count.int_ops.polynomial.param.<xmlattr>.exp", 0);
	    
	    
	    // send	    
	    // if((*iter).second->out_ports.size() > j &&
// 	       (*iter).second->sends.size() > j)
	    for(int k = 0; k < (*iter).second->out_ports.size(); ++k)
	    {
	       boost::property_tree::ptree tr;
	       tr.put("<xmlattr>.out_id", (*iter).second->out_ports.at(k));
	       tr.put("<xmlattr>.prob", 1.0);
	       tr.put("byte_amount.polynomial.param.<xmlattr>.value", 
		      (*iter).second->sends.at(k));
	       tr.put("byte_amount.polynomial.param.<xmlattr>.exp", 0);
	       te.add_child("send", tr);
	    }
	    trigger.add_child("exec_count", te);
	 }
	 	 
	 task.add_child("trigger", trigger);
	 tree.add_child("system.application.task_graph.task", task );
	 
      }
      

      // port connections
      for(int i = 0; i < ports.size(); ++i)
      {
	 boost::property_tree::ptree tr;
	 tr.put("<xmlattr>.src", ports.at(i).src);
	 tr.put("<xmlattr>.dst", ports.at(i).dst);
	 tree.add_child("system.application.task_graph.port_connection", tr);
      }
      

      // Mapping and platform
      for(int i = 0; i < m.num_pe; ++i)
      {
	 boost::property_tree::ptree tr;
	 boost::property_tree::ptree tg;
	 boost::property_tree::ptree pl;
	 std::ostringstream oss;
	 oss << "cpu" <<  i;
	 tr.put("<xmlattr>.name", oss.str());
	 tr.put("<xmlattr>.id", i);
	 pl.put("<xmlattr>.name", oss.str());
	 pl.put("<xmlattr>.id", i);
	 pl.put("<xmlattr>.frequency", 10);
	 pl.put("<xmlattr>.type", "CPU_TYPE_1");
	 pl.put("<xmlattr>.scheduler", "sequence");
	 pl.put("<xmlattr>.packet_size", 16);
	 oss.str("");
	 oss << "group" << i;
	 tg.put("<xmlattr>.name", oss.str());
	 tg.put("<xmlattr>.id", i);
	 for(std::map<int, task_info*>::iterator iter = exec_map.begin();
	     iter != exec_map.end(); ++iter)
	 {
	    if((*iter).second->pe_id == i)
	    {
	       boost::property_tree::ptree tt;
	       oss.str("");
	       oss << "task_" << (*iter).second->task_id;
	       tt.put("<xmlattr>.name", oss.str());
	       tt.put("<xmlattr>.id", (*iter).second->task_id);
	       std::ostringstream seqs;
	       for(int j = 0; j < (*iter).second->seq_nums.size(); ++j)
	       {
		     if(j == 0)
			seqs << (*iter).second->seq_nums.at(j);
		     else
			seqs << "," <<  (*iter).second->seq_nums.at(j);
	       }
	       tt.put("<xmlattr>.schedule_seq", seqs.str());
	       tg.add_child("task", tt);
	    }
	 }
	 tr.add_child("group", tg);
	 tree.add_child("system.mapping.resource", tr);
	 tree.add_child("system.platform.resource_list.resource", pl);	 
      }
      
      
      ifs.close();
      return tree;
   
}
}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
