Directory for libraries used by Execution Monitor only.
All Jars in this directory are included in the build path.