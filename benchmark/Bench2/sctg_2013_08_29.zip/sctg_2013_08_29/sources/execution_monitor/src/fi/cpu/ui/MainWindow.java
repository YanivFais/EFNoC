/*
 * CVS-tietoja:
 * $Author: perttul5 $ 
 * $Date: 2008-05-20 17:23:56 +0300 (ti, 20 touko 2008) $ 
 * $Revision: 3514 $
 *
 * Created on 19.7.2005
 *
 *
 *
 * Copyright 2009 Tampere University of Technology
 * 
 *  This file is part of Execution Monitor.
 *
 *  Execution Monitor is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Execution Monitor is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Execution Monitor.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 *
 */
package fi.cpu.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.beans.PropertyVetoException;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JToggleButton;
import javax.swing.KeyStroke;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.MouseInputAdapter;

import fi.cpu.Settings;
import fi.cpu.data.GraphDataLogger;
import fi.cpu.data.Configuration;
import fi.cpu.data.Model;
import fi.cpu.data.TraceDataLogger;
import fi.cpu.event.ModelEvent;
import fi.cpu.event.ModelListener;
import fi.cpu.handler.Handler;
import fi.cpu.serial.LinuxSerial;
import fi.cpu.serial.WindowsSerial;
import fi.cpu.tcp.TCPClient;


import fi.cpu.ui.ctrl.ControlTab;
import fi.cpu.ui.ctrl.PePanel;
import fi.cpu.ui.ctrl.ProcessIcon;
import fi.cpu.ui.graph.GraphPanel;
import fi.cpu.ui.report.PeTab;
import fi.cpu.ui.service.ServiceDataFlowTab;
import fi.cpu.ui.service.ServiceTab;
import fi.cpu.ui.xml.UIConfigIO;


/**
 * The main window for Execution Monitor
 */
public class MainWindow extends JFrame {

    // Shown messages
    public static final String VERSION = Settings.getAttributeValue("VERSION");

    public static final String OPEN_NAME = "OPEN";
    public static final String SAVE_NAME = "SAVE";
    public static final String SAVE_AS_NAME = "SAVE_AS";
    public static final String CONNECTION = "CONNECTION";
    public static final String EXIT_NAME = "EXIT";

    public static final String EDIT_SETTINGS_NAME = "EDIT_SETTINGS";
    public static final String ABOUT_NAME = "ABOUT";

    public static final String SHOW_DEBUG_WINDOW = "SHOW_DEBUG_WINDOW";
    public static final String ADD_GRAPH = "ADD_GRAPH";

    protected static final String RECONNECT_CMD = "reconnect";
    protected static final String ACTIVATE_PROCESSES_CMD = "activate";
    protected static final String RUN_USECASE_CMD = "runusecase";

    // "header" files (x.properties) for common definitions
    private static final String UITEXT_BUNDLE_NAME = "uitexts";
    private static final String SERIAL_BUNDLE_NAME = "serial";
    public static ResourceBundle bundle;
    private ResourceBundle serialProperties;

    // Current settings 
    protected static MainWindow self;
    protected Configuration configuration; // GUI settings
    protected Map<String, GraphPanel> graphPanels; //Opened custom graphs
    protected Handler connectionHandler;
    protected File currentLogDir;
    protected File currentTraceDir;
    protected boolean activatingProcesses;

    // Icons, menus etc.
    protected ImageIcon logoIcon;
    protected ProcessIcon draggedProcess;
    private MyProcessDragListener dragListener;
    private Point dragPoint;
    private JTextArea debugTextArea;
    private JInternalFrame debugWindow;
    protected JMenuItem connectionMenuItem;
    protected JPopupMenu popupMenu;

    // Tabs for different views
    protected JTabbedPane tabbedPane;
    protected ControlTab         controlTab;
    protected PeTab              peTableTab;
    protected ProcessTab         processTableTab;
    protected SignalTab          signalTableTab;
    protected ServiceDataFlowTab serviceTab;
    protected ServiceTab         serviceTableTab;
    protected JDesktopPane       graphTab;

    // Buttons etc.
    protected JButton reconnectButton;
    protected JToggleButton doLoggingButton;
    protected JButton clearButton;           //added by ES
    protected JToggleButton doTracingButton; // not used with TG
    protected JButton activateButton;        // not used with TG
    protected JButton runUseCaseButton;      // not used with TG
    protected JCheckBox autoActiveCheckBox;  // not used with TG
    protected JPanel serviceActiveTimePanel;
    protected JSpinner serviceActiveTimeSpinner;
    protected JLabel serviceActiveTimeLabel;

    
    
    /**
     * @return An instance of MainWindow.
     */
    public static MainWindow getInstance() {
        if (self == null) {
            self = new MainWindow();
        }
        return self;
    }

    
    /**
     * Constructor. Creates new MainWindow.
     */
    private MainWindow() {
    	configuration = new Configuration();
    	dragListener  = new MyProcessDragListener();
    	graphPanels   = new HashMap<String, GraphPanel>();
    	activatingProcesses = false;
    	
	// Create icon
	String iconLocation = "/fi/cpu/resources/koski_logo_16x16.gif";
	URL iconURL = MainWindow.class.getResource(iconLocation);
		
	if (iconURL != null) {
	    logoIcon = new ImageIcon(iconURL);
	    setIconImage(logoIcon.getImage());
	} else {
	    System.err.println("Couldn't load the logo:" + iconLocation);
	}
    	
    	// Create resource bundles to access the common definitions
        bundle = ResourceBundle.getBundle(UITEXT_BUNDLE_NAME);
        serialProperties = ResourceBundle.getBundle(SERIAL_BUNDLE_NAME);

        // Create all the tabs
        controlTab       = new ControlTab(configuration);
        peTableTab       = new PeTab(configuration);
        processTableTab  = new ProcessTab(configuration);
        signalTableTab   = new SignalTab(configuration);
        serviceTab       = new ServiceDataFlowTab(configuration);
        serviceTableTab  = new ServiceTab(configuration);

        graphTab         = new JDesktopPane();
        graphTab.addMouseListener(new MyMouseListener());
        graphTab.setBackground(getBackground());

        // Create a tabbed pane to navigate through the tabs
        tabbedPane = new JTabbedPane();
        tabbedPane.addChangeListener(new MyTabChangeListener());
        
        tabbedPane.addTab(bundle.getString("CONTROL_TAB"), controlTab);
        tabbedPane.addTab(bundle.getString("PE_TABLE_TAB"), peTableTab);
        tabbedPane.addTab(bundle.getString("PROCESSES_TAB"), processTableTab);
        tabbedPane.addTab(bundle.getString("SIGNALS_TAB"), signalTableTab);
        tabbedPane.addTab(bundle.getString("SERVICES_TAB"), serviceTab);
        tabbedPane.addTab(bundle.getString("SERVICE_TABLE_TAB"), serviceTableTab);
        tabbedPane.addTab(bundle.getString("GRAPHS_TAB"), graphTab);


        // Add main components to the view
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle(bundle.getString("MAINTITLE"));
        setPreferredSize(new Dimension(800, 600));
        addWindowListener(new MyWindowListener());
        setLayout(new BorderLayout());
        add(tabbedPane, BorderLayout.CENTER);
        add(createBottomPanel(), BorderLayout.SOUTH);
        
        configuration.getServiceModel().addModelListener(new MyServiceModelListener());
        
        initMenus();
        initConnectionHandler(); //connect to FPGA or TG
    }

    
    /**
     * Creates the button panel at the bottom of the main window
     */
    private JPanel createBottomPanel() {
    	MyActionListener actionListener = new MyActionListener();
    	
    	// Create the panel
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBorder(BorderFactory.createEtchedBorder());
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        
        // Create button for reconnection via TCP socket or serial connection
        reconnectButton = new JButton(bundle.getString("RECONNECT_BUTTON"));
        reconnectButton.setMnemonic(KeyEvent.VK_R);
        reconnectButton.setActionCommand(RECONNECT_CMD);
        reconnectButton.addActionListener(actionListener);
        
        // Create button for starting and stopping graph data logging
        doLoggingButton = new JToggleButton(bundle.getString("LOGGING_BUTTON"));
        doLoggingButton.setMnemonic(KeyEvent.VK_L);
        doLoggingButton.addItemListener(new MyLoggingButtonListener());

	// ES. tyhjennet��n k�ppyr�t ennen uusia arvoja
        clearButton = new JButton("Clear stats");
	clearButton.setMnemonic(KeyEvent.VK_C);
        clearButton.setActionCommand("clear");
        clearButton.addActionListener(actionListener);



        // Create button for starting and stopping the storing of execution trace
	// 2012-09-27 Commented out since this is not needed with TG, ES
        //doTracingButton = new JToggleButton(bundle.getString("TRACING_BUTTON"));
        //doTracingButton.setMnemonic(KeyEvent.VK_T);
        //doTracingButton.addItemListener(new MyTracingButtonListener());

        // Create button for run a use case
	// 2012-09-25 Commented out since this is not needed with TG, ES
	//runUseCaseButton = new JButton(bundle.getString("RUN_USECASE_BUTTON"));
        //runUseCaseButton.setMnemonic(KeyEvent.VK_U);
        //runUseCaseButton.setActionCommand(RUN_USECASE_CMD);
        //runUseCaseButton.addActionListener(actionListener);
        
        // Create components for activation of process remapping
        autoActiveCheckBox = new JCheckBox( bundle.getString( "AUTO_ACTIVE" ) );
	// 2012-09-25 Commented out since this is not needed with TG, ES
        //autoActiveCheckBox.setSelected( true );

        activateButton = new JButton( bundle.getString( "ACTIVE_BUTTON" ) );
	// 2012-09-25 Commented out since this is not needed with TG, ES
        //activateButton.setMnemonic(KeyEvent.VK_A);
        //activateButton.setActionCommand(ACTIVATE_PROCESSES_CMD);
        //activateButton.addActionListener(actionListener);

        
        // Create components for service activation time selection
	double activeTimeDefault = Double.parseDouble( Settings.getAttributeValue("SERVICE_ACTIVE_TIME_DEFAULT"));
	double activeTimeMin = Double.parseDouble( Settings.getAttributeValue("SERVICE_ACTIVE_TIME_MIN"));
	double activeTimeMax = Double.parseDouble( Settings.getAttributeValue("SERVICE_ACTIVE_TIME_MAX"));
	double activeTimeStep = Double.parseDouble( Settings.getAttributeValue("SERVICE_ACTIVE_TIME_STEP"));
	
	serviceActiveTimePanel = new JPanel();
	serviceActiveTimePanel.setLayout(new GridBagLayout());
        serviceActiveTimeLabel = new JLabel(bundle.getString("ACTIVATION_TIME_LENGTH"));
        
        // create spinner for selecting activation duration
        SpinnerNumberModel spinnerModel = new SpinnerNumberModel(
        		activeTimeDefault, activeTimeMin, activeTimeMax, activeTimeStep);
        serviceActiveTimeSpinner = new JSpinner(spinnerModel);
        serviceActiveTimeSpinner.addChangeListener(new ChangeListener() {
        	public void stateChanged(ChangeEvent e) {
        		Double value = (Double)serviceActiveTimeSpinner.getValue();
        		serviceTab.setActivationTime(value);
        	}
        });

        serviceActiveTimePanel.add(serviceActiveTimeLabel, new GridBagConstraints(
        		0, 0, 1, GridBagConstraints.REMAINDER, 1.0, 0.0,
        		GridBagConstraints.EAST, GridBagConstraints.NONE,
        		new Insets(0, 0, 0, 0), 0, 0));
        serviceActiveTimePanel.add(serviceActiveTimeSpinner, new GridBagConstraints(
        		1, 0, GridBagConstraints.REMAINDER, GridBagConstraints.REMAINDER, 0.0, 0.0,
        		GridBagConstraints.EAST, GridBagConstraints.NONE,
        		new Insets(0, 5, 0, 0), 0, 0));
        // initially not visible, because starting tab is not service tab
        serviceActiveTimePanel.setVisible(false);


        
        // Add the components to the panel
        bottomPanel.add( Box.createHorizontalStrut( 30 ) );
        bottomPanel.add( reconnectButton );
        bottomPanel.add( Box.createHorizontalStrut( 30 ) );
        bottomPanel.add( doLoggingButton );
        bottomPanel.add( Box.createHorizontalStrut( 30 ) );
        bottomPanel.add( clearButton );
        // bottomPanel.add( doTracingButton );
        bottomPanel.add( Box.createHorizontalStrut( 30 ) );
	// 2012-09-25 Commented out since this is not needed with TG, ES
	//  bottomPanel.add( runUseCaseButton );
        // bottomPanel.add( Box.createVerticalStrut( 40 ) );
        bottomPanel.add( Box.createHorizontalGlue() );
        //bottomPanel.add( autoActiveCheckBox );
        bottomPanel.add( Box.createHorizontalStrut( 30 ) );
        //bottomPanel.add( activateButton );
        bottomPanel.add( Box.createHorizontalStrut( 30 ) );
        bottomPanel.add( serviceActiveTimePanel );
        bottomPanel.add( Box.createHorizontalStrut( 30 ) );

        return bottomPanel;
    }

    
    /**
     * Initializes main window menus
     */
    private void initMenus() {
        JMenuBar menuBar = null;
        JMenu menu = null;
        JMenuItem menuItem = null;
        MenuItemListener actionListener = new MenuItemListener();
        
        //Create the top menu bar.
        menuBar = new JMenuBar();

        //Build the FILE menu.
        menu = new JMenu( bundle.getString( "MENU_FILE" ) );
        menu.setMnemonic( KeyEvent.VK_F );
        menu.getAccessibleContext().setAccessibleDescription(
                "MENU_FILE_DESCRIPTION" );
        menuBar.add( menu );

        menuItem = new JMenuItem( bundle.getString( "MENU_OPEN" ) );
        menuItem.setMnemonic( KeyEvent.VK_O );
        menuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_O,
                ActionEvent.CTRL_MASK ) );
        menuItem.setName( OPEN_NAME );
        menuItem.addActionListener( actionListener );
        menu.add( menuItem );

        menuItem = new JMenuItem( bundle.getString( "MENU_SAVE" ) );
        menuItem.setMnemonic( KeyEvent.VK_S );
        menuItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_S,
                ActionEvent.CTRL_MASK ) );
        menuItem.setName( SAVE_NAME );
        menuItem.addActionListener( actionListener );
        menu.add( menuItem );

        menuItem = new JMenuItem( bundle.getString( "MENU_SAVE_AS" ) );
        menuItem.setName( SAVE_AS_NAME );
        menuItem.addActionListener( actionListener );
        menu.add( menuItem );

        menu.addSeparator();
        
        menuItem = new JCheckBoxMenuItem( bundle.getString( "CONNECTION" ) );
        menuItem.setName( CONNECTION );
        menuItem.addActionListener( actionListener );
        menuItem.setSelected( true );
        menu.add( menuItem );
        connectionMenuItem = menuItem;
        
        menu.addSeparator();
        
        menuItem = new JMenuItem( bundle.getString( "MENU_EXIT" ) );
        menuItem.setMnemonic( KeyEvent.VK_X );
        menuItem.setName( EXIT_NAME );
        menuItem.addActionListener( actionListener );
        menu.add( menuItem );


        //Build the EDIT menu.
        menu = new JMenu( bundle.getString( "MENU_EDIT" ) );
        menu.setMnemonic( KeyEvent.VK_E );
        menu.getAccessibleContext().setAccessibleDescription(
                "MENU_EDIT_DESCRIPTION" );
        menuBar.add( menu );

        menuItem = new JMenuItem( bundle.getString( "MENU_EDIT_SETTINGS" ) );
        menuItem.setMnemonic( KeyEvent.VK_S );
        menuItem.setName( EDIT_SETTINGS_NAME );
        menuItem.addActionListener( actionListener );
        menu.add( menuItem );

    
        //Build the HELP menu.
        menu = new JMenu( bundle.getString( "MENU_HELP" ) );
        menu.setMnemonic( KeyEvent.VK_H );
        menu.getAccessibleContext().setAccessibleDescription(
                "MENU_HELP_DESCRIPTION" );
        menuBar.add( menu );

        menuItem = new JMenuItem( bundle.getString( "MENU_ABOUT" ) );
        menuItem.setMnemonic( KeyEvent.VK_A );
        menuItem.setName( ABOUT_NAME );
        menuItem.addActionListener( actionListener );
        menu.add( menuItem );

        this.setJMenuBar( menuBar );


        // Create the popup menu for adding graphs and debug window
        popupMenu = new JPopupMenu();

        menuItem = new JMenuItem( bundle.getString( ADD_GRAPH ) );
        menuItem.setName( ADD_GRAPH );
        menuItem.addActionListener( actionListener );

        popupMenu.add( menuItem );
        popupMenu.addSeparator();

        menuItem = new JMenuItem( bundle.getString( SHOW_DEBUG_WINDOW ) );
        menuItem.setName( SHOW_DEBUG_WINDOW );
        menuItem.addActionListener( actionListener );

        popupMenu.add( menuItem );
    }
    
    
    /**
     * Initializes the handler for the FGPA board connection. Works also 
     * with TG (Transaction Generator, a SystemC simulator).
     */
    private void initConnectionHandler() {
        try {
            if ((System.getProperty("os.name").toString().equalsIgnoreCase("linux"))
		&& System.getProperty("serial") != null) {
            	// linux + serial
                connectionHandler = new LinuxSerial(serialProperties.getString("PORT_LINUX"),
						    Integer.parseInt(serialProperties.getString("SPEED")), true);
                                
            } else if (System.getProperty("serial") != null) {
            	// windows + serial
                connectionHandler = new WindowsSerial(serialProperties.getString("PORT_LINUX"),
						      Integer.parseInt(serialProperties.getString("SPEED")), true);
		
            } else {
            	// tcp/ip
            	String tcpIp = null;
            	String tcpPort = null;
            	Integer tcpPortInt = null;
            	
		tcpIp = System.getProperty("ip");
		if (tcpIp == null) {
		    tcpIp = serialProperties.getString("TCP_IP");					
		}
		
		tcpPort = System.getProperty("port");
		if (tcpPort != null) {
		    tcpPortInt = Integer.parseInt(tcpPort);
		} else {
		    tcpPortInt = Integer.parseInt(serialProperties.getString("TCP_PORT"));
		}
            	
                connectionHandler = new TCPClient(tcpIp, tcpPortInt);
            }
            
        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
        }
    }
    
    /**
     * @return The configuration that is in use.
     */
    public Configuration getConfiguration() {
    	return configuration;
    }
    
    
    /**
     * @return Returns the signals tab.
     */
    public SignalTab getSignalTableTab() {
	return signalTableTab;
    }

    /**
     * @return Returns the PE table tab.
     */
    /*	public PeTab getPeTableTab() {
		return peTableTab;
	}
	
    */
    /** Renamed from getProcessTab
     * @return Returns the processes tab.
     */
    public ProcessTab getProcessTableTab() {
	return processTableTab;
    }
    
    /**
     * @return Returns the service tab.
     */
    public ServiceDataFlowTab getServiceTab() {
	return serviceTab;
    }

    
    /**
     * @return The container tab for user-defined graphs
     */
    public JDesktopPane getGraphTab() {
    	return graphTab;
    }
    
    

    
    /**
     * @return The debug window
     */
    public JInternalFrame getDebugWindow() {
    	return debugWindow;
    }

            
    /**
     * Sets the auto activation on/off.
     */
    public void setAutoActive(boolean autoActive) {
    	autoActiveCheckBox.setSelected(autoActive);
    }
    
    
    /**
     * @return True if auto activation is on.
     */
    public boolean isAutoActive() {
        return autoActiveCheckBox.isSelected();
    }
    
    
    /**
     * @return The handler for the board connection.
     */
    public Handler getConnectionHandler() {
    	return connectionHandler;
    }


    
    public void setSimulationTime(long time) {
    	GraphPanel.setSimulationTime(time);
    }
    
    public void configurationChanged() {
	System.out.println("cfgchanged()");
    	Set<Map.Entry<String, GraphPanel>> graphPanelSet = graphPanels.entrySet();
        for (Map.Entry<String, GraphPanel> graphPanelEntry : graphPanelSet) {
	    // System.out.println("call addMarker()");
	    graphPanelEntry.getValue().addMarker();
        }
    }
    


    /**
     * @return The list of custom graphs
     */
    public List<GraphPanel> getGraphPanels() {
    	return new ArrayList<GraphPanel>(graphPanels.values());
    }

    /**
     * Returns a graph panel, e.g. CPU utilization in ctrl tab.
     * @param peId    Id of the PE, or null if a non-PE graph.
     * @param graphId Id of the graph.
     * @return        The graph, or null if not found.
     */
    public GraphPanel getGraphPanel(String peId, String graphId) {
    	GraphPanel panel = null;
    	if (peId == null) {
	    panel = graphPanels.get(graphId);
    	} else {
	    // Find the pe graph panel from ControlTab
	    PePanel pePanel = controlTab.getPePanel(peId);
	    if (pePanel != null) {
		panel = pePanel.getGraphPanel(graphId);
	    }
    	}
    	
    	return panel;
    }
    
    
    
    /**
     * Adds new value to graph.
     * @param peId    Id of the PE, or null if a non-PE graph.
     * @param graphId Id of the graph.
     * @param value The new value.
     */
    public void addValueToGraph(String peId, String graphId, double value) {
    	GraphPanel panel = getGraphPanel(peId, graphId);
        if (panel != null) {
	    //System.out.println("main: addVal(" + peId + ", " +
	    //		       graphId + ", " + value + ")");
	    
	    // Find out who called this function
	    //StackTraceElement[] stacktrace = Thread.currentThread().getStackTrace();
	    //StackTraceElement e = stacktrace[2];//maybe this number needs to be corrected
	    //String methodName = e.getMethodName();
	    //System.out.println ("called by " + methodName);


	    panel.addData(value);
        }
    }
    
    
    /**
     * Adds a graph to a container panel with given location
     * and size, and makes the graph visible.
     */
    public void addGraph(GraphPanel gpanel,
			 int xLocation, int yLocation, 
			 int width, int height) {
    	addGraph(gpanel, xLocation, yLocation, width, height, true);
    }
    
    
    /**
     * Adds a graph to the graph tab with given location
     * and size.
     */
    public void addGraph(GraphPanel gpanel,
			 int xLocation, int yLocation, 
			 int width, int height, boolean showIt) {
    	String id = gpanel.getGraphInfo().getId();
    	GraphPanel existingPanel = graphPanels.get(id);
        JInternalFrame iFrame = null;
    	
	//System.out.println ("main: addGraph " + id);

    	if (existingPanel == null) {
	    // Add as new graphWindow
	    graphPanels.put(id, gpanel);
            iFrame = createGraphWindow(gpanel);
            iFrame.setLocation(xLocation, yLocation);
            iFrame.setSize(width, height);
            iFrame.addInternalFrameListener(new MyInternalFrameListener(id));
            graphTab.add(iFrame);
            
    	} else {
	    // This graph has been created already. Find it, so it can be selected and set visible
	    JInternalFrame[] iFrames = graphTab.getAllFrames();
	    boolean found = false;
	    for (int i=0; i<iFrames.length && !found; ++i) {
		JInternalFrame f = iFrames[i];
		
		for (int j=0; j<f.getComponentCount(); ++j) {
		    if (SwingUtilities.isDescendingFrom(existingPanel, f.getComponent(j))) {
			iFrame = f;
			found = true;
			break;
		    }
		}
	    }
	    
	    if (!found) {
		// shouldn't happen...anymore :)
		return;
	    }
    	}
	

	// Set the graph visible and put Graph tab to front
        iFrame.setVisible(true);
	
        try {
            iFrame.setSelected(true);    
        } catch (PropertyVetoException e) {
            // do nothing
        }
	
        graphTab.moveToFront(iFrame);
        if (showIt) {
	    tabbedPane.setSelectedIndex(tabbedPane.indexOfComponent(graphTab));
        }
        repaint();
    }
    
    

    /**
     * Removes all graphs.
     */
    public void removeGraphs() {
    	graphTab.removeAll();
    	graphPanels.clear();
    	repaint();
    }


    /**
     * Creates a window that contains the given graph panel. (Will be
     * put into graph tab)
     */
    private JInternalFrame createGraphWindow(GraphPanel panel) {
        JInternalFrame jif = new JInternalFrame( "", true, true, true, true );
        //jif.setLocation((2%4)*140,(2/4)*180);
        jif.getContentPane().add(panel);
        jif.setTitle(panel.getGraphInfo().getTitle());
        jif.setToolTipText(panel.getGraphInfo().getTitle());
        jif.setFrameIcon(logoIcon);
        jif.pack();
        jif.setVisible(true);
        return jif;
    }
    
    

    /**
     *  Shows the debug window in the Graph tab
     */
    public void showDebugWindow(int xLocation, int yLocation, int width,
            int height) {
        if (debugWindow == null) {
            createDebugWindow(xLocation, yLocation, width, height);
        }
        
        // Check if the debug window exists in the graph tab
        Component[] compArrray = graphTab.getComponents();

        boolean contain = false;
        for (int i = 0; i < compArrray.length; ++i) {
            if (compArrray[i].equals(debugWindow)) {
                contain = true;
            }
        }

        if (!contain) {
            graphTab.add(debugWindow);
        }

        debugWindow.setVisible(true);
    }


    /**
     * Creates a window for showing debug messages.
     */
    private void createDebugWindow( int xLocation, int yLocation, int width,
            int height ) {
        debugTextArea = new JTextArea( 20, 40 );

        debugTextArea.setEditable( false );
        debugTextArea.setAutoscrolls( true );

        JScrollPane jsp = new JScrollPane( debugTextArea );
        jsp.setPreferredSize( new Dimension( 120, 140 ) );
        jsp.setAutoscrolls( true );

        debugWindow = new JInternalFrame( bundle
                .getString( "DEBUG_WINDOW_TITLE" ), true, true, true, true );

        debugWindow.getContentPane().add( jsp );
        debugWindow.pack();

        debugWindow.setSize( width, height );
        debugWindow.setLocation( xLocation, yLocation );

        graphTab.add( debugWindow );
    }
    
    /**
     * Adds a debug message.
     * @param message
     */
    public void addDebugMessage(String message) {
        if ( debugTextArea == null ) {
            createDebugWindow( 0, 0, 200, 300 );
        }

        debugTextArea.append( new java.text.SimpleDateFormat(
                "dd.MM.yyyy, HH:mm:ss" ).format( new java.util.Date( System
                .currentTimeMillis() ) )
                + " " + message + "\n" );

        debugTextArea.setCaretPosition(debugTextArea.getText().length());
    }



    
    /**
     * Checks if current service model contains services
     * and sets service related tabs visible accordingly.
     */
    protected void checkServiceExistence() {
    	Model sModel = configuration.getServiceModel();
    	
    	if (sModel.getChildren(sModel.getModelRoot()).size() == 0) {
    		// No services: disable service tabs
    		tabbedPane.setEnabledAt(tabbedPane.indexOfComponent(serviceTab), false);
    		tabbedPane.setEnabledAt(tabbedPane.indexOfComponent(serviceTableTab), false);
    		
    		// If service tab selected, change to control tab
    		Component comp = tabbedPane.getSelectedComponent();
    		if (comp == serviceTab) {
    			tabbedPane.setSelectedComponent(controlTab);
    		}
    	} else {
    		tabbedPane.setEnabledAt(tabbedPane.indexOfComponent(serviceTab), true);
    		tabbedPane.setEnabledAt(tabbedPane.indexOfComponent(serviceTableTab), true);
    	}
    	
    	validate();
    	repaint();
    }
    



    
    /**
     * Listener for changes in activated tab.
     */
    private class MyTabChangeListener implements ChangeListener {
    	public void stateChanged(ChangeEvent e) {
	    Component selected = tabbedPane.getSelectedComponent();
	    
	    if (controlTab != null
		&& activateButton != null
		&& autoActiveCheckBox != null
		&& serviceActiveTimePanel != null) {
    		
		// set visibility of process activation selections
		if (selected == controlTab) {
		    // Commented away, since not needed with TG. ES, fall 2012
		    //activateButton.setVisible(true);
		    //autoActiveCheckBox.setVisible(true);
		    
		} else {
		    activateButton.setVisible(false);
		    autoActiveCheckBox.setVisible(false);    			
		}
    		
		// set visibility of service activation time selection
		if (selected == serviceTab) {
		    serviceActiveTimePanel.setVisible(true);
		    
		} else {
		    serviceActiveTimePanel.setVisible(false);
		}
	    }
    	}
    }
    
    
    /**
     * Listener for MouseEvents from graph panel
     */
    private class MyMouseListener extends MouseAdapter {
        public void mouseClicked(MouseEvent e) {
            if (SwingUtilities.isRightMouseButton(e)) {
                popupMenu.show( e.getComponent(), e.getX(), e.getY() );
            }
        }
    }

    /** 
     * Removes the data points and lines, and clears min/avg/max counters
     */
    public void clearGraphs() {
	// System.out.println("MainWindow.clerGraphs()");

	// CPU graphs
	controlTab.clearGraphs();

	// Custom graphs
    	Set<Map.Entry<String, GraphPanel>> graphPanelSet = graphPanels.entrySet();
        for (Map.Entry<String, GraphPanel> graphPanelEntry : graphPanelSet) {
	    graphPanelEntry.getValue().clearGraph();
        }

    }


    /** new 2013-02-04
     * Removes the statistics from the tables
     */
    public void clearTables() {
	//System.out.println("MainWindow.clerTables()");

	// Clear the data structures
	Model mo = configuration.getPeModel();
	mo.clearStats(mo.getModelRoot());

	mo = configuration.getServiceModel();
	mo.clearStats(mo.getModelRoot());

	// Redraw the tabs
	peTableTab.initPanel();
	processTableTab.initPanel();
	signalTableTab.clear();
    }

    
    /**
     * Listener for ActionEvents (used with button panel at the bottom).
     */
    private class MyActionListener implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
    		String cmd = e.getActionCommand();
    		
    		if (cmd.equals(RECONNECT_CMD)) {
				if (connectionHandler != null) {
					connectionHandler.reconnect();
					connectionMenuItem.setSelected(true);
				}
				
    		} else if (cmd.equals("clear")) {
		    //System.out.println("Clear all graphs - pressed");
		    clearGraphs();
		    clearTables();

    		} else if (cmd.equals(RUN_USECASE_CMD)) {
		    // Ask device to run use case
		    try {
			System.out.println ("Run use case");
			startTracing(true); // true = send cmd to fpga
			connectionHandler.writeToDestination("<run_usecase>");
		    } catch (IOException exception) {
			// TODO Auto-generated catch block
			exception.printStackTrace();
		    }
		    
		} else if (cmd.equals(ACTIVATE_PROCESSES_CMD)) {
		    System.out.println ("Activate process remapping");
		    activatingProcesses = true;
		    controlTab.commitProcessMoves();
		    activatingProcesses = false;
		    sendMappingString();
		}
    	}
    }
    
    
    /**
     * Listener for ItemEvents from doLoggingButton
     */
    private class MyLoggingButtonListener implements ItemListener {
    	private boolean ignoreChange = false;

    	public void itemStateChanged(ItemEvent e) {
	    if (!ignoreChange) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
		    try {
			String logParentDir = SettingsDialog.getInstance().getLogDirectoryPath();
			GraphDataLogger.getInstance().setLogDirectory(new File(logParentDir));
			currentLogDir = GraphDataLogger.getInstance().startLogging();
		    } catch (IOException ioe) {
			Object source = e.getSource();
			if (source instanceof JToggleButton) {
			    JToggleButton tButton = (JToggleButton) source;
			    ignoreChange = true;
			    tButton.setSelected(false);
			    ignoreChange = false;
			}
			JOptionPane.showMessageDialog(MainWindow.getInstance(),
						      bundle.getString("LOGGING_START_ERROR_MSG")+" "+ioe.getMessage(),
						      null, JOptionPane.ERROR_MESSAGE);
		    }
		} else {
		    stopLogging(null);
		}
	    }
    	}
    }
    
    /**
     * Stops graph data logging. 
     * Called if user deactivates button or if FPGA sends an end tag </log>
     * @param errorMsg The message to be shown if logging ended due to an error.
     */
    public void stopLogging(String errorMsg) {
		if (currentLogDir == null) {
			// logging hasn't started
			return;
		}
		
		GraphDataLogger.getInstance().stopLogging();
		
		if (errorMsg == null) {
			JOptionPane.showMessageDialog(MainWindow.getInstance(),
					bundle.getString("LOGGING_ENDED_MSG")+" "+currentLogDir.getAbsolutePath(),
					bundle.getString("LOGGING_ENDED_TITLE"), JOptionPane.INFORMATION_MESSAGE);
		} else {
			JOptionPane.showMessageDialog(MainWindow.getInstance(),
					bundle.getString("LOGGING_ERROR_MSG")+" "+errorMsg,
					bundle.getString("LOGGING_ENDED_TITLE"), JOptionPane.ERROR_MESSAGE);
		}
		currentLogDir = null;
		doLoggingButton.setSelected(false);
    }
    
    

    
    /**
     * Listener for events from graph windows.
     */
    private class MyInternalFrameListener extends InternalFrameAdapter {
    	private String graphId;
    	public MyInternalFrameListener(String graphId) {
    		this.graphId = graphId;
    	}
    	public void internalFrameClosed(InternalFrameEvent e) {
    		graphPanels.remove(graphId);
    	}
    }
    
    
    /**
     * Listener for service model events.
     */
    private class MyServiceModelListener implements ModelListener {
    	public void nodeInserted(ModelEvent e) {
    		checkServiceExistence();
    	}
    	public void nodeRemoved(ModelEvent e) {
    		checkServiceExistence();
    	}
    	public void nodeMoved(ModelEvent e) {
    		checkServiceExistence();
    	}
    	public void structureChanged(ModelEvent e) {
    		checkServiceExistence();
    	}
    }
    
    /**
     * Listener for Window changes
     * 
     * @author perttul5
     *
     */
    public class MyWindowListener implements WindowListener {

    	@Override
    	public void windowActivated(WindowEvent e) {
    		// TODO Auto-generated method stub
    		
    	}

    	@Override
    	public void windowClosed(WindowEvent e) {
    		connectionHandler.disconnect();
    		System.exit(0);
    	}

    	@Override
    	public void windowClosing(WindowEvent e) {
    		connectionHandler.disconnect();
    		System.exit(0);
    	}

    	@Override
    	public void windowDeactivated(WindowEvent e) {
    		// TODO Auto-generated method stub
    		
    	}

    	@Override
    	public void windowDeiconified(WindowEvent e) {
    		// TODO Auto-generated method stub
    		
    	}

    	@Override
    	public void windowIconified(WindowEvent e) {
    		// TODO Auto-generated method stub
    		
    	}

    	@Override
    	public void windowOpened(WindowEvent e) {
    		// TODO Auto-generated method stub
    		
    	}
    	
    }



    /*************
     * Code below this point is useful only with FPGA, not TG.
     ************ */

    
    /**
     * Listener for process drag events
     */
    private class MyProcessDragListener extends MouseInputAdapter {
    	public void mouseReleased(MouseEvent e) {
    		setDraggedProcess(null);
    		self.repaint();
    	}
    	public void mouseDragged(MouseEvent e) {
    		Point p = e.getPoint();
    		Point offset = draggedProcess.getDragOffset();
    		Point shadowIconOrigin = new Point(p.x-offset.x, p.y-offset.y);
    		
    		// Convert the icon origin to main window coordinate space
    		Point convertedOrigin = SwingUtilities.convertPoint(draggedProcess, shadowIconOrigin, self);

    		self.setProcessDraggingPoint(convertedOrigin);
    		self.repaint();
    	}
    }
    
    
    /**
     * Sets process dragging on/off.
     */
    public void setDraggedProcess(ProcessIcon process) {
    	if (draggedProcess != null) {
    		draggedProcess.removeMouseListener(dragListener);
    		draggedProcess.removeMouseMotionListener(dragListener);
    	}
        draggedProcess = process;
    	
        if (draggedProcess == null) {
        	return;
        }
        
        Point pLoc = new Point(0,0);
        
        // Calculate the location of the process in main window's
        // coordinate space
        Point convertedLoc = SwingUtilities.convertPoint(draggedProcess, pLoc, this);
        setProcessDraggingPoint(new Point(convertedLoc.x, convertedLoc.y));

        draggedProcess.addMouseListener(dragListener);
        draggedProcess.addMouseMotionListener(dragListener);
    }

    
    /**
     * Sets the point where the dragged process is.
     */
    protected void setProcessDraggingPoint(Point p) {
        dragPoint = p;
    }

    
    /**
     * Sends the (modified) mapping information to FPGA. (Not useful with TG)
     */
    public void sendMappingString() {
    	if (activatingProcesses) {
    		return;
    	}
        try {
            if ( connectionHandler != null ) {
                connectionHandler.writeToDestination(UIConfigIO.createMappingXMLString(configuration));
            }
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }
    
    /** If a process is being dragged, draw the shadow icon
     */
    public void paint(Graphics g) {
        super.paint(g);

        if (draggedProcess != null) {
            Graphics2D g2 = (Graphics2D)g.create();    
            g2.setColor(ProcessIcon.MOVE_COLOR);

            if (ProcessIcon.SQUARE_SHAPE) {
                g2.fillRect(dragPoint.x, dragPoint.y,
                		ProcessIcon.ICON_WIDTH, ProcessIcon.ICON_HEIGHT);

            } else {
                g2.fillOval(dragPoint.x, dragPoint.y,
                		ProcessIcon.ICON_WIDTH, ProcessIcon.ICON_HEIGHT);
            }

            g2.dispose(); 
        }
    }


    
    /**
     * Listener for ItemEvents from doTracingButton
     */
    private class MyTracingButtonListener implements ItemListener {
    	private boolean ignoreChange = false;
	
    	public void itemStateChanged(ItemEvent e) {
	    boolean ret_val;
	    
	    if (!ignoreChange) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
		    System.out.println (System.currentTimeMillis() + " trace button selected");
		    ret_val = startTracing(true); // true = send cmd to fpga
		    if (ret_val == false) {
			Object source = e.getSource();
			if (source instanceof JToggleButton) {
			    JToggleButton tButton = (JToggleButton) source;
			    ignoreChange = true;
			    tButton.setSelected(false);
			    ignoreChange = false;
			}
		    }
		} else {
		    System.out.println (System.currentTimeMillis() + " trace button inactivated");
		    stopTracing(null, true);
		}
	    }
    	}
    }
    
    
    /**
     * Starts logging the execution trace (all incoming statistics)
     */
    public boolean startTracing(boolean reqFpga) {
    	try {
	    String traceParentDir = SettingsDialog.getInstance().getTraceDirectoryPath();
	    TraceDataLogger.getInstance().setTraceDirectory(new File(traceParentDir));
	    currentTraceDir = TraceDataLogger.getInstance().startTracing(reqFpga);
	    return true;
	} catch (IOException ioe) {
	    JOptionPane.showMessageDialog(MainWindow.getInstance(),
					  bundle.getString("TRACING_START_ERROR_MSG")+" "+ioe.getMessage(),
					  null, JOptionPane.ERROR_MESSAGE);
	    return false;
	}
    }
    
    
    /**
     * Stops logging the execution trace
     * @param errorMsg The message to be shown if logging ended due to an error.
     */
    public void stopTracing(String errorMsg, boolean reqFpga) {
	if (currentTraceDir == null) {
	    // tracing hasn't started
	    return;
	}
	
	TraceDataLogger.getInstance().stopTracing(reqFpga);
	// TraceDataLogger.getInstance().stopTracing();
	
	if (errorMsg == null) {
	    // Show a completion message window
	    JOptionPane.showMessageDialog(MainWindow.getInstance(),
					  bundle.getString("TRACING_ENDED_MSG")+" "+currentTraceDir.getAbsolutePath(),
					  bundle.getString("TRACING_ENDED_TITLE"), JOptionPane.INFORMATION_MESSAGE);
	} else {
	    // Show an error message window
	    JOptionPane.showMessageDialog(MainWindow.getInstance(),
					  bundle.getString("TRACING_ERROR_MSG")+" "+errorMsg,
					  bundle.getString("TRACING_ENDED_TITLE"), JOptionPane.ERROR_MESSAGE);
	}
	currentTraceDir = null;
	//doTracingButton.setSelected(false);
    }


    
}
