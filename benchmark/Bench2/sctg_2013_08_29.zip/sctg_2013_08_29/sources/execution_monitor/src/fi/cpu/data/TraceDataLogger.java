/*
 *
 * Copyright 2009 Tampere University of Technology
 * 
 *  This file is part of Execution Monitor.
 *
 *  Execution Monitor is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Execution Monitor is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Execution Monitor.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package fi.cpu.data;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date; //ES

import fi.cpu.handler.Handler;
import fi.cpu.ui.MainWindow;

public class TraceDataLogger {
    private static TraceDataLogger self;
    private File parentDirectory;
    private File logDirectory;
    private PrintStream stream;
    private Handler connectionHandler;
    private String errorMessage;
    public enum TracingStatus {STOPPED, TRACING, WAITING_FOR_STOP};
    private TracingStatus status; 

	
    public static TraceDataLogger getInstance() {
	if (self == null) {
	    self = new TraceDataLogger();
	}
	return self;
    }
	
	
    /**
     * Creates a new TraceDataLogger.
     */
    public TraceDataLogger() {
	status = TracingStatus.STOPPED;
    }
	
	
    /**
     * Sets the directory where trace files are created.
     */
    public void setTraceDirectory(File directory) throws IOException {
	directory.mkdir();
	parentDirectory = directory;
    }
	
	
    /**
     * Returns the directory where the trace files will be created.
     */
    public File getTraceDirectory() {
	return parentDirectory;
    }
	
	
    /**
     * Returns the message of an error during tracing. If no error happened,
     * null returned.
     */
    public String getErrorMessage() {
	return errorMessage;
    }
	    
    
    /**
     * Returns status of tracing.
     */
    public TracingStatus getStatus() {
	return status;
    }
    
	
    /**
     * Begins tracing by creating file. Requests FPGA to start
     * sending.
     * param reqFpga whether to send a start command to FPGA
     */ 
    public File startTracing(boolean reqFpga) throws IOException {

	if (status != TracingStatus.TRACING) { //if by ES

	    System.err.println("Start logging the Trace");


	    // Get current date and time
	    long time = System.currentTimeMillis();
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTimeInMillis(time);
	    
	    int year = calendar.get(Calendar.YEAR);
	    int month = calendar.get(Calendar.MONTH);
	    int day = calendar.get(Calendar.DATE);
	    int hour = calendar.get(Calendar.HOUR_OF_DAY);
	    int min = calendar.get(Calendar.MINUTE);
	    int sec = calendar.get(Calendar.SECOND);
	    
	    DecimalFormat format = new DecimalFormat("00"); // two digits
	    
	    StringBuilder name = new StringBuilder();
	    name.append(year);
	    name.append(format.format(month));
	    name.append(format.format(day));
	    name.append("_");
	    name.append(format.format(hour));
	    name.append(format.format(min));
	    name.append(format.format(sec));
	    
	    logDirectory = new File(parentDirectory, name.toString());
	    logDirectory.mkdir();
	    errorMessage = null;
	    
	    // Get connection handler and ask device to start tracing
	    if (connectionHandler == null ) {
		connectionHandler = MainWindow.getInstance().getConnectionHandler();
	    }
	    if (connectionHandler != null && reqFpga) { //es
		try {
		    System.out.println("Send start command to FPGA");
		    connectionHandler.writeToDestination("<start_trace>");
		    } catch (Exception e) {
		    // } catch (IOException e) {
		    System.err.println(System.currentTimeMillis() + " Could not send trace request to FPGA");
		    System.err.println(e.getMessage());
		    System.err.flush();
		    // e.printStackTrace();
		}
	    }
	    //	    status = TracingStatus.TRACING;
	}
	// else do nothing
	
	status = TracingStatus.TRACING;
	return logDirectory;
    } //end startTracing()

    
    /**
     * Adds trace string data to log.
     */
    public void logTraceData(String data) throws IOException {
	if (status == TracingStatus.STOPPED || logDirectory == null) {
	    return;
	}
	
	try {	
	    if (stream == null) {
		// Create new stream
		File traceFile = new File(logDirectory, "Execution_trace.xml");
		if (traceFile.exists()) {
		    traceFile.delete();
		}		
		traceFile.createNewFile();
		stream = new PrintStream(traceFile);
		
		// Print file header
		Date now = new Date();
		stream.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		stream.println("<!-- Created in " + now.toString() + " -->");
		stream.println("<log>");
	    }
	    stream.println(data + "\n");
	    
	    
	} catch (IOException e) {
	    errorMessage = "Could not log trace data to: "+logDirectory.getAbsolutePath()+": "+e.getMessage();
	    throw e;
	}
    }
	
    /**
     * Stops tracing. Requests FPGA device to stop sending log
     * messages
     */
    public void stopTracing(boolean reqFpga) {	
	System.out.println("Stop logging Trace");

	if (connectionHandler != null && reqFpga) {
	    try {
		System.out.println("Send stop  command to FPGA");
		System.out.flush();
		connectionHandler.writeToDestination("<stop_trace>");
	    } catch (Exception e) {
		//} catch (IOException e) {
		// TODO Auto-generated catch block
		System.err.println(System.currentTimeMillis() + " Could not send trace stop request to FPGA");
		System.err.println(e.getMessage());
		//e.printStackTrace();
	    }
	}	
	status = TracingStatus.WAITING_FOR_STOP;
	
	// code from traceREady() moved here	
	// Print the file footer and close the stream
	if (stream != null) {
	    stream.println("</log>");
	    stream.close();
	    stream = null;
	}
	
	// Release connection handler
	connectionHandler = null;
	logDirectory = null;
	
	status = TracingStatus.STOPPED;		
    }
}