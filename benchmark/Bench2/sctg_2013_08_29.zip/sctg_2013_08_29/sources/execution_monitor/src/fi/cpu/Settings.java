/*
 * CVS-tietoja:
 * $Author: jantti2 $ 
 * $Date: 2006-10-27 12:39:15 +0300 (pe, 27 loka 2006) $ 
 * $Revision: 2670 $
 *
 * Created on 4.8.2005
 *
 * Copyright 2009 Tampere University of Technology
 * 
 *  This file is part of Execution Monitor.
 *
 *  Execution Monitor is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Execution Monitor is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Execution Monitor.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */
package fi.cpu;

import java.util.ResourceBundle;

/**
 * @author jsikio 

 * Read some common definitions from XML configuration file,
 * e.g. shapes and colors
 */
public class Settings
{
    
    private static Settings linker_ = null;

    private static final String resourceString_ = "uilook"; //"configuration";

    private static ResourceBundle bundle_ = null;
    

    static
    {
        try
        {
            bundle_ = ResourceBundle.getBundle( resourceString_ );
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }
    }

    public static String getAttributeValue( String attributeName )
    {
        return bundle_.getString( attributeName );
    }

}
