/**
 * File:    UIConfigIO.java
 * Author:  Tomi Jantti <tomi.jantti@tut.fi>
 * Created: 12.3.2007
 *
 *
 *
 * Copyright 2009 Tampere University of Technology
 * 
 *  This file is part of Execution Monitor.
 *
 *  Execution Monitor is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Execution Monitor is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Execution Monitor.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */
package fi.cpu.ui.xml;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.util.Iterator;
import java.util.List;

import javax.swing.JInternalFrame;
import javax.swing.SwingUtilities;

import fi.cpu.data.Graph;
import fi.cpu.data.Configuration;
import fi.cpu.data.Model;
import fi.cpu.data.ModelNode;
import fi.cpu.data.Process;
import fi.cpu.data.ProcessingElement;
import fi.cpu.data.Thread;
import fi.cpu.ui.MainWindow;
import fi.cpu.ui.graph.GraphPanel;

// XML schemas define how Java is serialized
import fi.cpu.xml.bind.configuration.ServicesType;
import fi.cpu.xml.bind.uiconfig.ChartType;
import fi.cpu.xml.bind.uiconfig.ConfigurationType;
import fi.cpu.xml.bind.uiconfig.CtrlTabType;
import fi.cpu.xml.bind.uiconfig.CpuType;
import fi.cpu.xml.bind.uiconfig.MainWindowType;
import fi.cpu.xml.bind.uiconfig.GraphTabType;
import fi.cpu.xml.bind.uiconfig.ObjectFactory;
import fi.cpu.xml.bind.uiconfig.ServiceTabType;
import fi.cpu.xml.bind.uiconfig.ThreadType;
import fi.cpu.xml.bind.uiconfig.UIConfigType;
import fi.cpu.xml.bind.uiconfig.WindowLocationType;
import fi.cpu.xml.bind.uiconfig.WindowSizeType;
import fi.cpu.xml.bind.uiconfig.ServiceTabType.Connection;
import fi.cpu.xml.bind.uiconfig.ServiceTabType.Service;
import fi.cpu.xml.bind.uiconfig.ServiceTabType.ConnectionType.PointType;


/**
 * UIConfigIO handles reading and writing UI configurations.
 */
public class UIConfigIO {
	
    private UIConfigIO() {
	// only static methods, no use for constructor
    }
	
    
    /**
     * Reads configuration from a file.
     * @param configuration
     * @param mw
     * @param filename
     */
    public static void readConfiguration(
    		Configuration configuration, MainWindow mw, String filename) {
    	Model peModel = new Model();
    	Model serviceModel = new Model();
    	
        try {
	    // Load XML file and parse it. 
            UIConfigMarshaller m = new UIConfigMarshaller();
            UIConfigType loadedUIConfig = m.loadUIConfig( filename );

            MainWindowType window = loadedUIConfig.getMainWindow();
            mw.setSize( window.getWindowSize().getX(), 
			window.getWindowSize().getY() );

            // Create control tab and add CPU information, incl
            // threads, processes, and graphs
            CtrlTabType ctrlTab = loadedUIConfig.getCtrlTab();
            mw.setAutoActive(ctrlTab.isAutoActivateState());

            ConfigurationType confType = ctrlTab.getConfiguration();
            List cpus = confType.getCpu();
            Iterator iter = cpus.iterator();
            
            while ( iter.hasNext() )
            {
                ConfigurationType.Cpu cpu = (ConfigurationType.Cpu) iter.next();

		Boolean mutable = cpu.isMutable();
		//System.out.println ("attr mutable = " + mutable);
                ProcessingElement pe 
		    = new ProcessingElement(""+cpu.getId(), cpu.getName(), 
					    mutable);

                Iterator threads = cpu.getThread().iterator();

                while ( threads.hasNext() )
                {
                    CpuType.Thread threadType = (CpuType.Thread) threads.next();

                    Thread thread 
			= new Thread(""+threadType.getId(),
				     threadType.getName(), threadType.getPriority());

                    Iterator processes = threadType.getProcess().iterator();

                    while ( processes.hasNext() )
                    {
                        ThreadType.Process process 
			    = (ThreadType.Process) processes.next();

                        Process p = new Process(process.getId(), process.getName());
                        peModel.insertNode(p, thread);
                    }

                    peModel.insertNode(thread, pe);
                }


                Iterator charts = cpu.getChart().iterator();
                while ( charts.hasNext() )
                {
                    CpuType.Chart cha = (CpuType.Chart) charts.next();

                    String graphID           = cha.getGraphID();
                    int typeID               = Integer.parseInt( cha.getTypeID() );
                    double maxValue          = cha.getMaxValue();
                    double minValue          = cha.getMinValue();
                    double length            = cha.getLength();
                    String title             = cha.getChartTitle();
                    String xAxis             = cha.getXaxisTitle();
                    String yAxis             = cha.getYaxisTitle();
                    boolean automaticScaling = cha.isAutomaticScaling();
                    boolean logged           = cha.isLogged();
                    
                    Graph gra = new Graph(graphID, typeID, title,
                    		xAxis, yAxis, minValue, maxValue, length,
                    		automaticScaling, logged);
                    pe.setGraph(graphID, gra);
                }
                //pe.setHasGraphs(true); // unnecessary?
                //pe.setVisibleGraph(cpu.getVisibleChart()); // unnecessary?

                peModel.insertNode(pe, peModel.getModelRoot());
            } //end while ( iter.hasNext() )

	    // ES 2012-10-16: refactored away large section of copied code that handled accelerators

            configuration.initializePeModel(peModel);


            
            // Fetch the windows in GraphTab
            GraphTabType graphTab = loadedUIConfig.getGraphTab();
            Iterator windowList = graphTab.getWindow().iterator();

            mw.removeGraphs(); // Remove old graphs

            while ( windowList.hasNext() )
            {
                GraphTabType.Window graphWindow 
		    = (GraphTabType.Window) windowList.next();

                // Get window location and size
                WindowLocationType windowLocation 
		    = graphWindow.getWindowLocation();
                WindowSizeType windowSize = graphWindow.getWindowSize();

                if ( graphWindow.getType().equalsIgnoreCase( "debug" ) )
                {
                    // Debug-window
                    mw.showDebugWindow( windowLocation.getX(), 
					windowLocation.getY(), 
					windowSize.getX(), windowSize.getY() );
                }
                else
                {
                    // Normal chart
                    ChartType cha = graphWindow.getChart();

                    String graphID           = cha.getGraphID();
                    int typeID               = Integer.parseInt( cha.getTypeID() );
                    double maxValue          = cha.getMaxValue();
                    double minValue          = cha.getMinValue();
                    double length            = cha.getLength();
                    String title             = cha.getChartTitle();
                    String xAxis             = cha.getXaxisTitle();
                    String yAxis             = cha.getYaxisTitle();
                    boolean automaticScaling = cha.isAutomaticScaling();
                    boolean logged           = cha.isLogged();

                    Graph gra = new Graph(graphID, typeID, title,
                    		xAxis, yAxis, minValue, maxValue, length,
                    		automaticScaling, logged);

                    GraphPanel gPanel = new GraphPanel();
                    gPanel.setGraph(gra);

                    //Joudutaan tekem��n pieni hackki. Tiedostoon tallennetut
                    // tiedot
                    //koskevat n�iden graaffien osalta JInternalFramen kokoa,
                    // mutta
                    //addGraph muuttaa ja sijoittaa JInternalFramea. Siksi
                    // pit�� paikka- ja kokotietoon
                    //lis�t� muutama arvo, ett� ikkunat menev�t samoihin
                    // kohtiin kuin oli talletustilanteessa
                    mw.addGraph( gPanel, windowLocation.getX() - 5, windowLocation
                            .getY() - 27, windowSize.getX() + 10, windowSize
                            .getY() + 32, false);
                }
            }

            
            // Handle the services
            ServiceTabType serviceTab = loadedUIConfig.getServiceTab();
            if (serviceTab != null) {
            	
            	// Transform configuration services to ui services
            	List serviceList = serviceTab.getService();
            	for (int i=0; i<serviceList.size(); ++i) {
            		Object s = serviceList.get(i);
            		if (s instanceof Service) {
			    Service service = (Service) s;
			    fi.cpu.data.Service uiService 
				= new fi.cpu.data.Service(service.getId(), service.getName());
			    uiService.setLocation(new Point2D.Double(service.getX(), service.getY()));
			    
			    // Handle processes
			    Iterator processes = service.getProcess().iterator();
			    
			    while (processes.hasNext()) {
				ServiceTabType.ServiceType.Process process =
				    (ServiceTabType.ServiceType.Process)processes.next();
				Process p = new Process(process.getId(), process.getName());

				serviceModel.insertNode(p, uiService);
			    }
						
	                    serviceModel.insertNode(uiService, serviceModel.getModelRoot());
			}
            	}

            	// Transform configuration connections to ui connections
            	List connectionList = serviceTab.getConnection();
            	for (int i=0; i<connectionList.size(); ++i) {
		    Object c = connectionList.get(i);
            		if (c instanceof Connection) {
			    Connection conn = (Connection) c;
			    fi.cpu.data.Connection uiConnection 
				= new fi.cpu.data.Connection(conn.getId(), conn.getSrc(), conn.getDest());
						
			    List points = conn.getPoint();
			    for (int j=0; j<points.size(); ++j) {
				PointType p = (PointType)points.get(j);
				Point2D uiPoint = new Point2D.Double(p.getX(), p.getY());
				uiConnection.addPoint(uiPoint);
			    }
						
	                    serviceModel.insertNode(uiConnection, serviceModel.getModelRoot());
			}
            	}
            }
	    configuration.initializeServiceModel(serviceModel);
        }
        catch ( Exception e )
	    {
		System.out.println(" Parsing of " +  filename + " failed: ");
		System.out.println(e.getMessage());
            // e.printStackTrace();
	    }
    }
    
    
    /**
     * Reads a simplified configuration from a string (coming from FPGA or TG).
     * @param configuration
     * @param data
     */
    public static void readConfigurationString(
    		Configuration configuration, MainWindow mw, String data) {
    	Model peModel = new Model();
    	Model serviceModel = new Model();

        try
        {            	
            XML_Source_FPGA fpga = new XML_Source_FPGA();
            
            fi.cpu.xml.bind.configuration.ConfigurationType configType = fpga.getConfiguration( data );
            
	    // Go through all cpus, all threads, and all processes with 3 nested foor loops
            List cpuList = configType.getCpu();
            
            for ( int i = 0; i < cpuList.size(); i++ )
		{
		    fi.cpu.xml.bind.configuration.CpuType cpu = 
            		(fi.cpu.xml.bind.configuration.CpuType) cpuList.get( i );                

		    Boolean mutable = cpu.isMutable();
		    System.out.println ("attr mutable = " + mutable);
		    
		    ProcessingElement pe 
			= new ProcessingElement(""+cpu.getId(), cpu.getName(), 
						mutable);
		    
		    List threadList = cpu.getThread();
		    for ( int j = 0; j < threadList.size(); j++ )
			{
			    fi.cpu.xml.bind.configuration.ThreadType threadType = 
                		(fi.cpu.xml.bind.configuration.ThreadType) threadList.get( j );
			    
			    Thread thread = new Thread(""+threadType.getId(), 
						       threadType.getName(), 
						       threadType.getPriority());
			    
			    List processList = threadType.getProcess();
			    
			    for ( int k = 0; k < processList.size(); k++ )
				{
				    fi.cpu.xml.bind.configuration.ProcessType processType = 
					(fi.cpu.xml.bind.configuration.ProcessType) processList.get( k );
				    
				    Process process = new Process(processType.getId(), processType.getName());
				    peModel.insertNode(process, thread);
				}
			    
			    peModel.insertNode(thread, pe);
			}


		    // ES 2012-10-10. Added this so that measurement
		    // log can add the CPU graphs directly. Then,
		    // you'll not need to load UI config separately in
		    // the basic cases.
		    Iterator chartIter = cpu.getChart().iterator();
		    while ( chartIter.hasNext() )
			{
			    System.out.println("Adding a graph");
			    fi.cpu.xml.bind.configuration.ChartType cha 
				= (fi.cpu.xml.bind.configuration.ChartType) chartIter.next();

			    String graphID           = cha.getGraphID();
			    int typeID               = Integer.parseInt( cha.getTypeID() );
			    double maxValue          = cha.getMaxValue();
			    double minValue          = cha.getMinValue();
			    double length            = cha.getLength();
			    String title             = cha.getChartTitle();
			    String xAxis             = cha.getXaxisTitle();
			    String yAxis             = cha.getYaxisTitle();
			    boolean automaticScaling = cha.isAutomaticScaling();
			    boolean logged           = cha.isLogged();
			    
			    Graph gra = new Graph(graphID, typeID, title,
						  xAxis, yAxis, minValue, maxValue, length,
						  automaticScaling, logged);
			    pe.setGraph(graphID, gra);

			}
		    // new stuff ends


   
		    peModel.insertNode(pe, peModel.getModelRoot());
		}


	    // ES 2012-10-16: don't care about the the type, PEs are handled similarly anyways

            configuration.initializePeModel(peModel);



            

            // Handle services
            ServicesType serviceTab = configType.getServices();
            if (serviceTab != null) {
		
            	// Transform configuration's services to ui services
            	List serviceList = serviceTab.getService();
            	for (int i=0; i<serviceList.size(); ++i) {
		    Object s = serviceList.get(i);
		    if (s instanceof ServicesType.Service) {
			ServicesType.Service service = (ServicesType.Service) s;
			fi.cpu.data.Service uiService 
			    = new fi.cpu.data.Service(service.getId(), service.getName());
			
			System.out.println ("cfg srvc, id " + service.getId() + ", name " + service.getName());


			// Handle processes
			Iterator processes = service.getProcess().iterator();
	                
			while (processes.hasNext()) {
			    ServicesType.ServiceType.Process process =
				(ServicesType.ServiceType.Process)processes.next();

			    // Don't use process name from xml but
			    // look it up from the configuration based on id
			    // es 2012-10-26
			    String realProcName = "undefined";
			    // for all processes in pe model
			    List<ModelNode> processNodes =
				configuration.getPeModel().getNodesOfType(Process.class);
			    Iterator<ModelNode> nodeIter = processNodes.iterator();
			    
			    while (nodeIter.hasNext()) {
				ModelNode node = nodeIter.next();
				
				if (node instanceof Process) {
				    Process p = (Process) node;
				    if (process.getId() == p.getId()) {
					realProcName = p.getName();
					break;
				    }
				}
			    }
			    Process p = new Process(process.getId(), realProcName);

			    //Process p = new Process(process.getId(), process.getName()); //orig
			    
			    serviceModel.insertNode(p, uiService);

			    System.out.println ("cfg srvc/proc, id " + process.getId() + ", name " + process.getName());

			}
			
			serviceModel.insertNode(uiService, serviceModel.getModelRoot());
		    }
            	}
		
            	// Transform configuration's connections to ui connections
            	List connectionList = serviceTab.getConnection();
            	for (int i=0; i<connectionList.size(); ++i) {
		    Object c = connectionList.get(i);
		    if (c instanceof ServicesType.Connection) {
			ServicesType.Connection conn = (ServicesType.Connection) c;
			fi.cpu.data.Connection uiConnection 
			    = new fi.cpu.data.Connection(conn.getId(), conn.getSrc(), conn.getDest());
			
			serviceModel.insertNode(uiConnection, serviceModel.getModelRoot());
		    }
            	}
            }
            configuration.initializeServiceModel(serviceModel);
        }
        catch ( Exception e )
	    {
		
		e.printStackTrace();
	    }
    }
    
	
    /**
     * Writes UI configuration to file.
     * @param configuration
     * @param mw
     * @param filename
     */
    public static void writeConfiguration(
    		Configuration configuration, MainWindow mw, String filename ) {
    	
    	Model peModel = configuration.getPeModel();
    	Model serviceModel = configuration.getServiceModel();
    	
        try {
	    // Marshaller serializes Java into XML. ObjectFactory
	    // allows creating new classes from scratch (which will then be
	    // serialized)
            UIConfigMarshaller m = new UIConfigMarshaller();
            ObjectFactory of = m.getObjectFactory();

	    // Create the top-level tag <UIConfig> and 4 tags under it
            UIConfigType uiconfig = m.getObjectFactory().createUIConfig();
            uiconfig.setMainWindow( of.createMainWindowType() );
            uiconfig.setCtrlTab( of.createCtrlTabType() );
            uiconfig.setGraphTab( of.createGraphTabType() );
            
            if (serviceModel.getChildCount(serviceModel.getModelRoot()) > 0) {
            	uiconfig.setServiceTab( of.createServiceTabType() );
            }


	    // <UIConfig><MainWindow> has just size information
            MainWindowType mainWindow = uiconfig.getMainWindow();
            mainWindow.setWindowSize( of.createWindowSizeType() );

            WindowSizeType windowSize = mainWindow.getWindowSize();
            windowSize.setX(mw.getWidth());
            windowSize.setY(mw.getHeight());


	    // <UIConfig><CtrlTab> has the PEs and their graphs
            CtrlTabType controlView = uiconfig.getCtrlTab();
            controlView.setConfiguration( of.createConfigurationType() );
            controlView.setAutoActivateState(mw.isAutoActive());

            // Save processing element information
            ConfigurationType confType = controlView.getConfiguration();
            List cpus = confType.getCpu();

            Iterator<ModelNode> peIter = peModel.getChildren(peModel.getModelRoot()).iterator();

            // for all pes
            while (peIter.hasNext()) {
            	ModelNode peNode = peIter.next();
            	if (!(peNode instanceof ProcessingElement)) {
            		continue;
            	}
                ProcessingElement pe = (ProcessingElement)peNode;

		// ES 2012-10-16: don't care about the the type, PEs are handled similarly anyways.
                // I removed condition: if (pe.getType() == ProcessingElement.CPU_TYPE) and its else-branch
		ConfigurationType.Cpu cpuType = of
		    .createConfigurationTypeCpu();
		cpuType.setId(Integer.parseInt(pe.getId()));
		cpuType.setName(pe.getName());
		cpuType.setMutable(pe.isMutable()); // es 2012-10-16
                
		List xml_threads = cpuType.getThread();
		Iterator<ModelNode> threadIter = peModel.getChildren(pe).iterator();
                
		// for all threads
		while (threadIter.hasNext()) {
		    ModelNode tNode = threadIter.next();
		    if (!(tNode instanceof Thread)) {
			continue;
		    }
		    Thread thread = (Thread)tNode;
                    
		    // create threadtype
		    CpuType.Thread threadType = of.createCpuTypeThread();
		    threadType.setName(thread.getName());
		    threadType.setId(Integer.parseInt(thread.getId()));
		    threadType.setPriority(thread.getPriority());
		    
		    List processList = threadType.getProcess();
		    Iterator<ModelNode> processIter = peModel.getChildren(thread).iterator();
		    
		    // for all processes
		    while (processIter.hasNext()) {
			ModelNode pNode = processIter.next();
			if (!(pNode instanceof Process)) {
			    continue;
			}
			Process p = (Process)pNode;
                        
			// create xml process
			ThreadType.Process process = of
			    .createThreadTypeProcess();
			process.setId(p.getId());
			process.setName(p.getName());
			
			processList.add(process);
		    }
		    
		    xml_threads.add(threadType);
		}
		
		// for all charts
		List xml_charts = cpuType.getChart();
		Iterator<Graph> graIter = pe.getGraphs().iterator();
		while (graIter.hasNext()) {
		    Graph gra = graIter.next();
		    
		    String graphID = gra.getId();
		    int typeID = gra.getTypeId();
		    double maxValue = gra.getMaxValue();
		    double minValue = gra.getMinValue();
		    double length = gra.getLength();
		    String title = gra.getTitle();
		    String xAxis = gra.getXAxis();
		    String yAxis = gra.getYAxis();

		    CpuType.Chart chartType = of.createCpuTypeChart();
		    chartType.setAutomaticScaling(gra.isAutoScale());
		    chartType.setChartTitle( title );
		    chartType.setGraphID( "" + graphID );
		    chartType.setLength( length );
		    chartType.setMaxValue( maxValue );
		    chartType.setMinValue( minValue );
		    chartType.setTypeID( "" + typeID );
		    chartType.setXaxisTitle( xAxis );
		    chartType.setYaxisTitle( yAxis );
		    chartType.setLogged(gra.isLogged());
		    
		    xml_charts.add( chartType );
		    
		}
		String visibleGraph = pe.getVisibleGraph();
		if (visibleGraph != null) {
		    cpuType.setVisibleChart(visibleGraph);
		}
		cpus.add( cpuType );

		// ES 2012-10-16: refactored away large section of copied code that handled accelerators

            }



	    // <UIConfig><GraphTab> has the user-defind graphs
            GraphTabType graphTab = uiconfig.getGraphTab();
            List windowList = graphTab.getWindow();

            //  First, save debug window
            JInternalFrame debugWindow = mw.getDebugWindow();
            if (debugWindow != null) {
                GraphTabType.Window window = of.createGraphTabTypeWindow();

                // Save the location
                WindowLocationType windowLocation = of.createWindowLocationType();
                Point currentLocation = new Point();

                // Icon location with respect to GraphTab
                currentLocation = SwingUtilities.convertPoint(debugWindow,
							      currentLocation, mw.getGraphTab());

                if ( currentLocation.x < 0 )
                {
                    currentLocation.x = 20;
                }
                if ( currentLocation.y < 0 )
                {
                    currentLocation.y = 20;
                }

                windowLocation.setX( currentLocation.x );
                windowLocation.setY( currentLocation.y );
                window.setWindowLocation( windowLocation );

                // Tieto, ett� kyseess� on debug-window
                window.setType( "debug" );

                // Save the window size
                WindowSizeType debugWindowSize = of.createWindowSizeType();
                debugWindowSize.setX( debugWindow.getWidth() );
                debugWindowSize.setY( debugWindow.getHeight() );
                window.setWindowSize( debugWindowSize );

                windowList.add( window );
            }

            //  Then, the rest of the graphs
            Iterator<GraphPanel> graIter = mw.getGraphPanels().iterator();
            while (graIter.hasNext()) {
            	GraphPanel gPanel = graIter.next();
            	GraphTabType.Window window = of.createGraphTabTypeWindow();
            	
            	//Tallennetaan paikka
            	WindowLocationType windowLocation = of.createWindowLocationType();
            	Point currentLocation = new Point();
            	// Convert icon location with respect to GraphTab
            	currentLocation = SwingUtilities.convertPoint( gPanel,
							       currentLocation, mw.getGraphTab() );
            	
            	if ( currentLocation.x < 0 )
            	{
            		currentLocation.x = 20;
            	}
            	if ( currentLocation.y < 0 )
            	{
            		currentLocation.y = 20;
            	}
            	
            	windowLocation.setX( currentLocation.x );
            	windowLocation.setY( currentLocation.y );
            	window.setWindowLocation( windowLocation );
            	
            	//Tieto, ett� kyseess� on chart-window
            	window.setType( "chart" );
            	
            	//Tallennetaan ikkunan koko
            	WindowSizeType chartWindowSize = of.createWindowSizeType();
            	chartWindowSize.setX( gPanel.getWidth() );
            	chartWindowSize.setY( gPanel.getHeight() );
            	window.setWindowSize( chartWindowSize );
            	
            	//Luodaan ChartType, joka kertoo chartin yksityiskohdat
            	String graphID  = gPanel.getGraphInfo().getId();
            	int typeID      = gPanel.getGraphInfo().getTypeId();
            	double maxValue = gPanel.getGraphInfo().getMaxValue();
            	double minValue = gPanel.getGraphInfo().getMinValue();
            	double length   = gPanel.getGraphInfo().getLength();
            	String title    = gPanel.getGraphInfo().getTitle();
            	String xAxis    = gPanel.getGraphInfo().getXAxis();
            	String yAxis    = gPanel.getGraphInfo().getYAxis();
            	
            	ChartType chartType = of.createChartType();
            	chartType.setAutomaticScaling( gPanel.getGraphInfo().isAutoScale() );
            	chartType.setChartTitle( title );
            	chartType.setGraphID( "" + graphID );
            	chartType.setLength( length );
            	chartType.setMaxValue( maxValue );
            	chartType.setMinValue( minValue );
            	chartType.setTypeID( "" + typeID );
            	chartType.setXaxisTitle( xAxis );
            	chartType.setYaxisTitle( yAxis );
            	chartType.setLogged(gPanel.getGraphInfo().isLogged());
            	
            	window.setChart( chartType );
            	
            	windowList.add( window );
            }




	    // <UIConfig><ServiceTab> has service block diagram
            ServiceTabType serviceTab = uiconfig.getServiceTab();
            if (serviceTab != null) {
            	
            	Iterator<ModelNode> nodeIter = serviceModel.getChildren(
            			serviceModel.getModelRoot()).iterator();
            	List serviceList = serviceTab.getService();
            	List connectionList = serviceTab.getConnection();

            	// Transform ui services and connections to
            	// configuration services and connections
            	while (nodeIter.hasNext()) {
		    ModelNode node = nodeIter.next();
		    if (node instanceof fi.cpu.data.Service) {
			fi.cpu.data.Service uiService = (fi.cpu.data.Service) node;
			
			Service service = of.createServiceTabTypeService();
			service.setId(uiService.getId());
			service.setName(uiService.getName());
			service.setX((int)uiService.getLocation().getX());
			service.setY((int)uiService.getLocation().getY());
			
			List processes = service.getProcess();
			
    	                Iterator<ModelNode> pIter = serviceModel.getChildren(uiService).iterator();
    	                while (pIter.hasNext()) {
			    ModelNode pNode = pIter.next();
			    if (!(pNode instanceof Process)) {
				continue;
			    }
    	                    Process uiProcess = (Process)pNode;
			    ServiceTabType.ServiceType.Process p = of.createServiceTabTypeServiceTypeProcess();
			    p.setId(uiProcess.getId());
			    p.setName(uiProcess.getName());
			    processes.add(p);
			}
    			
			serviceList.add(service);
    			
		    } else if (node instanceof fi.cpu.data.Connection) {
			fi.cpu.data.Connection uiConnection = (fi.cpu.data.Connection) node;
			
			Connection connection = of.createServiceTabTypeConnection();
			connection.setId(uiConnection.getId());
			connection.setSrc(uiConnection.getSrcService());
			connection.setDest(uiConnection.getDestService());
	            	
			List points = connection.getPoint();
			List<Point2D> uiPoints = uiConnection.getPoints();
			for (int j=0; j<uiPoints.size(); ++j) {
			    Point2D uiPoint = uiPoints.get(j);
			    
			    PointType p = of.createServiceTabTypeConnectionTypePointType();
			    p.setX((int)uiPoint.getX());
			    p.setY((int)uiPoint.getY());
			    
			    points.add(p);
			}
	            	
			connectionList.add(connection);
		    }
            	}
            }

	    
	    // Write everything to file
            m.saveUIConfig( filename, uiconfig );
        }
        catch ( Exception e )
	    {
		e.printStackTrace();
	    }
    } // end writeConfiguration()
    




    
    /**
     * Creates an XML-string describing the current mapping to be sent
     * to FPGA.  Threads cannot be moved to other CPUs, so it is
     * enough to send just the thread contents.
     * @param configuration
     * @return
     */
    public static String createMappingXMLString(Configuration configuration) {
        StringBuffer xmlString = new StringBuffer();
        Model peModel = configuration.getPeModel();
        
        // Add start tag
        xmlString.append("<mapping>");

        // Go through all pes
        Iterator<ModelNode> peIter = peModel.getChildren(peModel.getModelRoot()).iterator();
        while (peIter.hasNext()) {
	    ModelNode peNode = peIter.next();
	    if (!(peNode instanceof ProcessingElement)) {
		continue;
	    }
            ProcessingElement pe = (ProcessingElement)peNode;
            
            // Go through all threads
            Iterator<ModelNode> threadIter = peModel.getChildren(pe).iterator();
            while (threadIter.hasNext()) {
            	ModelNode tNode = threadIter.next();
            	if (!(tNode instanceof Thread)) {
		    continue;
            	}
                Thread t = (Thread)tNode;
		
                xmlString.append("<thread id=\"" + t.getId() + "\" priority=\"" + t.getPriority() + "\">");
		
                // Go through all processes
                Iterator<ModelNode> pIter = peModel.getChildren(t).iterator();
                while (pIter.hasNext()) {
		    ModelNode pNode = pIter.next();
		    if (!(pNode instanceof Process)) {
			continue;
		    }
                    Process p = (Process)pNode;
                    xmlString.append("<process id=\"" + p.getId() + "\" />");
                }
                xmlString.append( "</thread>" );
            }
        }
	
        // Add end tag
        xmlString.append( "</mapping>" );
	
        return xmlString.toString();
    }
}
