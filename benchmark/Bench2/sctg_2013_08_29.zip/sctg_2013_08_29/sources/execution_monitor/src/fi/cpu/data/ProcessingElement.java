/**
 * File:    ProcessingElement.java
 * Author:  Tomi Jantti <tomi.jantti@tut.fi>
 * Created: 23.2.2007
 *
 *
 *
 * Copyright 2009 Tampere University of Technology
 * 
 *  This file is part of Execution Monitor.
 *
 *  Execution Monitor is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Execution Monitor is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Execution Monitor.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */
package fi.cpu.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import fi.cpu.event.ModelNodeEvent;


/**
 * Class for processing element information.
 */
public class ProcessingElement extends ModelNode implements Comparable<ProcessingElement> {
	public static final int GRAPH_ADDED_EVENT = 1;
	public static final int GRAPH_REMOVED_EVENT = 2;

	private String id;
	private String name;
	private Boolean mutable; // was: ProcessingElementType type;
	
	private boolean hasGraphs;
	private String visibleGraph = null;
	private Map<String, Graph> graphs = new HashMap<String, Graph>();
	
	
	/**
	 * Contructor. Creates a new ProcessingElement.
	 */
	public ProcessingElement(String id, String name, Boolean mutable) {
		super(name);
		this.id = id;
		this.name = name;
		//this.type = type;
		this.mutable = mutable;
		
		//System.out.println ("PE created: " + name + ", " + id + ", mutable "+ mutable);

		hasGraphs = false;
	}


	/**
	 * Returns the name.
	 */
	public String getName() {
		return name;
	}


	/**
	 * Sets the name.
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * Returns the id.
	 */
	public String getId() {
		return id;
	}


	/**
	 * @return Tells if the mapped processes can be moved, i.e. if
	 * the contents of CPU cab be "mutated"
	 */
	public Boolean isMutable() {
		return mutable;
	}

	
	/**
	 * @return Returns the hasGraphs.
	 */
	public boolean getHasGraphs() {
		return hasGraphs;
	}


	/**
	 * Sets the hasGraphs.
	 */
	public void setHasGraphs(boolean hasGraphs) {
		this.hasGraphs = hasGraphs;
	}


	/**
	 * Returns the id of the visible graph.
	 */
	public String getVisibleGraph() {
		return visibleGraph;
	}


	/**
	 * Sets the visible graph
	 */
	public void setVisibleGraph(String visibleGraph) {
		this.visibleGraph = visibleGraph;
	}


	/**
	 * Returns ids of graphs.
	 */
	/*	public Set<String> getGraphIds() {
		return graphs.keySet();
	}	
	*/

	/**
	 * Returns graphs.
	 */
	public List<Graph> getGraphs() {
		return new ArrayList<Graph>(graphs.values());
	}
	
	/**
	 * Sets graphs
	 */
	public void setGraphs(List<Graph> graphs) {
		for (Graph g : graphs) {
			this.graphs.put(g.getId(), g);
		}
	}
	
	/**
	 * Returns the graph with given id.
	 */
	public Graph getGraph(String gid) {
		return graphs.get(gid);
	}

	
	/**
	 * Sets the graph with given id.
	 */
	public void setGraph(String gid, Graph g) {
		removeGraph(gid);

		if (g == null) {
			return;
		}
		
		graphs.put(gid, g);
		hasGraphs = true;
		
		// Show this new one if no graph was visible before
		if (getVisibleGraph() == null)
		    {
			this.setVisibleGraph(gid);
		    }


		fireModelNodeChanged(new ModelNodeEvent(this, GRAPH_ADDED_EVENT, gid));
	}
	
	
	/**
	 * Removes the graph with given id.
	 */
       	public void removeGraph(String gid) {
		Graph g = getGraph(gid);
		graphs.remove(gid);

		if (g != null) {
			fireModelNodeChanged(new ModelNodeEvent(this, GRAPH_REMOVED_EVENT, gid));
		}
	}

	
	/**
	 * Implements the Compararable-interface
	 * ES: this is quite strange function...
	 */
	public int compareTo(ProcessingElement o) {
	    if (mutable == o.isMutable()) {
		return name.compareTo(o.name);
	    } else {
		if (mutable) {
		    return -1;
		} else {
		    return 1;
		}
	    }
	}
	

}
