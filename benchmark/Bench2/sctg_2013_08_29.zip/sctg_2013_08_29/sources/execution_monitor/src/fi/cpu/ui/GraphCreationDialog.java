/**
 * File:    GraphCreationDialog.java
 * Author:  Tomi Jantti <tomi.jantti@tut.fi>
 * Created: 9.3.2007
 *
 *
 *
 * Copyright 2009 Tampere University of Technology
 * 
 *  This file is part of Execution Monitor.
 *
 *  Execution Monitor is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Execution Monitor is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Execution Monitor.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */
package fi.cpu.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.List; //ES

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

import fi.cpu.data.Graph;
import fi.cpu.ui.graph.SimpleChartFactory;
import fi.cpu.ui.xml.SystemConfigMarshaller;
import fi.cpu.xml.bind.systemconfig.GraphType;
import fi.cpu.xml.bind.systemconfig.GraphListType;
import fi.cpu.xml.bind.systemconfig.SystemConfigType;


/**
 * GraphCreationDialog implements a dialog window for
 * creating graphs.
 */
public class GraphCreationDialog extends JDialog {

    protected static GraphCreationDialog self;
    protected boolean cpuSpecific = false;
    protected Graph createdGraphInfo;
    private MyActionListener actionListener = new MyActionListener();

    // Available selections
    //    private static final String CPU_GRAPHS = "/cpugraphconfiguration.xml"; obsolete since 2012-01-17
    private static final String NORMAL_GRAPHS = "/systemconfig.xml"; //"/graphconfiguration.xml";
    protected String[] graphNames;
    protected String[] graphIDs;
    protected String[] cpuGraphNames;
    protected String[] cpuGraphIDs;
    protected JComboBox nameCoB;
    protected int latestNameCobIndex;
    protected JComboBox typeCoB;
    
    // Printed texts
    private JLabel nameLabel;
    private JLabel typeLabel;
    private JLabel lengthLabel;
    private JLabel yLabel;
    private JLabel scalingLabel;

    // Text fields for used-defined numbers and label
    protected JTextField lengthTF;
    protected JTextField yLabelTF;
    protected JTextField maxValueTF;
    protected JTextField minValueTF;
    protected JTextField newNameTF; //Es
    protected JTextField newIdTF; //Es

    // Buttons
    protected JRadioButton automaticRB;
    protected JRadioButton selectedRangeRB;
    protected JButton cancelButton;
    protected JButton okButton;
    protected JRadioButton builtinNameRB; //Es
    protected JRadioButton newNameRB; //Es
    

    
    
    /**
     * @return An instance of GraphCreationDialog.
     */
    public static GraphCreationDialog getInstance() {
        if ( self == null ) {
            self = new GraphCreationDialog();
        }

        return self;
    }

    
    /**
     * Constructor. Creates a new GraphCreationDialog.
     */
    private GraphCreationDialog() {
        super(MainWindow.getInstance(), true);
        self = this;
        initGraphNames();
        init();
    }

    
    /**
     * Reads available graph names and ids from xml file.
     */
    private void initGraphNames() {
	
        try {

	    SystemConfigMarshaller m = new SystemConfigMarshaller();	    
	    SystemConfigType systemConfig 
		= m.loadSystemConfig(this.getClass().getResourceAsStream(NORMAL_GRAPHS));	    



	    // Create the list of Pe specific graphs
	    //System.out.println ("cpu graphs");
	    GraphListType graSeq = systemConfig.getSupportedCpuGraphs();

	    // Count the available graphs and add 1 place for empty string
	    List graList  = graSeq.getGraph();
	    cpuGraphNames = new String[ graList.size() +1 ];
	    cpuGraphIDs   = new String[ cpuGraphNames.length ];
	    
	    int index = 0;
	    cpuGraphNames[index] = null;
	    cpuGraphIDs[index] = null;
	    index++;

	    Iterator gIter = graList.iterator();
	    while( gIter.hasNext() ) {
		GraphType gra = (GraphType)gIter.next();
		
		cpuGraphNames[index] = gra.getName();
		cpuGraphIDs[index] = gra.getId();
		
		//System.out.println ("name[" + index + "] = " + cpuGraphNames[index]);
		index++;                   
	    }
	    

	    // Create the list of custom graphs
	    //System.out.println ("custom graphs");
	    graSeq  = systemConfig.getSupportedGraphs();

	    // Count the available graphs and add 1 place for empty string
	    graList = graSeq.getGraph();
	    graphNames = new String[ graList.size() +1 ];
	    graphIDs   = new String[ graphNames.length];
	    
	    index = 0;
	    graphNames[index] = null;
	    graphIDs[index] = null;
	    index++;

	    gIter = graList.iterator();
	    while( gIter.hasNext() ) {
		GraphType gra = (GraphType)gIter.next();
		
		graphNames[index] = gra.getName();
		graphIDs[index] = gra.getId();
		
		//System.out.println ("name[" + index + "] = " + graphNames[index]);
		index++;                   
	    }
	    
        } catch ( Exception e ) {
	    e.printStackTrace();
        }
    }
    
    
    /**
     *  Initializes the dialog view.  User can select name, type
     * (=line), X-axis length, Y label, and scaling.
     */
    private void init() {

        this.setResizable(false);
        this.setSize( 300, 400 );

	// Text labels to be printed
        this.getContentPane().setLayout( new SpringLayout() );
        this.setTitle(MainWindow.bundle.getString("GRAPH_DIALOG_TITLE"));

        nameLabel = new JLabel( MainWindow.bundle.getString( "NAME_LABEL" ) );
        typeLabel = new JLabel( MainWindow.bundle.getString( "TYPE_LABEL" ) );
        lengthLabel = new JLabel( MainWindow.bundle.getString( "LENGTH_LABEL" ) );
        yLabel = new JLabel( MainWindow.bundle.getString( "VALUE_LABEL" ) );
        scalingLabel = new JLabel( MainWindow.bundle.getString( "SCALING_LABEL" ) );

        this.getContentPane().add( nameLabel );
        this.getContentPane().add( lengthLabel );
        this.getContentPane().add( yLabel );
        this.getContentPane().add( scalingLabel );


	// Make layout for labels (10 pel from left, 15 pel vertical separation)
        SpringLayout sLayout = (SpringLayout) this.getContentPane().getLayout();


        sLayout.putConstraint( SpringLayout.WEST, nameLabel, 10, 
			       SpringLayout.WEST, this.getContentPane() );
        sLayout.putConstraint( SpringLayout.NORTH, nameLabel, 15,
			       SpringLayout.NORTH, this.getContentPane() );

	// Type selection commented out, because line graph is the
	// only choice anyways currently, es, 2012-10-15
        // this.getContentPane().add( typeLabel );
        //sLayout.putConstraint( SpringLayout.WEST, typeLabel, 10, SpringLayout.WEST,
        //        this.getContentPane() );
        //sLayout.putConstraint( SpringLayout.NORTH, typeLabel, 25,
        //        SpringLayout.SOUTH, nameLabel );

        sLayout.putConstraint( SpringLayout.WEST, lengthLabel, 10,
			       SpringLayout.WEST, this.getContentPane() );
        sLayout.putConstraint( SpringLayout.NORTH, lengthLabel, 80,
			       // SpringLayout.SOUTH, typeLabel );
			       SpringLayout.SOUTH, nameLabel );

        sLayout.putConstraint( SpringLayout.WEST, yLabel, 10,
			       SpringLayout.WEST, this.getContentPane() );
        sLayout.putConstraint( SpringLayout.NORTH, yLabel, 15,
			       SpringLayout.SOUTH, lengthLabel );


        sLayout.putConstraint( SpringLayout.WEST, scalingLabel, 10,
			       SpringLayout.WEST, this.getContentPane() );
        sLayout.putConstraint( SpringLayout.NORTH, scalingLabel, 15,
			       SpringLayout.SOUTH, yLabel );





	// Make layout for comboBoxes and text fields

	/** start used-specified graph*/
	// Select the graph: built-in or user-defined
        ButtonGroup group2 = new ButtonGroup();

	builtinNameRB = new JRadioButton();
        builtinNameRB.setSelected( true );
        builtinNameRB.addActionListener( actionListener );

        newNameRB = new JRadioButton();
        newNameRB.addActionListener( actionListener );

        group2.add( builtinNameRB );
        group2.add( newNameRB );

	this.getContentPane().add( builtinNameRB );
        this.getContentPane().add( newNameRB );

        nameCoB = new JComboBox( graphNames );
        this.getContentPane().add( nameCoB );
	nameCoB.setSelectedIndex( 1 );
	latestNameCobIndex = 1;

        sLayout.putConstraint( SpringLayout.WEST, nameCoB, 55,
			       SpringLayout.EAST, yLabel );
        sLayout.putConstraint( SpringLayout.NORTH, nameCoB, 10,
			       SpringLayout.NORTH, this.getContentPane() );

        sLayout.putConstraint( SpringLayout.WEST, builtinNameRB, 45,
			       SpringLayout.EAST, nameLabel );
        sLayout.putConstraint( SpringLayout.NORTH, builtinNameRB, 10,
			       SpringLayout.NORTH, this.getContentPane() );

        sLayout.putConstraint( SpringLayout.WEST, newNameRB, 45,
			       SpringLayout.EAST, nameLabel );
        sLayout.putConstraint( SpringLayout.NORTH, newNameRB, 20,
			       SpringLayout.SOUTH, builtinNameRB );


        JLabel newName = new JLabel( "name:");
        JLabel newId = new JLabel( "id:"  );

        this.getContentPane().add( newName );
        this.getContentPane().add( newId );

        sLayout.putConstraint( SpringLayout.WEST, newName, 10, 
			       SpringLayout.EAST, newNameRB );
        sLayout.putConstraint( SpringLayout.NORTH, newName, 10, 
			       SpringLayout.SOUTH,  builtinNameRB );

        sLayout.putConstraint( SpringLayout.WEST, newId, 10, 
			       SpringLayout.EAST, newNameRB );
        sLayout.putConstraint( SpringLayout.NORTH, newId, 10, 
			       SpringLayout.SOUTH, newName );


        newNameTF = new JTextField( 9 );
        newNameTF.setEditable( false );
        newIdTF = new JTextField( 9 );
        newIdTF.setEditable( false );

        this.getContentPane().add( newNameTF );
        this.getContentPane().add( newIdTF );

        sLayout.putConstraint( SpringLayout.WEST, newNameTF, 10,
			       SpringLayout.EAST, newName );
        sLayout.putConstraint( SpringLayout.NORTH, newNameTF, 10,
			       SpringLayout.SOUTH, builtinNameRB );

        sLayout.putConstraint( SpringLayout.WEST, newIdTF, 10,
			       SpringLayout.EAST, newName );
        sLayout.putConstraint( SpringLayout.NORTH, newIdTF, 10,
			       SpringLayout.SOUTH, newNameTF );

	/** end used-specified graph*/


	typeCoB = new JComboBox( SimpleChartFactory.getChartTypes() );
        // this.getContentPane().add( typeCoB );
        //sLayout.putConstraint( SpringLayout.WEST, typeCoB, 45,
        //        SpringLayout.EAST, yLabel );
        //sLayout.putConstraint( SpringLayout.NORTH, typeCoB, 10,
        //        SpringLayout.SOUTH, nameCoB );
	
        lengthTF = new JTextField( 8 );
        yLabelTF = new JTextField( 8 );
	this.getContentPane().add( lengthTF );
        this.getContentPane().add( yLabelTF );

	
        sLayout.putConstraint( SpringLayout.WEST, lengthTF, 45,
			       SpringLayout.EAST, nameLabel );
        sLayout.putConstraint( SpringLayout.NORTH, lengthTF, 80,
			       //SpringLayout.SOUTH, typeCoB );
			       SpringLayout.SOUTH, nameLabel );

        sLayout.putConstraint( SpringLayout.WEST, yLabelTF, 45,
			       SpringLayout.EAST, nameLabel );
        sLayout.putConstraint( SpringLayout.NORTH, yLabelTF, 10,
			       SpringLayout.SOUTH, lengthTF );


	// Scaling buttons, labels and text fields
        ButtonGroup group = new ButtonGroup();

        automaticRB = new JRadioButton( MainWindow.bundle
                .getString( "AUTOMATIC_RADIO" ) );
        automaticRB.setSelected( true );
        automaticRB.addActionListener( actionListener );

        selectedRangeRB = new JRadioButton();
        selectedRangeRB.addActionListener( actionListener );

        group.add( automaticRB );
        group.add( selectedRangeRB );

        this.getContentPane().add( automaticRB );
        this.getContentPane().add( selectedRangeRB );

        sLayout.putConstraint( SpringLayout.WEST, automaticRB, 45,
			       SpringLayout.EAST, nameLabel );
        sLayout.putConstraint( SpringLayout.NORTH, automaticRB, 10,
			       SpringLayout.SOUTH, yLabelTF );

        sLayout.putConstraint( SpringLayout.WEST, selectedRangeRB, 45,
			       SpringLayout.EAST, nameLabel );
        sLayout.putConstraint( SpringLayout.NORTH, selectedRangeRB, 20,
			       SpringLayout.SOUTH, automaticRB );


        JLabel max = new JLabel( MainWindow.bundle.getString( "MAX" ) );
        JLabel min = new JLabel( MainWindow.bundle.getString( "MIN" ) );

        this.getContentPane().add( max );
        this.getContentPane().add( min );

        sLayout.putConstraint( SpringLayout.WEST, max, 10, SpringLayout.EAST,
			       selectedRangeRB );
        sLayout.putConstraint( SpringLayout.NORTH, max, 10, SpringLayout.SOUTH,
			       automaticRB );

        sLayout.putConstraint( SpringLayout.WEST, min, 10, 
			       SpringLayout.EAST, selectedRangeRB );
        sLayout.putConstraint( SpringLayout.NORTH, min, 10, 
			       SpringLayout.SOUTH, max );


        maxValueTF = new JTextField( 5 );
        maxValueTF.setEditable( false );
        minValueTF = new JTextField( 5 );
        minValueTF.setEditable( false );

        this.getContentPane().add( maxValueTF );
        this.getContentPane().add( minValueTF );

        sLayout.putConstraint( SpringLayout.WEST, maxValueTF, 10,
			       SpringLayout.EAST, max );
        sLayout.putConstraint( SpringLayout.NORTH, maxValueTF, 10,
			       SpringLayout.SOUTH, automaticRB );

        sLayout.putConstraint( SpringLayout.WEST, minValueTF, 10,
			       SpringLayout.EAST, max );
        sLayout.putConstraint( SpringLayout.NORTH, minValueTF, 10,
			       SpringLayout.SOUTH, maxValueTF );











	// OK + Cancel buttons
        cancelButton = new JButton( MainWindow.bundle.getString( "CANCEL" ) );
        cancelButton.addActionListener( actionListener );
        okButton = new JButton( MainWindow.bundle.getString( "OK" ) );
        okButton.addActionListener( actionListener );

        this.getContentPane().add( okButton );
        this.getContentPane().add( cancelButton );

        sLayout.putConstraint( SpringLayout.SOUTH, okButton, -10,
			       SpringLayout.SOUTH, this.getContentPane() );

        sLayout.putConstraint( SpringLayout.SOUTH, cancelButton, -10,
			       SpringLayout.SOUTH, this.getContentPane() );

        sLayout.putConstraint( SpringLayout.EAST, cancelButton, -10, 
			       SpringLayout.EAST, this.getContentPane() );

        sLayout.putConstraint( SpringLayout.EAST, okButton, -10,
			       SpringLayout.WEST, cancelButton );

    }


    /** 
     * @param yes Whether to show a list of pe specific graphs of other graphs.
     */
    public void setCPUspecifig(boolean yes) {
        cpuSpecific = yes;
        
        if( cpuSpecific ) {
            nameCoB.removeAllItems();    
            for( int i=0; i < cpuGraphNames.length; i++ ) {
                nameCoB.addItem( cpuGraphNames[i] );
            }
            
        } else {
            nameCoB.removeAllItems();    
            for( int i=0; i < graphNames.length; i++ )
            {
                nameCoB.addItem( graphNames[i] );
            }
        }
    }
    
    
    /**
     * Shows the dialog.
     * @return The created graphInfo, or null if canceled.
     */
    public Graph showDialog() {
    	setVisible(true);
    	return createdGraphInfo;
    }
    
    
    /**
     * Listener for ActionEvents.
     */
    private class MyActionListener implements ActionListener {
        public void actionPerformed( ActionEvent e ) {
            Object source = e.getSource();

            if ( source.equals( cancelButton ) ) {
            	createdGraphInfo = null;
                self.dispose();
                
            } else if ( source.equals( okButton ) ) {
            	// Create a graph panel

                String name = (String) nameCoB.getSelectedItem();
                String graphID = "";

		if ( builtinNameRB.isSelected() ) {
		    // Buil-in graph

		    if ( name == null ) {
			JOptionPane.showMessageDialog( self, " You must select some graph name from menu!", 
						       "Error", JOptionPane.ERROR_MESSAGE );
			return;
		    }

		    if( cpuSpecific ) {
                	graphID =  cpuGraphIDs[ nameCoB.getSelectedIndex() ];
		    } else {
                	graphID = graphIDs[ nameCoB.getSelectedIndex() ];
		    }

		} else {
		    // user-defined graph
		    name = newNameTF.getText();
		    graphID = newIdTF.getText();

		    System.out.println("you defined name=" + name + " and id=" + graphID);
		}


                int typeID = typeCoB.getSelectedIndex(); // just line type available...
                double length = 0;
                double maxValue = 0.0;
                double minValue = 0.0;

                try {
                    length = Double.parseDouble( lengthTF.getText() );

                    if ( selectedRangeRB.isSelected() ) {
                        maxValue = Double.parseDouble( maxValueTF.getText() );
                        minValue = Double.parseDouble( minValueTF.getText() );
                    }

                } catch ( NumberFormatException exp ) {
                    JOptionPane.showMessageDialog( self, MainWindow.bundle
                            .getString( "ERROR_NUMBER_TEXT" ), MainWindow.bundle
                            .getString( "ERROR_NUMBER_TITLE" ),
                            JOptionPane.ERROR_MESSAGE );
                    return;
                }
                
                String label = yLabelTF.getText();

                createdGraphInfo = new Graph(graphID, typeID, name, MainWindow.bundle.getString("XAXIS"),
                		label, minValue, maxValue, length, automaticRB.isSelected(), false);
                self.dispose();
                
            } else if ( source.equals( automaticRB ) ) {
                maxValueTF.setEditable( false );
                minValueTF.setEditable( false );

            } else if ( source.equals( selectedRangeRB ) ) {
                maxValueTF.setEditable( true );
                minValueTF.setEditable( true );

	    } else if ( source.equals( builtinNameRB)) {
		nameCoB.setSelectedIndex( latestNameCobIndex );
                newNameTF.setEditable( false );
                newIdTF.setEditable( false );

            } else if ( source.equals( newNameRB ) ) {
		latestNameCobIndex = nameCoB.getSelectedIndex();
		nameCoB.setSelectedIndex(0);
                newNameTF.setEditable( true );
                newIdTF.setEditable( true );
	    }
        }
    }
}
