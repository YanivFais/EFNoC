/**
 * CVS:
 * $Id: SignalsTableModel.java 1399 2010-08-26 13:56:45Z lehton87 $
 * 
 * File:    SignalsTableModel.java
 * Author:  Tomi Jantti <tomi.jantti@tut.fi>
 * Created: 22.11.2006
 *
 *
 *
 * Copyright 2009 Tampere University of Technology
 * 
 *  This file is part of Execution Monitor.
 *
 *  Execution Monitor is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Execution Monitor is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Execution Monitor.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */
package fi.cpu.table;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map; //ES
import java.util.Set; //ES
import java.util.Vector; //ES
import java.util.Iterator;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import fi.cpu.data.Configuration;
import fi.cpu.data.Model;
import fi.cpu.data.ModelNode;
import fi.cpu.data.Process;
import fi.cpu.data.ProcessingElement;
import fi.cpu.data.Thread;
import fi.cpu.event.ModelEvent;
import fi.cpu.event.ModelListener;
import fi.cpu.ui.MainWindow;


/**
 * SignalsTableModel provides model information for
 * the signals table.
 */
public class SignalsTableModel extends AbstractTableModel {
    private static final String TABLE_TITLE = MainWindow.bundle.getString("SIGNAL_LABEL_TITLE");
    
    private Configuration config;
    
    /** Maps row indices in the table to process ids */
    private HashMap<Integer, Integer> ind2pidMap;
    
    /** Maps process ids to row indices in the table */
    private HashMap<Integer, Integer> pid2indMap;
    
    /** Maps process ids to process names */
    private HashMap<Integer, String> pid2nameMap;
    
    /** Maps source pids to map containing destination pids and signal counts. 
     * This holds the actual data of the signal table
     */
    private HashMap< Integer, HashMap<Integer, Integer> > signalCounts;
    
    /** ES 2013-02-14*/
    private int sumPid       = 0; // this becomes the index of sum row
    private Vector<Integer> pCounts; // how many processes per PE

    
    /**
     * Creates new SignalsTableModel.
     */
    public SignalsTableModel(Configuration config) {
	super();
	this.config = config;
	config.getPeModel().addModelListener(new MyModelListener());

	
	ind2pidMap   = new HashMap<Integer, Integer>();
	pid2indMap   = new HashMap<Integer, Integer>();
	pid2nameMap  = new HashMap<Integer, String>();
	signalCounts = new HashMap< Integer, HashMap<Integer, Integer> >();
	pCounts      = new Vector<Integer>();
	initProcesses();
    }
    
    
    /* (non-Javadoc)
     * @see javax.swing.table.TableModel#getColumnCount()
     */
    public int getColumnCount() {
	return pid2nameMap.size()+1; // also header column
    }
    
    
    /* (non-Javadoc)
     * @see javax.swing.table.TableModel#getRowCount()
     */
    public int getRowCount() {
	return ind2pidMap.size();
    }
    
    /**
     * Clear table contents. Note that table is indexed with process
     * ID (pid).
     */
    public void clear() {
	int i=0;
	
	for (int r=0; r < ind2pidMap.size(); r++) {
	    for (int c=0; c < ind2pidMap.size(); c++) {
		
		Integer srcP = ind2pidMap.get(r);
		Integer dstP = ind2pidMap.get(c);
		/*
		  System.out.println(i + " clear cell (" + r + "," + c + "),  "
		  + pid2nameMap.get(srcP) + "(" + srcP + ") -> "
		  + pid2nameMap.get(dstP) + "(" + dstP + ") which was "
		  + getValueAt (srcP, dstP));
		*/
		
		setValue (srcP,dstP, 0); //i);
		i++;		
	    }
	}		
	return;
    }
    
    
    /* (non-Javadoc)
     * @see javax.swing.table.TableModel#getColumnName(int)
     */
    public String getColumnName(int column) {
	if (column == 0) {
	    // get the left most column name
	    return TABLE_TITLE;
	} else {
	    // get one of the other column names
	    Integer pid = ind2pidMap.get(column-1);
	    return pid2nameMap.get(pid);
	}
    }
    
    
    /* (non-Javadoc)
     * @see javax.swing.table.TableModel#getValueAt(int, int)
     * Note that indices refer to visible table - They are NOT pids!
     */
    public Object getValueAt(int rowIndex, int columnIndex) {
	Integer srcPid = ind2pidMap.get(rowIndex);
	
	if (columnIndex == 0) {
	    // get the value in the left most column,
	    // i.e. name of the process
	    return pid2nameMap.get(srcPid);
	} else {
	    // get one of the other values
	    Integer destPid = ind2pidMap.get(columnIndex-1);
	    
	    HashMap<Integer, Integer> map = signalCounts.get(srcPid);
	    if (map == null) {
		return new Integer(0);
	    }
	    
	    Object val = map.get(destPid); 
	    if (val == null) {
		val = new Integer(0);
	    }
	    return val;
	}
    }
    
    
    /**
     * Sets the signal value.
     * @param sourcePid Id of the source process.
     * @param destPid   Id of the destination process.
     * @param newValue  The signal value.
     * Note that pids are used unlike in getValueAt!
     */
    public void setValue(Integer sourcePid, Integer destPid, int newValue) {
	//System.out.println("SgnTabMod.setVal(" + sourcePid + "," 
	//		   + destPid + ")= " + newValue);
       

	String sourceName = pid2nameMap.get(sourcePid);
	String destName   = pid2nameMap.get(destPid);
	if (sourceName == null || destName == null) {
	    // unknown id
	    return; 
	}
	
	// Get the inner map of form <dst,sgncount>. If that doesn't
	// exist yet, create.
	HashMap<Integer, Integer> destMap = signalCounts.get(sourcePid);
	if (destMap == null) {
	    destMap = new HashMap<Integer, Integer>();
	    signalCounts.put(sourcePid, destMap);
	}	
	// Set the value
	destMap.put(destPid, newValue);
	fireTableCellUpdated(pid2indMap.get(sourcePid), pid2indMap.get(destPid)+1);
	
	return;
    }
    
    
    /**
     * Increments signal count (instead of overwriting like setValue does)
     * This function added  2012-10-26, ES
     */
    public void incrementSignalCount(int srcPid, int dstPid, int count) {
	int rowIdx = pid2indMap.get (srcPid);
	int colIdx = pid2indMap.get (dstPid)+1; //+1 needed due to name column

	// Sum new signal value to old values
	Integer old = (Integer) getValueAt (new Integer (rowIdx), new Integer (colIdx));
	
	setValue (srcPid, dstPid, count + old);

	sumPerProcess(srcPid, dstPid);
	sumPerPe     ();

	return;
    }
    
    
    /**
     * Calculates the sum of Tx and RX bytes per task
     * ES
     */
    protected void sumPerProcess(Integer sourcePid, Integer destPid) {

	HashMap<Integer, Integer> destMap = signalCounts.get(sourcePid);

	// Calculate the sums
	// First, sum over columns, i.e. sum of TX bytes in one row
	int sigSum = 0;
	for (Map.Entry<Integer, Integer> entry : destMap.entrySet()) {
	    // Do not add "sum" to itself recursively
	    if (entry.getKey() != sumPid
		&& entry.getKey() != (sumPid+1)
		){
		sigSum += entry.getValue();
	    }
	}
	destMap.put(sumPid, sigSum);


	// Then, sum over rows, i.e. sum of RX bytes in one column
	sigSum     = 0;
	int totSum = 0;
	HashMap<Integer, Integer> sumMap 
	    = signalCounts.get(sumPid); //current sum row
	Set<Integer> keyset =signalCounts.keySet(); //source pids = rows

	// All rows (=sources)
	for (Integer key : keyset) {
	    HashMap <Integer, Integer>  dstMap= signalCounts.get(key);
	    // Calculate sum of incoming bytes for this destination
	    Integer bytes = dstMap.get(destPid);
	    if (bytes != null 
		&& key != sumPid && key != sumPid+1
		) {
		sigSum += bytes;
	    }
	    // Calculate total byte sum of all destinations
	    bytes = dstMap.get(sumPid);
	    if (bytes != null 
		&& key != sumPid && key != sumPid+1
		) {
		totSum += bytes;
	    }	    
	}
	setValue(sumPid, destPid, sigSum);
	setValue(sumPid, sumPid, totSum); 
	//System.out.println ("sum per task at (" + sumPid + ", " + destPid 
	//		    + ") becomes " + sigSum);
	fireTableCellUpdated(pid2indMap.get(sumPid), pid2indMap.get(sumPid)+1);

	return;
    }



    /**
     * Calculates the sum of Tx and RX bytes per PE. Always
     * ES
     */
    private void sumPerPe() {

	// Calculate bottom row
	int rowIdx = 0;
	int pe     = 0;
	int dstPid = 0;
	for (int i: pCounts) {

	    int sigSum =0;
	    //System.out.println ("PE:" + pe + "has " + i + " tasks");
	    
	    // Sum all "sum per process" columns of this PE
	    for (int p=0; p<i; p++) {

		Integer tmpSum = (Integer) getValueAt(pid2indMap.get(sumPid), rowIdx+1);
		//System.out.println(" sigsum/PE += " + tmpSum);
		sigSum += tmpSum;
		dstPid = ind2pidMap.get(rowIdx);
		setValue (sumPid+1, dstPid,  -1);
		rowIdx++;
	    }
	    //System.out.println ("sum per PE " + pe + " becomes " + sigSum);	   
	    if (i > 0) {
		// Update only if PE has some tasks (otherwise would overwrite the prev sum)
		setValue(sumPid+1, dstPid, sigSum);
		fireTableCellUpdated(pid2indMap.get(sumPid+1), pid2indMap.get(sumPid+1)+1);
	    }
	    pe++;
	}

	// Calculate the right-most column
	rowIdx     = 0;
	pe         = 0;
	int srcPid = 0;
	for (int i: pCounts) {

	    int sigSum =0;
	    
	    // All "sum per process" rows of this PE
	    for (int p=0; p<i; p++) {

		Integer tmpSum = (Integer) getValueAt(rowIdx, pid2indMap.get(sumPid)+1);
		srcPid = ind2pidMap.get(rowIdx);
		//System.out.println(" process " + srcPid 
		//		   + " sigsum/PE: " + sigSum + " += " + tmpSum);
		sigSum += tmpSum;
		setValue (srcPid, sumPid+1, -1);
		rowIdx++;
	    }
	    //System.out.println ("sum per PE " + pe + " becomes " + sigSum);	   
	    if (i > 0) {
		// Update only if PE has some tasks
		setValue (srcPid, sumPid+1, sigSum);
		fireTableCellUpdated(rowIdx-1, pid2indMap.get(sumPid+1)+1);
	    }
	    pe++;
	}

	return;
    }



    
    
    /**
     * Initializes the table. Seeks all the processes and sorts
     * processes of one PE alphabetically. Updates the maps which tie
     * PIDs to row indices etc.
     */
    protected void initProcesses() {
	HashMap<Integer, Integer> newInd2pidMap = new HashMap<Integer, Integer>();
	HashMap<Integer, Integer> newPid2indMap = new HashMap<Integer, Integer>();
	HashMap<Integer, String> newPid2nameMap = new HashMap<Integer, String>();
	
	Model peModel = config.getPeModel();
	Iterator<ModelNode> peIter = peModel.getChildren(peModel.getModelRoot()).iterator();
	int processCount = 0;
	sumPid           = 0;
	HashMap sumMap = new HashMap<Integer, Integer>();
	HashMap sumPeMap = new HashMap<Integer, Integer>();
	pCounts.clear();

	// From all processors,
	while (peIter.hasNext()) {
	    ModelNode peNode = peIter.next();
	    if (!(peNode instanceof ProcessingElement)) {
		continue;
	    }
	    ProcessingElement pe = (ProcessingElement) peNode;
	    Iterator<ModelNode> tIter = peModel.getChildren(pe).iterator();
	    int pCount = 0; //es
	    
	    // and their all threads,
	    while (tIter.hasNext()) {
		ModelNode tNode = tIter.next();
		if (!(tNode instanceof Thread)) {
		    continue;
		}
		Thread thread = (Thread) tNode;

		pCount += peModel.getChildCount(thread);//Es


		Iterator<ModelNode> pIter = peModel.getChildren(thread).iterator();
		List<Process> pList = new ArrayList<Process>();
		
		// copy all processes to a list
		while(pIter.hasNext()) {
		    ModelNode pNode = pIter.next();
		    if (!(pNode instanceof Process)) {
			continue;
		    }
		    Process process = (Process) pNode;
		    pList.add(process);
		}		
		Collections.sort(pList);
		
		// Add sorted processes to new maps
		for (int i=0; i<pList.size(); ++i) {
		    Process process = pList.get(i);
		    Integer pid     = process.getId();

		    sumPid += pid;
		    sumMap.put(pid, 0);
		    sumPeMap.put(pid, 0);

		    newInd2pidMap.put(new Integer(processCount), pid);
		    newPid2indMap.put(pid, new Integer(processCount));
		    newPid2nameMap.put(pid, process.getName());
		    
		    // Remove the possible old info
		    pid2nameMap.remove(pid);
		    ++processCount;
		}
	    } // end while (tTter.hasNext)

	    // Store the num of processes on this PE
	    System.out.println("pCount:" + pCount);
	    //System.out.println( "pCounts.size()" + pCounts.size());
	    pCounts.add(pCount); //es

	} // end while (peIter.hasNext)


	// If there are still processes left in the old map,
	// those don't really exist anymore. Clear related values.
	Iterator<Integer> pidIter = pid2nameMap.keySet().iterator();
	while (pidIter.hasNext()) {
	    Integer pid = pidIter.next();
	    
	    // Clear values when 'pid' is the source
	    signalCounts.remove(pid);
	    
	    // Clear values when 'pid' is the destination
	    Iterator< HashMap<Integer, Integer> > mapIter = signalCounts.values().iterator();
	    while (mapIter.hasNext()) {
		HashMap<Integer, Integer> map = mapIter.next();
		if (map != null) {
		    map.remove(pid);
		}
	    }
	}
		


	/** Add two sums as the last "processes" 
	    Right-most columns   is the sum of outgoing bytes from 1 task and from 1 PE
	    Bottom row          is the sum of incoming bytes to    1 task and to   1 PE
	    Bottom-right corner is the sum of all outgoing bytes per task and    per PE
	*/
	//System.out.println("sumPid = " + sumPid + " goes to row " + processCount);
	newInd2pidMap.put(processCount, sumPid);
	newPid2indMap.put(sumPid, processCount);
	newPid2nameMap.put(sumPid, new String("Sum per task [bytes]"));	

	newInd2pidMap.put(processCount+1, sumPid+1);
	newPid2indMap.put(sumPid+1, processCount+1);
	newPid2nameMap.put(sumPid+1, new String("Sum per PE [bytes]"));	

	signalCounts.put(sumPid, sumMap);
	signalCounts.put(sumPid+1, sumPeMap);


	ind2pidMap  = newInd2pidMap;
	pid2indMap  = newPid2indMap;
	pid2nameMap = newPid2nameMap;
	fireTableStructureChanged();

	return;
    }
    
    
    /**
     * Listener for ModelEvents.
     */
    private class MyModelListener implements ModelListener {
    	public void nodeInserted(ModelEvent e) {
	    initProcesses();
    	}
    	public void nodeRemoved(ModelEvent e) {
	    initProcesses();
    	}
    	public void nodeMoved(ModelEvent e) {
	    initProcesses();
    	}
    	public void structureChanged(ModelEvent e) {
	    initProcesses();
    	}
    }
}
