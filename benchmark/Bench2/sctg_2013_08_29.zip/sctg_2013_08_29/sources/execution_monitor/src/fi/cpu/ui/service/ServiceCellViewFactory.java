/**
 * File:    ServiceCellViewFactory.java
 * Author:  Tomi Jantti <tomi.jantti@tut.fi>
 * Created: 6.3.2007
 *
 *
 *
 * Copyright 2009 Tampere University of Technology
 * 
 *  This file is part of Execution Monitor.
 *
 *  Execution Monitor is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Execution Monitor is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Execution Monitor.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 */
package fi.cpu.ui.service;

import org.jgraph.graph.DefaultCellViewFactory;
import org.jgraph.graph.VertexView;

/**
 * ServiceCellViewFactory creates views for service model
 * objects.
 */
public class ServiceCellViewFactory extends DefaultCellViewFactory {
	/* (non-Javadoc)
	 * @see org.jgraph.graph.DefaultCellViewFactory#createVertexView(java.lang.Object)
	 */
	protected VertexView createVertexView(Object cell) {
		return new ServiceVertexView(cell);
	}
}
