/*
 * CVS-tietoja:
 * $Author: perttul5 $ 
 * $Date: 2008-05-20 17:23:56 +0300 (ti, 20 touko 2008) $ 
 * $Revision: 3514 $
 *
 * Created on 25.7.2005
 *
 *
 *
 * Copyright 2009 Tampere University of Technology
 * 
 *  This file is part of Execution Monitor.
 *
 *  Execution Monitor is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Execution Monitor is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Execution Monitor.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 *
 */
package fi.cpu.ui.graph;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Date; //ES
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JLabel; //es
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import fi.cpu.Settings;
import fi.cpu.data.Graph;
import fi.cpu.data.GraphDataLogger;
import fi.cpu.ui.MainWindow;
import fi.cpu.ui.ctrl.PePanel;


/**
 * @author jsikio
 *
 * Panel that contain some JFreeChart graph, used e.g. for CPU utilization
 * or user-selected custom, e.g. input queue of a task
 */
public class GraphPanel extends JPanel
{
    protected static final Color COLOR_CURVE;
    protected static final Color COLOR_MIN;
    protected static final Color COLOR_AVG;
    protected static final Color COLOR_MAX;
    
    protected JFreeChart chart_ = null;
    protected ChartPanel chartPanel_ = null;
    protected Graph graphInfo;
    
    protected JCheckBox loggingSelection_;
    protected JLabel idLabel_;
    protected boolean logHeaderPrinted = false; //ES
    protected static long simulationTime = 0;
    protected static long previousSimulationTime = 0;
    
    protected static final String MIN_CMD = "min";
    protected static final String AVG_CMD = "avg";
    protected static final String MAX_CMD = "max";
    
    protected JCheckBoxMenuItem minCB_;
    protected JCheckBoxMenuItem avgCB_;
    protected JCheckBoxMenuItem maxCB_;
    protected Map<JCheckBoxMenuItem, Integer> seriesMap_;
    
    protected int statCurvesSelected_ = 0;
    protected TimeSeries minSeries_ = null;
    protected TimeSeries avgSeries_ = null;
    protected TimeSeries maxSeries_ = null;
    
    protected double minimum_ = 0;
    protected double maximum_ = 0;
    protected double sum_ = 0;
    protected int valueCount_ = 0;
    
    static {
    	// Initialize curve colors
        int red = 0;
        int green = 0;
        int blue = 0;
        
        red = Integer.parseInt( Settings.getAttributeValue("CURVE_COLOR_RED") );
        green = Integer.parseInt( Settings.getAttributeValue("CURVE_COLOR_GREEN") );
        blue = Integer.parseInt( Settings.getAttributeValue("CURVE_COLOR_BLUE") );
        
        COLOR_CURVE = new Color(red, green, blue);
        
        red = Integer.parseInt( Settings.getAttributeValue("CURVE_MIN_COLOR_RED") );
        green = Integer.parseInt( Settings.getAttributeValue("CURVE_MIN_COLOR_GREEN") );
        blue = Integer.parseInt( Settings.getAttributeValue("CURVE_MIN_COLOR_BLUE") );
        
        COLOR_MIN = new Color(red, green, blue);
        
        red = Integer.parseInt( Settings.getAttributeValue("CURVE_AVG_COLOR_RED") );
        green = Integer.parseInt( Settings.getAttributeValue("CURVE_AVG_COLOR_GREEN") );
        blue = Integer.parseInt( Settings.getAttributeValue("CURVE_AVG_COLOR_BLUE") );
        
        COLOR_AVG = new Color(red, green, blue);

        red = Integer.parseInt( Settings.getAttributeValue("CURVE_MAX_COLOR_RED") );
        green = Integer.parseInt( Settings.getAttributeValue("CURVE_MAX_COLOR_GREEN") );
        blue = Integer.parseInt( Settings.getAttributeValue("CURVE_MAX_COLOR_BLUE") );
        
        COLOR_MAX  = new Color(red, green, blue);
    }
    

    /** Constructor
     */
    public GraphPanel()
    {
        this.setLayout( new BoxLayout( this, BoxLayout.X_AXIS) );
        seriesMap_ = new HashMap<JCheckBoxMenuItem, Integer>();
    }
    

    // Removes all the data points from the graph. es 2012-09-28
    public void clearGraph ()
    {
	// System.out.println ("GraphPanel.clearGraph()");

	// Main data line
        XYSeriesCollection collection = (XYSeriesCollection)chart_.getXYPlot().getDataset();    	
	collection.getSeries(0).clear();

	// Min/max/etc counters and lines
	minimum_ = 0;
	maximum_ = 0;
	sum_ = 0;
	simulationTime = 0;
	previousSimulationTime = 0;

	Integer series = seriesMap_.get(minCB_);
	if (series != null) {
	    collection.getSeries(series.intValue()).clear();
	}
	series = seriesMap_.get(avgCB_);
	if (series != null) {
	    collection.getSeries(series.intValue()).clear();
	}
	series = seriesMap_.get(maxCB_);
	if (series != null) {
	    collection.getSeries(series.intValue()).clear();
	}

    }

    /**
     * Creates an XY scatter plot. User can later select if min/avg/max values are shown 
     * and the ranges for axes.
     */
    public void setGraph(Graph gInfo)
    {
    	graphInfo = gInfo;
    	
        this.removeAll();

        chart_ = SimpleChartFactory.createChart(graphInfo.getTypeId(), 
						graphInfo.getTitle(),
        		graphInfo.getYAxis(), graphInfo.getXAxis());
	if (chart_ == null) 
	    {
		System.out.println ("SimpleChartFactory failed");
	    }

        chartPanel_ = new ChartPanel( chart_ );
	// chartPanel_.setPreferredSize( new Dimension(100, 50) );
        
        loggingSelection_ = new JCheckBox(MainWindow.bundle.getString("GRAPH_LOG_ENABLE"));
        loggingSelection_.addItemListener(new MyLoggingListener());
        loggingSelection_.setSelected(graphInfo.isLogged());
        

	// Show graph
        this.setLayout(new GridBagLayout());
        this.add(chartPanel_, 
		 new GridBagConstraints(
					0, 0,  // x and y coordinates
					GridBagConstraints.REMAINDER, GridBagConstraints.RELATIVE,  // width + height
					1.0, 1.0,  // weigthx + weighty
					GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, // anchor + fill
					new Insets(0, 0, 0, 0), 0, 0) // isets means borders
		 );
	
	// Show id (2012-10-15 es)
	idLabel_ = new JLabel ("  (id =" + graphInfo.getId() + ")");
        this.add(idLabel_, 
		 new GridBagConstraints(
					0, 1, GridBagConstraints.REMAINDER, GridBagConstraints.REMAINDER,
					0.0, 0.0, GridBagConstraints.NORTHWEST, GridBagConstraints.NONE,
					new Insets(0, 0, 0, 0), 0, 0));
	
	// Show check box for logging
        this.add(loggingSelection_, 
		 new GridBagConstraints(
					0, 1, GridBagConstraints.REMAINDER, GridBagConstraints.REMAINDER,
					0.0, 0.0, GridBagConstraints.NORTHEAST, GridBagConstraints.NONE,
					new Insets(0, 0, 0, 0), 0, 0));
        

	// Define the main data line
        float width = Float.parseFloat( Settings.getAttributeValue( "LINE_WIDTH" ) );
        chart_.getXYPlot().getRenderer().setSeriesPaint(0, COLOR_CURVE);
        chart_.getXYPlot().getRenderer().setStroke(new BasicStroke( width ));


	// Ranges for axes
        ValueAxis axis = chart_.getXYPlot().getRangeAxis();
        if( graphInfo.isAutoScale() )
        {
            axis.setAutoRange( true );
        }
        else
        {
            axis.setAutoRange( false );
            axis.setRange( graphInfo.getMinValue(), graphInfo.getMaxValue() );
        }

        //chart_.getXYPlot().getDomainAxis().setFixedAutoRange( graphInfo.getLength()*1000.0 );
        chart_.getXYPlot().getDomainAxis().setFixedAutoRange( graphInfo.getLength() );


        // Put choices min, avg, max, and range to popup menu
        ResourceBundle bundle = MainWindow.bundle;
        minCB_ = new JCheckBoxMenuItem(bundle.getString("GRAPH_MENU_MIN"));
        avgCB_ = new JCheckBoxMenuItem(bundle.getString("GRAPH_MENU_AVG"));
        maxCB_ = new JCheckBoxMenuItem(bundle.getString("GRAPH_MENU_MAX"));
        
        minCB_.setActionCommand(MIN_CMD);
        avgCB_.setActionCommand(AVG_CMD);
        maxCB_.setActionCommand(MAX_CMD);

        MyItemListener listener = new MyItemListener();
        minCB_.addItemListener(listener);
        avgCB_.addItemListener(listener);
        maxCB_.addItemListener(listener);

	avgCB_.setSelected( true ); // Draw the average line by default, ES 2012-09-25

        JMenuItem changeRangeItem = new JMenuItem(bundle.getString("GRAPH_MENU_RANGE"));
        changeRangeItem.addActionListener(new MyActionListener());

        JPopupMenu popup = chartPanel_.getPopupMenu();
        popup.addSeparator();
        popup.add(maxCB_);
        popup.add(avgCB_);
        popup.add(minCB_);
        popup.addSeparator();
        popup.add(changeRangeItem);

    }
    
    public JFreeChart getChart() {
        return chart_;
    }
    
    
    public Graph getGraphInfo() {
    	return graphInfo;
    }
    

    // @return A string containing the name of the log file
    public String getLogName() {
    	String name = "";
    	
    	// Is this a pe graph?
    	Container cpu = SwingUtilities.getAncestorOfClass(PePanel.class, this);
    	if (cpu != null && cpu instanceof PePanel) {
    		PePanel p = (PePanel)cpu;
    		name = p.getProcessingElement().getName() + ": ";
    	}
    	name = name + chart_.getTitle().getText();
    	name = name.replace(" ", "_");
    	name = name.replace(":", "_");
    	name = name.replace(".", "_");
    	name = name.replace("__", "_");
    	name = name +".txt";

    	return name;
    }
    


    // Store one new measurement value into dataset, e.g. CPU utilization
    public void addData( double value )
    {  

	// Some obsolete stuff...
        //((TimeSeriesCollection)chart_.getXYPlot().getDataset()).getSeries(0).addOrUpdate( new Millisecond() , value);
    	//TimeSeriesCollection collection = (TimeSeriesCollection)chart_.getXYPlot().getDataset();    	
    	//Millisecond ms = new Millisecond();
        //collection.getSeries(0).addOrUpdate( ms , value);

        
	// Add the value and current time to data series
        long currentTime = simulationTime + previousSimulationTime;
        XYSeriesCollection collection = (XYSeriesCollection)chart_.getXYPlot().getDataset();    	
        collection.getSeries(0).addOrUpdate( currentTime , value);


	// Calculate min/avg/max statistics, if they are enabled
        if (statCurvesSelected_ > 0) {
        	double avg = 0.0;
        	if (valueCount_ == 0) {
        		minimum_ = value;
        		maximum_ = value;
        		avg = value;
        		sum_ = value;
        		
        	} else {
        		if (value < minimum_) {
        			minimum_ = value;
        		}
        		if (value > maximum_) {
        			maximum_ = value;
        		}
        		sum_ += value;
        		avg = sum_ / (valueCount_+1);
        	}
        	
        	Integer series = seriesMap_.get(minCB_);
        	if (series != null) {
        		collection.getSeries(series.intValue()).addOrUpdate(currentTime, minimum_);
        	}
        	series = seriesMap_.get(avgCB_);
        	if (series != null) {
        		collection.getSeries(series.intValue()).addOrUpdate(currentTime, avg);
        	}
        	series = seriesMap_.get(maxCB_);
        	if (series != null) {
        		collection.getSeries(series.intValue()).addOrUpdate(currentTime, maximum_);
        	}
        	++valueCount_;
        }


	// Write to log file
        if (graphInfo.isLogged()) {
	    try {
		if ( !logHeaderPrinted ) {
		    // Add header information to log
		    Date dNow = new Date( );
		    GraphDataLogger.getInstance().logData(this, "Log created ;", dNow.toString());
		    GraphDataLogger.getInstance().logData(this, "", "");
		    GraphDataLogger.getInstance().logData(this, "Graph title ;", graphInfo.getTitle());
		    GraphDataLogger.getInstance().logData(this, "Graph id ;", graphInfo.getId());
		    GraphDataLogger.getInstance().logData(this, "Graph type ;", Integer.toString(graphInfo.getTypeId()));
		    GraphDataLogger.getInstance().logData(this, graphInfo.getXAxis(), graphInfo.getYAxis());
		    GraphDataLogger.getInstance().logData(this, "", "");
		    GraphDataLogger.getInstance().logData(this, "X; ", "Y;");
		    logHeaderPrinted = true;
		}		

		/* Old style puts the current wall clock time as x value
            	long time = System.currentTimeMillis();
            	Calendar calendar = Calendar.getInstance();
            	calendar.setTimeInMillis(time);		
            	int hour = calendar.get(Calendar.HOUR_OF_DAY);
            	int min = calendar.get(Calendar.MINUTE);
            	int sec = calendar.get(Calendar.SECOND);
            	DecimalFormat format = new DecimalFormat("00"); // two digits
            	StringBuilder xvalue = new StringBuilder();
            	xvalue.append(format.format(hour));
            	xvalue.append(":");
            	xvalue.append(format.format(min));
            	xvalue.append(":");
            	xvalue.append(format.format(sec));
		GraphDataLogger.getInstance().logData(this, xvalue.toString(), ""+value);
		*/

		// New style puts the sim time, e.g. 0,1,2..., and uses CSV format
            	StringBuilder xvalue = new StringBuilder();
            	xvalue.append(simulationTime + previousSimulationTime);
		GraphDataLogger.getInstance().logData(this, xvalue.toString()+" ;", ""+value);
        	

	    } catch (IOException ioe) {
		String eMsg = GraphDataLogger.getInstance().getErrorMessage();
		if (eMsg != null) {
		    MainWindow.getInstance().stopLogging(eMsg);
		} else {
		    MainWindow.getInstance().stopLogging(ioe.getMessage());
		}
	    }
        }
    }
    
    /** Thin vertical line, drawn e.g. between measurements
     */
    public void addMarker() {
    	final XYPlot plot = chart_.getXYPlot();
	final Marker configChanged = new ValueMarker(simulationTime + previousSimulationTime);
	configChanged.setPaint(Color.RED);
	plot.addDomainMarker(configChanged);
    }
    
    public static void setSimulationTime(long time) {
    	if (time < previousSimulationTime) {
        	simulationTime += previousSimulationTime;
        }
        previousSimulationTime = time;
    }
    


    // Handles the event if user selects/delects the logging checkBox
    private class MyLoggingListener implements ItemListener {
    	public void itemStateChanged(ItemEvent e) {
    		graphInfo.setLogged(loggingSelection_.isSelected());
    	}
    }

    

    // Handles the events from popup-menu, such as user selecting the drawing of max line
    private class MyItemListener implements ItemListener {
    	public void itemStateChanged(ItemEvent e) {
	    //    		TimeSeriesCollection seriesCollection = (TimeSeriesCollection)chart_.getXYPlot().getDataset();
            XYSeriesCollection seriesCollection = (XYSeriesCollection)chart_.getXYPlot().getDataset();
	    XYItemRenderer renderer = chart_.getXYPlot().getRenderer();
	    

	    // Some checkBoX was selected
	    if (e.getStateChange() == ItemEvent.SELECTED) {
		if (statCurvesSelected_ == 0) {
		    // first item that was selected
		    
		    // Create series for containing data of stat. curves
		    // TimeSeries series = new TimeSeries( "", Millisecond.class );
		    XYSeries series = new XYSeries( "1" );
		    
		    if (SimpleChartFactory.historySize > 0) { 
			// series.setHistoryCount(SimpleChartFactory.historySize);
			series.setMaximumItemCount(SimpleChartFactory.historySize);
		    }
		    seriesCollection.addSeries(series);
		    seriesMap_.put(minCB_, new Integer(1));
		    
		    // series = new TimeSeries( "", Millisecond.class );
		    series = new XYSeries( "2" );
		    
		    if (SimpleChartFactory.historySize > 0) { 
			// eries.setHistoryCount(SimpleChartFactory.historySize);
			series.setMaximumItemCount(SimpleChartFactory.historySize);
		    }
		    seriesCollection.addSeries(series);
		    seriesMap_.put(avgCB_, new Integer(2));
		    
		    // series = new TimeSeries( "", Millisecond.class );
		    series = new XYSeries( "3" );
		    
		    if (SimpleChartFactory.historySize > 0) { 
			// series.setHistoryCount(SimpleChartFactory.historySize);
			series.setMaximumItemCount(SimpleChartFactory.historySize);
		    }
		    seriesCollection.addSeries(series);
		    seriesMap_.put(maxCB_, new Integer(3));
		    
		    // set curves initially invisible
		    renderer.setSeriesVisible(1, false);
		    renderer.setSeriesVisible(2, false);
		    renderer.setSeriesVisible(3, false);
		    renderer.setSeriesPaint(1, COLOR_MIN);
		    renderer.setSeriesPaint(2, COLOR_AVG);
		    renderer.setSeriesPaint(3, COLOR_MAX);
		}
		
		Integer series = seriesMap_.get(e.getSource());
		if (series != null) {
		    renderer.setSeriesVisible(series.intValue(), true);
		}
		++statCurvesSelected_;
		
	    } else if (e.getStateChange() == ItemEvent.DESELECTED){
		// Some checkBoX is not selected anymore

		--statCurvesSelected_;
		
		Integer series = seriesMap_.get(e.getSource());
		if (series != null) {
		    renderer.setSeriesVisible(series.intValue(), false);
		}
		
		// are all deselected now?
		if (statCurvesSelected_ == 0) {
		    seriesMap_.clear();
		    seriesCollection.removeSeries(3);
		    seriesCollection.removeSeries(2);
		    seriesCollection.removeSeries(1);
		    
		    valueCount_ = 0;
		}
	    }
    	}
    }



    // Handles the event when user changes x-axis length (lenght measured in seconds)
    private class MyActionListener implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
    		String msg = MainWindow.bundle.getString("GRAPH_RANGE_TEXT");
    		String title = MainWindow.bundle.getString("GRAPH_RANGE_TITLE");
    		
    		double length= 0; // changed int -> double, ES
		String answer = null;
    		
    		while (true) {
    			answer = JOptionPane.showInputDialog(chartPanel_, msg, title, JOptionPane.QUESTION_MESSAGE);
    			if (answer == null) {
    				return;  // cancel pressed
    			}
    			try {
    				length = Double.parseDouble(answer);  // changed int -> double, ES
    			} catch (NumberFormatException nfe) {
    				continue;  // value was not an integer
    			}
    			break; // a legal value received
    		}
            chart_.getXYPlot().getDomainAxis().setFixedAutoRange( length*1000.0 );
            graphInfo.setLength(length);
    	}
    }

}
