/*
 * CVS-tietoja:
 * $Author: jantti2 $ 
 * $Date: 2006-10-27 12:39:15 +0300 (pe, 27 loka 2006) $ 
 * $Revision: 2670 $
 *
 * Created on 10.10.2005
 *
 *
 *
 * Copyright 2009 Tampere University of Technology
 * 
 *  This file is part of Execution Monitor.
 *
 *  Execution Monitor is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Execution Monitor is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Execution Monitor.  If not, see <http://www.gnu.org/licenses/>.
 *
 *
 *
 */
package fi.cpu.handler;

import java.io.IOException;

/**
 * @author jsikio
 *
*
 */
public interface Handler
{
    public void writeToDestination( String message ) throws IOException;
    
    public void reconnect();
    public void disconnect();
    
}
