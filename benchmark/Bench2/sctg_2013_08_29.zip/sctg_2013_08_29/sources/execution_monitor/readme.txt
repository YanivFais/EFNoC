##############################################################
# Filename:	readme.txt
# Description:	Readme file for Execution Monitor
# Author:	Tomi J�ntti, tomi.jantti@tut.fi, 18.10.2006
# Modified: Kalle Lappalainen, kalle.lappalainen@tut.fi, 14.09.2007
##############################################################


################
# General
################

- A program for monitoring execution on a FPGA board.

- Draws e.g. CPU utilization graphs, tables for tasks' execution and
  communication cycles etc

- Gets statistics in XML format, either from FPGA, TG simulation, or
  TG log file

- The views can be configured with few XML files as well


################
# Prerequisites
################

 - Current version of Execution Monitor requires
   Java JDK version 1.6 (or above) to be installed
   on your system. Note that only JRE is not enough!
   
 - More information about Java and installation packages
   can be found at http://java.sun.com


################
# Installation
################

> cd <location_of_this_file>
> ant [options ...] configure
> ant build
> ant install

or

> ant -buildfile <location_of_this_file>/build.xml [options ...] configure
> ant -buildfile <location_of_this_file>/build.xml build
> ant -buildfile <location_of_this_file>/build.xml install


- Installation assumes that ant can be found from path.
  If not, ../../ant_launcher.sh can be used instead.

- Use the latter installation procedure when build.xml
  is not in the current directory.

- To see available configure options, type:
  > ant help
  or
  > ant -buildfile <location_of_this_file>/build.xml help


################
# Usage
################

> cd <install_dir>
> ./execution_monitor [options ...]

- Use option -help to see available options.

