///////////////////////////////////////////////////////////////////////////////
//                                                                           //
// (c) Copyright OCP-IP 2008
// OCP-IP Confidential and Proprietary
//
//
//============================================================================
//      Project : OCP SLD WG
//       Author : Anssi Haverinen, Nokia Inc.
//
//          $Id:
//
//  Description :  Simple helper functions that parse the command line arguments
//
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
#ifndef COMMAND_LINE_H_
#define COMMAND_LINE_H_

#include "legacy_config_map.h"

void process_command_line(int   argc,
                          char* argv[],
                          std::string& ocp_params_file_name);

void process_command_line(int   argc,
                          char* argv[],
                          std::string& ocp_params_file_name1,
                          std::string& ocp_params_file_name2);

void readMapFromFile(const std::string &myFileName, map_string_type &myParamMap);

#endif
