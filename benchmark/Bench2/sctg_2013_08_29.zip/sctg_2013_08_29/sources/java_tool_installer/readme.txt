##############################################################
# Filename:  readme.txt
# Author:    Tomi J�ntti, tomi.jantti@tut.fi, 25.10.2006
##############################################################


###############
# General
###############

- This is an installer for Java tools of the Koski flow.

- This directory contains files needed in configuring, building
  and installing those tools, either one of them or all at the
  same time.

- All tools can also be handled directly from their own directories.

- To select which versions of tools are installed, use file
  ./tools.properties

- When ant needed, install it (http://ant.apache.org/) or use
  ../ant_launcher.sh instead (i.e. replace "ant" with "../ant_launcher.sh")

- More help:
> cd <location_of_this_file>
> ant help



##################################
# A very short introduction to ant
##################################

- ant is somewhat (and not at all) like make.

- build.xml corresponds to Makefile, but is in XML format.

- As with make, you put the name of the target you want to
  execute after the command:
  make install -> ant install

- As a default, ant tries to use build.xml located in the
  current directory. To use build file located somewhere
  else or having a different name, use -buildfile option:
  ant -buildfile <SOME_DIR>/build.xml install

- Available targets can be listed with -p option:
  ant -p

- Parameters to build files are specified before the name
  of the target, and parameters always start with "-D":
  ant -Dprefix=<SOME_DIR> configure

- If you don't want so detailed output from ant, use -q option:
  ant -q install

