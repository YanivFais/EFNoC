#!/bin/bash

# Purpose: Check that directory paths are valid
# Author:  Erno Salminen
# Date:    19.8.2011
# Usage:   1st param is the path, 2nd is a symblic name for printing
#          


if [ -d "$1" -o -f "$1" ]; then
    echo "  ok: $2"
else
    echo "  error: $2 not found!"
fi 
