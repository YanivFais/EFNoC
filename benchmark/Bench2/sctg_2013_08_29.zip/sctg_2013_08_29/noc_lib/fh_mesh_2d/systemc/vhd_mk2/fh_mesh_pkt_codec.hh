/**
 *
 * @file fh_mesh_pkt_codec.hh
 * @author Lasse Lehtonen
 *
 * @brief Foreign module declaration for fh_mesh_pkt_codec
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: mesh_2d_with_pkt_codec_top.hh 6 2011-11-23 13:57:28Z lehton87 $
 *
 */


#ifndef FH_MESH_PKT_CODEC_HH
#define FH_MESH_PKT_CODEC_HH

#include <systemc>

namespace sctg
{
namespace fh_mesh
{

   template <int data_width_g, int cmd_width_g, int agents_g, int len_width_g>
   class fh_mesh_pkt_codec : public sc_core::sc_foreign_module
   {
   public:      
      sc_core::sc_in_clk              clk_ip;
      sc_core::sc_in_clk              clk_net;
      sc_core::sc_in<sc_dt::sc_logic> rst_n;

      sc_core::sc_in<sc_dt::sc_lv<agents_g * cmd_width_g - 1 + 1> >  cmd_in;
      sc_core::sc_in<sc_dt::sc_lv<agents_g * data_width_g - 1 + 1> > data_in;
      sc_core::sc_out<sc_dt::sc_lv<agents_g - 1 + 1> >               stall_out;

      sc_core::sc_in<sc_dt::sc_lv<agents_g * len_width_g - 1 + 1> > len_in;

      sc_core::sc_out<sc_dt::sc_lv<agents_g * cmd_width_g - 1 + 1> >  cmd_out;
      sc_core::sc_out<sc_dt::sc_lv<agents_g * data_width_g - 1 + 1> > data_out;
      sc_core::sc_in<sc_dt::sc_lv<agents_g - 1 + 1> >                 stall_in;

  
      fh_mesh_pkt_codec(sc_core::sc_module_name nm, const char* hdl_name,
			int cols_g, int rows_g, int agent_ports_g,
			int addr_flit_en_g, int address_mode_g,
			int clock_mode_g, int rip_addr_g, 
			int fifo_depth_g)
	 : sc_foreign_module(nm),
	   clk_ip("clk_ip"),
	   clk_net("clk_net"),
	   rst_n("rst_n"),

	   cmd_in("cmd_in"),
	   data_in("data_in"),
	   stall_out("stall_out"),
	   len_in("len_in"),

	   cmd_out("cmd_out"),
	   data_out("data_out"),
	   stall_in("stall_in")
      {
	 this->add_parameter("data_width_g", data_width_g);
	 this->add_parameter("cmd_width_g", cmd_width_g);
	 this->add_parameter("len_width_g", len_width_g);
	 this->add_parameter("agents_g", agents_g);
	 this->add_parameter("cols_g", cols_g);
	 this->add_parameter("rows_g", rows_g);
	 this->add_parameter("agent_ports_g", agent_ports_g);
	 this->add_parameter("addr_flit_en_g", addr_flit_en_g);
	 this->add_parameter("address_mode_g", address_mode_g);
	 this->add_parameter("clock_mode_g", clock_mode_g);
	 this->add_parameter("rip_addr_g", rip_addr_g);
	 this->add_parameter("fifo_depth_g", fifo_depth_g);
	 elaborate_foreign_module(hdl_name);
      }
  
      ~fh_mesh_pkt_codec()
      {}
  
   };

}
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
