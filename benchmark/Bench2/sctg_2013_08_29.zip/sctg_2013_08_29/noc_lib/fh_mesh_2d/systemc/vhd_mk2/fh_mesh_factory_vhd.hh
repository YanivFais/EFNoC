/**
 *
 * @file fh_mesh_factory.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: noc_factory_vhd.hh 6 2011-11-23 13:57:28Z lehton87 $
 *
 */

#ifndef FH_MESH_VHD_FACTORY_HH
#define FH_MESH_VHD_FACTORY_HH


#include "vhd_mk2/fh_mesh_vhd_bfm.hh"
#include "noc_conf_if.hh"

#include <systemc>

namespace sctg
{
   namespace fh_mesh
   {

      class FhMeshFactoryVhd
      {
      public:
   
	 FhMeshFactoryVhd(sctg::NocConfIf* nocConfIf);
   
	 virtual ~FhMeshFactoryVhd();      
   
      private:
	 
	 fh_mesh_vhd_bfm<32, 2, 4, 8>* mesh_4;
	 fh_mesh_vhd_bfm<32, 2, 9, 8>* mesh_9;
	 fh_mesh_vhd_bfm<32, 2, 16, 8>* mesh_16;
	 fh_mesh_vhd_bfm<32, 2, 25, 8>* mesh_25;
	 fh_mesh_vhd_bfm<32, 2, 36, 8>* mesh_36;
	 fh_mesh_vhd_bfm<32, 2, 64, 8>* mesh_64;
	 
      };

   }
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
