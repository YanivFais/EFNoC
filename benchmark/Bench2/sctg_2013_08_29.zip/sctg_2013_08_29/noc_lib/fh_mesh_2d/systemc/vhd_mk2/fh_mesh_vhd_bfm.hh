/**
 *
 * @file ase_mesh1_vhd_bfm.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: mesh_2d_with_pkt_codec_vhd_bfm.hh 22 2012-01-02 11:44:17Z lehton87 $
 *
 */

#ifndef FH_MESH_VHD_BFM_HH
#define FH_MESH_VHD_BFM_HH

#include "vhd_mk2/fh_mesh_pkt_codec.hh"
#include "buffer_if.hh"
#include "tg_packet.hh"
#include "noc_conf_if.hh"

#include <systemc>
#include <vector>
#include <queue>
#include <iostream>
#include <stdexcept>


namespace sctg
{
namespace fh_mesh
{
   template <int data_width_g, int cmd_width_g, int agents_g, int len_width_g>
   class fh_mesh_vhd_bfm : public sc_core::sc_module
   {
   public:
  
      SC_HAS_PROCESS(fh_mesh_vhd_bfm);

      //* Constructor
      fh_mesh_vhd_bfm(sc_core::sc_module_name name,
			sctg::NocConfIf* confIf,
			int cols_g, int rows_g, int agent_ports_g,
			int addr_flit_en_g, int address_mode_g,
			int clock_mode_g, int rip_addr_g, 
			int fifo_depth_g, int ip_freq_g, int noc_freq_g)
      : sc_module(name),
	_confIf(confIf)
   {

      clk_ip = new sc_core::sc_clock("clk_ip", 
				     sc_core::sc_time(1000000000.0/ip_freq_g, sc_core::SC_NS));
      clk_noc = new sc_core::sc_clock("clk_noc", 
				      sc_core::sc_time(1000000000.0/noc_freq_g, sc_core::SC_NS));

      mesh = new fh_mesh_pkt_codec< 
      data_width_g, cmd_width_g, agents_g, len_width_g
	 >("fh_mesh_pkt_codec", "fh_mesh_pkt_codec", cols_g, rows_g, 
	   agent_ports_g, addr_flit_en_g, address_mode_g,
	   clock_mode_g, rip_addr_g, fifo_depth_g);
   
      // Bind ports      
      mesh->clk_ip(*clk_ip);
      mesh->clk_net(*clk_noc);
      mesh->rst_n(rst_n);

      mesh->cmd_in(rx_cmd);
      mesh->data_in(rx_data);      
      mesh->stall_out(rx_stall);
      mesh->len_in(rx_len);

      mesh->cmd_out(tx_cmd);
      mesh->data_out(tx_data);      
      mesh->stall_in(tx_stall);


      // Initial values
      rst_n.write(sc_dt::SC_LOGIC_0);
      rx_cmd = "0";
      rx_data = "0";
      rx_len = "0";
      tx_stall = "0";

      SC_THREAD(thread);
      
      for(int i = 0; i < agents_g; ++i)
      {
	 sc_spawn(sc_bind(&fh_mesh_vhd_bfm::sender, this, i));
	 sc_spawn(sc_bind(&fh_mesh_vhd_bfm::receiver, this, i));
      }
   
   }

      //* Destructor
      ~fh_mesh_vhd_bfm()
      {
	 delete clk_ip;
	 delete clk_noc;
	 delete mesh;
      }


      void sender(unsigned int agent)
      {   
	 wait(reset);

	 sctg::BufferInterface* buffer = _confIf->getBufferIf(agent);

	 if(!buffer) 
	 {return;}

	 tgPacket* packet = 0;

	 sc_core::sc_lv<agents_g*cmd_width_g>  rx_cmd_s;
	 sc_core::sc_lv<agents_g*data_width_g> rx_data_s;
	 sc_core::sc_lv<agents_g*len_width_g> rx_len_s;


	 while(true)
	 {
	    // Wait for packets to send
	    if(!buffer->txPacketAvailable())
	    {
	       sc_core::wait(*(buffer->txGetPacketAvailableEvent()));
	    }
	    // Read packet from buffer
	    packet = buffer->txGetPacket();
	    sc_core::wait(clk_ip->posedge_event());
	    
	    // Wait until NoC is ready	    
	    while(rx_stall.read()[agent] == sc_dt::SC_LOGIC_1)
	    { sc_core::wait(clk_ip->posedge_event()); }

// 	    if((*reinterpret_cast<int*>(packet->data)) == 25) {
//  	       std::cout << "Agent " << agent << " setting packet id "
//  			 << (*reinterpret_cast<int*>(packet->data))
//  			 << " size " << packet->size/4 << " bytes"
// 			 << " len_width_g " << len_width_g << std::endl;
// 	    }

	    // Send address
	    rx_cmd_s = rx_cmd.get_new_value();
	    rx_cmd_s.range((agent+1)*cmd_width_g-1, agent*cmd_width_g) = "01";
	    rx_cmd = rx_cmd_s;

	    rx_data_s = rx_data.get_new_value();
	    rx_data_s.range((agent+1)*data_width_g-1, agent*data_width_g)
	       = packet->address;
	    rx_data = rx_data_s;

	    rx_len_s = rx_len.get_new_value();
	    rx_len_s.range((agent+1)*len_width_g-1, agent*len_width_g)
	       = packet->size/4;
	    rx_len = rx_len_s;

	    // Send data
	    for(unsigned int i = 0; i < packet->size/4; ++i)
	    {
	       // Wait until NoC is ready
	       do { sc_core::wait(clk_ip->posedge_event()); }
	       while(rx_stall.read()[agent] == sc_dt::SC_LOGIC_1);

	       // Data word
	       rx_cmd_s = rx_cmd.get_new_value();
	       rx_cmd_s.range((agent+1)*cmd_width_g-1, agent*cmd_width_g) = 
		  "10";
	       rx_cmd = rx_cmd_s;

	       // Set data to line (packets ID)
	       rx_data_s = rx_data.get_new_value();
	       rx_data_s.range((agent+1)*data_width_g-1, agent*data_width_g)
		  = sc_dt::sc_uint<data_width_g>
		  (*reinterpret_cast<int*>(packet->data));
	       rx_data = rx_data_s;	       
	    }
	    // Wait until NoC is ready
	    do { sc_core::wait(clk_ip->posedge_event()); }
	    while(rx_stall.read()[agent] == sc_dt::SC_LOGIC_1);
	    

	    // Empty word
	    rx_cmd_s = rx_cmd.get_new_value();
	    rx_cmd_s.range((agent+1)*cmd_width_g-1, agent*cmd_width_g) = "00";
	    rx_cmd = rx_cmd_s;
	    
	    // Set data bus to zero (not necessary, for easier debugging in sim)
	    rx_data_s = rx_data.get_new_value();
	    rx_data_s.range((agent+1)*data_width_g-1, agent*data_width_g)
	       = sc_dt::sc_uint<data_width_g>(0);
	    rx_data = rx_data_s;
	    // Delete packet
	    delete [] packet->data;
	    delete packet; packet = 0;      
	 }
      }


      void receiver(unsigned int agent)
      {
	 wait(reset);

	 sc_core::sc_lv<agents_g> tx_stall_s;

	 sctg::BufferInterface* buffer = _confIf->getBufferIf(agent);
	 tgPacket* packet = 0;

	 unsigned long int prev_addr = 0;
	 unsigned int      prev_id = 0;

	 if(!buffer) 
	 {return;}

	 while(true)
	 {
	    sc_core::wait(clk_ip->posedge_event());

	    if(tx_cmd.read().range((agent+1)*cmd_width_g-1, agent*cmd_width_g) 
	       == "01")
	    {
	       /*std::cout << "Agent " << agent << " getting addr "
		 << tx_data.read().range((agent+1)*data_width_g-1, 
		 agent*data_width_g).to_string() 
		 << " at " << sc_core::sc_time_stamp() << std::endl;
	       */
	       if(packet == 0)
	       {
		  packet = new tgPacket;
		  packet->address =
		     tx_data.read().range((agent+1)*data_width_g-1, 
					  agent*data_width_g).to_ulong();
		  prev_addr = packet->address;
		  packet->size = 0;
		  packet->data = 0;
	       }
	       else
	       {
		  unsigned long int addr = tx_data.read().
		     range((agent+1)*data_width_g-1, 
			   agent*data_width_g).to_ulong();
		  prev_addr = addr;
		  
// 		  std::cout << "Agent " << agent << " got new packet "
// 			    << "without pause with addr "
// 			    << addr << " previous addr was "
// 			    << packet->address << std::endl;
		  tx_stall_s = tx_stall;
		  tx_stall_s[agent] = sc_dt::SC_LOGIC_1;
		  tx_stall = tx_stall_s;
		  // Wait until packet fits to agent's buffer
		  while(buffer->rxSpaceLeft() < packet->size)
		  {	       
		     wait(*(buffer->rxGetReadEvent()));
		  }
		  buffer->rxPutPacket(packet);
		  packet = 0;
		  tx_stall_s = tx_stall;
		  tx_stall_s[agent] = sc_dt::SC_LOGIC_0;
		  tx_stall = tx_stall_s;
		  
		  packet = new tgPacket;
		  packet->address = addr;
		  packet->size = 0;
		  packet->data = 0;

	       }

	    }
	    else if
	       (tx_cmd.read().range((agent+1)*cmd_width_g-1, agent*cmd_width_g)
		== "10")
	    {
	       /*std::cout << "Agent " << agent << " getting data "
		 << tx_data.read().range((agent+1)*data_width_g-1,
		 agent*data_width_g).to_string() 
		 << " at " << sc_core::sc_time_stamp() << std::endl;*/
	       if(packet == 0)
	       {
		  packet = new tgPacket;
		  packet->address = prev_addr;
		  packet->size = 0;
		  packet->data = new unsigned char[sizeof(unsigned int)];
		  *reinterpret_cast<unsigned int*>(packet->data) = prev_id;
	       }
	       else if(packet->size == 0)
	       {
		  packet->data = new unsigned char[sizeof(unsigned int)];
		  unsigned int data = tx_data.read().
		     range((agent+1)*data_width_g-1, agent*data_width_g).
		     to_uint();
		  		  
		  *reinterpret_cast<unsigned int*>(packet->data) = data;
		  prev_id = data;
		  
	       }
	       packet->size += data_width_g/8;
	    }	 	 
	    else
	    {
	 
	       // If we have packet put it to buffer
	       if(packet != 0 && packet->size != 0)
	       {
		  tx_stall_s = tx_stall;
		  tx_stall_s[agent] = sc_dt::SC_LOGIC_1;
		  tx_stall = tx_stall_s;
		  // Wait until packet fits to agent's buffer
		  while(buffer->rxSpaceLeft() < packet->size)
		  {	       
		     wait(*(buffer->rxGetReadEvent()));
		  }
// 		  unsigned int data = 
// 		     *reinterpret_cast<unsigned int*>(packet->data);
// 		  if(data == 25) {
// 		     std::cout << "Agent " << agent << " getting packet id "
// 			       <<  data
// 			       << " size " << packet->size
// 			       << std::endl;
//		  }

		  buffer->rxPutPacket(packet);
		  packet = 0;
		  tx_stall_s = tx_stall;
		  tx_stall_s[agent] = sc_dt::SC_LOGIC_0;
		  tx_stall = tx_stall_s;
	       }
	    }
	 }
      }

      void thread()
      {      
	 // Handles reset only
	 sc_core::wait(1, sc_core::SC_NS);
	 rst_n.write(sc_dt::SC_LOGIC_1);
	 reset.notify();
      }

   private:

      sc_core::sc_event reset;

      sctg::NocConfIf* _confIf;
 
      sc_core::sc_clock* clk_ip;
      sc_core::sc_clock* clk_noc;
      sc_core::sc_signal<sc_dt::sc_logic> rst_n;

      sc_core::sc_signal<sc_dt::sc_lv<agents_g*cmd_width_g> >  rx_cmd; 
      sc_core::sc_signal<sc_dt::sc_lv<agents_g*data_width_g> > rx_data;
      sc_core::sc_signal<sc_dt::sc_lv<agents_g*len_width_g> >  rx_len;
      sc_core::sc_signal<sc_dt::sc_lv<agents_g> >              rx_stall;

      sc_core::sc_signal<sc_dt::sc_lv<agents_g*cmd_width_g> >  tx_cmd;
      sc_core::sc_signal<sc_dt::sc_lv<agents_g*data_width_g> > tx_data;
      sc_core::sc_signal<sc_dt::sc_lv<agents_g> >              tx_stall;

      sc_dt::sc_lv<cmd_width_g>    rx_cmd_v[agents_g];   // Out
      sc_dt::sc_lv<data_width_g>   rx_data_v[agents_g];  // Out
      sc_dt::sc_logic              rx_stall_v[agents_g]; // In

      sc_dt::sc_lv<cmd_width_g>    tx_cmd_v[agents_g];   // In
      sc_dt::sc_lv<data_width_g>   tx_data_v[agents_g];  // In
      sc_dt::sc_logic              tx_stall_v[agents_g]; // Out
 
      fh_mesh_pkt_codec< 
	 data_width_g, cmd_width_g, agents_g, len_width_g
	 >* mesh;

   };

}
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
