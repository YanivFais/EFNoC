/**
 *
 * @file tlm_1_factory.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: tlm_1_factory.cc 206 2013-08-28 12:45:29Z ege $
 *
 */


#include "tlm_1_factory.hh"

#include <string>
#include <iostream>
#include <stdexcept>

namespace asebt
{
   namespace mesh_2d_sc_tlm_1
   {
      /*
       * Constructor
       */      
      Tlm1Factory::Tlm1Factory(sctg::NocConfIf* nocConfIf)
      :
	 tlmMesh_2x2_(0),
	 adapter_4_  (0),
	 tlmMesh_3x3_(0),
	 adapter_9_  (0),
	 tlmMesh_4x4_(0),
	 adapter_16_ (0),
	 tlmMesh_5x5_(0),
	 adapter_25_ (0),
	 tlmMesh_6x6_(0),
	 adapter_36_ (0),
	 tlmMesh_8x8_(0),
	 adapter_64_ (0)
      {  
	 std::string subtype = nocConfIf->getNocSubType();
	 
	 if(subtype == "2x2")
	 {
	    adapter_4_   = new sctg::SctgToOsciTlm<4, 32>("adapter", nocConfIf);
	    tlmMesh_2x2_ = new TlmMesh2D<32, 2, 2>("mesh_2d");
	    for(unsigned int i = 0; i < 4; ++i)
	    {	    
	       adapter_4_->initSockets[i].bind(tlmMesh_2x2_->targetSockets[i]);
	       tlmMesh_2x2_->initSockets[i].bind(adapter_4_->targetSockets[i]);
	    }
	 }
	 else if(subtype == "3x3")
	 {
	    adapter_9_ = new sctg::SctgToOsciTlm<9, 32>("adapter", nocConfIf);
	    tlmMesh_3x3_ = new TlmMesh2D<32, 3, 3>("mesh_2d");
	    for(unsigned int i = 0; i < 9; ++i)
	    {	    
	       adapter_9_->initSockets[i].bind(tlmMesh_3x3_->targetSockets[i]);
	       tlmMesh_3x3_->initSockets[i].bind(adapter_9_->targetSockets[i]);
	    }
	 }
	 else if(subtype == "4x4")
	 {

	    adapter_16_ = new sctg::SctgToOsciTlm<16, 32>("adapter", nocConfIf);
	    tlmMesh_4x4_ = new TlmMesh2D<32, 4, 4>("mesh_2d");
	    for(unsigned int i = 0; i < 16; ++i)
	    {	    
	       adapter_16_->initSockets[i].bind(tlmMesh_4x4_->targetSockets[i]);
	       tlmMesh_4x4_->initSockets[i].bind(adapter_16_->targetSockets[i]);
	    }
	 }
	 else if(subtype == "5x5")
	 {
	    adapter_25_ = new sctg::SctgToOsciTlm<25, 32>("adapter", nocConfIf);
	    tlmMesh_5x5_ = new TlmMesh2D<32, 5, 5>("mesh_2d");
	    for(unsigned int i = 0; i < 25; ++i)
	    {	    
	       adapter_25_->initSockets[i].bind(tlmMesh_5x5_->targetSockets[i]);
	       tlmMesh_5x5_->initSockets[i].bind(adapter_25_->targetSockets[i]);
	    }
	 }
	 else if(subtype == "6x6")
	 {
	    adapter_36_ = new sctg::SctgToOsciTlm<36, 32>("adapter", nocConfIf);
	    tlmMesh_6x6_ = new TlmMesh2D<32, 6, 6>("mesh_2d");
	    for(unsigned int i = 0; i < 36; ++i)
	    {	    
	       adapter_36_->initSockets[i].bind(tlmMesh_6x6_->targetSockets[i]);
	       tlmMesh_6x6_->initSockets[i].bind(adapter_36_->targetSockets[i]);
	    }
	 }
	 else if(subtype == "8x8")
	 {
	    adapter_64_ = new sctg::SctgToOsciTlm<64, 32>("adapter", nocConfIf);
	    tlmMesh_8x8_ = new TlmMesh2D<32, 8, 8>("mesh_2d");
	    for(unsigned int i = 0; i < 64; ++i)
	    {	    
	       adapter_64_->initSockets[i].bind(tlmMesh_8x8_->targetSockets[i]);
	       tlmMesh_8x8_->initSockets[i].bind(adapter_64_->targetSockets[i]);
	    }
	 }
	 else
	 {
	    std::ostringstream oss;
	    oss << "Tlm1Factory unknown subtype :\"" << subtype << "\"";
	    throw std::runtime_error(oss.str().c_str());
	 }

      }
      

      /*
       * Destructor
       */      
      Tlm1Factory::~Tlm1Factory()
      {
	 if(tlmMesh_2x2_) {delete tlmMesh_2x2_; tlmMesh_2x2_ = 0;}
	 if(adapter_4_)   {delete adapter_4_;   adapter_4_ = 0;}
	 if(tlmMesh_3x3_) {delete tlmMesh_3x3_; tlmMesh_3x3_ = 0;}
	 if(adapter_9_)   {delete adapter_9_;   adapter_9_ = 0;}
	 if(tlmMesh_4x4_) {delete tlmMesh_4x4_; tlmMesh_4x4_ = 0;}
	 if(adapter_16_)  {delete adapter_16_;  adapter_16_ = 0;}
	 if(tlmMesh_5x5_) {delete tlmMesh_5x5_; tlmMesh_5x5_ = 0;}
	 if(adapter_25_)  {delete adapter_25_;  adapter_25_ = 0;}
	 if(tlmMesh_6x6_) {delete tlmMesh_6x6_; tlmMesh_6x6_ = 0;}
	 if(adapter_36_)  {delete adapter_36_;  adapter_36_ = 0;}
	 if(tlmMesh_8x8_) {delete tlmMesh_8x8_; tlmMesh_8x8_ = 0;}
	 if(adapter_64_)  {delete adapter_64_;  adapter_64_ = 0;}
      }           
   }
}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:

