/**
 *
 * @file tlm_mesh_2d.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: tlm_mesh_2d.hh 206 2013-08-28 12:45:29Z ege $
 *
 * Models a 2D mesh network at transaction-level.
 *
 */

#ifndef ASEBT_TLM_MESH_2_D_HH
#define ASEBT_TLM_MESH_2_D_HH

#include "sc_tlm_1/tlm_mesh_router.hh"

#include "tlm.h"
#ifdef MTI_SYSTEMC
#include "simple_initiator_socket.h"
#include "simple_target_socket.h"
#else
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"
#endif
#include <systemc>

#include <iostream>

namespace asebt
{
   namespace mesh_2d_sc_tlm_1
   {
      
      template<unsigned int data_width_g = 32,
	       unsigned int rows_g = 2,
	       unsigned int cols_g = 2>
      class TlmMesh2D : public sc_core::sc_module
      {
      public:
	 
	 SC_HAS_PROCESS(TlmMesh2D);	 
	 
	 // Sockets: N, W, S, E, IP
	 //          0, 1, 2, 3, 4
	 tlm_utils::simple_target_socket_tagged
	 <TlmMesh2D, data_width_g> targetSockets[rows_g * cols_g]; // input terminals, PE writes data to these
	 tlm_utils::simple_initiator_socket_tagged
	 <TlmMesh2D, data_width_g> initSockets[rows_g * cols_g]; // output terminals
	 
	 /** 
	  * Constructor
	  */
	 TlmMesh2D(sc_core::sc_module_name name)
	    : sc_core::sc_module(name),
	      cycleTime_(20, sc_core::SC_NS) // 20ns = 50 MHz
	 {
	    for(unsigned int r = 0; r < rows_g; ++r)
	    {
	       for(unsigned int c = 0; c < cols_g; ++c)
	       {
		  // Data flow:
		  //
		  // pe -> adapter ---> targetSocket  -> iterm_ni_fw() -> ip_peq  -> tx_ni_thread() -> init_   ->   router
		  //                                                                               <- rou_ni_bw()      |
		  //                                                                                                   v
		  // pe <- adapter <--- initSocket <- rx_ni_thread() <- noc_peq <- noc_ni_fw() <-  target_ <- ... <- router
		  //                 oterm_ni_bw() ->
		  //
		  //		      		 		  

		  unsigned int i = r * cols_g + c; // runnning index number, 0,1,2...


				  
		  // Instantiate the tx stuff
		  targetSockets[i].register_nb_transport_fw
		     (this, &TlmMesh2D::iterm_ni_fw, i); // accept data from PEs

		  std::ostringstream oss2;
		  oss2 << "router_r" << r << "_c" << c << "ip_peq_";
		  ip_peq_[i] = new tlm_utils::peq_with_get
		     <tlm::tlm_generic_payload>(oss2.str().c_str()); // tx fifo

		  sc_spawn(sc_bind(&TlmMesh2D::tx_ni_thread, this, i)); // tx NI

		  init_[i].register_nb_transport_bw
		     (this, &TlmMesh2D::rou_ni_bw, i); 





		  // The router
		  std::ostringstream oss;
		  oss << "router_r" << r << "_c" << c;
		  routers_[i] = 
		     new TlmMeshRouter<data_width_g>
		     (oss.str().c_str(), r, c, rows_g, cols_g);

		  init_[i].bind(*(routers_[i]->targetSockets[4]));


		  // Connect the routers' W <-> E and N <-> S ports
		  // together
		  if(c > 0)
		  {
		     unsigned int t = r * cols_g + c - 1;
		     (*routers_[i]->initSockets[1]).
			bind(*routers_[t]->targetSockets[3]);
		     (*routers_[t]->initSockets[3]).
			bind(*routers_[i]->targetSockets[1]);
		  }
		  if(r > 0)
		  {
		     unsigned int t = (r-1) * cols_g + c;
		     (*routers_[i]->initSockets[0]).
			bind(*routers_[t]->targetSockets[2]);
		     (*routers_[t]->initSockets[2]).
			bind(*routers_[i]->targetSockets[0]);
		  }



		  // Instantiate the rx stuff
		  target_[i].register_nb_transport_fw
		     (this, &TlmMesh2D::noc_ni_fw, i);
		  (*(routers_[i]->initSockets[4])).bind(target_[i]);

		  sc_spawn(sc_bind(&TlmMesh2D::rx_ni_thread, this, i)); //rx NI
		  
		  oss2.str("");
		  oss2 << "router_r" << r << "_c" << c << "noc_peq_";
		  noc_peq_[i] = new tlm_utils::peq_with_get
		     <tlm::tlm_generic_payload>(oss2.str().c_str());
		  
		  initSockets[i].register_nb_transport_bw
		     (this, &TlmMesh2D::oterm_ni_bw, i);  // give data to PEs
		  

		  
	       }
	    }	 	 
	 }
	 
	 
	 //* Destructor
	 ~TlmMesh2D()
	 {
	    for(unsigned int i = 0; i < rows_g * cols_g; ++i)
	    {
	       delete routers_[i]; routers_[i] = 0;
	       delete noc_peq_[i]; noc_peq_[i] = 0;
	       delete ip_peq_[i];  ip_peq_[i]  = 0;
	    }
	 }
	 
      private:



	 /* Transmitting funcitonality */


	 /*
	  * Callback function. Gets data from targetSocket (input
	  * terminal=iterm) and puts it into payload event queue (peq)
	  * of NI.
	  */
	 tlm::tlm_sync_enum iterm_ni_fw(int id,
				       tlm::tlm_generic_payload &trans,
				       tlm::tlm_phase           &phase,
				       sc_core::sc_time         &delay)
	 {
	    // Only write command is supported
	    if(trans.get_command() != tlm::TLM_WRITE_COMMAND)
	    {
	       std::ostringstream oss;
	       oss << "TlmMesh2D::iterm_ni_fw " << id 
		   << ": only write command is supported";
	       throw std::runtime_error(oss.str().c_str());
	    }
	 
	    if(phase == tlm::BEGIN_REQ)
	    {
	       trans.acquire();
	       ip_peq_[id]->notify(trans, delay); // put data to queue and ask queue to wait
	    }
	    else if(phase == tlm::END_RESP)
	    {
	       trans.set_response_status(tlm::TLM_OK_RESPONSE);
	       return tlm::TLM_COMPLETED;
	    }
	    else
	    {
	       std::ostringstream oss;
	       oss << "TlmMesh2D::iterm_ni_fw " << id 
		   << ": got invalid PHASE";
	       throw std::runtime_error(oss.str().c_str());
	    }
	    trans.set_response_status( tlm::TLM_OK_RESPONSE );
	    return tlm::TLM_ACCEPTED;
	 }


	 
	 
	 
	 /*
	  * Models network interface (NI) at the sender side. Takes
	  * data from peq and gives it to socket "init_" which is
	  * connected to router.
	  */
	 void tx_ni_thread(unsigned int agent)
	 {
	    tlm::tlm_generic_payload* trans = 0;
	    tlm::tlm_phase            phase;
	    sc_core::sc_time          delay;
	    tlm::tlm_sync_enum        retval;
	    unsigned int              source = 0;
	    
	    //std::cout << "TlmMesh2D::ip_thread(" << agent << ")" << std::endl;	    
	    // std::ostringstream oss;
	    // oss << "at_" << agent << "_from_ip.txt";
	    // std::ofstream ofs(oss.str().c_str());
	    


	    while(true)
	    {
	       // Check for pending transactions coming from PEs
	       if((trans = ip_peq_[agent]->get_next_transaction()) == 0)
	       { 		  
		  wait(ip_peq_[agent]->get_event());
		  trans = ip_peq_[agent]->get_next_transaction();
	       }
	       
	       // ofs << "Agent " << agent << " sending data  "
	       // 	   << sc_core::sc_time_stamp().value() << std::endl;

	       phase = tlm::END_REQ;



	       // Send acknowledge to PE (=its adapter)
	       delay = cycleTime_ * 
		  ((trans->get_data_length() / trans->get_streaming_width()) + 
		     2 );
	       //std::cout << sc_core::sc_time_stamp() << " tx_ni_thread " << agent
	       //	  << " ack_delay= 2 + n/4 = " << delay << std::endl;

	       retval = targetSockets[agent]->nb_transport_bw(*trans, phase, delay);	    
	       if(retval != tlm::TLM_COMPLETED)
	       {
		  std::ostringstream oss;
		  oss << "TlmMesh2Dr::ip_thread : Not supporting responses";
		  throw std::runtime_error(oss.str().c_str());
	       }




	    
	       // Forward the transaction to routers
	       phase = tlm::BEGIN_REQ;
	       delay = cycleTime_ * 7; // Constant delay models the Network interface (NI)
	       //std::cout << sc_core::sc_time_stamp() << " tx_ni_thread " << agent << " calls fw() with delay=" 
	       //	 << delay << std::endl;
	       retval = init_[agent]->nb_transport_fw(*trans, phase, delay);
	    

	       if(retval == tlm::TLM_ACCEPTED || retval == tlm::TLM_UPDATED)
	       {
		  if(phase == tlm::BEGIN_REQ)
		  {	
		     wait(rouAckEvent_[agent]);		
		  }
		  else if(phase == tlm::END_REQ)
		  {
		     std::ostringstream oss;
		     oss << "TlmMesh2D::thread : END_REQ not supported";
		     throw std::runtime_error(oss.str().c_str());
		  }
		  else if(phase == tlm::BEGIN_RESP)
		  {
		     std::ostringstream oss;
		     oss << "TlmMesh2D::thread : BEGIN_RESP not supported";
		     throw std::runtime_error(oss.str().c_str());
		  }
		  else
		  {
		     std::ostringstream oss;
		     oss << "TlmMesh2D::thread : invalid PHASE";
		     throw std::runtime_error(oss.str().c_str());
		  }	       
	       }
	       else if(retval == tlm::TLM_COMPLETED)
	       {
		  if(delay != sc_core::SC_ZERO_TIME)
		  {
		     wait(delay);
		  }
	       }
	       else
	       {
		  std::ostringstream oss;
		  oss << "TlmMesh2D::thread : invalid SYNC_ENUM";
		  throw std::runtime_error(oss.str().c_str());
	       }

	       trans->release();

	    } // end of while(true)
	 }      


	 /**
	  * Callback function. Router (rou) acknowledges the sending
	  * NI that transmission was accepted.
	  */
	 tlm::tlm_sync_enum rou_ni_bw(int id,
					tlm::tlm_generic_payload &trans,
					tlm::tlm_phase           &phase,
					sc_core::sc_time         &delay)
	 {

	    //std::cout << sc_core::sc_time_stamp() << " rou ni bw(), " << id << ", delay=" << delay 
	    //	      << std::endl;

	    if(phase == tlm::BEGIN_REQ || phase == tlm::END_RESP)
	    {
	       std::ostringstream oss;
	       oss << "TlmMesh2D::rou_ni_bw " << id << " got wrong phase";
	       throw std::runtime_error(oss.str().c_str());
	    }

	    rouAckEvent_[id].notify(delay);
	 
	    trans.set_response_status( tlm::TLM_OK_RESPONSE );
	    return tlm::TLM_COMPLETED;
	 }




	 

	 /* Receiving functionality */


	 /*
	  * Callback function. Puts the data from router's IP output
	  * into RX peq of network interface (NI)
	  */
	 tlm::tlm_sync_enum noc_ni_fw(int id,
					tlm::tlm_generic_payload &trans,
					tlm::tlm_phase           &phase,
					sc_core::sc_time         &delay)
	 {
	    // Only write command is supported
	    if(trans.get_command() != tlm::TLM_WRITE_COMMAND)
	    {
	       std::ostringstream oss;
	       oss << "TlmMesh2D::noc_ni_fw " << id 
		   << ": only write command is supported";
	       throw std::runtime_error(oss.str().c_str());
	    }
	 
	    if(phase == tlm::BEGIN_REQ)
	    {
	       trans.acquire();
	       noc_peq_[id]->notify(trans, delay);
	    }
	    else if(phase == tlm::END_RESP)
	    {
	       trans.set_response_status(tlm::TLM_OK_RESPONSE);
	       return tlm::TLM_COMPLETED;
	    }
	    else
	    {
	       std::ostringstream oss;
	       oss << "TlmMesh2D::noc_ni_fw " << id 
		   << ": got invalid PHASE";
	       throw std::runtime_error(oss.str().c_str());
	    }
	    trans.set_response_status( tlm::TLM_OK_RESPONSE );
	    return tlm::TLM_ACCEPTED;
	 }





	 /*
	  * Models the network interface (NI) at the receiver (rx
	  * side). Gets data from rx peq and puts it into init socket
	  * (output terminal).
	  */
	 void rx_ni_thread(unsigned int agent)
	 {
	    tlm::tlm_generic_payload* trans = 0;
	    tlm::tlm_phase            phase;
	    sc_core::sc_time          delay;
	    tlm::tlm_sync_enum        retval;
	    unsigned int              source = 0;

	    //std::cout << "TlmMesh2D::noc_thread(" << agent << ")" << std::endl;
	    // std::ostringstream oss;
	    // oss << "at_" << agent << "_to_ip.txt";
	    // std::ofstream ofs(oss.str().c_str());

	    while(true)
	    {
	       // Check for pending transactions in RX peq
	       if((trans = noc_peq_[agent]->get_next_transaction()) == 0)
	       { 
		  wait(noc_peq_[agent]->get_event());
		  trans = noc_peq_[agent]->get_next_transaction();
	       }

	       // ofs << "Agent " << agent << " getting data  "
	       // 	   << sc_core::sc_time_stamp().value() << std::endl;

	       phase = tlm::END_REQ;


	       // Acknowledge
	       delay = cycleTime_ * 
		  ((trans->get_data_length() / trans->get_streaming_width() +
		    3));
	       retval = target_[agent]->nb_transport_bw(*trans, 
							phase, delay);
	    
	       if(retval != tlm::TLM_COMPLETED)
	       {
		  std::ostringstream oss;
		  oss << "TlmMesh2Dr::noc_thread : Not supporting responses";
		  throw std::runtime_error(oss.str().c_str());
	       }
	    



	       // Forward the transaction
	       phase = tlm::BEGIN_REQ;
	       delay = cycleTime_ * 
		  ((trans->get_data_length() / trans->get_streaming_width() +
		    2));	    
	       retval = initSockets[agent]->nb_transport_fw(*trans, phase, delay);
	    

	       if(retval == tlm::TLM_ACCEPTED || retval == tlm::TLM_UPDATED)
	       {
		  if(phase == tlm::BEGIN_REQ)
		  { 
		     wait(otermAckEvent_[agent]);		
		  }
		  else if(phase == tlm::END_REQ)
		  {
		     std::ostringstream oss;
		     oss << "TlmMesh2D::thread : END_REQ not supported";
		     throw std::runtime_error(oss.str().c_str());
		  }
		  else if(phase == tlm::BEGIN_RESP)
		  {
		     std::ostringstream oss;
		     oss << "TlmMesh2D::thread : BEGIN_RESP not supported";
		     throw std::runtime_error(oss.str().c_str());
		  }
		  else
		  {
		     std::ostringstream oss;
		     oss << "TlmMesh2D::thread : invalid PHASE";
		     throw std::runtime_error(oss.str().c_str());
		  }	       
	       }
	       else if(retval == tlm::TLM_COMPLETED)
	       {
		  if(delay != sc_core::SC_ZERO_TIME)
		  {
		     wait(delay);
		  }
	       }
	       else
	       {
		  std::ostringstream oss;
		  oss << "TlmMesh2D::thread : invalid SYNC_ENUM";
		  throw std::runtime_error(oss.str().c_str());
	       }

	       trans->release();

	    } // end of while(true)
	 }      



	 /*
	  * Callback function. Output terminal (oterm) acknowledges
	  * the receiving NI that data was accepted.
	  */
	 tlm::tlm_sync_enum oterm_ni_bw(int id,
				       tlm::tlm_generic_payload &trans,
				       tlm::tlm_phase           &phase,
				       sc_core::sc_time         &delay)
	 {
	    if(phase == tlm::BEGIN_REQ || phase == tlm::END_RESP)
	    {
	       std::ostringstream oss;
	       oss << "TlmMesh2D::oterm_ni_bw " << id << " got wrong phase";
	       throw std::runtime_error(oss.str().c_str());
	    }

	    otermAckEvent_[id].notify(delay);
	 
	    trans.set_response_status( tlm::TLM_OK_RESPONSE );
	    return tlm::TLM_COMPLETED;
	 }




	 /* Member variables */
	 sc_core::sc_time cycleTime_;

	 // Send functionality
	 tlm_utils::simple_initiator_socket_tagged
	 <TlmMesh2D, data_width_g> init_[rows_g * cols_g];	 
	 tlm_utils::peq_with_get<tlm::tlm_generic_payload>* 
	 ip_peq_[rows_g * cols_g]; // between tx NI and router, ip writes to this
	 sc_core::sc_event rouAckEvent_[rows_g * cols_g]; // router has acknowledged tx


	 TlmMeshRouter<data_width_g>* routers_[rows_g * cols_g];
	 
	 // Receiving functionality
	 tlm_utils::simple_target_socket_tagged
	 <TlmMesh2D, data_width_g> target_[rows_g * cols_g];
	 tlm_utils::peq_with_get<tlm::tlm_generic_payload>* 
	 noc_peq_[rows_g * cols_g]; // between router and rx NI, noc writes to this
	 sc_core::sc_event otermAckEvent_[rows_g * cols_g]; //output terminal has acknowledged rx


      };

   }
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:

