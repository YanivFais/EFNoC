/**
 *
 * @file tlm_1_factory.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: tlm_1_factory.hh 6 2011-11-23 13:57:28Z lehton87 $
 *
 */

#ifndef MESH_2D_SC_TLM_1_FACTORY_HH
#define MESH_2D_SC_TLM_1_FACTORY_HH

#include "sctg_to_osci_tlm.hh"
#include "sc_tlm_1/tlm_mesh_2d.hh"
#include "noc_conf_if.hh"

#include <systemc>

namespace asebt
{
   namespace mesh_2d_sc_tlm_1
   {
      
      class Tlm1Factory
      {
      public:
	 
	 Tlm1Factory(sctg::NocConfIf* nocConfIf);
	 
	 virtual ~Tlm1Factory();
	 
      private:
	 
	 TlmMesh2D<32, 2, 2>*        tlmMesh_2x2_;
	 sctg::SctgToOsciTlm<4, 32>* adapter_4_;

	 TlmMesh2D<32, 3, 3>*        tlmMesh_3x3_;
	 sctg::SctgToOsciTlm<9, 32>* adapter_9_;

	 TlmMesh2D<32, 4, 4>*         tlmMesh_4x4_;
	 sctg::SctgToOsciTlm<16, 32>* adapter_16_;
	 
	 TlmMesh2D<32, 5, 5>*         tlmMesh_5x5_;
	 sctg::SctgToOsciTlm<25, 32>* adapter_25_;

	 TlmMesh2D<32, 6, 6>*         tlmMesh_6x6_;
	 sctg::SctgToOsciTlm<36, 32>* adapter_36_;

	 TlmMesh2D<32, 8, 8>*         tlmMesh_8x8_;
	 sctg::SctgToOsciTlm<64, 32>* adapter_64_;
	 
      };
      
   }
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:
