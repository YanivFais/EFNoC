/**
 *
 * @file tlm_mesh_router.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: tlm_mesh_router.hh 206 2013-08-28 12:45:29Z ege $
 *
 */

#ifndef ASEBT_TLM_MESH_ROUTER_HH
#define ASEBT_TLM_MESH_ROUTER_HH

#include "tlm.h"
#ifdef MTI_SYSTEMC
#include "simple_initiator_socket.h"
#include "simple_target_socket.h"
#include "peq_with_get.h"
#else
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"
#include "tlm_utils/peq_with_get.h"
#endif

#include <systemc>
#include <stdexcept>
#include <iostream>

namespace asebt
{
   namespace mesh_2d_sc_tlm_1
   {

      template<unsigned int data_width_g = 32>
      class TlmMeshRouter : public sc_core::sc_module
      {
      public:
      
	 SC_HAS_PROCESS(TlmMeshRouter);
      
	 // Sockets: N, W, S, E, IP
	 tlm_utils::simple_target_socket_tagged<TlmMeshRouter,
						data_width_g>* targetSockets[5];
	 tlm_utils::simple_initiator_socket_tagged<TlmMeshRouter,
						   data_width_g>* initSockets[5];

	 //* Constructor
	 TlmMeshRouter(sc_core::sc_module_name name,
		       unsigned int row,
		       unsigned int col,
		       unsigned int n_rows,
		       unsigned int n_cols)
	    : sc_module(name),
	      row_(row),
	      col_(col),
	      cycleTime_(20, sc_core::SC_NS),
	      n_cols_(n_cols)
	 {


	    // Instantiate a queue (=FIFO) for each src-dst port pair
	    for(unsigned int d = 0; d < 5; ++d)
	    {
	       for(unsigned int s = 0; s < 5; ++s)
	       {
		  std::ostringstream oss;
		  oss << "tlm_router_peq_" << d << "_" << s;
		  peq_[d][s] = 
		     new tlm_utils::peq_with_get<tlm::tlm_generic_payload>
		     (oss.str().c_str());
	       }
	    }



	    // Create ports = sockets. Inports are targets because PE
	    // writes to them. Outport are initiators.

	    // Create first the ports for the PE
	    targetSockets[4] = new tlm_utils::simple_target_socket_tagged
	       <TlmMeshRouter, data_width_g>;
	    initSockets[4] = new tlm_utils::simple_initiator_socket_tagged
	       <TlmMeshRouter, data_width_g>;


	    // Create other ports but network boundaries do not need
	    // all of them
	    if(row != 0)
	    {
	       initSockets[0] = new tlm_utils::simple_initiator_socket_tagged
		  <TlmMeshRouter, data_width_g>;
	       targetSockets[0] = new tlm_utils::simple_target_socket_tagged
		  <TlmMeshRouter, data_width_g>;
	    }
	    else
	    {
	       initSockets[0] = 0;
	       targetSockets[0] = 0;
	    }
	    
	    if(row != (n_rows - 1))
	    {
	       initSockets[2] = new tlm_utils::simple_initiator_socket_tagged
		  <TlmMeshRouter, data_width_g>;
	       targetSockets[2] = new tlm_utils::simple_target_socket_tagged
		  <TlmMeshRouter, data_width_g>;
	    }
	    else
	    {
	       initSockets[2] = 0;
	       targetSockets[2] = 0;
	    }
	    
	    if(col != 0)
	    {
	       initSockets[1] = new tlm_utils::simple_initiator_socket_tagged
		  <TlmMeshRouter, data_width_g>;
	       targetSockets[1] = new tlm_utils::simple_target_socket_tagged
		  <TlmMeshRouter, data_width_g>;
	    }
	    else
	    {
	       initSockets[1] = 0;
	       targetSockets[1] = 0;
	    }

	    if(col != (n_cols - 1))
	    {
	       initSockets[3] = new tlm_utils::simple_initiator_socket_tagged
		  <TlmMeshRouter, data_width_g>;
	       targetSockets[3] = new tlm_utils::simple_target_socket_tagged
		  <TlmMeshRouter, data_width_g>;
	    }
	    else
	    {
	       initSockets[3] = 0;
	       targetSockets[3] = 0;
	    }


	    // Register callback functions to sockets. Launch a thread
	    // for each outport.
	    for(unsigned int i = 0; i < 5; ++i)
	    {
	       if(initSockets[i])
	       {
		  targetSockets[i]->register_nb_transport_fw
		     (this, &TlmMeshRouter::nb_transport_fw, i);
		  initSockets[i]->register_nb_transport_bw
		     (this, &TlmMeshRouter::nb_transport_bw, i);
		  sc_spawn(sc_bind(&TlmMeshRouter::thread, this, i));
	       }
	    }
	 }
      
	 //* Destructor
	 ~TlmMeshRouter()
	 {
	    for(unsigned int i = 0; i < 5; ++i)
	    {
	       if(initSockets[i]) {delete initSockets[i]; initSockets[i] = 0;}
	       if(targetSockets[i]) {delete targetSockets[i]; targetSockets[i] = 0;}

	       for(unsigned int j = 0; j < 5; ++j)
	       {
		  delete peq_[i][j]; peq_[i][j] = 0;
	       }
	    }
	 }
      


	 /*
	  * Main functionality. Gets data from FIFO and forwards it to
	  * outport 'dir'.
	  */
	 void thread(unsigned int dir)
	 {
	    tlm::tlm_generic_payload* trans = 0;
	    tlm::tlm_phase            phase;
	    sc_core::sc_time          delay;
	    tlm::tlm_sync_enum        retval;
	    unsigned int              source = 0;

	    // std::ostringstream oss;
	    // oss << "at_" << row_ << "_" << col_ << "_"
	    // 	<< dir << "_router.txt";
	    // std::ofstream ofs(oss.str().c_str());

	    while(true)
	    {
	       // Check for pending transactions
	       for(unsigned int i = 0; i < 5; ++i)
	       {
		  if((trans = peq_[dir][i]->get_next_transaction()) != 0)
		  { //std::cout << sc_core::sc_time_stamp() << " thr ("<< row_ << "," << col_ 
		     //	      << ") " << dir << " got next transcact from " << i << std::endl;
		     source = i; break; }
	       }

	       if(trans == 0)
	       {
		  // Wait for transactions going towards 'dir'
		  //std::cout << sc_core::sc_time_stamp() << " thr ("<< row_ << "," << col_ 
		  //	    << ") " << dir << " wait peq_event" << std::endl;
		  wait(peq_[dir][0]->get_event() |
		       peq_[dir][1]->get_event() |
		       peq_[dir][2]->get_event() |
		       peq_[dir][3]->get_event() |
		       peq_[dir][4]->get_event());
		  continue; // jump back to beginning of while(true)
	       }


	       //std::cout << sc_core::sc_time_stamp() << " thr ("<< row_ << "," << col_ << ") " << dir << " proceeds" << std::endl;




	       // Send acknowledge
	       if(source == 4)
	       {
		  // 2013-08-26 (ES): why is ip-outport path faster than others???
		  delay = sc_core::SC_ZERO_TIME;
	       }
	       else
	       {
		  delay = cycleTime_ * 
		     ((trans->get_data_length() / trans->get_streaming_width())
		      + 3); // pkt latency = hdr latency + data copying
	       }

	       phase = tlm::END_REQ;
	       //std::cout << sc_core::sc_time_stamp() << " thr ("<< row_ << "," << col_ << ") " << dir << "  sends ack" << source << "->bw() with delay" << delay << std::endl;
	       retval = (*targetSockets[source])->nb_transport_bw(*trans, phase, delay);
	    
	       if(retval != tlm::TLM_COMPLETED)
	       {
		  std::ostringstream oss;
		  oss << "TlmMeshRouter::thread : Not supporting responses";
		  throw std::runtime_error(oss.str().c_str());
	       }
	    


	       // Forward the transaction to router's outport (=init socket)	       
	       phase = tlm::BEGIN_REQ;
	       delay = cycleTime_ * 3;	// header latency    
	       //std::cout << sc_core::sc_time_stamp() << " thr ("<< row_ << "," << col_ << ") " << dir << "  calls fw() with delay= " << delay << std::endl;
	       retval = (*initSockets[dir])->nb_transport_fw(*trans, phase, delay);
	    


	       if(retval == tlm::TLM_ACCEPTED || retval == tlm::TLM_UPDATED)
	       {
		  if(phase == tlm::BEGIN_REQ)
		  {		  
		     wait(txCompleteEvent_[dir]);		
		  }
		  else if(phase == tlm::END_REQ)
		  {
		     std::ostringstream oss;
		     oss << "TlmMeshRouter::thread : END_REQ not supported";
		     throw std::runtime_error(oss.str().c_str());
		  }
		  else if(phase == tlm::BEGIN_RESP)
		  {
		     std::ostringstream oss;
		     oss << "TlmMeshRouter::thread : BEGIN_RESP not supported";
		     throw std::runtime_error(oss.str().c_str());
		  }
		  else
		  {
		     std::ostringstream oss;
		     oss << "TlmMeshRouter::thread : invalid PHASE";
		     throw std::runtime_error(oss.str().c_str());
		  }	       
	       }
	       else if(retval == tlm::TLM_COMPLETED)
	       {
		  if(delay != sc_core::SC_ZERO_TIME)
		  {
		     wait(delay);
		  }
	       }
	       else
	       {
		  std::ostringstream oss;
		  oss << "TlmMeshRouter::thread : invalid SYNC_ENUM";
		  throw std::runtime_error(oss.str().c_str());
	       }	       
	    	    
	       trans->release();

	       //wait(cycleTime_ * 1);

	    } // end of while(true)
	 }      



      private:


	 /*
	  * Puts incoming data into payload event queue (=FIFO)
	  */
	 tlm::tlm_sync_enum nb_transport_fw(int id,
					    tlm::tlm_generic_payload &trans,
					    tlm::tlm_phase           &phase,
					    sc_core::sc_time         &delay)
	 {

	    //std::cout << sc_core::sc_time_stamp() << " fw() ("<< row_ << "," << col_ 
	    //	      << ") "  << id << " " << phase << ", del " << delay << std::endl;

	    // Check the command
	    if(trans.get_command() != tlm::TLM_WRITE_COMMAND)
	    {
	       std::ostringstream oss;
	       oss << "TlmMeshRouter::nb_tranport_fw " << id 
		   << ": only write command is supported";
	       throw std::runtime_error(oss.str().c_str());
	    }
	 

	    // Two phases of transfer
	    if(phase == tlm::BEGIN_REQ)
	    {
	       trans.acquire();
	       unsigned int destination = yx_routing(trans.get_address());
	       peq_[destination][id]->notify(trans, delay); // put data to queue
	       //_receiveEvent[destination].notify(delay);
	    }
	    else if(phase == tlm::END_RESP)
	    {
	       trans.set_response_status(tlm::TLM_OK_RESPONSE);
	       return tlm::TLM_COMPLETED;
	    }
	    else
	    {
	       std::ostringstream oss;
	       oss << "TlmMeshRouter::nb_tranport_fw " << id 
		   << ": got invalid PHASE";
	       throw std::runtime_error(oss.str().c_str());
	    }

	    trans.set_response_status( tlm::TLM_OK_RESPONSE );
	    return tlm::TLM_ACCEPTED;
	 }


	 /*
	  * Acknowledge that data was received
	  */
	 tlm::tlm_sync_enum nb_transport_bw(int id,
					    tlm::tlm_generic_payload &trans,
					    tlm::tlm_phase           &phase,
					    sc_core::sc_time         &delay)
	 {

	    //std::cout << sc_core::sc_time_stamp() << " bw() ("<< row_ << "," << col_ << ") "  << id << " "  << phase << ", del " << delay << std::endl;

	    if(phase == tlm::BEGIN_REQ || phase == tlm::END_RESP)
	    {
	       std::ostringstream oss;
	       oss << "TlmMeshRouter::nb_tranport_bw " << id << " got wrong phase";
	       throw std::runtime_error(oss.str().c_str());
	    }

	    txCompleteEvent_[id].notify(delay);
	 
	    trans.set_response_status( tlm::TLM_OK_RESPONSE );
	    return tlm::TLM_COMPLETED;
	 }





	 /*
	  * Route the packet. i.e. decide which outport it is
	  * heading. Simple deterministic, algorithmic dimension-order
	  * routing. Guarantees in-order delivery for packets.
	  */
	 unsigned int yx_routing(unsigned long int addr)
	 {
	    unsigned long int rowPart = addr / n_cols_;
	    unsigned long int colPart = addr - row_*n_cols_;

	    if(row_ == rowPart && col_ == colPart)
	    {
	       return 4; // IP
	    }
	    else if(row_ < rowPart)
	    {
	       return 2; // S
	    }
	    else if(row_ > rowPart)
	    {
	       return 0; // N
	    }
	    else if(col_ < colPart)
	    {
	       return 3; // E
	    }
	    else
	    {
	       return 1; // W
	    }
	 }


	 // Member variables
	 sc_core::sc_time cycleTime_;
	 unsigned int row_;
	 unsigned int col_;
	 int n_cols_;

	 sc_core::sc_event txCompleteEvent_[5];
	 tlm_utils::peq_with_get<tlm::tlm_generic_payload>* peq_[5][5];

      };

   }
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:

