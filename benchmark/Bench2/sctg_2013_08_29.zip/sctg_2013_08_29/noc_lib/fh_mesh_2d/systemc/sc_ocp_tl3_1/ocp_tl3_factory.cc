/**
 *
 * @file ocp_tl3_factory.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: ocp_tl3_factory.cc 208 2013-08-29 12:40:20Z ege $
 *
 */


#include "ocp_tl3_factory.hh"

#include <string>
#include <iostream>
#include <stdexcept>

namespace sctg
{
   namespace mesh_2d_sc_ocp_tl3_1
   {
      
      OcpTl3Factory::OcpTl3Factory(sctg::NocConfIf* nocConfIf)
      {  
	 std::string subtype = nocConfIf->getNocSubType();
	 if(subtype == "2x2")
	 {
	    adapter_4_ = new sctg::SctgToOcpTl3<4, 32>("adapter", nocConfIf);
	    mesh_2x2_  = new OcpTl3Mesh2D<32, 2, 2, 20>("mesh");	    
	    for(unsigned int i = 0; i < 4; ++i)
	    {
	       (adapter_4_->masterSocket)->bind(*(mesh_2x2_->slaveSocket[i]));
	       (mesh_2x2_->masterSocket[i])->bind(*(adapter_4_->slaveSocket));
	    }
	 }
	 else if(subtype == "4x4")
	 {
	    adapter_16_ = new sctg::SctgToOcpTl3<16, 32>("adapter", nocConfIf);
	    mesh_4x4_  = new OcpTl3Mesh2D<32, 4, 4, 20>("mesh");
	    for(unsigned int i = 0; i < 16; ++i)
	    {
	       (adapter_16_->masterSocket)->bind(*(mesh_4x4_->slaveSocket[i]));
	       (mesh_4x4_->masterSocket[i])->bind(*(adapter_16_->slaveSocket));
	    }
	 }
	 else if(subtype == "6x6")
	 {
	    adapter_36_ = new sctg::SctgToOcpTl3<36, 32>("adapter", nocConfIf);
	    mesh_6x6_  = new OcpTl3Mesh2D<32, 6, 6, 20>("mesh");
	    for(unsigned int i = 0; i < 36; ++i)
	    {
	       (adapter_36_->masterSocket)->bind(*(mesh_6x6_->slaveSocket[i]));
	       (mesh_6x6_->masterSocket[i])->bind(*(adapter_36_->slaveSocket));
	    }
	 }
	 else if(subtype == "8x8")
	 {
	    adapter_64_ = new sctg::SctgToOcpTl3<64, 32>("adapter", nocConfIf);
	    mesh_8x8_  = new OcpTl3Mesh2D<32, 8, 8, 20>("mesh");
	    for(unsigned int i = 0; i < 64; ++i)
	    {
	       (adapter_64_->masterSocket)->bind(*(mesh_8x8_->slaveSocket[i]));
	       (mesh_8x8_->masterSocket[i])->bind(*(adapter_64_->slaveSocket));
	    }
	 }
	 else
	 {
	    std::ostringstream oss;
	    oss << "OcpTl3Factory unknown subtype :\"" << subtype << "\"";
	    throw std::runtime_error(oss.str().c_str());
	 }
      }
      
      OcpTl3Factory::~OcpTl3Factory()
      {
	 std::cout << "OcpTl3Factory destructor" << std::endl;
      }           
   }
}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:

