/**
 *
 * @file ocp_tl3_mesh_router.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: ocp_tl3_mesh_router.hh 208 2013-08-29 12:40:20Z ege $
 *
 */

#ifndef SCTG_OCPTL3_MESH_ROUTER_HH
#define SCTG_OCPTL3_MESH_ROUTER_HH


#include <tlm.h>
#include <ocpip.h>

#ifdef MTI_SYSTEMC
#include "peq_with_get.h"
#else
#include "tlm_utils/peq_with_get.h"
#endif

#include <systemc>
#include <stdexcept>
#include <iostream>
#include <queue>

namespace sctg
{
   namespace mesh_2d_sc_ocp_tl3_1
   {
      
      template<unsigned int data_width_g>
      class OcpTl3MeshRouter : public sc_core::sc_module
      {
      public:
	 
	 SC_HAS_PROCESS(OcpTl3MeshRouter);

	 // Interface sockets: N, W, S, E, IP
	 ocpip::ocp_slave_socket_tl3<data_width_g, 1>*  slaveSocket[5];  // inports
	 ocpip::ocp_master_socket_tl3<data_width_g, 1>* masterSocket[5]; // outports

	 
	 //* Constructor
	 OcpTl3MeshRouter(sc_core::sc_module_name name,
			  unsigned int row,
			  unsigned int col,
			  unsigned int n_rows,
			  unsigned int n_cols_g,
			  sc_core::sc_time cycleLength)
	    : sc_module(name),
	      row_(row),
	      col_(col),
	      cycleLength_(cycleLength),
	      n_cols_(n_cols_g)
	 {

	    // OCP-IP parameters
	    ocpParameters_.byteen = false;

	    for(unsigned int d = 0; d < 5; ++d)
	    {
	       for(unsigned int s = 0; s < 5; ++s)
	       {
		  std::ostringstream oss;
		  oss << "tlm_router_peq_" << d << "_" << s;
		  peq_[d][s] = 
		     new tlm_utils::peq_with_get<tlm::tlm_generic_payload>
		     (oss.str().c_str());
	       }
	    }

	    // Create IP side sockets
	    std::ostringstream oss;
	    oss << "router_" << row_ << "_" << col_ << "_ip_master_socket";
	    masterSocket[4] = new ocpip::ocp_master_socket_tl3<data_width_g, 1>
	       (oss.str().c_str(), 
		ocpip::ocp_master_socket_tl3<data_width_g, 1>::mm_txn_with_data());
	    
	    oss.str("");
	    oss << "router_" << row_ << "_" << col_ << "_ip_slave_socket";
	    slaveSocket[4] = new ocpip::ocp_slave_socket_tl3<data_width_g, 1>
	       (oss.str().c_str());

	    masterSocket[4]->set_ocp_config(ocpParameters_);
	    slaveSocket[4]->set_ocp_config(ocpParameters_);


	    // Create North sockets, for other than top-row routers
	    if(row_ != 0)
	    {
	       oss.str("");
	       oss << "router_" << row_ << "_" << col_ << "_n_master_socket";
	       masterSocket[0] = 
		  new ocpip::ocp_master_socket_tl3<data_width_g, 1>
		  (oss.str().c_str(), 
		   ocpip::ocp_master_socket_tl3<data_width_g, 1>::mm_txn_with_data());

	       oss.str("");
	       oss << "router_" << row_ << "_" << col_ << "_n_slave_socket";
	       slaveSocket[0]  = 
		  new ocpip::ocp_slave_socket_tl3<data_width_g, 1>
		  (oss.str().c_str());

	       masterSocket[0]->set_ocp_config(ocpParameters_);
	       slaveSocket[0]->set_ocp_config(ocpParameters_);
	    }
	    else
	    {
	       masterSocket[0] = 0;
	       slaveSocket[0]  = 0;
	    }


	    // Create South sockets
	    if(row_ != (n_rows - 1))
	    {
	       oss.str("");
	       oss << "router_" << row_ << "_" << col_ << "_w_master_socket";
	       masterSocket[2] = 
		  new ocpip::ocp_master_socket_tl3<data_width_g, 1>
		  (oss.str().c_str(), 
		   ocpip::ocp_master_socket_tl3<data_width_g, 1>::mm_txn_with_data());
	       oss.str("");
	       oss << "router_" << row_ << "_" << col_ << "_w_slave_socket";
	       slaveSocket[2]  = 
		  new ocpip::ocp_slave_socket_tl3<data_width_g, 1>
		  (oss.str().c_str());
	       masterSocket[2]->set_ocp_config(ocpParameters_);
	       slaveSocket[2]->set_ocp_config(ocpParameters_);
	    }
	    else
	    {
	       masterSocket[2] = 0;
	       slaveSocket[2]  = 0;
	    }


	    // Create West sockets
	    if(col_ != 0)
	    {
	       oss.str("");
	       oss << "router_" << row_ << "_" << col_ << "_s_master_socket";
	       masterSocket[1] = 
		  new ocpip::ocp_master_socket_tl3<data_width_g, 1>
		  (oss.str().c_str(), 
		   ocpip::ocp_master_socket_tl3<data_width_g, 1>::mm_txn_with_data());
	       oss.str("");
	       oss << "router_" << row_ << "_" << col_ << "_s_slave_socket";
	       slaveSocket[1]  = 
		  new ocpip::ocp_slave_socket_tl3<data_width_g, 1>
		  (oss.str().c_str());
	       masterSocket[1]->set_ocp_config(ocpParameters_);
	       slaveSocket[1]->set_ocp_config(ocpParameters_);
	    }
	    else
	    {
	       masterSocket[1] = 0;
	       slaveSocket[1]  = 0;
	    }


	    // Create East sockets
	    if(col_ != (n_cols_g - 1))
	    {
	       oss.str("");
	       oss << "router_" << row_ << "_" << col_ << "_e_master_socket";
	       masterSocket[3] = 
		  new ocpip::ocp_master_socket_tl3<data_width_g, 1>
		  (oss.str().c_str(), 
		   ocpip::ocp_master_socket_tl3<data_width_g, 1>::mm_txn_with_data());
	       oss.str("");
	       oss << "router_" << row_ << "_" << col_ << "_e_slave_socket";
	       slaveSocket[3]  = 
		  new ocpip::ocp_slave_socket_tl3<data_width_g, 1>
		  (oss.str().c_str());
	       masterSocket[3]->set_ocp_config(ocpParameters_);
	       slaveSocket[3]->set_ocp_config(ocpParameters_);
	    }
	    else
	    {
	       masterSocket[3] = 0;
	       slaveSocket[3]  = 0;
	    }

	    
	    // Bind callbacks and spawn a thread for outgoing links (masters)	   	    
	    if(masterSocket[0])
	    {
	       masterSocket[0]->register_nb_transport_bw
		  (this, &OcpTl3MeshRouter::nb_transport_bw_0, false);
	       slaveSocket[0]->register_nb_transport_fw
		  (this, &OcpTl3MeshRouter::nb_transport_fw_0, false);
	       sc_spawn(sc_bind(&OcpTl3MeshRouter::thread, this, 0));
	    }
	    if(masterSocket[1])
	    {
	       masterSocket[1]->register_nb_transport_bw
		  (this, &OcpTl3MeshRouter::nb_transport_bw_1, false);
	       slaveSocket[1]->register_nb_transport_fw
		  (this, &OcpTl3MeshRouter::nb_transport_fw_1, false);
	       sc_spawn(sc_bind(&OcpTl3MeshRouter::thread, this, 1));
	    }
	    if(masterSocket[2])
	    {
	       masterSocket[2]->register_nb_transport_bw
		  (this, &OcpTl3MeshRouter::nb_transport_bw_2, false);
	       slaveSocket[2]->register_nb_transport_fw
		  (this, &OcpTl3MeshRouter::nb_transport_fw_2, false);
	       sc_spawn(sc_bind(&OcpTl3MeshRouter::thread, this, 2));
	    }
	    if(masterSocket[3])
	    {
	       masterSocket[3]->register_nb_transport_bw
		  (this, &OcpTl3MeshRouter::nb_transport_bw_3, false);
	       slaveSocket[3]->register_nb_transport_fw
		  (this, &OcpTl3MeshRouter::nb_transport_fw_3, false);
	       sc_spawn(sc_bind(&OcpTl3MeshRouter::thread, this, 3));
	    }
	    if(masterSocket[4])
	    {
	       masterSocket[4]->register_nb_transport_bw
		  (this, &OcpTl3MeshRouter::nb_transport_bw_4, false);
	       slaveSocket[4]->register_nb_transport_fw
		  (this, &OcpTl3MeshRouter::nb_transport_fw_4, false);
	       sc_spawn(sc_bind(&OcpTl3MeshRouter::thread, this, 4));
	    }
	    

	    // Configure Sockets	    

	    for(unsigned int i = 0; i < 5; ++i)
	    {
	       if(slaveSocket[i]) 
	       {slaveSocket[i]->set_ocp_config(ocpParameters_);}
	       if(masterSocket[i]) 
	       {masterSocket[i]->set_ocp_config(ocpParameters_);}
	    }
	 }


	 //* Destructor
	 ~OcpTl3MeshRouter()
	 {
	    // Free sockets
	    for(unsigned int i = 0; i < 5; ++i)
	    {
	       if(slaveSocket[i]) 
	       {delete slaveSocket[i]; slaveSocket[i] = 0;}
	       if(masterSocket[i]) 
	       {delete masterSocket[i]; masterSocket[i] = 0;}
	    }
	 }

      private:



	 /*
	  * Main functionality. Gets data from FIFO (=peq) and
	  * forwards it to outport 'dir'.
	  */
	 void thread(unsigned int dir)
	 {
	    tlm::tlm_generic_payload* trans = 0;
	    tlm::tlm_phase            phase;
	    sc_core::sc_time          delay;
	    tlm::tlm_sync_enum        retval;
	    unsigned int              source = 0;

	    while(true)
	    {
	       // Check for pending transactions
	       for(unsigned int i = 0; i < 5; ++i)
	       {
		  if((trans = peq_[dir][i]->get_next_transaction()) != 0)
		  {
		     source = i;
		     break;
		  }
	       }

	       if(trans == 0)
	       {
		  // Wait for transaction
		  wait(peq_[dir][0]->get_event() |
		       peq_[dir][1]->get_event() |
		       peq_[dir][2]->get_event() |
		       peq_[dir][3]->get_event() |
		       peq_[dir][4]->get_event());
		  continue; // Jump back to the beginning of while(true)
	       }

	       //std::cout << sc_core::sc_time_stamp() << " thr ("<< row_ << "," << col_ << ") " << dir << " proceeds" << std::endl;

	       // Calculate delay
	       phase = tlm::BEGIN_RESP; //orig


	       if(source == 4)
	       {
		  delay = sc_core::SC_ZERO_TIME;
	       }
	       else
	       {
		  delay = cycleLength_ * 
		     ((trans->get_data_length() / trans->get_streaming_width())
		      + 3);
	       }
	       std::cout << sc_core::sc_time_stamp() << " thr ("<< row_ << "," << col_ << ") " << dir << "  sends ack " << source << "->bw() with delay" << delay << std::endl;
	       


	       // Guess the completion time
	       retval = (*slaveSocket[source])->nb_transport_bw(*trans, 
								phase, 
								delay);

	       if(retval != tlm::TLM_COMPLETED)
	       {
		  std::ostringstream oss;
		  oss << sc_core::sc_time_stamp() << " OcpTl3MeshRouter::thread : No support for responses but got" << retval;
		  throw std::runtime_error(oss.str().c_str());
	       }



	       // Forward transaction
	       phase = tlm::BEGIN_REQ;
	       delay = cycleLength_ * 3;

	       //std::cout << sc_core::sc_time_stamp() << " thr ("<< row_ << "," << col_ << ") " << dir << "  calls fw() with delay= " << delay << std::endl;
	       retval = (*masterSocket[dir])->
		  nb_transport_fw(*trans, phase, delay);

	       if(retval == tlm::TLM_ACCEPTED || retval == tlm::TLM_UPDATED)
	       {
		  if(phase == tlm::BEGIN_REQ)
		  {		  
		     wait(txCompleteEvent_[dir]);		
		  }
		  else if(phase == tlm::END_REQ)
		  {
		     std::ostringstream oss;
		     oss << "OcpTlm3MeshRouter::thread : END_REQ not supported";
		     throw std::runtime_error(oss.str().c_str());
		  }
		  else if(phase == tlm::BEGIN_RESP)
		  {
		     std::ostringstream oss;
		     oss << "OcpTlm3MeshRouter::thread : BEGIN_RESP"
			 << " not supported";
		     throw std::runtime_error(oss.str().c_str());
		  }
		  else
		  {
		     std::ostringstream oss;
		     oss << "OcpTlm3MeshRouter::thread : invalid PHASE";
		     throw std::runtime_error(oss.str().c_str());
		  }	       
	       }
	       else if(retval == tlm::TLM_COMPLETED)
	       {
		  if(delay != sc_core::SC_ZERO_TIME)
		  {
		     wait(delay);
		  }
	       }
	       else
	       {
		  std::ostringstream oss;
		  oss << "OcpTl3MeshRouter::thread : invalid SYNC_ENUM";
		  throw std::runtime_error(oss.str().c_str());
	       }	       
	    	    
	       trans->release();


	    } // End of while(true)

	 }

	 

	 /*
	  * Puts incoming data into payload event queue (=FIFO)
	  */
	 tlm::tlm_sync_enum nb_transport_fw(int id,
					    tlm::tlm_generic_payload &trans,
					    tlm::tlm_phase           &phase,
					    sc_core::sc_time         &delay)
	 {

	    //std::cout << sc_core::sc_time_stamp() << " fw() ("<< row_ << "," << col_ 
	    //	      << ") "  << id << " " << phase << ", del " << delay << std::endl;

	    // Sanity check. Only write command is supported
	    if(trans.get_command() != tlm::TLM_WRITE_COMMAND)
	    {
	       std::ostringstream oss;
	       oss << "OcpTl3MeshRouter::nb_tranport_fw " << id 
		   << ": only write command is supported";
	       throw std::runtime_error(oss.str().c_str());
	    }
	 
	    // Model only two phases
	    if(phase == tlm::BEGIN_REQ)
	    {
	       trans.acquire();
	       unsigned int destination = yx_routing(trans.get_address());
	       peq_[destination][id]->notify(trans, delay);	       
	    }
	    else if(phase == tlm::END_RESP)
	    {
	       trans.set_response_status(tlm::TLM_OK_RESPONSE);
	       return tlm::TLM_COMPLETED;
	    }
	    else
	    {
	       std::ostringstream oss;
	       oss << "OcpTl3MeshRouter::nb_tranport_fw " << id 
		   << ": got invalid PHASE";
	       throw std::runtime_error(oss.str().c_str());
	    }

	    trans.set_response_status( tlm::TLM_OK_RESPONSE );
	    return tlm::TLM_ACCEPTED;
	 }



	 /*
	  * Acknowledge that data was received
	  */	 
	 tlm::tlm_sync_enum nb_transport_bw(int id,
					    tlm::tlm_generic_payload &trans,
					    tlm::tlm_phase           &phase,
					    sc_core::sc_time         &delay)
	 {


	    if(phase == tlm::BEGIN_REQ || phase == tlm::END_RESP)
	    {
	       std::ostringstream oss;
	       oss << "OcpTl3MeshRouter::nb_tranport_bw " << id 
		   << " got wrong phase";
	       throw std::runtime_error(oss.str().c_str());
	    }

	    txCompleteEvent_[id].notify(delay);
	 
	    trans.set_response_status( tlm::TLM_OK_RESPONSE );
	    return tlm::TLM_COMPLETED;
	 }



	 /** Callback for each direction. Just call the common
	  * callback function with rigth parameter value. */
	 tlm::tlm_sync_enum nb_transport_bw_0(tlm::tlm_generic_payload &trans,
					      tlm::tlm_phase           &phase,
					      sc_core::sc_time         &delay)
	 {
	    return nb_transport_bw(0, trans, phase, delay);
	 }

	 tlm::tlm_sync_enum nb_transport_fw_0(tlm::tlm_generic_payload &trans,
					      tlm::tlm_phase           &phase,
					      sc_core::sc_time         &delay)
	 {
	    return nb_transport_fw(0, trans, phase, delay);
	 }

	 tlm::tlm_sync_enum nb_transport_bw_1(tlm::tlm_generic_payload &trans,
					      tlm::tlm_phase           &phase,
					      sc_core::sc_time         &delay)
	 {
	    return nb_transport_bw(1, trans, phase, delay);
	 }

	 tlm::tlm_sync_enum nb_transport_fw_1(tlm::tlm_generic_payload &trans,
					      tlm::tlm_phase           &phase,
					      sc_core::sc_time         &delay)
	 {
	    return nb_transport_fw(1, trans, phase, delay);
	 }

	 tlm::tlm_sync_enum nb_transport_bw_2(tlm::tlm_generic_payload &trans,
					      tlm::tlm_phase           &phase,
					      sc_core::sc_time         &delay)
	 {
	    return nb_transport_bw(2, trans, phase, delay);
	 }

	 tlm::tlm_sync_enum nb_transport_fw_2(tlm::tlm_generic_payload &trans,
					      tlm::tlm_phase           &phase,
					      sc_core::sc_time         &delay)
	 {
	    return nb_transport_fw(2, trans, phase, delay);
	 }

	 tlm::tlm_sync_enum nb_transport_bw_3(tlm::tlm_generic_payload &trans,
					      tlm::tlm_phase           &phase,
					      sc_core::sc_time         &delay)
	 {
	    return nb_transport_bw(3, trans, phase, delay);
	 }

	 tlm::tlm_sync_enum nb_transport_fw_3(tlm::tlm_generic_payload &trans,
					      tlm::tlm_phase           &phase,
					      sc_core::sc_time         &delay)
	 {
	    return nb_transport_fw(3, trans, phase, delay);
	 }

	 tlm::tlm_sync_enum nb_transport_bw_4(tlm::tlm_generic_payload &trans,
					      tlm::tlm_phase           &phase,
					      sc_core::sc_time         &delay)
	 {
	    return nb_transport_bw(4, trans, phase, delay);
	 }

	 tlm::tlm_sync_enum nb_transport_fw_4(tlm::tlm_generic_payload &trans,
					      tlm::tlm_phase           &phase,
					      sc_core::sc_time         &delay)
	 {
	    return nb_transport_fw(4, trans, phase, delay);
	 }




	 /*
	  * Route the packet. i.e. decide which outport it is
	  * heading. Simple deterministic, algorithmic dimension-order
	  * routing. Guarantees in-order delivery for packets.
	  */
	 unsigned int yx_routing(unsigned long int addr)
	 {
	    unsigned long int rowPart = addr / n_cols_;
	    unsigned long int colPart = addr - row_ * n_cols_;

	    if(row_ == rowPart && col_ == colPart)
	    {
	       return 4; // IP
	    }
	    else if(row_ < rowPart)
	    {
	       return 2; // S
	    }
	    else if(row_ > rowPart)
	    {
	       return 0; // N
	    }
	    else if(col_ < colPart)
	    {
	       return 3; // E
	    }
	    else
	    {
	       return 1; // W
	    }
	 }
	 
	 unsigned int row_;
	 unsigned int col_;
	 int n_cols_;
	 sc_core::sc_time cycleLength_;
	 ocpip::ocp_parameters ocpParameters_;

	 // Queues for all dst-src pairs
	 tlm_utils::peq_with_get<tlm::tlm_generic_payload>* peq_[5][5];
	 sc_core::sc_event                     txCompleteEvent_[5];
      };
	 
   }
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:

