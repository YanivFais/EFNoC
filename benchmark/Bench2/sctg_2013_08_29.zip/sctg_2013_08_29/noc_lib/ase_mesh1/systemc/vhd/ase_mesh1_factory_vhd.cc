/**
 *
 * @file ase_mesh1_factory_vhd.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: noc_factory_vhd.cc 6 2011-11-23 13:57:28Z lehton87 $
 *
 */


#include "noc_factory.hh"

#include <string>
#include <stdexcept>
#include <iostream>

namespace sctg
{
   static int findGeneric(std::map<std::string, int>& m,
			  const std::string& s, 
			  int def)
   {
      if(m.find(s) != m.end())
      {
	 std::cout << "Generic " << s << " set to value " << m[s] << std::endl;
	 return m[s];
      }
      else
      {
	 std::cout << "Generic " << s 
		   << " set to default value " << def << std::endl;
	 return def;
      }
   }

   namespace ase_mesh1
   {

      AseMesh1FactoryVhd::AseMesh1FactoryVhd(sctg::NocConfIf* nocConfIf)
	 : mesh_4(0),
	   mesh_9(0),
	   mesh_16(0),
	   mesh_25(0),
	   mesh_36(0),
	   mesh_64(0)
      {
	 std::string subtype = nocConfIf->getNocSubType();
	 std::map<std::string, int> nodes = nocConfIf->getGenerics();

	 int cols_g = findGeneric(nodes, "cols_g", 1);
	 int rows_g = findGeneric(nodes, "rows_g", 1);
	 int agent_ports_g = findGeneric(nodes, "agent_ports_g", 1);
	 int addr_flit_en_g = findGeneric(nodes, "addr_flit_en_g", 0);
	 int address_mode_g = findGeneric(nodes, "address_mode_g", 1);
	 int clock_mode_g = findGeneric(nodes, "clock_mode_g", 1);
	 int rip_addr_g = findGeneric(nodes, "rip_addr_g", 0);
	 int ni_fifo_depth_g = findGeneric(nodes, "ni_fifo_depth_g", 4);
	 int link_fifo_depth_g = findGeneric(nodes, "link_fifo_depth_g", 0);
	 int ip_freq_g = findGeneric(nodes, "ip_freq_g", 50000000);
	 int noc_freq_g = findGeneric(nodes, "noc_freq_g", 50000000);
	 
	 if(subtype == "4")
	 {
	    mesh_4 = new ase_mesh1_vhd_bfm<32, 2, 4>
	       ("ase_mesh1", nocConfIf, cols_g, rows_g, agent_ports_g,
		addr_flit_en_g, address_mode_g, clock_mode_g, rip_addr_g,
		ni_fifo_depth_g, link_fifo_depth_g, ip_freq_g, noc_freq_g);
	 }
	 else if(subtype == "9")
	 {
	    mesh_9 = new ase_mesh1_vhd_bfm<32, 2, 9>
	       ("ase_mesh1", nocConfIf, cols_g, rows_g, agent_ports_g,
		addr_flit_en_g, address_mode_g, clock_mode_g, rip_addr_g,
		ni_fifo_depth_g, link_fifo_depth_g, ip_freq_g, noc_freq_g);
	 }
	 else if(subtype == "16")
	 {
	    mesh_16 = new ase_mesh1_vhd_bfm<32, 2, 16>
	       ("ase_mesh1", nocConfIf, cols_g, rows_g, agent_ports_g,
		addr_flit_en_g, address_mode_g, clock_mode_g, rip_addr_g,
		ni_fifo_depth_g, link_fifo_depth_g, ip_freq_g, noc_freq_g);
	 }
	 else if(subtype == "25")
	 {
	    mesh_25 = new ase_mesh1_vhd_bfm<32, 2, 25>
	       ("ase_mesh1", nocConfIf, cols_g, rows_g, agent_ports_g,
		addr_flit_en_g, address_mode_g, clock_mode_g, rip_addr_g,
		ni_fifo_depth_g, link_fifo_depth_g, ip_freq_g, noc_freq_g);
	 }
	 else if(subtype == "36")
	 {
	    mesh_36 = new ase_mesh1_vhd_bfm<32, 2, 36>
	       ("ase_mesh1", nocConfIf, cols_g, rows_g, agent_ports_g,
		addr_flit_en_g, address_mode_g, clock_mode_g, rip_addr_g,
		ni_fifo_depth_g, link_fifo_depth_g, ip_freq_g, noc_freq_g);
	 }
	 else if(subtype == "64")
	 {
	    mesh_64 = new ase_mesh1_vhd_bfm<32, 2, 64>
	       ("ase_mesh1", nocConfIf, cols_g, rows_g, agent_ports_g,
		addr_flit_en_g, address_mode_g, clock_mode_g, rip_addr_g,
		ni_fifo_depth_g, link_fifo_depth_g, ip_freq_g, noc_freq_g);
	 }
	 else
	 {
	    std::ostringstream oss;
	    oss << "AseMeshFactory (VHDL) unsupported subtype \""
		<< subtype << "\"";
	    throw std::runtime_error(oss.str().c_str());
	 }      
      }

      AseMesh1FactoryVhd::~AseMesh1FactoryVhd()
      {
      }


   }
}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:

