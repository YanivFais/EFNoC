/**
 *
 * @file noc_factory.cc
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: noc_factory.cc 28 2012-04-11 07:06:34Z lehton87 $
 *
 */


#include "noc_factory.hh"

#include <systemc>

#include <iostream>
#include <stdexcept>
#include <string>

NocFactory::NocFactory(sctg::NocConfIf* nocConfIf)
   : 
   ase_mesh1_factory_(0),
   mesh_factory_(0),
   sbus_factory_(0),
   crossbar_factory_(0),
   ring_factory_(0)
{
   std::string nocClass = nocConfIf->getNocClass();

   std::cout << "NocFactory class: " << nocClass << std::endl;

   if(nocClass == "mesh_2d")
   {
      mesh_factory_ = new asebt::MeshFactory(nocConfIf);
   }
   else if(nocClass == "ase_mesh1")
   {
      ase_mesh1_factory_ = new sctg::AseMesh1Factory(nocConfIf);
   }
   else if(nocClass == "crossbar")
   {
      crossbar_factory_ = new sctg::CrossbarFactory(nocConfIf);
   }
   else if(nocClass == "ring")
   {
      ring_factory_ = new sctg::RingFactory(nocConfIf);
   }
   else if(nocClass == "simple_bus")
   {
      sbus_factory_ = new asebt::SBusFactory(nocConfIf);
   }
   else
   {
      std::ostringstream oss;
      oss << "NocFactory: NoC with class \"" << nocClass 
	  << "\" not found";
      throw std::runtime_error(oss.str().c_str());
   }
}

NocFactory::~NocFactory()
{
}





// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:

