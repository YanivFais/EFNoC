/**
 *
 * @file sctg_to_osci_tlm.hh
 * @author Lasse Lehtonen
 *
 *
 */

/*
 * Copyright 2010 Tampere University of Technology
 * 
 *  This file is part of Transaction Generator.
 *
 *  Transaction Generator is free software: you can redistribute it and/or modify
 *  it under the terms of the Lesser GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Transaction Generator is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  Lesser GNU General Public License for more details.
 *
 *  You should have received a copy of the Lesser GNU General Public License
 *  along with Transaction Generator.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * $Id: sctg_to_osci_tlm.hh 206 2013-08-28 12:45:29Z ege $
 *
 */

#ifndef SCTG_TO_OSCI_TLM_HH
#define SCTG_TO_OSCI_TLM_HH

#include "noc_conf_if.hh"
#include "buffer_if.hh"
#include "tg_packet.hh"

#include "tlm.h"
#ifdef MTI_SYSTEMC
#include "simple_initiator_socket.h"
#include "simple_target_socket.h"
#include "peq_with_get.h"
#else
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"
#include "tlm_utils/peq_with_get.h"
#endif
#include <systemc>

#include <stdexcept>
#include <iostream>


/**
 * Adapter is placed between TG's buffer and NoC modeled at
 * transaction level (TLM).
 */

namespace sctg
{
   template<unsigned int N_AGENTS,
	    unsigned int DATA_WIDTH>
   class SctgToOsciTlm : public sc_core::sc_module, public tlm::tlm_mm_interface
   {
   public:

      SC_HAS_PROCESS(SctgToOsciTlm);
      
      tlm_utils::simple_initiator_socket_tagged
      <SctgToOsciTlm, DATA_WIDTH> initSockets[N_AGENTS];
      tlm_utils::simple_target_socket_tagged
      <SctgToOsciTlm, DATA_WIDTH> targetSockets[N_AGENTS];      

      void free(tlm::tlm_generic_payload* pl)
      {
	 delete pl;
      }

      //* Constructor
      SctgToOsciTlm(sc_core::sc_module_name name,
		    sctg::NocConfIf* confIf)
	 : sc_module(name),
	   confIf_(confIf),
	   cycleTime_(20, sc_core::SC_NS) // 20ns = 50 MHZ
      {

	 std::cout << "sctgToOsciTlm";
	 peqLen =0;

	 // Generating 2 sockets and 2 threads for every agent and 1
	 // peq per agent
	 for(unsigned int i = 0; i < N_AGENTS; ++i)
	 {

	    // Send
	    std::ostringstream oss;
	    oss << "rxPeq_" << i;
	    sc_spawn(sc_bind(&SctgToOsciTlm::senderThread, this, i));
	    initSockets[i].register_nb_transport_bw
	       (this, &SctgToOsciTlm::nb_transport_bw, i);


	    // Receive
	    targetSockets[i].register_nb_transport_fw
	       (this, &SctgToOsciTlm::nb_transport_fw, i);
	    rxPeq_[i] = new tlm_utils::peq_with_get<tlm::tlm_generic_payload>
	       (oss.str().c_str());
	    sc_spawn(sc_bind(&SctgToOsciTlm::receiveThread, this, i));
	    
	 }
      }

      //* Destructor
      ~SctgToOsciTlm()
      {
	 for(unsigned int i = 0; i < N_AGENTS; ++i)
	 {	    
	    delete rxPeq_[i]; rxPeq_[i] = 0;
	 }
      }

   private:

      // Disable operator= and copy constructor
      SctgToOsciTlm& operator=(const SctgToOsciTlm& rhs);
      SctgToOsciTlm(const SctgToOsciTlm& rhs);


      // Sending side

      /**
       * Get data from PE's buffer and send it to NoC via initSocket
       */
      void senderThread(unsigned int agent)
      {
	 
	 // Get pointer to buffer between IP -> NoC
	 sctg::BufferInterface* buffer = confIf_->getBufferIf(agent);

	 // If buffer doesn't point anywhere there is no agent with this ID
	 if(!buffer)
	 { return; }



	 // The struct we get from TG
	 tgPacket* packet = 0;

	 // std::ostringstream oss;
	 // oss << "at" << agent << "_sender.txt";
	 // std::ofstream ofs(oss.str().c_str());

	 // TLM structures we're sending to NoC
	 tlm::tlm_generic_payload* trans = 0;
	 tlm::tlm_phase            phase;
	 sc_core::sc_time          delay;

	 tlm::tlm_sync_enum        retval;
	 	 	 

	 while(true)
	 {

	    // Wait for packets to send
	    if(!buffer->txPacketAvailable())
	    {	       
	       sc_core::wait(*(buffer->txGetPacketAvailableEvent()));
	    }
	    	    
	    // Read one packet from buffer
	    packet = buffer->txGetPacket();
	    	    
	    //ofs << "Agent " << agent << " got packet  "
	    //std::cout << sc_core::sc_time_stamp() << " Osci-adapter " << agent << " got "
	    //	      << packet->size << " B pkt" << std::endl;

	    // Initialize generic payload
	    trans = new tlm::tlm_generic_payload;
	    trans->set_command(tlm::TLM_WRITE_COMMAND);
	    trans->set_data_length(packet->size);
	    trans->set_byte_enable_ptr(0);
	    trans->set_streaming_width(DATA_WIDTH / 8);
	    trans->set_mm(this);
	    trans->set_address(packet->address); 	    
	    trans->set_data_ptr(packet->data); 
	    trans->set_dmi_allowed(false);	    
	    trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
	    phase = tlm::BEGIN_REQ;
	    delay = sc_core::SC_ZERO_TIME;




	    // Send packet to NoC
	    trans->acquire();
	    retval = initSockets[agent]->nb_transport_fw(*trans, phase, delay);
	    
	    // Check for errors
	    if(trans->is_response_error())
	    {
	       std::ostringstream oss;
	       oss << "SenderThread " << agent << " got error response: "
		   << trans->get_response_string().c_str();
	       throw std::runtime_error(oss.str().c_str());
	    }

	    if(retval == tlm::TLM_COMPLETED)
	    {
	       //std::cout << sc_core::sc_time_stamp() << " ADAPTER::SenderThread " << agent << " got TLM_COMPLETED, wait" << delay << std::endl;
	       if(delay != sc_core::SC_ZERO_TIME)
	       {
		  wait(delay);
	       }
	    }
	    else if(retval == tlm::TLM_UPDATED || retval == tlm::TLM_ACCEPTED)
	    {
	       if(phase == tlm::BEGIN_REQ)
	       {
		  // Wait for END_REQ or BEGIN_RESP
		  //std::cout << sc_core::sc_time_stamp() << " ADAPTER::SenderThread " << agent << " waiting for END_REQ or BEGIN_RESP"  << std::endl;
		  wait(txAckEvent_[agent]);
		  //std::cout << sc_core::sc_time_stamp() << " ADAPTER::SenderThread " << agent << " txAckEvent"  << std::endl;


	       }
	       else if(phase == tlm::END_REQ)
	       {
		  // BEGIN_RESP will come via backward path
		  //std::cout <<  sc_core::sc_time_stamp() << " ADAPTER::SenderThread " << agent << " in END_REQ, wait" << delay << std::endl;
		  
		  if(delay != sc_core::SC_ZERO_TIME)
		  {
		     wait(delay);
		  }		  
		  wait(txAckEvent_[agent]);

	       }
	       else if(phase == tlm::BEGIN_RESP)
	       {
		  //std::cout <<  sc_core::sc_time_stamp() << " ADAPTER::SenderThread " << agent << " in BEGIN_RESP, wait" << delay << std::endl;
		  if(delay != sc_core::SC_ZERO_TIME)
		  {
		     wait(delay);
		  }
		  
		  //std::cout <<  sc_core::sc_time_stamp() << " ADAPTER::SenderThread " << agent << " sending END_RESP" << std::endl;

		  // Send END_RESP immediately
		  trans->set_dmi_allowed(false);
		  trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE);
		  phase = tlm::END_RESP;
		  delay = sc_core::SC_ZERO_TIME;
		  retval = initSockets[agent]->nb_transport_fw(*trans, phase, delay);

		  // Check for errors
		  if(trans->is_response_error())
		  {
		     std::ostringstream oss;
		     oss << "SctgToOsciTlm::SenderThread " << agent << " got error response: "
			 << trans->get_response_string().c_str();
		     throw std::runtime_error(oss.str().c_str());
		  }

		  // Transaction completed
		  
	       }
	       else
	       {
		  std::ostringstream oss;
		  oss << "SctgToOsciTlm::SenderThread " << agent << " got invalid TLM_UPDATED";
		  throw std::runtime_error(oss.str().c_str());
	       }

	    }
	    
	    trans->release();

	    // ofs << "Agent " << agent << " sent packet "
	    // 	<< sc_core::sc_time_stamp().value() << std::endl;

	    // Free memory used by the packet
	    packet->data = 0;
	    delete   packet;       packet       = 0;

	 } // End of while(true)

      }


      /**
       * Callback function. Acknowledge that data was accepted into NoC
       */
      tlm::tlm_sync_enum nb_transport_bw(int id,
					 tlm::tlm_generic_payload &trans,
					 tlm::tlm_phase           &phase,
					 sc_core::sc_time         &delay)
      {

	 //std::cout << "adapter::nb_transport_bw " << id << " called" << std::endl;

	 if(phase == tlm::BEGIN_REQ || phase == tlm::END_RESP)
	 {
	    std::ostringstream oss;
	    oss << "nb_tranport_bw " << id << " got wrong phase";
	    throw std::runtime_error(oss.str().c_str());
	 }
	 
	 txAckEvent_[id].notify(delay);
	 
	 trans.set_response_status( tlm::TLM_OK_RESPONSE );
	 return tlm::TLM_COMPLETED;
      }




      // Receiving side

      /**
       * Callback function. Puts the data arriving from NoC into peq
       */
      tlm::tlm_sync_enum nb_transport_fw(int id,
					 tlm::tlm_generic_payload &trans,
					 tlm::tlm_phase           &phase,
					 sc_core::sc_time         &delay)
      {
	 //std::cout << sc_core::sc_time_stamp() << " adapter::nb_transport_fw " << id << " got data from NoC, delay= " << delay << std::endl;

	 // Only write command is supported
	 if(trans.get_command() != tlm::TLM_WRITE_COMMAND)
	 {
	    std::ostringstream oss;
	    oss << "SctgToOsciTlm::nb_tranport_fw " << id 
		<< ": only write command is supported";
	    throw std::runtime_error(oss.str().c_str());
	 }
	 
	 if(phase == tlm::BEGIN_REQ)
	 {
	    trans.acquire();
	    rxPeq_[id]->notify(trans, delay);

	    peqLen++;
	    if (peqLen>10) std::cout << "peq[" << id << "]: " << peqLen << std::endl;

	 }
	 
	 trans.set_response_status( tlm::TLM_OK_RESPONSE );
	 return tlm::TLM_ACCEPTED;
      }
      

      /**
       * Gets data from rx peq and puts it into TG's PE's buffer
       */
      void receiveThread(unsigned int agent)
      {	 
	 // Get pointer to buffer between NoC -> IP
	 sctg::BufferInterface* buffer = confIf_->getBufferIf(agent);

	 tlm::tlm_generic_payload* trans;
	 tlm::tlm_phase            phase = tlm::END_REQ;
	 sc_core::sc_time          delay = sc_core::SC_ZERO_TIME;

	 tlm::tlm_sync_enum        retval;

	 tgPacket* packet = 0;
	 
	 // If buffer doesn't point anywhere there is no agent with this ID
	 if(!buffer)
	 { return; }

	 
	 while(true)
	 {

	    // Wait for data to arrive at queue
	    if((trans = rxPeq_[agent]->get_next_transaction()) == 0)
	    {	       
	       wait(rxPeq_[agent]->get_event());
	       trans = rxPeq_[agent]->get_next_transaction();
	    peqLen--;

	    }	    


	    // Create a TG packet
	    packet = new tgPacket;
	    packet->address = trans->get_address();
	    packet->size    = trans->get_data_length();
	    packet->data    = trans->get_data_ptr();
	    unsigned int id = *(reinterpret_cast<unsigned int*>(packet->data));      

	    //unsigned int flits = 
	    //   trans->get_data_length() / trans->get_streaming_width();



	    /* std::cout << sc_core::sc_time_stamp() << " ADAPTER::ReceiveThread " << agent 
		      << " got packet, size= " << packet->size
		      << ",toke n id= " << id
		      << std::dec << std::endl;
	    */



	    // Sanity check, bufSize=0 means 'infinite' buffer
	    if (buffer->rxBufSize() > 0
	       && buffer->rxBufSize() < packet->size) {
	       std::ostringstream oss;
	       oss << "Adapter (osci tlm): Deadlock at " << sc_core::sc_time_stamp()
		   << ". Rx buf " << agent << " is too small for a PE-PE pkt: " 
		   << buffer->rxBufSize() << " B < " 
		   << packet->size << " B. "
		   << std::endl;
	       std::cout << oss.str() << std::endl; // print also because Modelsim which does not support expections
	       throw std::runtime_error(oss.str().c_str());
	    }
	    

	    // Wait until PE has space to receive packet and put packet there
	    while(buffer->rxSpaceLeft() < packet->size)
	    {
	       wait(*(buffer->rxGetReadEvent()));
	    }	    
	    buffer->rxPutPacket(packet);
	    packet = 0; // buffer handles freeing memory


	    // Send acknowledge of reception to NoC (or its NI)
	    phase = tlm::END_REQ;
	    delay = sc_core::SC_ZERO_TIME;

	    trans->set_response_status( tlm::TLM_OK_RESPONSE );
	    retval = targetSockets[agent]->nb_transport_bw(*trans, phase, delay);
	    trans->release();

	    // Assuming it returns TLM_COMPLETED as we are not using responces
	    if(retval != tlm::TLM_COMPLETED)
	    {
	       std::ostringstream oss;
	       oss << "SctgToOsciTlm::receiveThread " << agent
		   << ": was expecting TLM_COMPLETE";
	       throw std::runtime_error(oss.str().c_str());
	    }

	 } // End of while(true)

	 
      }


      // Member variables
      sc_core::sc_time cycleTime_; // obsolete??
      sctg::NocConfIf* confIf_;   // Reach the PE buffers via configuration object

      sc_core::sc_event txAckEvent_[N_AGENTS]; // NoC accepted the data      
      tlm_utils::peq_with_get<tlm::tlm_generic_payload>* rxPeq_[N_AGENTS];

      int peqLen;


   };
}

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 3
// End:

