Traffic model set from MCSL Benchmark Suite v1.1.  

Get the original packet including a traffic loader library and a
manual from: http://www.ece.ust.hk/~eexu/index_files/benchmark.htm
