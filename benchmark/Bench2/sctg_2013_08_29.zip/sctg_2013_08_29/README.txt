Project Transaction Generator 2
 - A SystemC simulation tool for simulating SoC and benchmarking 
   network-on-chip designs

The project is distributed under the terms of the Lesser GPL license. 
Please refer to COPYING and COPYING.LESSER for details.


Read Transaction Generator 2 Usage documentation for install and usage
information in directory doc/

Other related info on The Nocbench project webpage
http://www.tkt.cs.tut.fi/research/nocbench

To compile, edit the paths in Makefile and execute "make".  You can
check your path definitions with "make check_dir"

Testrun the first simple simulation "./sctg.exe -i
examples/test_mesh.xml"


The project was originally implemented at Tampere University of
Technology, in 2010-2012. (TG1 was developed also in TUT around
2000-2005).



Contact information:

  Tampere University of Technology
  Department of Computer Systems
  --
  Erno Salminen, ege@cs.tut.fi
