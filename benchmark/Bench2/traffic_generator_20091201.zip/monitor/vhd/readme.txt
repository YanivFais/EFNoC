This is NOCBENCH NoC monitor, currently supporting at least monitoring for
MESH, RING, HIBI and CROSSBAR networks provided by us.

Monitor can be used seamlessly with NocBench Traffic Generator or as itself.

Communicates with the host PC via RS232 UART using a simple text-based system.

Usage:

Use monitor_top for mesh and ring
Use monitor_top_for_hibi for HIBI
Use monitor_top_for_xbar for crossbar

Connect signals to NoC signals as instructed

The 2-bit command bus works like this:
00: Normal operation (monitor)
01: Stall counters
10: Reset counters
11: Give report to UART

Report can also asked by typing r to UART from the host PC. This way, monitoring is active during reporting.

See ../doc/NOCBENCH_monitors.pdf for further information.
