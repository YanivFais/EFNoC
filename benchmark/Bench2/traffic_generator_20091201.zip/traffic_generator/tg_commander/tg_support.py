# supporting functions and constants

# Copyright (c) 2009 by Tampere University of Technology


# This file is part of Traffic generator.

# Traffic generator is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as
# published by the Free Software Foundation, either version 3 of
# the License, or (at your option) any later version.

# Traffic generator is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public
# License along with Traffic generator.
# If not, see <http://www.gnu.org/licenses/>.



import sys


# Should we print out debug messages?
DEBUG = False

# Some much used prints
INVALID_CMD = "Invalid command, try again."
INVALID_NUM = "Invalid number, try again."

# how many hex numbers each config value is
ADDR_W       = 2
WAITING_W    = 4
DATATYPE_W   = 1
LENGTH_W     = 4
PROCESSING_W = 4
RUNTIME_W    = 8
DEP_FLAG_W   = 1

# the amount of newlines to clear the screen
CLEAR_NEWLINES = 100
def clear():
    for i in range(0, CLEAR_NEWLINES):
        print

def enable_debug():
    global DEBUG
    DEBUG = True

def error(msg):
    print "\n** Error: " + msg + "\n"

def warning(msg):
    print "\n** Warning: " + msg + "\n"

def debug(msg):
    if DEBUG:
        sys.stdout.write(msg)
