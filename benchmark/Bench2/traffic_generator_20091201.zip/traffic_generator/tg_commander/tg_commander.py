# TRAFFIC GENERATOR COMMANDER
# Jussi Nieminen, 2009
# Program to configure tg:s on chip and to read their reports


# Copyright (c) 2009 by Tampere University of Technology


# This file is part of Traffic generator.

# Traffic generator is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as
# published by the Free Software Foundation, either version 3 of
# the License, or (at your option) any later version.

# Traffic generator is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public
# License along with Traffic generator.
# If not, see <http://www.gnu.org/licenses/>.


import sys
import getopt
import serial
import os.path
import re
import time
from tg_config_data import *
from tg_support import *


# constants:
PORT_NUM  = 0
BAUD_RATE = 19200
BYTE_SIZE = 8
STOP_BITS = 2
RTSCTS    = 0
PARITY    = 'N'
TIMEOUT   = 1


# When reading from port, read until this has been received.
# After getting the prompt, we are clear to write.
UART_CMD_PROMPT = '> '


def xtra_spaces(text, column_width):
    # returns enough spaces to fill a column
    spaces = ''
    # -1 in the range because we want to have one space also on the other
    # side of the text
    for n in range(0, column_width - len(text) - 1):
        spaces += ' '
        
    return spaces

def instructions():
    help = """\
    Parameters:
    -h or --help              : print this help
    -f or --file <filename>   : configure device with selected file
    -d or --debug             : print debug messages
    -p or --port <number>     : define other port number than 0
    -o or --output <filename> : format and print output data from file
    no parameters             : start in an interactive mode"""

    print help





#****************************************************************************


class uart_comm:
    """A class taking care of uart communication using pyserial module."""

    def __init__(self, port_number = 0):
        self.open_serial_port(port_number)
        
    def open_serial_port(self, port_number = 0):
        self.port = serial.Serial(port_number, baudrate=BAUD_RATE, bytesize=BYTE_SIZE, stopbits=STOP_BITS, rtscts=RTSCTS, parity=PARITY, timeout = TIMEOUT)

    def read_prompt(self, not_first):
        # read until command prompt pops out
        # don't worry about timeouts while waiting for the first line
        # (reset switch has just not been released)
        msg = ''
        while not UART_CMD_PROMPT in msg:
            char = self.port.read()

            # don't print, if this is the first one (because we want to print the
            # "Configuring device" text before this
            if not_first:
                debug(char)
                sys.stdout.flush()
            if char == '' and not_first:
                msg = ''
                break
            msg += str(char)
            
        return msg

    def read_amount(self, amount):
        # read given number of chars
        msg = self.port.read(amount)
        return msg

    def read_all_lines(self):
        msg = []
        while msg == []:
            msg = self.port.readlines()
        return msg

    def write_str(self, to_wr, read_echo = True):
        response = ''
        if read_echo:
            for char in to_wr:
                self.port.write(char)
                resp = self.port.read()
                debug(resp)
                sys.stdout.flush()
                response += resp
                if resp == '':
                    response = ''
                    break
        else:
            self.port.write(to_wr)

        return response

    def close(self):
        self.port.close()


# *****************************************************************


class main_operation:

    def __init__(self, argv):

        # get the command line parameters
        try:
            opts, args = getopt.getopt(argv, 'hf:dp:o:', ["help", "file=", "debug", "port=", "output="])
        except getopt.GetoptError:
            instructions()
            sys.exit(2)

        # commands contains commands that are sent to device
        self.commands = []
        self.filename = None
        self.conf_data = tg_data()

        if len(args) > 0:
            trash = ''.join(args)
            warning("extra command line arguments dicarded: \n%s" %(trash))

        run_intep = False
        filename = ''
        # print help if needed, or select appropriate running mode
        if len(opts) > 0:
            for opt, arg in opts:
                if opt in ("-h", "--help"):
                    instructions()
                    sys.exit(0)
                elif opt in ("-f", "--file"):
                    filename = arg
                    run_intep = True
                elif opt in ("-d", "--debug"):
                    enable_debug()
                elif opt in ('-p', "--port"):
                    global PORT_NUM
                    PORT_NUM = int(arg)
                elif opt in ('-o', '--output'):
                    self.print_output_from_file(arg)
                    sys.exit(0)

        try:
            self.ser = uart_comm(PORT_NUM)
            if run_intep:
                self.run_intependent(filename)
            else:
                self.run_interactive()
        except KeyboardInterrupt:
            print "\nKeyboard interrupt received, exiting.\n"
            self.ser.close()
            sys.exit(1)

        # done
        self.ser.close()
        sys.exit(0)

    def run_interactive(self):

        clear()
        while True:
            self.print_start_message()

            # decide what to do
            cmd = raw_input('> ')
            cmds = cmd.split(' ')

            # some space, except if quitting
            if cmds[0] != 'q':
                clear()
        
            if cmds[0] == 'o' and len(cmds) == 2:
                self.parse_input_file(cmds[1])
            elif cmds[0] == 'n':
                self.create_new_file()
            elif cmds[0] == 'r':
                self.write_commands_to_port()
                self.read_results()
            elif cmds[0] == 'e':
                self.edit_file()
            elif cmds[0] == 'g':
                self.conf_data.make_graph()
            elif cmds[0] == 'h':
                instructions()
            elif cmds[0] == 'q':
                break
            else:
                print INVALID_CMD


    def run_intependent(self, input_file):
        # try to configurate device with input file given as a command line parameter
        if not self.parse_input_file(input_file):
            sys.exit(1)

        self.write_commands_to_port()
        self.read_results()

            
    def parse_input_file(self, input_file):
        # read the input file and store it's contents in correct format
        
        if not os.path.exists(input_file):
            error("Input file %s doesn't exist" %(input_file))
            return False

        try:
            inputfile = open(input_file, 'r')
        except IOError:
            error("Input file not readable")
            return False

        self.filename = input_file
        self.conf_data = tg_data()

        # track the line number for error messages
        line_num = 0
        last_comment = ''

        filecomment = ''
        filecomment_read = False
        # go trough all the lines in input file
        for line in inputfile:

            line_num += 1
            # discard empty lines (though there really shouldn't be any)
            if len(line.strip()) == 0:
                continue

            # file comment is in the beginning of the file, and it ends in line with single '#'
            if not filecomment_read:
                if line_num == 1 and line[0] != '#':
                    # filecomment must start from the first line
                    filecomment_read = True
                else:
                    if line[0] == '#':
                        # we don't know yet if this comment is file comment, so
                        # we save the comment to be used later
                        last_comment = line.strip()
                        
                        if len(line.strip()) == 1:
                            # single '#' means the end of file comment
                            filecomment_read = True
                            if filecomment != '':
                                self.conf_data.add_file_comment(filecomment)
                        else:
                            filecomment += line
                        continue
                    else:
                        # no more comments, and no file comment mark (single #)
                        # -> the comment wasn't filecomment
                        filecomment_read = True

            # save comments to be associated with following triggers
            elif line[0] == '#':
                if len(line.strip()) > 1:
                    last_comment = line.strip()
                else:
                    last_comment = ''
                continue

            # add line to conf_data
            if not self.conf_data.add_line(line, last_comment):
                error('Corrupted input file, exiting')
                sys.exit(1)
            
            last_comment = ''

        # after all the lines, get them back to self.commands
        self.commands = self.conf_data.data_lines()
        debug(self.commands)
            
        return True


    def create_new_file(self):
        print "\nCreating a new input file.\nGive all numeric values in decimal radix."

        data = ''

        cancel = False
        while True:
            print "\n'e' : add an event\n't' : add a trigger\n'p' : add path measurement"
            print "'r' : all ready, give running time and save\n'c' : cancel creating\n"

            cmd = raw_input('> ')

            # some space
            clear()
            
            if cmd == 'e':
                self.conf_data.add_event()
            elif cmd == 't':
                self.conf_data.add_trigger()
            elif cmd == 'p':
                self.conf_data.add_path()
            elif cmd == 'r':
                break
            elif cmd == 'c':
                cancel = True
                break
            else:
                print INVALID_CMD
                continue

        # command c received
        if cancel:
            print "\nCreation of file canceled."
            return

        # add running time and comment
        self.conf_data.add_running_time()

        # one more thing, load the new file
        self.commands = self.conf_data.data_lines()
        debug(self.commands)
        
        # save the file
        while True:
            filename = raw_input('Name for the file: ')
            try:
                wrfile = open(filename, 'w')
                wrfile.write(self.commands)
                wrfile.close()
                break
            except IOError:
                error("Writing to file '%s' failed, try again with a different filename" %(filename))
                continue

        # that's it
        print "\nNew input file successfully created.\n"

        self.filename = filename


    def edit_file(self):

        if self.filename == None:
            error("Editing unexisting file. This shouldn't be possible...")
            sys.exit(1)

        # whether to show the whole system or just a trigger/event
        # (in these names 'trigger' stands for both triggers and events..)
        trigger_view = False
        trigger_num = 0
        trigger_type = 't'

        # show the whole system right away
        self.conf_data.print_all()

        while True:
            # ask for a command

            if trigger_view:
                self.print_start_message('edit')
            else:
                self.print_start_message('view')
            
            cmd = raw_input('> ')

            # some space
            clear()
            
            cmds = cmd.split(' ')

            to_print = ''
            if trigger_view:

                # Here we are looking at a single trigger/event
                
                if cmds[0] == 'e' and len(cmds) == 3:
                    # user is willing to change a value
                    try:
                        num = int(cmds[1])
                        if self.conf_data.edit_value(trigger_type, trigger_num, num, cmds[2]):
                            to_print = '\nChanged property %s to value %s' %(str(cmds[1]), str(cmds[2]))
                        else:
                            to_print = '\n' + INVALID_CMD
                    except ValueError:
                        to_print = '\n' + INVALID_NUM

                elif cmds[0] == 'd':
                    self.conf_data.delete_one(trigger_type, trigger_num)
                    if trigger_type == 't':
                        to_print = '\nTrigger %i deleted' %(trigger_num)
                    elif trigger_type == 'e':
                        to_print = '\nEvent %i deleted' %(trigger_num)
                    elif trigger_type == 'p':
                        to_print = '\nPath deleted'
                    trigger_view = False

                elif cmds[0] == 'c':

                    self.conf_data.print_one(trigger_type, trigger_num)
                    new_comment = raw_input('\nEnter new comment:\n> ')
                    self.conf_data.change_comment(trigger_type, trigger_num, new_comment)
                    clear()
                elif cmds[0] == 'b':
                    trigger_view = False
                else:
                    to_print = '\n' + INVALID_CMD

                if trigger_view:
                    self.conf_data.print_one(trigger_type, trigger_num)
                else:
                    self.conf_data.print_all()
                print to_print


            else:

                # Here we are looking at the whole system
                
                if cmds[0] in ('t', 'e') and len(cmds) == 2:
                    try:
                        num = int(cmds[1])
                        if self.conf_data.print_one(cmds[0], num):
                            trigger_view = True
                            trigger_num = num
                            trigger_type = cmds[0]
                        else:
                            to_print = '\n' + INVALID_NUM
                
                    except ValueError:
                        to_print = '\n' + INVALID_NUM
                elif cmds[0] == 'p':
                    if self.conf_data.print_one(cmds[0]):
                        trigger_view = True
                        trigger_type = cmds[0]
                    else:
                        to_print = '\nNo path.'
                    
                elif cmds[0] == 'a' and len(cmds) == 2 and cmds[1] in ('t', 'e', 'p'):
                    # add new trigger/event
                    if cmds[1] == 't':
                        self.conf_data.add_trigger()
                    elif cmds[1] == 'e':
                        self.conf_data.add_event()
                    elif cmds[1] == 'p':
                        if not self.conf_data.add_path():
                            to_print = 'Path already exists.'

                elif cmds[0] == 'r' and len(cmds) == 2:
                    try:
                        new_rt = int(cmds[1])
                        if not self.conf_data.change_running_time(new_rt):
                            to_print = '\n' + INVALID_NUM
                    except ValueError:
                        to_print = '\n' + INVALID_NUM

                elif cmds[0] == 'c':
                    # change file comment
                    self.conf_data.print_all()
                    new = raw_input('\nEnter new comment:\n> ')
                    if new != '':
                        # add comment char and newline
                        new = '# %s\n' %(new)
                    self.conf_data.add_file_comment(new)
                        
                elif cmds[0] == 's':
                    debug(self.conf_data.data_lines())
                    try:
                        wrfile = open(self.filename, 'w')
                        wrfile.write(self.conf_data.data_lines())
                        wrfile.close()
                    except IOError:
                        error('Saving changes failed.')
                    else:
                        print '\nChanges saved.'

                    # stop editing
                    break

                elif cmds[0] == 'q':
                    print 'Saving is overrated anyway...'
                    print 'Changes remain until the file is reloaded.'
                    break
                else:
                    to_print = '\n' + INVALID_CMD

                if not trigger_view:
                    self.conf_data.print_all()
                print to_print


    def write_commands_to_port(self):

        # load newest data lines
        self.commands = self.conf_data.data_lines()

        print "\nRelease device from reset now.\n"
        got_first_prompt = False

        for cmd in self.commands.splitlines():

            # discard comments and empty lines
            if len(cmd.strip()) == 0:
                continue
            if cmd.strip()[0] == '#':
                debug("\nDiscarded comment '%s'" %(cmd.strip()))
                continue
            
            parts = cmd.split(' ')

            for part in parts:
                part = part.strip()
                #print part
                # read until there is a cmd prompt
                msg = self.ser.read_prompt(got_first_prompt)

                # comment
                if msg == '':
                    print '\n** Error: Timeout from UART (waiting for cmd prompt),\n          data flow ended unexpectedly. Exiting.'
                    sys.exit(1)
                
                if not got_first_prompt:
                    print "\nConfiguring the device..."
                    debug(msg)
                    got_first_prompt = True
                    
                response = self.ser.write_str(part)

                if response == '':
                    print '\n** Error: Timeout from UART (waiting for character echoing),\n          data flow ended unexpectedly. Exiting.'
                    sys.exit(1)
                
                #debug("%s %s\n" %(msg.strip(), response))
                #debug(response)

    def read_results(self):

        debug('\nReading results...\n')
        self.results = self.ser.read_all_lines()
        debug(''.join(self.results) + '\n')
        self.format_results()

    def format_results(self):

        tgs = {}
        self.names = ('Min tx len', 'Max tx len', 'Total words', 'Average len', \
                      'Num of tx:s', 'Min lat', 'Max lat', 'Average lat', 'Errors')

        tg_id = 0
        counter = 0
        read_path = False
        self.path_data = {}
        self.path_names = ('TG number', 'Path tx:s', 'Average lat')
        
        for line in self.results:
            # If line is empty, or line contains other than hex characters (headline)
            if len(line.strip()) == 0 or re.match('[0-9a-f]', line.strip()) == None:
                if line.strip() == "PATH: pos tg am lat":
                    # start reading path data
                    read_path = True
                    continue
                else:
                    continue

            if not read_path:

                if len(line.strip()) == 2:
                    # this is TG id line
                    tg_id = int(line, 16)
                    tgs[tg_id] = {}
                    
                else:
                    # normal data line
                    values = line.split(' ')
                    sender_tg = int(values[0], 16)
                    tgs[tg_id][sender_tg] = {}
                    counter = 0
                    for value in values[1:]:
                        # we don't have the avg len, we calculate it later
                        if self.names[counter] == 'Average len':
                            tgs[tg_id][sender_tg][ self.names[counter] ] = 0
                            counter += 1

                        if self.names[counter] == 'Errors':
                            stripped = value.strip()
                            assert len(stripped) == 4
                            # error data has two values in one, so we want to separate them
                            tgs[tg_id][sender_tg][ self.names[counter] ] = int(stripped[0:1], 16) + int(stripped[2:3])
                        else:
                            tgs[tg_id][sender_tg][ self.names[counter] ] = int(value, 16)
                        counter += 1

            else:
                # read path data
                values = line.split(' ')
                if len(values) != 4:
                    # no more data
                    break

                # values:
                # 0 => position in path
                # 1 => TG number
                # 2 => amount of path measurement transfers for this TG
                # 3 => sum of latency

                self.path_data[ int(values[0], 16) ] = {}
                cnt = 0
                for value in values[1:]:
                    self.path_data[ int(values[0], 16) ][ self.path_names[cnt] ] = int(value, 16)
                    cnt += 1
                

        # remove useless values (if no transfers, replace numbers with '--')
        # also replave total lat value with avg
        for tg in tgs.values():
            for sender in tg.values():
                for key in sender.keys():

                    # fix meaningless values
                    if sender['Num of tx:s'] == 0 or sender['Num of tx:s'] == '--':
                        sender[key] = '--'

                    # calculate avg latency (at this point it is really total latency)
                    elif key == 'Average lat':
                        # round values correctly
                        sender[key] = int(round(float(sender[key]) / sender['Num of tx:s']))

                    # calculate avg tx length
                    elif key == 'Total words':
                        sender['Average len'] = int(round(float(sender[key]) / sender['Num of tx:s']))

        # same for path
        for key in self.path_data.keys():
            if self.path_data[key]['Path tx:s'] != 0:
                self.path_data[key]['Average lat'] = self.path_data[key]['Average lat'] / self.path_data[key]['Path tx:s']

        self.print_results(tgs)

    def print_results(self, data):

        # data is supposed to be a 3d dictionary

        column_width = 13
        total_values = {}
        total_lines = 0

        print '\nResults:\n'

        # printing the first line with things that have been measured
        sys.stdout.write('             ')
        for name in self.names:
            sys.stdout.write( '|%s%s ' %(xtra_spaces(name, column_width), name) )
        sys.stdout.write('\n')

        # printing the datalines
        for tg in data.keys():

            # separating line:
            sys.stdout.write('--------------')
            for n in data.values()[0].values()[0].keys():
                sys.stdout.write('--------------')
            sys.stdout.write('\n')

            print '%sTo tg %s ' %( xtra_spaces('To tg %s' %(str(tg)), column_width), str(tg) )
            print '-------------'

            # then the senders
            for sender in data[tg].keys():
                # don't print line from x to x
                if sender == tg:
                    continue

                # count the number of meaningful lines (the ones with data instead of '--'
                if data[tg][sender].values()[0] != '--':
                    total_lines += 1
                
                sys.stdout.write( '%sFrom %s ' %(xtra_spaces('From %s' %(str(sender)), column_width), str(sender)) )
                # and their values
                for key in self.names:
                    value = data[tg][sender][key]
                    sys.stdout.write( '|%s%s ' %(xtra_spaces(str(value), column_width), str(value)) )

                    # count total values
                    if value != '--':
                        if not total_values.has_key(key):
                            total_values[key] = value
                        else:
                            if key in ['Min tx len', 'Min lat']:
                                if value < total_values[key]:
                                    total_values[key] = value
                            elif key in ['Max tx len', 'Max lat']:
                                if value > total_values[key]:
                                    total_values[key] = value
                            elif key in ['Average len', 'Average lat']:
                                # averages are now only summed and real values
                                # are counted during printing
                                total_values[key] += value
                            else:
                                total_values[key] += value
                            
                sys.stdout.write('\n')


        # printing the last line with total values:
        # separating line:
        sys.stdout.write('--------------')
        for n in data.values()[0].values()[0].keys():
            sys.stdout.write('--------------')
        sys.stdout.write('\n')
        sys.stdout.write( '%sTot values ' %(xtra_spaces('Tot values', column_width)) )

        # data itself
        for key in self.names:
            if len(total_values) > 0:
                value = total_values[key]
                if key in ['Average len', 'Average lat']:
                    # calculate the true average, and round it
                    value = int(round(float(value) / total_lines))
                sys.stdout.write( '|%s%s ' %(xtra_spaces(str(value), column_width), str(value)) )
        sys.stdout.write('\n\n\n')

        # finally the path data, if there is any:
        if len(self.path_data) > 1:
            sys.stdout.write(' Path data:\n')
            sys.stdout.write('\n')

            # headline:
            sys.stdout.write( '%sPosition ' %( xtra_spaces('Position', column_width) ))
            for name in self.path_names:
                sys.stdout.write( '|%s%s ' %( xtra_spaces( name, column_width ), name ))
            sys.stdout.write('\n')
            # separating line:

            sys.stdout.write('--------------')
            for n in self.path_names:
                sys.stdout.write('--------------')
            sys.stdout.write('\n')

            # data itself
            for pos in self.path_data.keys():
                sys.stdout.write( '%s%s ' %( xtra_spaces( str(pos), column_width ), str(pos) ))
                for key in self.path_names:
                    sys.stdout.write( '|%s%s ' %( xtra_spaces( str(self.path_data[pos][key]), column_width ), str(self.path_data[pos][key]) ))
                sys.stdout.write('\n')
            sys.stdout.write('\n\n')


    def check_hex(self, to_check):
        # check that string to_check contains only valid hex characters
        regexp = re.compile("[0-9a-f]")
        for chr in to_check:
            assert regexp.search(chr) != None


    def print_output_from_file(self, filename):
        # open file, check that it's ok and then let the other functions
        # format and print the contents

        if not os.path.exists(filename):
            error("Output file %s doesn't exist" %(filename))
            return

        try:
            contents = open(filename, 'r')
        except IOError:
            error("Output file not readable")
            return

        # the output file may also contain the configuration part, so
        # make sure not to take those lines with the results
        self.results = []
        no_more_conf_lines = False
        for line in contents:
            if no_more_conf_lines:
                self.results.append(line)
            elif 'TG MINMAX' in line:
                # results start
                no_more_conf_lines = True

        self.format_results()
        

    def print_start_message(self, type = 'root'):

        print '\n----------'

        if type == 'root':
            msg = "\n*** Traffic generator commander ***\n"
            if self.filename != None:
                msg += "File '" + self.filename + "' loaded.\n"
        elif type == 'view':
            msg = "\nViewing file '%s'\n" %(self.filename)
        elif type == 'edit':
            msg = "\nEditing properties\n"

        msg += "Select an action:\n"

        if type == 'root':
            if self.filename != None:
                msg += "'r'        : run the test using currently loaded file\n"
                msg += "'e'        : edit or view the currently loaded file\n"
                msg += "'g'        : create a DOT graph file from the current system\n"

            msg += "'o <file>' : open an existing input file\n"
            msg += "'n'        : create a new input file\n"
            msg += "'h'        : show startup instructions\n"
            msg += "'q'        : quit\n"
        elif type == 'view':
            msg += "'t' <number>      : view a specific trigger\n"
            msg += "'e' <number>      : view a specific event\n"
            msg += "'p'               : view path\n"
            msg += "'a' <'t'/'e'/'p'> : add trigger, event or path\n"
            msg += "'r' <number>      : change running time\n"
            msg += "'c'               : change file comment\n"
            msg += "'s'               : save changes and quit editing\n"
            msg += "'q'               : quit editing without saving to file\n"
        elif type == 'edit':
            msg += "'e' <number> <value> : change parameter value\n"
            msg += "'d'                  : delete this\n"
            msg += "'c'                  : change comment\n"
            msg += "'b'                  : switch back to system view\n"

        print msg
    





# start the action
if __name__ == "__main__":
    main = main_operation(sys.argv[1:])

