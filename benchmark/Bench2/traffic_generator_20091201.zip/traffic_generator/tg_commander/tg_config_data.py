# module for TG Commander
# contains info about the configuration data

# Copyright (c) 2009 by Tampere University of Technology


# This file is part of Traffic generator.

# Traffic generator is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as
# published by the Free Software Foundation, either version 3 of
# the License, or (at your option) any later version.

# Traffic generator is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public
# License along with Traffic generator.
# If not, see <http://www.gnu.org/licenses/>.



import sys
import time
import subprocess
from tg_support import *

# Program to view PostScripts
MY_FAVOURITE_PS_VIEWER = "evince"

# parameter formats
MODE = 'mode'
BINARY = 'binary'
HEX = 'hex'

# data table, format:
# <parameter>, <param. format>, <hex_width>, <text to print>, <dependencies on other params>, <dep type (or/and)>
TRIGGER_DATA = (('owner', HEX, ADDR_W, 'Target TG number: ', [], ''), \
                ('mode', MODE, 0, "Trigger mode: ", [], '' ), \
                ('triggering_addr', HEX, ADDR_W, 'Triggering address: ', [('mode', '11'), ('mode', '01')], 'or' ), \
                ('triggering_type', HEX, DATATYPE_W, 'Triggering data type: ', [('mode', '11'), ('mode', '10')], 'or' ), \
                ('idle_times', HEX, WAITING_W, 'Idle times before activation: ', [], '' ), \
                ('reply_to_sender', BINARY, 0, 'Reply to sender: ', [], '' ), \
                ('rand_addr', BINARY, 0, 'Randomize address: ', [('reply_to_sender', False)], 'and' ), \
                ('target_addr', HEX, ADDR_W, 'Target address: ', [('reply_to_sender', False), ('rand_addr', False )], 'and' ), \
                ('type_out', HEX, DATATYPE_W, 'Transfer data type: ', [], '' ), \
                ('rand_len', BINARY, 0, 'Randomize transfer length: ', [], '' ), \
                ('tx_len', HEX, LENGTH_W, 'Transfer length (average, if randomizing): ', [], '' ), \
                ('dep_en', BINARY, 0, 'Dependent on a flag: ', [], '' ), \
                ('dep_flag', HEX, DEP_FLAG_W, 'Dependency flag number: ', [('dep_en', True)], 'and' ), \
                ('dont_wait_dep', BINARY, 0, "Don't wait for the dependency flag to rise: ", [('dep_en', True)], 'and' ), \
                ('set_dep', BINARY, 0, 'Set a dependency flag: ', [], '' ), \
                ('flag_to_set', HEX, DEP_FLAG_W, 'Dependency flag to set: ', [('set_dep', True)], 'and' ), \
                ('block_others', BINARY, 0, 'Block other triggers and events: ', [], '' ), \
                ('processing_time', HEX, PROCESSING_W, 'Processing time: ', [], '' ) )


EVENT_DATA = (('owner', HEX, ADDR_W, 'Target TG number: ', [], ''), \
              ('waiting_time', HEX, WAITING_W, 'Waiting time before activation: ', [], '' ), \
              ('once_only', BINARY, 0, 'Activate only once: ', [], '' ), \
              ('rand_addr', BINARY, 0, 'Randomize address: ', [], '' ), \
              ('target_addr', HEX, ADDR_W, 'Target address: ', [('rand_addr', False )], 'and' ), \
              ('type_out', HEX, DATATYPE_W, 'Transfer data type: ', [], '' ), \
              ('rand_len', BINARY, 0, 'Randomize transfer length: ', [], '' ), \
              ('tx_len', HEX, LENGTH_W, 'Transfer length (average, if randomizing): ', [], '' ), \
              ('dep_en', BINARY, 0, 'Dependent on a flag: ', [], '' ), \
              ('dep_flag', HEX, DEP_FLAG_W, 'Dependency flag number: ', [('dep_en', True)], 'and' ), \
              ('dont_wait_dep', BINARY, 0, "Don't wait for the dependency flag to rise: ", [('dep_en', True)], 'and' ), \
              ('set_dep', BINARY, 0, 'Set a dependency flag: ', [], '' ), \
              ('flag_to_set', HEX, DEP_FLAG_W, 'Dependency flag to set: ', [('set_dep', True)], 'and' ), \
              ('block_others', BINARY, 0, 'Block other triggers and events: ', [], '' ), \
              ('processing_time', HEX, PROCESSING_W, 'Processing time: ', [], '' ) )




def conv_to_hex(decimal, width):

    if decimal < 0:
        debug('conv_to_hex: decimal value less than zero\n')
        raise NameError
        
    raw_hex = hex(decimal)
    # remove '0x' from the beginning of the hex
    plain_hex = raw_hex[2:]
    if len(plain_hex) > width:
        # decimal value was too large
        debug("Invalid value: '%s'" %(plain_hex))
        raise NameError

    while len(plain_hex) < width:
        # add zeros to the front until the width matches
        plain_hex = '0' + plain_hex

    return plain_hex



# ******************************************************************************


class trigger:
    # in fact this can be either trigger or an event

    def __init__(self, is_event, from_line = False, line = None, path = False, comment = ''):
        # create a new trigger

        self.data = {}
        self.line = ''
        data_table = None
        self.path = path
        self.is_event = is_event
        self.comment = comment

        if from_line:
            self.line_parts = line.split(' ')
            # if an event, we need to remove the mode
            if is_event:
                self.line_parts.remove('00')
            # reverse order, so that pop gets what it needs
            self.line_parts.reverse()
            if not path:
                # pop away the 'a'
                assert self.line_parts.pop() == 'a'


        if self.is_event:
            self.data_table = EVENT_DATA
            self.data['mode'] = '00'
        else:
            self.data_table = TRIGGER_DATA
            # data values that are dependent by each other and someone else must be initialized
            self.data['reply_to_sender'] = False
            self.data['rand_addr'] = False

        for (name, type, width, text, deps, dep_type) in self.data_table:

            loops = 0
            while True:
                
                loops += 1
                if loops > 10:
                    print name
                    sys.exit(1)

                # if dependencies not met, jump to the next parameter
                if not self.check_deps(deps, dep_type):
                    break

                # path makes few exeptions
                if path and name in ('owner', 'target_addr'):
                    # owner is the first one in path and target
                    # (if needed anyway) is second, so no need to specify them
                    break

                if not self.ask_value(name, type, text, width, from_line):
                    continue
                else:
                    break

        # ask for a comment
        if not from_line:
            comment_line = raw_input('Voluntary comment for the trigger/event\n> ')
            if len(comment_line) > 0:
                self.comment = '# %s' %(comment_line)

        # form the config file line from parameters
        self.params_to_line()

    def ask_value(self, name, type, text, width, from_line = False):

        try:
            if type == MODE:
                to_print = text
                if not from_line:
                    to_print += "\n'a' : address sensitive\n't' : type sensitive\n'b' : both address and type sensitive\n> "
                ttype = self.get_value(type, to_print, from_line)
                if ttype == 'a' or ttype == '01':
                    self.data[name] = '01'
                elif ttype == 't' or ttype == '10':
                    self.data[name] = '10'
                elif ttype == 'b' or ttype == '11':
                    self.data[name] = '11'
                else:
                    if from_line:
                        print ttype
                        print "Invalid mode in line, exiting.\n'%s'" %(line.strip())
                        sys.exit(1)
                    else:
                        print 'Invalid mode, try again.'
                        return False
                    
            elif type == BINARY:
                value = self.get_value(type, text, from_line)
                if value == 0:
                    self.data[name] = False
                elif value == 1:
                    self.data[name] = True
                else:
                    if from_line:
                        print "Invalid binary value in line ('%s' = %s), exiting.\n'%s'" %(name, value, line.strip())
                        sys.exit(1)
                    else:
                        print 'Invalid binary value (not 0 or 1), try again.'
                        return False

            elif type == HEX:
                value = self.get_value(type, text, from_line)
                # conversion is made to check the validness
                hex_value = conv_to_hex(value, width)
                self.data[name] = value

            else:
                print 'Problems with python code, cannot proceed.'
                sys.exit(1)

        except NameError:
            if from_line:
                print 'Invalid file, exiting.'
                sys.exit(1)
            else:
                print 'Invalid number, try again.'
                return False

        return True



    def get_value(self, type, text, from_line = False):
        # get value either from data line or from user
        if from_line:
            try:
                if type == MODE:
                    # no integer conversion for mode
                    value = self.line_parts.pop()
                else:
                    value = int(self.line_parts.pop(), 16)
            except ValueError:
                print 'Invalid data line'
                sys.exit(1)
            return value
        
        else:
            # ask the user
            value = raw_input(text)

            if type != MODE:
                try:
                    value = int(value)
                except ValueError:
                    value = None
            return value


    def check_deps(self, deps, dep_type):
        if deps == []:
            deps_ok = True
        else:
            # check dependencies
            if dep_type == 'or':
                deps_ok = False
                for param, val in deps:
                    if self.data.get(param) == val:
                        deps_ok = True
            else:
                deps_ok = True
                for param, val in deps:
                    if self.data.get(param) != val:
                        deps_ok = False

        return deps_ok


    def params_to_line(self):
        # form a config file file line from parameters

        if not self.path:
            self.line = 'a'
                    
        for (name, type, width, text, deps, dep_type) in self.data_table:

            # if dependencies not met, jump to the next parameter
            if not self.check_deps(deps, dep_type):
                continue

            # path makes few exeptions
            if self.path:
                if name == 'owner':
                    # owner is the first one in path
                    continue
                elif name == 'target_addr':
                    # deps are ok, so target addr would be asked
                    continue

            # event mode must be added separately
            if name == 'waiting_time':
                # just before waiting time
                self.line += ' 00'
                        
            if type == MODE:
                self.line += ' %s' %(self.data[name])

            elif type == BINARY:
                if self.data[name]:
                    self.line += ' 1'
                else:
                    self.line += ' 0'

            elif type == HEX:
                self.line += ' %s' %(conv_to_hex(self.data[name], width))

    def edit_value(self, num, value):

        cnt = 0
        for (name, type, width, text, deps, dep_type) in self.data_table:
            if self.data.has_key(name):
                cnt += 1
                if cnt == num:
                    # matching parameter
                    if type == BINARY:
                        if value == '1' or value.lower() == 'true':
                            self.data[name] = True
                        elif value == '0' or value.lower() == 'false':
                            self.data[name] = False
                        else:
                            return False
                        
                    elif type == HEX:
                        try:
                            # check correctness when converted
                            hex_val = conv_to_hex( int(value), width )
                            self.data[name] = int(value)
                        except NameError:
                            return False
                        except ValueError:
                            print 'Invalid number.'
                            return False
                        
                    elif type == MODE:
                        if not value in ('10', '01', '11'):
                            return False
                        else:
                            self.data[name] = value

                    break

        # now we have to make sure that all needed values exist and not needed do not
        for (name, type, width, text, deps, dep_type) in self.data_table:

            if not self.check_deps(deps, dep_type):
                # this is not needed
                if self.data.has_key(name):
                    # but we still have it...
                    # ...so we delete it! Buahhahhahaaaa!
                    del self.data[name]
            
            elif not self.data.has_key(name):
                # this is needed but doesn't exist
                
                # path makes few exeptions
                if self.path and name in ('owner', 'target_addr'):
                    continue
                
                print 'Enter missing values.'
                while not self.ask_value(name, type, text, width):
                    pass

        return True
                            

    def print_data(self):

        # print the comment
        if self.comment != '':
            print '%s\n' %(self.comment)

        # count the longest text line length
        longest = 0
        for (name, type, width, text, deps, dep_type) in self.data_table:
            current = len(text)
            if current > longest:
                longest = current

        cnt = 0
        for (name, type, width, text, deps, dep_type) in self.data_table:
            if self.data.has_key(name):
                # count the number of spaces
                spaces_after = ''
                for i in range(0, longest - len(text)):
                    spaces_after += ' '

                # lets hope there's never over 99 properties.. =)
                if cnt+1 < 10:
                    spaces_before = '  '
                else:
                    spaces_before = ' '
                    
                cnt += 1
                print '%i:%s%s%s%s' %(cnt, spaces_before, text, spaces_after, str(self.data[name]))

    def print_short(self, path = False, path_owner = 0, path_target = 0):

        if self.data.get('rand_addr'):
            trgt = 'random'
        elif self.data.get('reply_to_sender'):
            trgt = 'sender'
        elif self.data.has_key('target_addr'):
            trgt = self.data['target_addr']
        elif path:
            trgt = path_target
        else:
            trgt = ''

        if not self.is_event:
            start = "Trigger (mode '%s')" %(self.data['mode'])
        else:
            start = "Event"

        if self.data['rand_len']:
            len = "randomized length (avg: %i words)" %(self.data['tx_len'])
        else:
            len = "length %i words" %(self.data['tx_len'])

        if path:
            owner = path_owner
        else:
            owner = self.data.get('owner')
        
        whole_story = '%s from %s to %s, %s.' %(start, owner, trgt, len)
        print whole_story

    def change_comment(self, new):
        self.comment = '# %s' %(new)

    def data_line(self):
        self.params_to_line()
        
        to_return = ''
        if self.comment != '':
            to_return = self.comment + '\n'
        to_return += self.line
        return to_return

    def graph_data(self):

        # if length in nothing, return None
        if self.data.get('tx_len') == 0:
            return None
        
        owner = str(self.data.get('owner'))
        
        if self.data.get('reply_to_sender'):
            if self.data.has_key('triggering_addr'):
                target = str(self.data.get('triggering_addr'))
            else:
                target = 'sender'
        elif self.data.get('rand_addr'):
            target = 'random'
        else:
            target = str(self.data.get('target_addr'))

        datatype = str(self.data.get('type_out'))

        if self.data.get('rand_len'):
            length = '~%i' %(self.data.get('tx_len'))
        else:
            length = str(self.data.get('tx_len'))

        return (owner, target, datatype, length)

        
# ******************************************************************************


class path:

    def __init__(self, from_line = False, line = None, comment = ''):

        self.tgs = []
        self.starter = None
        self.line = ''
        starter_line = ''
        self.comment = comment
        self.starter_is_event = False

        while True:
            try:
                if not from_line:
                    # get input from the user
                    raw_tgs = raw_input('Give path TGs in correct order separated by spaces:\n> ')
                    tgs_l = raw_tgs.split(' ')
                    if len(tgs_l) < 2:
                        raise NameError
                else:
                    tgs_l = line.split(' ')
                    # remove the first 'p'
                    tgs_l = tgs_l[1:]

                counter = 0
                for tg in tgs_l:
                    counter += 1
                    if from_line:
                        if tg == 'p':
                            # end of path tgs
                            # line to form the starting trigger/event
                            starter_line = tgs_l[counter:]
                            break
                        self.tgs.append(int(tg, 16))
                    else:
                        self.tgs.append(int(tg))
                        # conversion is made here only to check the integers for validness
                        hex_val = conv_to_hex(int(tg), ADDR_W)
                break
            
            except NameError:
                if from_line:
                    print "Invalid path in input file, exiting.\n'%s'" %(line)
                    sys.exit(1)
                print "\nInvalid input, try again."
                continue
            except ValueError:
                if from_line:
                    print "Invalid path in input file, exiting.\n'%s'" %(line)
                    sys.exit(1)
                print "\nInvalid input, try again."
                continue

            # that's it for the path tgs, then the starting event/trigger

        while True:
            # trigger/event
            type = ''
            line_str = ''
            
            if not from_line:
                type = raw_input('Start path with:\ne: event\nt: trigger\n> ')
            else:
                type = starter_line[0]
                line_str = ' '.join(starter_line)

            if type == 'e' or type == '00':
                self.starter = trigger(is_event = True, from_line = from_line, \
                                       line = line_str, path = True, comment = comment)
                self.starter_is_event = True
                
            elif type == 't' or type in ('10', '01', '11'):
                self.starter = trigger(is_event = False, from_line = from_line, \
                                       line = line_str, path = True, comment = comment)
                self.starter_is_event = False
                
            else:
                if from_line:
                    print 'Invalid path starter line, exiting.\n%s' %(line_str)
                    sys.exit(1)

                print 'Invalid input, try again.'
                continue
            break

        self.params_to_line()


    def params_to_line(self):

        self.line = 'p'
        for tg in self.tgs:
            hex_val = conv_to_hex(tg, ADDR_W)
            self.line += ' %s' %(hex_val)
        self.line += ' p'

        starter_lines = self.starter.data_line().split('\n')
        if len(starter_lines) == 2 and starter_lines[0][0] == '#':
            self.comment = starter_lines[0]
            self.line += starter_lines[1]
        else:
            self.line += starter_lines[0]

    def print_data(self):
        start = 'Path TGs: '
        for tg in self.tgs:
            start += ' %s,' %(str(tg))

        # remove last comma
        start = start[0:-1]
        print start
        if self.starter_is_event:
            print 'Starting event:\n'
        else:
            print 'Starting trigger:\n'
        
        self.starter.print_data()

    def print_short(self):
        start = 'Path TGs: '
        for tg in self.tgs:
            start += ' %s,' %(str(tg))

        # remove last comma
        start = start[0:-1]

        if self.starter_is_event:
            starter = 'Starting event: '
        else:
            starter = 'Starting trigger: '

        sys.stdout.write('%s. %s' %(start, starter))
        self.starter.print_short(True, self.tgs[0], self.tgs[1])

    def edit_value(self, param_num, new_value):
        return self.starter.edit_value(param_num, new_value)

    def change_comment(self, new):
        self.starter.change_comment(new)

    def data_line(self):
        to_return = ''
        if self.comment != '':
            to_return = self.comment + '\n'
        to_return += self.line
        return to_return

    def graph_data(self):

        data = self.starter.graph_data()
        if data == None:
            return None
        else:
            (owner, target, datatype, length) = data

        owner = self.tgs[0]
        if target == 'None':
            target = self.tgs[1]

        return (owner, target, datatype, length)


# ******************************************************************************


class tg_data:

    def __init__(self):
        self.triggers = []
        self.events = []
        self.path = None
        self.runtime = 0
        self.comment = ''

    def add_line(self, line, comment = ''):
        data = line.split(' ')

        if data[0] == 'a' and len(data) > 2:
            # trigger/event
            if data[2] == '00':
                # event
                self.add_event(True, line, comment)
            else:
                # trigger
                self.add_trigger(True, line, comment)
        elif data[0] == 'p':
            self.add_path(True, line, comment)
        elif data[0] == 's':
            try:
                self.runtime = int(data[1], 16)
            except ValueError:
                print 'Running time not a valid hex value'
                return False
        else:
            # error
            return False

        return True

    def add_trigger(self, from_line = False, line = None, comment = ''):

        new = trigger(is_event = False, from_line = from_line, line = line, comment = comment)
        self.triggers.append(new)

    def add_event(self, from_line = False, line = None, comment = ''):

        new = trigger(is_event = True, from_line = from_line, line = line, comment = comment)
        self.events.append(new)
    
    def add_path(self, from_line = False, line = None, comment = ''):

        if self.path == None:
            self.path = path(from_line, line, comment)
        else:
            print 'Path already exists! Nothing created.'
            return False

        return True

    def add_running_time(self):

        # ask for running time
        while True:
            try:
                value = raw_input('Running time for the test (clk cycles): ')
                value = int(value)
                if not self.change_running_time(value):
                    print INVALID_NUM
                    continue
                self.runtime = value
                break
            except NameError:
                print "Invalid value, try again."
                continue
            except ValueError:
                print INVALID_NUM
                continue

        # add date to beginning
        self.comment = '# %s\n' %(time.ctime())

        # ask for a comment
        comment_line = raw_input('Voluntary comment to the beginning of the file\n> ')
        if len(comment_line) > 0:
            self.comment += '# %s\n#\n' %(comment_line)

    def change_running_time(self, new):

        if new < 1:
            return False

        try:
            hex_val = conv_to_hex(new, RUNTIME_W)
        except NameError:
            return False
            
        self.runtime = new
        return True

    def add_file_comment(self, comment):
        if comment == '':
            self.comment = ''
        else:
            self.comment = '%s#\n' %(comment)

    def data_lines(self):
        data = self.comment

        for trig in self.triggers:
            data += '%s\n' %(trig.data_line())

        for eve in self.events:
            data += '%s\n' %(eve.data_line())

        if self.path != None:
            data += '%s\n' %(self.path.data_line())

        data += 's %s\n' %(conv_to_hex(self.runtime, RUNTIME_W))

        return data


    def print_all(self):

        if self.comment != '':
            # remove last '#' line
            print '\n'.join( self.comment.split('\n')[:-2] )
        
        if len(self.triggers) > 0:
            print '\nTriggers:\n'
        cnt = 0
        for trig in self.triggers:
            cnt += 1
            sys.stdout.write(str(cnt) + ': ')
            trig.print_short()
            
        if len(self.events) > 0:
            print '\nEvents:\n'
        cnt = 0
        for eve in self.events:
            cnt += 1
            sys.stdout.write(str(cnt) + ': ')
            eve.print_short()
        
        if self.path != None:
            print '\nPath measurement:\n'
            self.path.print_short()

        print '\nRunning time %i clock cycles.' %(self.runtime)

    def print_one(self, which, number = 0):

        if which == 't':
            if number > len(self.triggers) or number < 1:
                # no such trigger
                return False
            else:
                print 'Trigger %i:\n' %(number)
                self.triggers[number - 1].print_data()
        elif which == 'e':
            if number > len(self.events) or number < 1:
                return False
            else:
                print 'Event %i:\n' %(number)
                self.events[number - 1].print_data()
        elif which == 'p':
            if self.path == None:
                return False
            else:
                print 'Path:\n'
                self.path.print_data()

        return True

    def delete_one(self, type, number = 0):

        if type == 't':
            if number > len(self.triggers) or number < 1:
                return False
            del self.triggers[number-1]
        elif type == 'e':
            if number > len(self.events) or number < 1:
                return False
            del self.events[number-1]
        elif type == 'p':
            self.path = None

        return True
        
    def edit_value(self, type, number, param_num, new_value):

        if type == 't':
            assert number <= len(self.triggers) and number > 0
            return self.triggers[number-1].edit_value(param_num, new_value)
        elif type == 'e':
            assert number <= len(self.events) and number > 0
            return self.events[number-1].edit_value(param_num, new_value)
        elif type == 'p':
            return self.path.edit_value(param_num, new_value)
        else:
            error('Error in code, aarrrggh!')
            sys.exit(1)

    def change_comment(self, type, number, comment):

        if type == 't':
            self.triggers[number-1].change_comment(comment)
        elif type == 'e':
            self.events[number-1].change_comment(comment)
        elif type == 'p':
            self.path.change_comment(comment)

    def make_graph(self):
        # Ok, this is the coolest thing ever. Form and spit out
        # a .dot file and try to generate and open an PostScript
        # image out of it.

        data = []
        for trig in self.triggers:
            values = trig.graph_data()
            if values != None:
                data.append(values)

        for eve in self.events:
            values = eve.graph_data()
            if values != None:
                data.append(values)

        if self.path != None:
            values = self.path.graph_data()
            if values != None:
                data.append(values)

        # normal 'from x to y' connections
        normals = []
        # from x to randoms
        randoms = []
        # from x to unknown sender
        replies = []
        
        for (source, target, datatype, length) in data:

            if target == 'random':
                randoms.append('%s -> random%i [label="%s"]' %(source, len(randoms), datatype))
            elif target == 'sender':
                replies.append('%s -> sender%i [label="%s"]' %(source, len(replies), datatype))
            else:
                normals.append('%s -> %s [label="%s"]' %(source, target, datatype))

        to_write = 'digraph "TG system" {\nratio=0.7\nnode [shape=box]\n'
        to_write += '\n'.join(normals)

        if len(randoms) > 0 or len(replies) > 0:
            to_write += '\nnode [style=dotted shape=ellipse]'

        for i in range(0, len(randoms)):
            to_write += '\nrandom%i [label="random" fontname="Times-Italic"]\n' %(i)
        to_write += '\n'.join(randoms)
        
        for i in range(0, len(replies)):
            to_write += '\nsender%i [label="sender" fontname="Times-Italic"]\n' %(i)
        to_write += '\n'.join(replies)

        to_write += '\n}'


        filename = raw_input('Insert filename for the DOT file:\n> ')
        if not filename.endswith('.dot'):
            filename += '.dot'

        try:
            wrfile = open(filename, 'w')
            wrfile.write(to_write)
            wrfile.close()
        except IOError:
            error("Writing to file '%s' failed." %(filename))
        else:
            print "\nCreated graph file '%s'." %(filename)

        # try to convert and open the file
        # works with linux dot and evince
        try:
            if subprocess.call( ["dot", "-Tps", "-o%s.ps" %(filename), "%s" %(filename)] ) == 0:
                # converting to postscript went ok
                evince = subprocess.Popen([MY_FAVOURITE_PS_VIEWER, "%s.ps" %(filename)])
            else:
                error("Converting dot file failed.")
        except OSError:
            print "Not able to convert and open the graph file automatically."
        
