------------------------------------------------------------------------------
Traffic Generator
Copyright (c) 2002-2009 by Tampere University of Technology

Traffic generator is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as
published by the Free Software Foundation, either version 3 of
the License, or (at your option) any later version.

Traffic generator is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with Traffic generator.
If not, see <http://www.gnu.org/licenses/>.

------------------------------------------------------------------------------

Traffic Generator Quick-Start Readme
TG version: 1
Package version: 1

Index
1. Introduction
2. Required tools and programs
3. A quick glance at features
4. Simulation & synthesis
5. Afterwords
6. Contact information



1. Introduction

This is the first and a very simple public release of our register 
transfer level (RTL) Traffic Generator (TG) for logic simulation 
and FPGA synthesis. This toolset is a part of NOCBENCH project 
which has the purpose of creating new methods for network-on-chip
(NoC) benchmarking.

This package includes:

 (i)   Traffic Generator (TG) itself
 (ii)  TG Commander
 (iii) A NoC monitor, working seamlessly with TG

TG consists of RTL VHDL descriptions that work in both simulation
and logic synthesis. TG Commander is a Python script that
makes the real-time configuring of FPGA TG easier.

In addition, some example networks can be downloaded from the NocBench
website to demonstrate the functionality of Traffic Generator.


2. Required tools and programs

In order to use TG and the example networks in simulation and on FPGA,
you will need at least:

1) Host computer with RS-232 UART serial port.

2) FPGA evaluation board with RS232 UART connector. An FPGA chip
   with at least 100k gate equivalent (30K logic elements) is 
   recommended.

3) Logic simulator software, eg. Mentor Graphics ModelSim.

4) FPGA synthesis software for your FPGA chip.

5) Python 2.x <http://www.python.org> and 
   pyserial <http://pyserial.sourceforge.net/> 
   in order to use tg_commander (recommended);
   or UART terminal program (usually supplied with your operating 
   system) if tg_commander is not used.



3. A quick glance at features

Number of TGs and maximum number of triggers and events are set at
synthesis time.

Events and triggers are fully configured at run-time to allow modeling
of several different systems or quick changes in the modelled system without
re-synthesis.

TG system has an interactive, simple configuration system. All the
events and triggers are configured via UART. Master TG has a simple
command prompt, making even manual configuration with any terminal
program possible. However, a configuration tool TG Commander is
supplied to make the configuration even easier.

The configuration command syntax is same in both simulation and synthesis.
In simulation, UART communication is replaced with text files. By default,
TG system uses tg_input.txt in the simulation directory and the supplied
NoC monitor uses mon_input.txt. tg_output.txt and mon_output.txt
are generated, respectively, during simulation.



4. Simulation & synthesis

Start by copying traffic_generator/vhd/tg_pkg_template.vhd as tg_pkg.vhd
and use tg_pkg.vhd in your project to change the settings like number of
TGs.

traffic_generator/network_tests provides you working toplevels for
simulation and synthesis, if you want to use our example networks.
These toplevel files generate the master TG and slave TGs, a network
of your choice (example networks can be downloaded from our
website), packet encoder-decoders between network and tg-wrapper, and
wrappers between network and TGs.

If you simulate your TG system, set simulating_c := 1 in tg_pkg. In this
way, tg_input.txt at your simulation directory becomes the run-time 
configuration input file for your TG system instead of UART communication.
An example file is provided in sim directory. It is recommended to use TG 
Commander to create and modify these files. Compile *pkg.vhd files first
as they are required to compile other vhdl files.

If you want to synthesize your TG system to an FPGA, follow your FPGA
vendor's design flow to create necessary project files. Make sure to
make pin mappings for UART.

The following settings work for UART as default: Baud rate 19200 bps,
8 bits, 2 stop bits, parity: none, no flow control. Now you should be
able to see "Give a command" prompt from master TG in your terminal
program when device reset is released.



5. Afterwords

Since this is our very first public release of our Traffic Generator
system, there may be bugs or unwanted features hiding. As this project
is released under an open-source license, you can help us and other
NoCists by making the Traffic Generator better; or just by reporting us
your opinions and suggestions. In fact, we will be interested to hear
about your interest in our TG.



6. Contact information

Tampere University of Technology
Department of Computer Systems
http://www.tkt.cs.tut.fi/index-english.html

Project coordinator for TG:
Erno Salminen, ege@cs.tut.fi
http://www.tkt.cs.tut.fi/~ege/
