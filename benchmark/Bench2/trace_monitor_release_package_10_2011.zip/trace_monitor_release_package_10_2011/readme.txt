Thank you for downloading Trace Monitor. You can start
by reading the reference manual at doc/trace_monitor_reference.pdf

If you are new to the concept, please find the background information
in doc/paper_extended.pdf

If you find that any files are missing, or if you have any problems
using or modifying Trace Monitor for your needs, please do not hesitate
to contact Antti Alhonen <antti.alhonen@tut.fi> to get assistance.
