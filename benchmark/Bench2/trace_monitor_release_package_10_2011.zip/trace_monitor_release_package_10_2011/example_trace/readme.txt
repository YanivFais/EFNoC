Example trace for trying out the PC software.

MPEG-4 video encoder ran on Altera Stratix II EP2S180 FPGA, using
4x4 mesh with wormhole switching with packet size of 16 and fixed 
Y-X routing.

First, four frames of video sequence are transferred from the
Main NIOS processor to the SDRAM.

Then, the four frames are processed. The first one is an intra-frame
without motion estimation.

The external SDRAM has two interfaces with different priorities.

Window length is 1000 clock cycles, ran at 25 MHz.

Either use the supplied trace_pc.cfg as is by copying it to
the Trace Monitor directory (the graphical settings are optimized
for 1600x1200 screen resolution), or use your own config and
just set the window length, network type, number of agents,
mesh size and nametag file name from the supplied file.

Run the trace monitor:
trace_pc v vid_1000_cut

When asked for creating decimation files (in the command prompt
window!), answer y. They need to be generated only once and are not
included to save download size. You can also generate Point-to-Point
Investigator files by clicking CMD and running 8: Point-to-Point
Investigator and then s: Start.
