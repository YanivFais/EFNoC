This example software is not for Trace Monitor, but may be useful
if you plan to make your own UDP/IP applications and need some
help in making the PC software. This uses the BOOST library.
Trace Monitor currently uses SFML. Both work.

This example works with example_udp_ip_for_de2.vhd supplied.

- Antti Alhonen 5.10.2011
