#include <cstdlib>
#include <iostream>
#include <cstdio>
#include <boost/bind.hpp>
#include <boost/asio.hpp>
#include <boost/asio/basic_datagram_socket.hpp>

using boost::asio::ip::udp;
using namespace std;

// Compile (Cygwin & Windows XP:)
// c++ udp_example.cc -o udp_example.exe -I /usr/local/include/boost -D_WIN32_WINNT=0x0501 -D__USE_W32_SOCKETS -lgd -lboost_system -lws2_32 -lkernel32 -lgdi32 -luser32 -lcomdlg32

int main(int argc, char** argv)
{
    const int max_length = 2000;
    unsigned char packet_data[max_length];

    try
    {
	boost::asio::io_service io_service;


	udp::socket socket(io_service);
	socket.open(udp::v4());

	udp::socket recv_socket(io_service, udp::endpoint(udp::v4(), 2000));

	// Put your own IP address here (4 bytes), followed by the port where you want the packets (2 bytes):
	unsigned char first_packet[6];
	first_packet[0] = 10;
	first_packet[1] = 0;
	first_packet[2] = 0;
	first_packet[3] = 4;
	first_packet[4] = 0x07;
	first_packet[5] = 0xD0;

	unsigned long int FPGA_ip_addr = (10<<24) + 10;

	// Ask FPGA to send data back to 10.0.0.4 port 2000 by sending a packet:

	udp::endpoint FPGA_endpoint(boost::asio::ip::address(boost::asio::ip::address_v4(FPGA_ip_addr)), 1234); // argv[3], atoi(argv[4]));
	cout << "Sending first packet to FPGA..." << endl;
	socket.send_to(boost::asio::buffer(first_packet, 6), FPGA_endpoint);
	cout << "Packet sent." << endl;
	// Then, wait for a reply.
	
	boost::array<unsigned char, 1600> recv_buf;
	while(true)
	{
	   size_t bytes_recvd = recv_socket.receive(boost::asio::buffer(recv_buf, max_length));
	    if(bytes_recvd != 1)
	    {
		cout << "Warning: Received " << bytes_recvd << " bytes instead of the expected 1." << endl;
		if(bytes_recvd == 6)
		{
		   cout << "But oh, wait, 6 probably means that the FPGA is already set up in the relay mode. So let's go on." << endl;
		   break;
		}
	    }
	    else
	    {
		if(recv_buf[0] != 0xAA)
		{
		    cout << "Warning: Received 1 byte, but it was not the expected 0xAA." << endl;
		}
		else
		{
		    cout << "Connection seems to work both ways!" << endl;
		    break; // we got what we wanted.
		}
	    }
	}

	cout << "Give an unsigned integer. (8 bits.)" << endl;
	unsigned int number;
	cin >> number;
	packet_data[0] = number;

	cout << "Sending your number to FPGA..." << endl;
	socket.send_to(boost::asio::buffer(packet_data, 1), FPGA_endpoint);

	cout << "Packet sent, waiting for answer..." << endl;
	size_t received = recv_socket.receive(boost::asio::buffer(recv_buf, max_length));
	cout << "Received " << received << " bytes." << endl;
	if(received != 1)
	   cout << "Something is wrong, you should have received 1 byte." << endl;
	cout << "The received value is: " << (unsigned int)recv_buf[0] << endl;

	cout << "Let's move on and test more." << endl;

	cout << "Number of iterations?" << endl;
	unsigned long int iters = 0;
	cin >> iters;

	cout << "Length of the packet? (Maximum supported by HW is 1472)" << endl;
	unsigned int pkt_len = 0;
	cin >> pkt_len;

	cout << "Want to print everything? (Answer 0 or 1)" << endl;
	bool print = false;
	cin >> print;

	cout << "Sending and receiving..." << endl;
	unsigned long int i;
	for(i = 0; i < iters; i++)
	{
	   // Create some varying test data:
	   for(unsigned long int o = 0; o < pkt_len; o++)
	      packet_data[o] = (unsigned char)(o+i);

	   if(print)
	      cout << "Sending packet " << i << endl;
	   else
	      cout << "Sending packet " << i << "       \r" << flush;

	   socket.send_to(boost::asio::buffer(packet_data, pkt_len), FPGA_endpoint);
	   // if FPGA does not answer, we will get stuck here:
	   size_t rcvd = recv_socket.receive(boost::asio::buffer(recv_buf, max_length));
	   if(rcvd != pkt_len)
	      cout << "Mismatch in packet length (received " << rcvd << ")." << endl;
	   for(int o=0; o < pkt_len; o++)
	   {
	      unsigned char expected = packet_data[o]+1;
	      bool mismatch = (unsigned char) recv_buf[o] != expected;
	      if(mismatch)
		 cout << endl << "Data mismatch ";
	      if(mismatch || print)
		 cout << "at packet " << i << " on byte " << o << ": sent " << 
		    (unsigned int)packet_data[o] << ", expected " <<
		    (unsigned int)expected << ", received " << 
		    (unsigned int)recv_buf[o] << endl;
	   }
	}
	cout << endl << i << " packets sent and also received, believe or not!" << endl;

    }
    catch (std::exception& excep)
    {
	std::cerr << "Exception: " << excep.what() << endl;
    }

    return 0;

}



// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
