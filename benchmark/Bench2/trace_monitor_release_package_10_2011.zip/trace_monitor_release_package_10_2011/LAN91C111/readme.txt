Simple controller for SMSC LAN91C111 by Antti Alhonen. Uses the same interface
as DM9000A controller by Jussi Nieminen and can be connected to the UDP/IP
controller by Jussi Nieminen exactly in the same way.

LAN91C111 was much more complex to configure and use than DM9000A, thus
the area usage may be somewhat larger. I tried to compensate for extra
complexity by simplifying the structures I could simplify.

This has been tested for both send and receive operations with
different packet sizes.

You can disable either rx or tx if you don't need them. This is recommended
to avoid unneeded interrupts and to reduce area usage in case they are not
needed.
