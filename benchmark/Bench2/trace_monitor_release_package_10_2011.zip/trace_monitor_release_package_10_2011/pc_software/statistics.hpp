// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

// statistics.hpp
// Provides higher level of statistics by calling parsing functions
// from the parser module. Used by GUI and P2P Investigator.

#ifndef STATISTICS_HPP
#define STATISTICS_HPP

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>

#include "parser.hpp"

using namespace std;

#define MAX_INIT -2147483647
#define MIN_INIT 2147483647


const int MAX_NUM_PES = 81;

// An optional Decimation File can be generated from trace data.
// It is parsed and contains MIN, MAX and AVG values for every 
// NAVI_DECIMATION snapshots. When user zooms so that
// zoom region >= NAVI_DECIMATION_APPLY, decimated data is used.
//#define NAVI_DECIMATION 20
//#define NAVI_DECIMATION_APPLY 6000

const int DECIMATION_ZONES = 8;

const int NUM_LINK_WINDOWS = 2;

struct statistics
{
    statistics();

    int navi_decimation[DECIMATION_ZONES];
    int navi_decimation_apply[DECIMATION_ZONES];
    long int cur_decimation;
    bool decimate;

    int logging_length;
    
//    double* avg_counter_log;
    int* min_counter_log;
    int* max_counter_log;
    int* tot_counter_log;
    int* tot_avg_counter_accumulate;
    int* min_counter_accumulate;
    int* max_counter_accumulate;
    
    // *last_values contains num_of_last_values last values of link number last_values_link_num.
    int num_of_last_values;
    int max_num_of_last_values;
    int last_values_link_num[NUM_LINK_WINDOWS];
    int *last_values[NUM_LINK_WINDOWS];
   
    const processing_data* pd;
    int snap_counter;
    
    int initialize(const processing_data* proc_data);
    void free();
    void parse_and_analyze(const unsigned char* input_data);
    void parse_and_analyze_region(const unsigned char* input_data, const int snaps);
    
    bool realtime;
    
    
    bool accum_done;
       
    void create_decimation_file(ifstream& inp_stream, unsigned long int size, int num_of_snapshots, int deci);

    void analyze_deci_region(const unsigned char* input_data, const int points);

    bool rt_stop;
    int rt_captured;
    int rt_errors;
    int rt_missed;
    int rt_ignored;


};


#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
