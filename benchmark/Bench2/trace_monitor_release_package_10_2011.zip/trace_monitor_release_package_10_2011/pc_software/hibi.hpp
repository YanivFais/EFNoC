// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

#ifndef HIBI_HPP
#define HIBI_HPP

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>

#define HIBI_TRESHOLDED_COLORS 5

struct hibi
{
    hibi();

    int bus_colors[HIBI_TRESHOLDED_COLORS+1];
    int bus_widths[HIBI_TRESHOLDED_COLORS+1];
    int bus_color_tresholds[HIBI_TRESHOLDED_COLORS];

    int hibi_pe_ysize;
    int hibi_wra_ysize;
    int hibi_wra_xsize;
    int hibi_ag_xoffset;
    int hibi_bridge_ysize;
    int hibi_table_font_size;
    int hibi_table_ysize;
    int hibi_table_yspace;
    int hibi_pe_wra_yspace;
    int hibi_table_title_font_size;

    void draw_hibi();

};

#endif

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
