// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2010

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

// parser.cpp
// This module takes in raw binary data from the UDP packet and parses it
// to array of counter values or writes the values to disk as CSV (Comma
// Separated Values) file.
//
// This module also maintains the large amount of processing parameters 
// that describe the NoC and the monitoring system in order to parse
// the data correctly.


#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>

#include "parser.hpp"

using namespace std;

int processing_data::check_values()
{
    if(net_type < 0 || net_type > 1)
    {
	cerr << "Only net_types 0 (mesh etc.) and 1 (HIBI) supported." << endl;
	return 1;
    }

    if(window_length < 1 || window_length > 65535)
    {
	cerr << "Illegal window length " << window_length << endl;
	return 1;
    }

    if(num_of_agents < 1 || num_of_agents > 255)
    {
	cerr << "Illegal number of agents " << num_of_agents << endl;
	return 1;
    }

    if(net_type == 0 && (mesh_rows * mesh_cols != num_of_agents))
    {
	cerr << "mesh colums (" << mesh_cols << ") * mesh rows (" <<
	    mesh_rows << ") != num of agents (" << num_of_agents << ")!";
	return 1;
    }

    if(packet_length < 10 || packet_length > 1472)
    {
	cerr << "Illegal packet length " << packet_length << endl;
	return 1;
    }

    if(net_type == 1)
    {
	int ags_check = 0;
	for(int i = 0; i < hibi_segments; i++)
	{
	    ags_check += hibi_ags_seg[i];

	    if(hibi_ags_seg[i] < 1)
	    {
		cerr << "There must be at least one agent in every HIBI segment." << endl;
		return 1;
	    }
	}
	
	if(ags_check != num_of_agents)
	{
	    cerr << "num_of_agents " << num_of_agents << " does not match the total number of agents in all hibi segments " << ags_check << endl;
	    return 1;
	}

    }

    return 0;
  
}

int processing_data::calculate_values()
{
    cout << "---- processing parameters ----" << endl;
    cout << "(Please check that these match with the ones used in HW.)" << endl;
    counter_bits = ceil(log2(window_length+1));
    cout << "counter_bits = " << counter_bits << endl;
    if(net_type == 0) 
	counters_per_link = 2; // mesh etc: READ, NOT READ
    else if(net_type == 1)
	counters_per_link = 3; // hibi: DATA, MSG, FULL
   
    switch(net_type)
    {
	case 0: cout << "MESH etc."; 
	    num_of_links = mesh_cols*mesh_rows*8 -  // For overhead monitoring, 4 links router<->PE instead of 2.
		mesh_cols*2 - mesh_rows*2;
	    num_of_extra_counters = 0;
	    num_of_counters = counters_per_link*num_of_links+num_of_extra_counters;
	    break;
	case 1: cout << "HIBI";

	    // compute number of agents per segment including bridge wrappers. Middle segments have two extra wrappers, others 1,
	    // or 0 when there is only one segment.
	    for(int i = 0; i < hibi_segments; i++)
		hibi_ags_incl_bri_seg[i] = hibi_ags_seg[i] + (  (hibi_segments > 1) ? (1+((i>0&&i<(hibi_segments-1))?1:0))  :  0   );

	    num_of_links = 99999; // this shouldn't be used with hibi.
	    num_of_extra_counters = 1; // bus idle counter
	    num_of_counters = 0;
	    for(int i = 0; i < hibi_segments; i++)
	    {
		hibi_counters_per_seg[i] = counters_per_link*hibi_ags_incl_bri_seg[i]*(hibi_ags_incl_bri_seg[i]-1);
		num_of_counters += hibi_counters_per_seg[i] + num_of_extra_counters;
	    }
	    break;
	default: cout << "???"; break;
    }
    cout << " type NoC with " << num_of_agents << " agents: ";
    cout << num_of_links << " links with " << counters_per_link << " counters per link." << endl;
    cout << "num_of_counters = " << num_of_counters << endl;
    data_per_snapshot = counter_bits*num_of_counters;
    cout << "data_per_snapshot = " << data_per_snapshot << " (bits)" << endl;
    padding_per_snapshot = 16 - (data_per_snapshot % 16);
    if(padding_per_snapshot == 16)
	padding_per_snapshot = 0;
    cout << "padding_per_snapshot = " << padding_per_snapshot << " (bits)" << endl;
    snapshot_length = data_per_snapshot + padding_per_snapshot;
    cout << "snapshot_length = " << snapshot_length << " (bits)" << endl;
    snapshot_bytes = snapshot_length/8;
    cout << "snapshot_bytes = " << snapshot_bytes << endl;
    snapshots_per_packet = packet_length/snapshot_bytes;
    cout << "snapshots_per_packet = " << snapshots_per_packet << endl;
    cout << "packet length rounded: " << packet_length << " ====> ";
    packet_length = snapshots_per_packet*snapshot_bytes;
    cout << packet_length << endl;

    double Mbps = (((double)clock_hz / (double)window_length)*(double)snapshot_length)/1000000.0;
    cout << "Payload data: " << setprecision(4) << Mbps << " Mbps" << endl;

    cout << "---- end of processing parameters ----" << endl << endl;
  
    //    char turha;
    //    cin >> turha;
    return 0;
}


/*********************
int parse_snapshot(...)

Parse one snapshot from given data, either file stream or memory pointer.
Outputs the counter data, either in binary directly to a memory pointer,
or in ASCII to a file stream. Counters are in the same order as in input,
so this works with any network and further parsing may be needed to sort
the counters.

Counters longer than 32 bits not supported.

int input_mode:
  0 = read from memory using const unsigned char* pointer data
  1 = read from file using ifstream* pointer data_file

int output_mode:
  0 = write counters to memory using int* pointer counters
  1 = write counters to file ofstream* output_file

const char delimiter:
  when output_mode = 1 (csv file), character inserted between values (usually comma).

const processing_data* pd:
  pointer to the necessary information how to parse the data.

return:
0 when ok
1 when input file ended unexpectedly

***********************/
int parse_snapshot(int input_mode, const unsigned char* data, ifstream* data_file,
		   int output_mode, int* counters, ofstream* output_file,
		   const char delimiter, const processing_data* pd)
{

    unsigned char * bytes_tmp;
    if(input_mode == 1)  // Read from file, so we need to allocate memory here for temp storage.
    {
	bytes_tmp = new unsigned char[pd->snapshot_bytes];
	for(int byte=0; byte < pd->snapshot_bytes; byte++)
	{
	    bytes_tmp[byte] = (*data_file).get();
	}
	data = bytes_tmp; // set the data pointer to the data we just read.
    }


    // Now, "data" pointer points to the real data in both input cases.

    int * counters_tmp;
    if(output_mode == 1) // Write to file, so we need to allocate memory here for temp storage.
    {
	counters_tmp = new int[pd->num_of_counters];
	counters = counters_tmp; // set the output pointer to this memory.
    }
    
    // Now, "counters" pointer points to either this function's local memory or the address
    // given as argument.

    // Do the actual parsing (counter extraction):
    int bit_counter = 0;  
    for(int counter = 0; counter < pd->num_of_counters; counter++)
    {
	counters[counter] = 0; // Zero the counter before adding bits.
	for(int bit = 0; bit < pd->counter_bits; bit++)
	{
	    counters[counter] += (data[bit_counter/8] & (1<<bit_counter%8)) >> bit_counter%8
		// here, first we took one bit from data, that is, bit_counter%8th bit. This is
		// either 1 or 0.
							  << bit;
	    // Then we gave it the magnitude of "bit" and added it to counter.
	    bit_counter++; // bit_counter tells us how many bits from the WHOLE data table has been read.
	}
    }


    // Write the counters to file if needed.
    if(output_mode == 1)
    {
	for(int counter = 0; counter < pd->num_of_counters; counter++)
	{
	    *output_file << counters[counter];
	    // No delimiter after the final value.
	    if(counter < pd->num_of_counters-1)
		(*output_file).put(delimiter);
	}
    }


    if(input_mode == 1)
    {
	delete bytes_tmp;
	bytes_tmp = 0;
    }
    data = 0;


    if(input_mode == 1)
    {
	if((*data_file).eof())
	    return 1;
    }

    return 0;

}

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
