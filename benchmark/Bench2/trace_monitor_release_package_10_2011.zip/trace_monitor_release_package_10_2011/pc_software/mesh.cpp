// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.


#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <assert.h>

#include <SFML/Graphics.hpp>

#include "parser.hpp"
#include "mesh.hpp"
#include "statistics.hpp"
#include "gui.hpp"


mesh::mesh(statistics* statsjoo, gui* guijoo, sf::RenderWindow& window) :
    stats_(statsjoo), gui_(guijoo), win(window)
{
    mesh_routing = YX_ROUTING;
}

//    char mesh_link_names[MAX_NUM_LINKS][MAX_LINK_NAME_LEN];
void mesh::create_mesh_link_names()
{
    int link = 0;
    int pe = 0;
    for(int row = 0; row < stats_->pd->mesh_rows; row++)
    {
	for(int col = 0; col < stats_->pd->mesh_cols; col++)
	{
	    if(col < stats_->pd->mesh_cols-1)
	    {
		sprintf(mesh_link_names[link], "Router %d,%d -> Router %d,%d", row, col, row, col+1);
		mesh_link_numbers_to_right[row][col] = link;
		vect_indeces_router_links.push_back(link);
		link++;

		sprintf(mesh_link_names[link], "Router %d,%d -> Router %d,%d", row, col+1, row, col);
		mesh_link_numbers_to_left[row][col+1] = link;
		vect_indeces_router_links.push_back(link);
		link++;
	    }
	    if(row < stats_->pd->mesh_rows-1)
	    {
		sprintf(mesh_link_names[link], "Router %d,%d -> Router %d,%d", row, col, row+1, col);
		mesh_link_numbers_to_down[row][col] = link;
		vect_indeces_router_links.push_back(link);
		link++;

		sprintf(mesh_link_names[link], "Router %d,%d -> Router %d,%d", row+1, col, row, col);
		mesh_link_numbers_to_up[row+1][col] = link;
		vect_indeces_router_links.push_back(link);
		link++;
	    }
	    
	    sprintf(mesh_link_names[link], "Router %d,%d -> %s", row, col, gui_->name_tags[pe]);
	    mesh_pe_datalink_indeces_in_with_overhead[row][col] = link;
	    vect_indeces_pe_overhead_links.push_back(link);
	    link++;

	    sprintf(mesh_link_names[link], "%s -> Router %d,%d", gui_->name_tags[pe], row, col);
	    mesh_pe_datalink_indeces_out_with_overhead[row][col] = link;
	    vect_indeces_pe_overhead_links.push_back(link);
	    link++;

	    mesh_pe_datalink_indeces_in_no_overhead[row][col] = link;
	    vect_indeces_pe_no_overhead_links.push_back(link);
	    link++;
	    mesh_pe_datalink_indeces_out_no_overhead[row][col] = link;
	    vect_indeces_pe_no_overhead_links.push_back(link);
	    link++;

	    pe++;
	    
	}
    }

    assert(link == stats_->pd->num_of_links);

/*
  for(int i = 0; i < stats_->pd->num_of_links; i++)
  {
  cout << "DEBUG: Name of link " << i << " = " << mesh_link_names[i] << endl;
  }
*/

}

int mesh::check_mesh_vis_values()
{
    /*  if(router_xsize < ROUTER_COORD_TEXT_WIDTH || router_xsize > 20 ||
	router_ysize < 1 || router_ysize > 10 || router_xspace < 5 ||
	router_yspace < 3 || pe_xsize > 20 || pe_xsize < 0 || pe_ysize > 15 ||
	pe_ysize < 0 || pe_xoffset > 30 || pe_xoffset < -30 || pe_yoffset > 30 ||
	pe_yoffset < -30 || left_margin < 0 || left_margin > 30 || top_margin < 0 ||
	top_margin > 20)
	{
	cerr << "Illegal mesh visualization parameters in config file!" << endl;
	cerr << router_xsize << " " << router_ysize << " " << router_xspace << " " <<
	router_yspace << " " << pe_xsize << " " << pe_ysize << " " << pe_xoffset << " " <<
	pe_yoffset << " " << left_margin << " " << top_margin << endl;
	return 1;
	}

	for(int i = 0; i < 5; i++)
	{
	if(router_colors[i] < 0 || router_colors[i] > 7 || link_colors[i] < 0 || link_colors[i] > 7)
	{
	cerr << "Illegal mesh visualization parameters (colors) in config file!" << endl;
	return 1;
	} 
	}
	for(int i = 0; i < 4; i++)
	{
	if(router_color_tresholds[i] < 0 || router_color_tresholds[i] > 100 ||
	link_color_tresholds[i] < 0 || link_color_tresholds[i] > 100)
	{
	cerr << "Illegal mesh visualization parameters (color tresholds) in config file!" << endl;
	return 1;
	} 
	}
    */
    return 0;
}

#define TOT_DATA(idx) ((stats_->decimate)?(stats_->cur_decimation*stats_->tot_counter_log[(idx)]*stats_->pd->window_length/255):(stats_->tot_counter_log[(idx)]))

void mesh::draw_mesh()
{
    int xloop;
    int yloop;

    static bool text_blink_state = false;

    int tmp1, tmp2, tmp3, tmp4;

    // MESH counters are interleaved like this:
    // Link 0 data
    // Link 0 stall
    // Link 1 data
    // Link 1 stall
    // ...
    // So, pointers are indexed with increment of 2.

    const int* link_datas;
    const int* link_stalls;
    const int* worst_link_datas;
    const int* worst_link_stalls;

    // These are used to determine if links can be drawn as totally idle.
    worst_link_datas  = &stats_->max_counter_log[0];
    worst_link_stalls = &stats_->max_counter_log[1];

    bool avg = false;
    if(gui_->averaging_mode == MODE_WORST)
    {
	link_datas  = &stats_->max_counter_log[0];
	link_stalls = &stats_->max_counter_log[1];
    }
    else if(gui_->averaging_mode == MODE_AVG)
    {
	link_datas  = &stats_->tot_counter_log[0];
	link_stalls = &stats_->tot_counter_log[1];
	avg = true;
    }
    else if(gui_->averaging_mode == MODE_BEST)
    {
	link_datas  = &stats_->min_counter_log[0];
	link_stalls = &stats_->min_counter_log[1];
    }
    else
    {
	link_datas = &stats_->tot_counter_log[0];
	link_stalls = &stats_->tot_counter_log[1];
    }

    const int* tot_datas = &stats_->tot_counter_log[0];
    const int* tot_stalls = &stats_->tot_counter_log[1];

    sf::Color* link_col;
    sf::Color* text_col;
    link_col = new sf::Color[stats_->pd->num_of_links];
    text_col = new sf::Color[stats_->pd->num_of_links];

    char** stall_percentages;
    char** data_percentages;
    int* line_widths;

    stall_percentages = new char*[stats_->pd->num_of_links];
    data_percentages = new char*[stats_->pd->num_of_links];
    line_widths = new int[stats_->pd->num_of_links];

    for(int i=0; i<stats_->pd->num_of_links; i++)
    {
	stall_percentages[i] = new char[10];
	data_percentages[i] = new char[10];
    }


    double fval;
  
    int pnt = 0;
    for(int i = 0; i < stats_->pd->num_of_links; i++)
    {
	int index_data = i*stats_->pd->counters_per_link;
	int index_stall = index_data+1;
	double min_data = (stats_->min_counter_log[index_data]*100.0)/((stats_->decimate)?255:stats_->pd->window_length);
	double max_data = (stats_->max_counter_log[index_data]*100.0)/((stats_->decimate)?255:stats_->pd->window_length);
	double avg_data = ((stats_->tot_counter_log[index_data]*100.0)/((stats_->decimate)?255:stats_->pd->window_length))/
	    gui_->nav_bar.zoom_region;
	
	unsigned long long int total_data = TOT_DATA(index_data); 
	
	double min_stall = (stats_->min_counter_log[index_stall]*100.0)/((stats_->decimate)?255:stats_->pd->window_length);
	double max_stall = (stats_->max_counter_log[index_stall]*100.0)/((stats_->decimate)?255:(stats_->pd->window_length));
	double avg_stall = ((stats_->tot_counter_log[index_stall]*100.0)/((stats_->decimate)?255:stats_->pd->window_length))/
	    gui_->nav_bar.zoom_region;
	unsigned long long int total_stall = stats_->tot_counter_log[index_stall];
	if(stats_->decimate)
	{
	    total_stall *= stats_->pd->window_length;
	    total_stall /= 255;
	}
	
	if(stats_->decimate)
	{
	    avg_data *= stats_->cur_decimation;
	    avg_stall *= stats_->cur_decimation;
	    total_stall *= stats_->cur_decimation;
	}
	
	double val_d, val_s;

	if(gui_->averaging_mode == MODE_TOTAL)
	{
	    val_d = avg_data;
	    val_s = avg_stall;
	}
	else if(gui_->averaging_mode == MODE_AVG)
	{
	    val_d = avg_data;
	    val_s = avg_stall;
	}
	else if(gui_->averaging_mode == MODE_BEST)
	{
	    val_d = min_data;
	    val_s = min_stall;
	}
	else if(gui_->averaging_mode == MODE_WORST)
	{
	    val_d = max_data;
	    val_s = max_stall;
	}
	
	// COMPUTE LINK COLORS AND TEXTS
	if(worst_link_datas[pnt] == 0 && worst_link_stalls[pnt] == 0)
	{
	    // Totally inactive link. No data, no stalling
	    link_col[i] = link_colors[0];
	    if(gui_->averaging_mode == MODE_TOTAL)
		sprintf(stall_percentages[i], "   0");
	    else
		sprintf(stall_percentages[i], "    ");
	}
	else
	{
	    // Else colorize link depending on stalling.
	    if(gui_->averaging_mode == MODE_TOTAL)
		print_int_with_postfix(total_stall, stall_percentages[i]);
	    else
		sprintf(stall_percentages[i], (val_s<10.0)?"%3.1f%%":"%3.0f%%", val_s);

	    link_col[i] = link_colors[TRESHOLDED_COLORS];
	    for(int c = 1; c < TRESHOLDED_COLORS+1; c++)
	    {
		if(val_s < link_color_tresholds[c])
		{
		    link_col[i] = link_colors[c];
		    break;
		}
	    }
	}

	// COMPUTE TEXTS NEXT TO LINKS AND THEIR COLORS
	if(worst_link_datas[pnt] == 0)
	{
	    text_col[i] = link_colors[0]*sf::Color(180,180,180);
	    sprintf(data_percentages[i], "   0");
	}
	else
	{
	    if(gui_->averaging_mode == MODE_TOTAL)
		print_int_with_postfix(total_data, data_percentages[i]);
	    else
		sprintf(data_percentages[i], (val_d<10.0)?"%3.1f%%":"%3.0f%%", val_d);

	    text_col[i] = link_colors[TRESHOLDED_COLORS];
	    for(int c = 1; c < TRESHOLDED_COLORS+1; c++)
	    {
		if(val_d < link_color_tresholds[c])
		{
		    text_col[i] = link_colors[c]*sf::Color(180,180,180);
		    break;
		}
	    }
	}

	// COMPUTE LINK WIDTHS
	if(link_datas[pnt] == 0)
	{
	    line_widths[i] = link_widths[0];
	}
	else
	{
	    line_widths[i] = link_widths[TRESHOLDED_COLORS];
	    for(int c = 1; c < TRESHOLDED_COLORS+1; c++)
	    {
		if(val_d < link_width_tresholds[c])
		{
		    line_widths[i] = link_widths[c];
		    break;
		}
	    }
	}


      
	pnt += 2;
    }

    sf::Color *pe_col;
    sf::Color *router_col;

    pe_col = new sf::Color[stats_->pd->num_of_agents];
    router_col = new sf::Color[stats_->pd->num_of_agents];

    const int num_router_subtexts = 6;

    char ***router_subtexts = new char**[num_router_subtexts];

    for(int sub_init = 0; sub_init < num_router_subtexts; sub_init++)
    {
	router_subtexts[sub_init] = new char*[stats_->pd->num_of_agents];

	for(int i = 0; i < stats_->pd->num_of_agents; i++)
	    router_subtexts[sub_init][i] = new char[45];
    }



    // Variables for counting data amounts on per router basis.
    unsigned long long int * links_in = new unsigned long long int[stats_->pd->num_of_agents];
    unsigned long long int * links_out = new unsigned long long int[stats_->pd->num_of_agents];
    unsigned long long int * to_pe_with_overhead = new unsigned long long int[stats_->pd->num_of_agents];
    unsigned long long int * from_pe_with_overhead = new unsigned long long int[stats_->pd->num_of_agents];
    unsigned long long int * to_pe_no_overhead = new unsigned long long int[stats_->pd->num_of_agents];
    unsigned long long int * from_pe_no_overhead = new unsigned long long int[stats_->pd->num_of_agents];
    signed long long int * overhead_tx = new signed long long int[stats_->pd->num_of_agents];
    signed long long int * overhead_rx = new signed long long int[stats_->pd->num_of_agents];


    // COMPUTE PE AND ROUTER COLORS and zero above counters
    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	pe_col[i] = sf::Color(100, 130, 180);
	router_col[i] = sf::Color(255,255,255);
	links_in[i] = 0;
	links_out[i] = 0;
	to_pe_with_overhead[i] = 0;
	from_pe_with_overhead[i] = 0;
	to_pe_no_overhead[i] = 0;
	from_pe_no_overhead[i] = 0;
	overhead_tx[i] = 0;
	overhead_rx[i] = 0;
    }

    // Colorize routers and PEs by routing algorithm depending on link selected
    // TODO: XY routing


    int cur_link_num = 0;
    int cur_router = 0;
    const sf::Color GOOD_ROUTING_COLOR_FROM = sf::Color(220, 80, 10);
    const sf::Color GOOD_ROUTING_COLOR_TO = sf::Color(80, 220, 10);
    for(yloop = 0; yloop < stats_->pd->mesh_rows; yloop++)
    {
	for(xloop = 0; xloop < stats_->pd->mesh_cols; xloop++)
	{
	    if(xloop > 0)
	    {
		// To left
		// From left
	    }
	    if(yloop > 0)
	    {
		// To up 
		// From up
	    }
	    if(xloop < stats_->pd->mesh_cols-1)
	    {
		// To right
		if(cur_link_num == stats_->last_values_link_num[0])
		{
		    if(mesh_routing == YX_ROUTING)
		    {
			int i = 0;
			do pe_col[cur_router+(++i)] = GOOD_ROUTING_COLOR_TO;
			while(xloop + i < stats_->pd->mesh_cols-1);

			for(int xx = xloop; xx >= 0; xx--)
			    for(int yy = 0; yy < stats_->pd->mesh_rows; yy++)
				pe_col[yy*stats_->pd->mesh_cols+xx] = GOOD_ROUTING_COLOR_FROM;
		      
		    }
		}


		cur_link_num++;

		// From right
		if(cur_link_num == stats_->last_values_link_num[0])
		{
		    if(mesh_routing == YX_ROUTING)
		    {
			int i = 0;
			do pe_col[cur_router-(i++)] = GOOD_ROUTING_COLOR_TO;
			while(xloop - i >= 0);		      

			for(int xx = xloop+1; xx < stats_->pd->mesh_cols; xx++)
			    for(int yy = 0; yy < stats_->pd->mesh_rows; yy++)
				pe_col[yy*stats_->pd->mesh_cols+xx] = GOOD_ROUTING_COLOR_FROM;

		    }
		}
		cur_link_num++;

	    }
	    if(yloop < stats_->pd->mesh_rows-1)
	    {
		// To down
		if(cur_link_num == stats_->last_values_link_num[0])
		{
		    if(mesh_routing == YX_ROUTING)
		    {
			for(int xx = 0; xx < stats_->pd->mesh_cols; xx++)
			    for(int yy = yloop+1; yy < stats_->pd->mesh_rows; yy++)
				pe_col[yy*stats_->pd->mesh_cols+xx] = GOOD_ROUTING_COLOR_TO;
		      
			for(int yy = yloop; yy >= 0; yy--)
			    pe_col[yy*stats_->pd->mesh_cols+xloop] = GOOD_ROUTING_COLOR_FROM;
		    }
		}
		cur_link_num++;

		// From down
		if(cur_link_num == stats_->last_values_link_num[0])
		{
		    if(mesh_routing == YX_ROUTING)
		    {
			for(int xx = 0; xx < stats_->pd->mesh_cols; xx++)
			    for(int yy = yloop; yy >= 0; yy--)
				pe_col[yy*stats_->pd->mesh_cols+xx] = GOOD_ROUTING_COLOR_TO;

			for(int yy = yloop+1; yy < stats_->pd->mesh_rows; yy++)
			    pe_col[yy*stats_->pd->mesh_cols+xloop] = GOOD_ROUTING_COLOR_FROM;

		    }
		}

		cur_link_num++;

	    }

	    cur_link_num++;
	    cur_link_num++;
	    cur_link_num++;
	    cur_link_num++;

	    cur_router++;
	}
    }



    // COMPUTE ROUTER TEXTS
    cur_link_num = 0;
    cur_router = 0;
    for(yloop = 0; yloop < stats_->pd->mesh_rows; yloop++)
    {
	for(xloop = 0; xloop < stats_->pd->mesh_cols; xloop++)
	{
	    if(xloop > 0)
	    {
		// To left
		// From left
	    }
	    if(yloop > 0)
	    {
		// To up 
		// From up
	    }
	    if(xloop < stats_->pd->mesh_cols-1)
	    {
		// To right
		links_out[cur_router] += TOT_DATA(cur_link_num*2);
		links_in[cur_router+1] += TOT_DATA(cur_link_num*2);
		cur_link_num++;

		// From right
		links_in[cur_router] += TOT_DATA(cur_link_num*2);
		links_out[cur_router+1] += TOT_DATA(cur_link_num*2);
		cur_link_num++;

	    }
	    if(yloop < stats_->pd->mesh_rows-1)
	    {
		// To down
		links_out[cur_router] += TOT_DATA(cur_link_num*2);
		links_in[cur_router+stats_->pd->mesh_cols] += TOT_DATA(cur_link_num*2);
		cur_link_num++;

		// From down
		links_in[cur_router] += TOT_DATA(cur_link_num*2);
		links_out[cur_router+stats_->pd->mesh_cols] += TOT_DATA(cur_link_num*2);
		cur_link_num++;

	    }

	    to_pe_with_overhead[cur_router] += TOT_DATA(cur_link_num*2);
	    cur_link_num++;

	    from_pe_with_overhead[cur_router] += TOT_DATA(cur_link_num*2);
	    cur_link_num++;

	    to_pe_no_overhead[cur_router] += TOT_DATA(cur_link_num*2);
	    cur_link_num++;

	    from_pe_no_overhead[cur_router] += TOT_DATA(cur_link_num*2);
	    cur_link_num++;


	    cur_router++;
	}
    }

    // Calculate overheads based on link data and PE data
    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	overhead_tx[i] = from_pe_with_overhead[i] - from_pe_no_overhead[i];
	overhead_rx[i] = to_pe_with_overhead[i] - to_pe_no_overhead[i];
    }


    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	char temp[10], temp2[10];
	print_int_with_postfix(links_in[i], temp, 2);
	sprintf(router_subtexts[0][i], "Links in: %s", temp);
      
	print_int_with_postfix(links_out[i], temp, 2);
	sprintf(router_subtexts[1][i], "Links out: %s", temp);
      
	print_int_with_postfix(to_pe_with_overhead[i], temp, 2);
//      print_int_with_postfix(to_pe_no_overhead[i], temp2, 2);
//      sprintf(router_subtexts[2][i], "To PE: %s (%s)", temp, temp2);
	sprintf(router_subtexts[2][i], "To PE: %s", temp);
      
	print_int_with_postfix(from_pe_with_overhead[i], temp, 2);
//      print_int_with_postfix(from_pe_no_overhead[i], temp2, 2);
//      sprintf(router_subtexts[3][i], "From PE: %s (%s)", temp, temp2);
	sprintf(router_subtexts[3][i], "From PE: %s", temp);
      
	if(overhead_rx[i] < 0) overhead_rx[i] = 0;
	print_int_with_postfix(overhead_rx[i], temp, 2);
	sprintf(router_subtexts[4][i], "RX overhead: %s", temp);

	if(overhead_tx[i] < 0) overhead_tx[i] = 0;
	print_int_with_postfix(overhead_tx[i], temp, 2);
	sprintf(router_subtexts[5][i], "TX overhead: %s", temp);  
    }



    cur_link_num = 0;
    cur_router = 0;

    const sf::Color ROUTER_COL      = sf::Color(255,255,255);
    const int       ROUTER_LINE_W   = 2;
    const sf::Color ROUTER_LINE_COL = sf::Color(0,0,0);

    // Draw rectangle showing selected link.
    sf::Shape linksel_rect1 = sf::Shape::Rectangle(mesh_link_click_coords[stats_->last_values_link_num[0]][0],
				       mesh_link_click_coords[stats_->last_values_link_num[0]][1],
				       mesh_link_click_coords[stats_->last_values_link_num[0]][2],
				       mesh_link_click_coords[stats_->last_values_link_num[0]][3],
				       sf::Color(0,0,0),
				       1,
				       sf::Color(100,100,100));
    linksel_rect1.EnableFill(false);

    sf::Shape linksel_rect2 = sf::Shape::Rectangle(mesh_link_click_coords[stats_->last_values_link_num[1]][0],
				       mesh_link_click_coords[stats_->last_values_link_num[1]][1],
				       mesh_link_click_coords[stats_->last_values_link_num[1]][2],
				       mesh_link_click_coords[stats_->last_values_link_num[1]][3],
				       sf::Color(0,0,0),
				       1,
				       sf::Color(150,150,150));
    linksel_rect2.EnableFill(false);

    win.Draw(linksel_rect1);
    win.Draw(linksel_rect2);

    const sf::Font& font = gui_->def_font;



    // PRINT ROUTERS AND PE'S
    for(yloop = 0; yloop < stats_->pd->mesh_rows; yloop++)
    {
	for(xloop = 0; xloop < stats_->pd->mesh_cols; xloop++)
	{
	    // Draw router
	    win.Draw(sf::Shape::Rectangle(left_margin+xloop*(router_xsize+router_xspace),
					  gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)),
					  left_margin+xloop*(router_xsize+router_xspace)+router_xsize,
					  gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize),
					  sf::Color(255,255,255),
					  3, sf::Color(0,0,0)));
  
	  
	    // Print router coordinates:
	    char tmp[10];
	    sprintf(tmp, "%d, %d", yloop, xloop);
	    sf::String str_coords(tmp, font, router_coord_font_size);
	    str_coords.SetPosition(left_margin+xloop*(router_xsize+router_xspace)+10, 
				   gui_->vis_window_ysize-
				   (bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize-10-router_coord_font_size)-router_coord_font_size-6);
	    str_coords.SetColor(sf::Color(0,0,0));
	    win.Draw(str_coords);
	
	    // Print router subtexts:
	
	    for(int i = 0; i < num_router_subtexts-2; i++)
	    {    
		sf::String subtext(router_subtexts[i+2][cur_router], font, gui_->small_font_size);
		subtext.SetPosition(left_margin+xloop*(router_xsize+router_xspace)+10,
				    gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+
							    router_ysize-10-router_coord_font_size-5
							    -gui_->small_font_size-3-i*(gui_->small_font_size+1+2))-gui_->small_font_size-6);
		subtext.SetColor(sf::Color(0,0,0));
		win.Draw(subtext);
	    }

	    // Draw PE
	    gui_->PE_click_coords[cur_router][0] = left_margin+xloop*(router_xsize+router_xspace)+router_xsize+pe_xoffset;
	    gui_->PE_click_coords[cur_router][1] = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*
									   (router_ysize+router_yspace)+router_ysize+pe_yoffset);
	    gui_->PE_click_coords[cur_router][2] = left_margin+xloop*(router_xsize+router_xspace)+router_xsize+pe_xoffset+pe_xsize;
	    gui_->PE_click_coords[cur_router][3] = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*
									   (router_ysize+router_yspace)+router_ysize+pe_yoffset+pe_ysize);
	
	    win.Draw(sf::Shape::Rectangle(gui_->PE_click_coords[cur_router][0], gui_->PE_click_coords[cur_router][1],
					  gui_->PE_click_coords[cur_router][2], gui_->PE_click_coords[cur_router][3],
					  pe_col[cur_router]));


	    // Print PE title

	    sf::String pe_title(gui_->name_tags[yloop*stats_->pd->mesh_cols+xloop], font, pe_title_font_size);
	    pe_title.SetPosition(left_margin+xloop*(router_xsize+router_xspace)+router_xsize+pe_xoffset+10,
				 gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+
							 router_ysize+pe_yoffset+pe_ysize-pe_title_font_size-10)-pe_title_font_size-6);
	    pe_title.SetColor(sf::Color(0,0,0));
	    win.Draw(pe_title);
	  

	    // Draw arrows
	    sf::String data_str;
	    sf::String stall_str;

	    data_str.SetFont(font);
	    data_str.SetSize(data_percentage_font_size);
	    stall_str.SetFont(font);
	    stall_str.SetSize(stall_percentage_font_size);
	    stall_str.SetColor(sf::Color(0,0,0));
	    const sf::Color TOT_MODE_COL = sf::Color(0,0,0);

	    if(xloop < stats_->pd->mesh_cols-1)
	    {
		// To right
		arrow(win, left_margin+xloop*(router_xsize+router_xspace)+router_xsize, 
		      gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize*2/3),
		      left_margin+xloop*(router_xsize+router_xspace)+router_xsize+router_xspace-2,
		      gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize*2/3), 8,
		      line_widths[cur_link_num], link_col[cur_link_num]);

		mesh_link_click_coords[cur_link_num][0] = left_margin+xloop*(router_xsize+router_xspace)+router_xsize;
		mesh_link_click_coords[cur_link_num][1] = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*
										  (router_ysize+router_yspace)+router_ysize*2/3+12);
		mesh_link_click_coords[cur_link_num][2] = left_margin+xloop*(router_xsize+router_xspace)+router_xsize+router_xspace-2;
		mesh_link_click_coords[cur_link_num][3] = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*
										  (router_ysize+router_yspace)+router_ysize*2/3-12);

		// Data amount:
		data_str.SetPosition(left_margin+xloop*(router_xsize+router_xspace)+router_xsize+router_xspace/2-15,
				     gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize*2/3));
		data_str.SetText(data_percentages[cur_link_num]);
		data_str.SetColor((gui_->averaging_mode == MODE_TOTAL)?TOT_MODE_COL:text_col[cur_link_num]);
		win.Draw(data_str);

		// Stall amount:
		stall_str.SetPosition(left_margin+xloop*(router_xsize+router_xspace)+router_xsize+router_xspace/2-15,
				      gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize*2/3+stall_percentage_font_size-4));
		stall_str.SetText(stall_percentages[cur_link_num]);
		win.Draw(stall_str);
		   

		cur_link_num++;

		// From right
		arrow(win, left_margin+xloop*(router_xsize+router_xspace)+router_xsize+router_xspace, 
		      gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize/3),
		      left_margin+xloop*(router_xsize+router_xspace)+router_xsize+2,
		      gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize/3), 8,
		      line_widths[cur_link_num], link_col[cur_link_num]);

		mesh_link_click_coords[cur_link_num][0] = left_margin+xloop*(router_xsize+router_xspace)+router_xsize+2;
		mesh_link_click_coords[cur_link_num][1] = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize/3+12);
		mesh_link_click_coords[cur_link_num][2] = left_margin+xloop*(router_xsize+router_xspace)+router_xsize+router_xspace;
		mesh_link_click_coords[cur_link_num][3] = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize/3-12);


		// Data amount:
		data_str.SetPosition(left_margin+xloop*(router_xsize+router_xspace)+router_xsize+router_xspace/2-15,
				     gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize/3-4));
		data_str.SetText(data_percentages[cur_link_num]);
		data_str.SetColor((gui_->averaging_mode == MODE_TOTAL)?TOT_MODE_COL:text_col[cur_link_num]);
		win.Draw(data_str);


		// Stall amount:

		stall_str.SetPosition(left_margin+xloop*(router_xsize+router_xspace)+router_xsize+router_xspace/2-15, gui_->vis_window_ysize-(
					  bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize/3+stall_percentage_font_size-4));
		stall_str.SetText(stall_percentages[cur_link_num]);
		win.Draw(stall_str);


		cur_link_num++;
	    }

	    if(yloop < stats_->pd->mesh_rows-1)
	    {
		// To down
		arrow(win, left_margin+xloop*(router_xsize+router_xspace)+router_xsize/3,
		      gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)),
		      left_margin+xloop*(router_xsize+router_xspace)+router_xsize/3,
		      gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)-router_yspace+2), 8,
		      line_widths[cur_link_num], link_col[cur_link_num]);


		mesh_link_click_coords[cur_link_num][0] = left_margin+xloop*(router_xsize+router_xspace)+router_xsize/3-15;
		mesh_link_click_coords[cur_link_num][1] = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace));
		mesh_link_click_coords[cur_link_num][2] = left_margin+xloop*(router_xsize+router_xspace)+router_xsize/3+15;
		mesh_link_click_coords[cur_link_num][3] = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)-router_yspace+2);


		// Data amount:
		data_str.SetPosition(left_margin+xloop*(router_xsize+router_xspace)+router_xsize/3-data_percentage_font_size*3,
				     gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)-router_yspace/2-data_percentage_font_size/2+24));
		data_str.SetText(data_percentages[cur_link_num]);
		data_str.SetColor((gui_->averaging_mode == MODE_TOTAL)?TOT_MODE_COL:text_col[cur_link_num]);
		win.Draw(data_str);


		// Stall amount:
		stall_str.SetPosition(left_margin+xloop*(router_xsize+router_xspace)+router_xsize/3-stall_percentage_font_size, gui_->vis_window_ysize-(
					  bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)-router_yspace/2-data_percentage_font_size/2+11));
		stall_str.SetText(stall_percentages[cur_link_num]);
		win.Draw(stall_str);


		cur_link_num++;

		// To up
		arrow(win, left_margin+xloop*(router_xsize+router_xspace)+router_xsize*2/3,
		      gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)-router_yspace),
		      left_margin+xloop*(router_xsize+router_xspace)+router_xsize*2/3,
		      gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)-2), 8,
		      line_widths[cur_link_num], link_col[cur_link_num]);


		mesh_link_click_coords[cur_link_num][0] = left_margin+xloop*(router_xsize+router_xspace)+router_xsize*2/3-15;
		mesh_link_click_coords[cur_link_num][1] = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace));
		mesh_link_click_coords[cur_link_num][2] = left_margin+xloop*(router_xsize+router_xspace)+router_xsize*2/3+15;
		mesh_link_click_coords[cur_link_num][3] = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)-router_yspace+2);


		// Data amount:
		data_str.SetPosition(left_margin+xloop*(router_xsize+router_xspace)+router_xsize*2/3+12,
				     gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)-router_yspace/2-data_percentage_font_size/2+24));
		data_str.SetText(data_percentages[cur_link_num]);
		data_str.SetColor((gui_->averaging_mode == MODE_TOTAL)?TOT_MODE_COL:text_col[cur_link_num]);
		win.Draw(data_str);


		// Stall amount:
		stall_str.SetText(stall_percentages[cur_link_num]);
		stall_str.SetPosition(left_margin+xloop*(router_xsize+router_xspace)+router_xsize*2/3-12, gui_->vis_window_ysize-(
					  bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)-router_yspace/2-data_percentage_font_size/2));
		win.Draw(stall_str);


		cur_link_num++;

	    }

	    // To PE, WITH OVERHEAD
	    tmp1 = left_margin+xloop*(router_xsize+router_xspace)+router_xsize*7/8;
	    tmp2 = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize); 
	    tmp3 = left_margin+xloop*(router_xsize+router_xspace)+router_xsize+pe_xoffset+router_xsize/8; 
	    tmp4 = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize+pe_yoffset-2);
	    arrow(win, tmp1, tmp2, tmp3, tmp4, 11,	line_widths[cur_link_num], link_col[cur_link_num]);


	    mesh_link_click_coords[cur_link_num][0] = (tmp1+tmp3)/2 - 14;
	    mesh_link_click_coords[cur_link_num][1] = (tmp2+tmp4)/2 - 10;
	    mesh_link_click_coords[cur_link_num][2] = (tmp1+tmp3)/2 + 10;
	    mesh_link_click_coords[cur_link_num][3] = (tmp2+tmp4)/2 + 12;


	    // Data amount:
	    data_str.SetPosition((tmp1 + tmp3)/2-data_percentage_font_size*3+15,
				 (tmp2 + tmp4)/2-data_percentage_font_size/2+5);
	    data_str.SetText(data_percentages[cur_link_num]);
	    data_str.SetColor((gui_->averaging_mode == MODE_TOTAL)?TOT_MODE_COL:text_col[cur_link_num]);
	    data_str.SetRotation(35);
	    win.Draw(data_str);


	    // Stall amount:
	    stall_str.SetPosition((tmp1 + tmp3)/2-stall_percentage_font_size, 
				  (tmp2 + tmp4)/2);
	    stall_str.SetText(stall_percentages[cur_link_num]);
	    stall_str.SetRotation(35);
	    win.Draw(stall_str);

	    cur_link_num++;

	    // From PE, WITH OVERHEAD

	    tmp1 = left_margin+xloop*(router_xsize+router_xspace)+router_xsize+pe_xoffset+router_xsize*3/7;
	    tmp2 = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize+pe_yoffset-2);
	    tmp3 = left_margin+xloop*(router_xsize+router_xspace)+router_xsize;
	    tmp4 = gui_->vis_window_ysize-(bottom_margin+(stats_->pd->mesh_rows-yloop-1)*(router_ysize+router_yspace)+router_ysize*7/8);
	    arrow(win, tmp1, tmp2, tmp3, tmp4, 11, line_widths[cur_link_num], link_col[cur_link_num]);

	    mesh_link_click_coords[cur_link_num][0] = (tmp1+tmp3)/2 - 10;
	    mesh_link_click_coords[cur_link_num][1] = (tmp2+tmp4)/2 - 12;
	    mesh_link_click_coords[cur_link_num][2] = (tmp1+tmp3)/2 + 14;
	    mesh_link_click_coords[cur_link_num][3] = (tmp2+tmp4)/2 + 12;

	    // Data amount:
	    data_str.SetPosition((tmp1 + tmp3)/2-data_percentage_font_size*3+60,
				 (tmp2 + tmp4)/2-data_percentage_font_size/2+10);
	    data_str.SetText(data_percentages[cur_link_num]);
	    data_str.SetColor((gui_->averaging_mode == MODE_TOTAL)?TOT_MODE_COL:text_col[cur_link_num]);
	    data_str.SetRotation(35);
	    win.Draw(data_str);
      
	    // Stall amount:
	    stall_str.SetPosition((tmp1 + tmp3)/2 - stall_percentage_font_size,
				      (tmp2 + tmp4)/2);
	    stall_str.SetText(stall_percentages[cur_link_num]);
	    stall_str.SetRotation(35);
	    win.Draw(stall_str);

      
	    cur_link_num++;


	    // IGNORE: To PE, without overhead
	    mesh_link_click_coords[cur_link_num][0] = 0;
	    mesh_link_click_coords[cur_link_num][1] = 0;
	    mesh_link_click_coords[cur_link_num][2] = 0;
	    mesh_link_click_coords[cur_link_num][3] = 0;

	    cur_link_num++;

	    // IGNORE: From PE, without overhead
	    mesh_link_click_coords[cur_link_num][0] = 0;
	    mesh_link_click_coords[cur_link_num][1] = 0;
	    mesh_link_click_coords[cur_link_num][2] = 0;
	    mesh_link_click_coords[cur_link_num][3] = 0;

	    cur_link_num++;


	    cur_router++;


	}
    }

    if(stats_->realtime)
    {
	sf::String realtime_str("REALTIME", font, gui_->big_font_size);
	realtime_str.SetPosition(20, gui_->vis_window_ysize-50-gui_->big_font_size);
	if(text_blink_state) // static bool
	{
	    text_blink_state = false;
	    realtime_str.SetColor(sf::Color(255,0,0));
	}
	else
	{
	    text_blink_state = true;
	    realtime_str.SetColor(sf::Color(220,220,220));
	}
	win.Draw(realtime_str);
    }

    char temptext[200];
    sf::String tempstr;
    tempstr.SetFont(font);
    tempstr.SetSize(gui_->medium_font_size);
    tempstr.SetColor(sf::Color(0,0,0));
    tempstr.SetText("Window: ");
    tempstr.SetPosition(20,5);
    win.Draw(tempstr);
  
    sprintf(temptext, "%d snapshots = %d clk = %3f s", stats_->logging_length*
	    ((stats_->decimate)?stats_->cur_decimation:1),
	    stats_->pd->window_length*stats_->logging_length*
	    ((stats_->decimate)?stats_->cur_decimation:1),
	    (double)gui_->nav_bar.zoom_region*stats_->pd->window_length/(stats_->pd->clock_hz));

    tempstr.SetPosition(20+tempstr.GetRect().GetWidth(), 5);
    tempstr.SetText(temptext);
    win.Draw(tempstr);

    tempstr.SetSize(gui_->big_font_size);
    tempstr.SetPosition(500, 5);
    if(gui_->averaging_mode == MODE_TOTAL)
    {
	tempstr.SetColor(sf::Color(100,130,180));
	tempstr.SetText("Total words");
	win.Draw(tempstr);
    }
    else if(stats_->logging_length > 1)
    {
	if(gui_->averaging_mode == MODE_WORST)
	{
	    tempstr.SetColor(sf::Color(230,0,0));
	    tempstr.SetText("Worst case percentages");
	    win.Draw(tempstr);
	}
	else if(gui_->averaging_mode == MODE_AVG)
	{
	    tempstr.SetColor(sf::Color(170,170,0));
	    tempstr.SetText("Average percentages");
	    win.Draw(tempstr);
	}
	if(gui_->averaging_mode == MODE_BEST)
	{
	    tempstr.SetColor(sf::Color(0,255,0));
	    tempstr.SetText("Best case percentages");
	    win.Draw(tempstr);
	}
    }
  

    if(stats_->decimate)
    {
	tempstr.SetPosition(gui_->vis_window_xsize-150, 5);
	tempstr.SetColor(sf::Color(200,40,40));
	tempstr.SetText("DECIMATED");
	win.Draw(tempstr);
    }


    for(int i=0; i<stats_->pd->num_of_links; i++)
    {
	delete stall_percentages[i];
	delete data_percentages[i];
    }
  
    delete stall_percentages;
    delete data_percentages;

    delete pe_col;
    delete router_col;
    delete link_col;
    delete text_col;


    sf::Color colors[2] = {sf::Color(0,110,50), sf::Color(255,128,128)};
  
    int *x_data = new int[stats_->num_of_last_values];
    for(int i = 0; i < stats_->num_of_last_values; i++)
	x_data[i] = i;

    // Draw link windows
    for(int l = 0; l < 2; l++)
    {
	if(stats_->decimate)
	    sprintf(temptext, "%s (%d snapshots), DECIMATED", mesh_link_names[stats_->last_values_link_num[l]], stats_->num_of_last_values*stats_->cur_decimation);
	else
	    sprintf(temptext, "%s (%d snapshots)", mesh_link_names[stats_->last_values_link_num[l]], stats_->num_of_last_values);
	
	int line_w = 3;
//	if(stats_->num_of_last_values > 1000)
//	    line_w--;
//	if(stats_->num_of_last_values > 4000)
//	    line_w--;
	
	draw_chart(gui_->link_wins[l], font,
		   2, stats_->num_of_last_values, 
		   x_data, stats_->last_values[l], colors, 
		   gui_->chart_xsize, gui_->chart_ysize, 0, 0,
		   false, 0, (stats_->decimate)?255:(stats_->pd->window_length), 
		   1, 1, 
		   temptext, "x-akseli", "y-akseli", 
		   5, 4, // grids
		   3, sf::Color(255,255,255), sf::Color(200,220,255), line_w, false,
		   1, gui_->chart_title_font_size);
	
	
	sf::String datatext("Data:", font, gui_->medium_font_size);
	datatext.SetColor(colors[0]);
	datatext.SetPosition(10, gui_->chart_ysize-25-gui_->medium_font_size);
	gui_->link_wins[l].Draw(datatext);
	
	sf::String stalltext("Stall:", font, gui_->medium_font_size);
	stalltext.SetColor(colors[1]);
	stalltext.SetPosition(10, gui_->chart_ysize-5-gui_->medium_font_size);
	gui_->link_wins[l].Draw(stalltext);
	
	int index_data = stats_->last_values_link_num[l]*stats_->pd->counters_per_link;
	int index_stall = index_data+1;
	double min_data = (stats_->min_counter_log[index_data]*100.0)/((stats_->decimate)?255:stats_->pd->window_length);
	double max_data = (stats_->max_counter_log[index_data]*100.0)/((stats_->decimate)?255:stats_->pd->window_length);
	double avg_data = ((stats_->tot_counter_log[index_data]*100.0)/((stats_->decimate)?255:stats_->pd->window_length))/
	    gui_->nav_bar.zoom_region;
	
	unsigned long long int total_data = TOT_DATA(index_data); 
	
	double min_stall = (stats_->min_counter_log[index_stall]*100.0)/((stats_->decimate)?255:stats_->pd->window_length);
	double max_stall = (stats_->max_counter_log[index_stall]*100.0)/((stats_->decimate)?255:(stats_->pd->window_length));
	double avg_stall = ((stats_->tot_counter_log[index_stall]*100.0)/((stats_->decimate)?255:stats_->pd->window_length))/
	    gui_->nav_bar.zoom_region;
	unsigned long long int total_stall = stats_->tot_counter_log[index_stall];
	if(stats_->decimate)
	{
	    total_stall *= stats_->pd->window_length;
	    total_stall /= 255;
	}
	
	
	char about = ' ';
	if(stats_->decimate)
	{
	    avg_data *= stats_->cur_decimation;
	    avg_stall *= stats_->cur_decimation;
	    total_stall *= stats_->cur_decimation;
	    about = '~';
	}
	
	sprintf(temptext, "min %c%.4f%% avg %c%.4f%% max %c%.4f%%, total %c%d words", about, min_data, about, avg_data, about, max_data, about, total_data);
	
	datatext.SetText(temptext);
	datatext.SetPosition(50, gui_->chart_ysize-25-gui_->medium_font_size);
	gui_->link_wins[l].Draw(datatext);
	
	sprintf(temptext, "min %c%.4f%% avg %c%.4f%% max %c%.4f%%, total %c%d clk", about, min_stall, about, avg_stall, about, max_stall, about, total_stall);
	stalltext.SetText(temptext);
	stalltext.SetPosition(50, gui_->chart_ysize-5-gui_->medium_font_size);
	gui_->link_wins[l].Draw(stalltext);
	
	gui_->link_wins[l].Display();
    }    

    delete x_data;

}

int mesh::get_snd_idx(int ip_num)
{
    int row = ip_num/(stats_->pd->mesh_cols);
    int col = ip_num - (row*(stats_->pd->mesh_cols));

    return 2*mesh_pe_datalink_indeces_out_with_overhead[row][col];
}

int mesh::get_rcv_idx(int ip_num)
{
    int row = ip_num/(stats_->pd->mesh_cols);
    int col = ip_num - (row*(stats_->pd->mesh_cols));

    return 2*mesh_pe_datalink_indeces_in_with_overhead[row][col];
}

int mesh::get_snd_no_overhead_idx(int ip_num)
{
    int row = ip_num/(stats_->pd->mesh_cols);
    int col = ip_num - (row*(stats_->pd->mesh_cols));

    return 2*mesh_pe_datalink_indeces_out_no_overhead[row][col];
}

int mesh::get_rcv_no_overhead_idx(int ip_num)
{
    int row = ip_num/(stats_->pd->mesh_cols);
    int col = ip_num - (row*(stats_->pd->mesh_cols));

    return 2*mesh_pe_datalink_indeces_in_no_overhead[row][col];
}

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
