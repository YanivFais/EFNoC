// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

// ui.cpp
// Set of very simple User Interface functions based on SFML Library.
// Implements mouse functionality with buttons that can be clicked.


#include <iostream>
#include <cstdio>
#include <cstring>
#include <SFML/Graphics.hpp>

#include "ui_on_sfml.hpp"

using namespace std;

ui_on_sfml::ui_on_sfml(sf::RenderWindow& win) : window(win), input(win.GetInput())
{
    num_buttons = 0;
    font = sf::Font::GetDefaultFont();
}

void ui_on_sfml::change_text(int num, const char* text)
{
    delete buttons[num]->text;
    buttons[num]->text = new char[strlen(text)+1];
    strcpy(buttons[num]->text, text);
}

int ui_on_sfml::add_button(int x, int y, int xs, int ys, const char* text, sf::Color color, int font_size,
			 int symbol, sf::Color color_pressed, bool pressed)
{
    buttons[num_buttons] = new button;
    buttons[num_buttons]->x = x;
    buttons[num_buttons]->y = y;
    buttons[num_buttons]->xs = xs;
    buttons[num_buttons]->ys = ys;
    buttons[num_buttons]->text = new char[strlen(text)+1];
    strcpy(buttons[num_buttons]->text, text);
    buttons[num_buttons]->visible = true;
    buttons[num_buttons]->font_size = font_size;
    buttons[num_buttons]->color = color;
    buttons[num_buttons]->symbol = symbol;
    buttons[num_buttons]->pressed = pressed;
    buttons[num_buttons]->color_pressed = color_pressed;
    buttons[num_buttons]->text_color = sf::Color(0,0,0);

    num_buttons++;

    return num_buttons-1;
}

void ui_on_sfml::hide_button(int num)
{
    buttons[num]->visible = false;
}

void ui_on_sfml::show_button(int num)
{
    buttons[num]->visible = true;
}

void ui_on_sfml::draw_button(int num)
{
    if(buttons[num]->visible == false)
	return;

    const sf::Color line_color = sf::Color(0,0,0);
    const int shadow_offset = 2;
    const sf::Color shadow_color = sf::Color(100,100,100);

    // Draw shadow first
    window.Draw(sf::Shape::Rectangle(
		    buttons[num]->x+shadow_offset, 
		    buttons[num]->y-shadow_offset, 
		    buttons[num]->x+buttons[num]->xs+shadow_offset,
		    buttons[num]->y+buttons[num]->ys-shadow_offset,
		    shadow_color,
		    2,
		    shadow_color));

    int button_offset = (buttons[num]->pressed)?shadow_offset:0;

    window.Draw(sf::Shape::Rectangle(
		    buttons[num]->x+button_offset, 
		    buttons[num]->y-button_offset, 
		    buttons[num]->x+buttons[num]->xs+button_offset,
		    buttons[num]->y+buttons[num]->ys-button_offset,
		    (buttons[num]->pressed)?(buttons[num]->color_pressed):(buttons[num]->color),
		    2,
		    line_color));



    int text_offset = 0;
    const int sym_xoffs = 5;
    const int sym_yoffs = 6;
    if(buttons[num]->symbol > -1)
    {
	for(int poly = 0; poly < SYMBOLS[buttons[num]->symbol].n_polys; poly++)
	{
	    sf::Shape shape;
	    shape.SetOutlineWidth(SYMBOLS[buttons[num]->symbol].polys[poly].line_width);
	    shape.EnableFill(SYMBOLS[buttons[num]->symbol].polys[poly].fill);
	    shape.EnableOutline(SYMBOLS[buttons[num]->symbol].polys[poly].line);

	    for(int i = 0; i < SYMBOLS[buttons[num]->symbol].polys[poly].n_points*2; i+=2)
	    {
		shape.AddPoint(SYMBOLS[buttons[num]->symbol].polys[poly].points[i],
			       SYMBOLS[buttons[num]->symbol].polys[poly].points[i+1],
			       SYMBOLS[buttons[num]->symbol].polys[poly].fill_color,
			       SYMBOLS[buttons[num]->symbol].polys[poly].line_color);
	    }

	    shape.Move(buttons[num]->x+sym_xoffs+button_offset, buttons[num]->y+sym_yoffs-button_offset);
	    window.Draw(shape);
	    text_offset = SYMBOLS[buttons[num]->symbol].text_offset;
	}
    }

    sf::String text(buttons[num]->text, font, buttons[num]->font_size);
    text.SetColor(buttons[num]->text_color);
    text.Move(buttons[num]->x+5+text_offset+button_offset, buttons[num]->y+3-button_offset);
    window.Draw(text);

}

void ui_on_sfml::draw_all_buttons()
{
    for(int i = 0; i < num_buttons; i++)
    {
	draw_button(i);
    }
}

int ui_on_sfml::check_button_status()
{
    unsigned int x, y;
    bool mouse;

    x = input.GetMouseX();
    y = input.GetMouseY();
    mouse = input.IsMouseButtonDown(sf::Mouse::Left);

    if(mouse) // && x > 0 && y > 0 && x < window_xsize && y < window_ysize)
    {
	for(int i = 0; i < num_buttons; i++)
	{
	    if(x > buttons[i]->x && x < buttons[i]->x+buttons[i]->xs &&
	       y > buttons[i]->y && y < buttons[i]->y+buttons[i]->ys &&
		buttons[i]->visible)
		return i;
	}
    }

    return -1;

}

void ui_on_sfml::query_mouse(int* x, int* y, bool* left, bool* mid, bool* right)
{
    *x = input.GetMouseX();
    *y = input.GetMouseY();
    if(left != 0)
	*left = input.IsMouseButtonDown(sf::Mouse::Left);
    if(mid != 0)
	*mid = input.IsMouseButtonDown(sf::Mouse::Middle);
    if(right != 0)
	*right = input.IsMouseButtonDown(sf::Mouse::Right);
}

void ui_on_sfml::destroy_buttons()
{
    for(int i = 0; i < num_buttons; i++)
    {
	delete buttons[i]->text;
	delete buttons[i];
	buttons[i]->text = 0;
	buttons[i] = 0;
    }

    num_buttons = 0;
}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
