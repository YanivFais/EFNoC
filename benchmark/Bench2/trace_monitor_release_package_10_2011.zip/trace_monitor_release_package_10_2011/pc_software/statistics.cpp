// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

// statistics.cpp
// Module that visualizes parsed data; "from counters to graphics".
// Uses G2 Graphical Library extensively and implements basic UI
// operations around the visualization look.

#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

#include "statistics.hpp"

using namespace std;

statistics::statistics()
{
    rt_stop = false;
    rt_captured = 0;
    rt_errors = 0;
    rt_missed = 0;
    rt_ignored = 0;

    decimate = false;
    cur_decimation = 1;
    navi_decimation_apply[0] = 1500;
    navi_decimation[0] = 5;
    navi_decimation_apply[1] = 3000;
    navi_decimation[1] = 10;
    navi_decimation_apply[2] = 9000;
    navi_decimation[2] = 30;
    navi_decimation_apply[3] = 30000;
    navi_decimation[3] = 100;
    navi_decimation_apply[4] = 90000;
    navi_decimation[4] = 300;
    navi_decimation_apply[5] = 300000;
    navi_decimation[5] = 1000;
    navi_decimation_apply[6] = 900000;
    navi_decimation[6] = 3000;
    navi_decimation_apply[7] = 3000000;
    navi_decimation[7] = 10000;

}

int statistics::initialize(const processing_data* proc_data)
{
    pd = proc_data;

    logging_length = 100;

    num_of_last_values = 100;
    max_num_of_last_values = 250000;
    last_values_link_num[0] = 0;
    last_values_link_num[1] = 1;
    last_values[0] = new int[max_num_of_last_values*pd->counters_per_link];
    last_values[1] = new int[max_num_of_last_values*pd->counters_per_link];

    realtime = true;
    accum_done = false;
    snap_counter = 0;

//    avg_counter_log = new double[pd->num_of_counters];
    min_counter_log = new int[pd->num_of_counters];    
    max_counter_log = new int[pd->num_of_counters];
    tot_counter_log = new int[pd->num_of_counters];
    tot_avg_counter_accumulate = new int[pd->num_of_counters];
    min_counter_accumulate = new int[pd->num_of_counters];    
    max_counter_accumulate = new int[pd->num_of_counters];

    if(min_counter_log == 0 || max_counter_log == 0 ||
       tot_counter_log == 0 || tot_avg_counter_accumulate == 0 ||
       min_counter_accumulate == 0 || max_counter_accumulate == 0)
    {
	return 1;
    }

    for(int cnt = 0; cnt < pd->num_of_counters; cnt++)
    {
//	avg_counter_log[cnt] = 0;
	min_counter_log[cnt] = MIN_INIT;
	max_counter_log[cnt] = MAX_INIT;
	tot_counter_log[cnt] = 0;
	tot_avg_counter_accumulate[cnt] = 0;
	min_counter_accumulate[cnt] = MIN_INIT;
	max_counter_accumulate[cnt] = MAX_INIT;
    }

    return 0;
}
  
void statistics::free()
{
//    delete avg_counter_log;
    delete min_counter_log;
    delete max_counter_log;
    delete tot_counter_log;
    delete tot_avg_counter_accumulate;
    delete min_counter_accumulate;
    delete max_counter_accumulate;
}


/******
  parse_and_analyze:
  Takes a pointer to a whole UDP packet of data.
  Accumulates the statistics to accumulation counters, and after
  logging_length snapshots have been processed, accumulated values
  are copied to _log tables.

  Used for live view.

 ******/

void statistics::parse_and_analyze(const unsigned char* input_data)
{
    int counters_tmp[pd->num_of_counters];
    for(int snap = 0; snap < pd->snapshots_per_packet; snap++)
    {
	parse_snapshot(0, input_data + (snap*(pd->snapshot_bytes)), 0, 0, counters_tmp, 0, 0, pd);
	
	// Compute results, increasing snap counter as needed
	for(int i = 0; i < pd->num_of_counters; i++)
	{
	    tot_avg_counter_accumulate[i] += counters_tmp[i];
	    if(counters_tmp[i] < min_counter_accumulate[i])
		min_counter_accumulate[i] = counters_tmp[i];
	    if(counters_tmp[i] > max_counter_accumulate[i])
		max_counter_accumulate[i] = counters_tmp[i];
	    
	    // CURRENT CODE WORKS ONLY FOR MESH (and other 2 counters per link networks):
	    for(int win = 0; win < NUM_LINK_WINDOWS; win++)
	    {
		if(i/2 == last_values_link_num[win])
		{
		    for(int o = num_of_last_values*2; o > 2; o--)
		    {
			last_values[win][o] = last_values[win][o-2];
			last_values[win][o-1] = last_values[win][o-3];
		    }
		    last_values[win][1] = counters_tmp[last_values_link_num[win]*2+1];
		    last_values[win][0] = counters_tmp[last_values_link_num[win]*2];
		}
	    }	
	    
	    // END ONLY FOR MESH
	    
	}
	
	snap_counter++;
	if(snap_counter >= logging_length)
	{
	    // Accumulation done. Copy the values to _log counters and zero
	    // the accumulation variables.
	    for(int cnt=0; cnt < pd->num_of_counters; cnt++)
	    {
		tot_counter_log[cnt] = tot_avg_counter_accumulate[cnt];
//		avg_counter_log[cnt] = (double)tot_avg_counter_accumulate[cnt]/(double)logging_length;
		min_counter_log[cnt] = min_counter_accumulate[cnt];
		max_counter_log[cnt] = max_counter_accumulate[cnt];
		
		tot_avg_counter_accumulate[cnt] = 0;
		min_counter_accumulate[cnt] = MIN_INIT;
		max_counter_accumulate[cnt] = MAX_INIT;
	    }
	    snap_counter = 0;
	    accum_done = true;
	}
	
    }
    
}

/*
  parse_and_analyze_region

  Parses any number of snapshots from raw input data and updates _log counters.
 */

void statistics::parse_and_analyze_region(const unsigned char* input_data, const int snaps)
{
    int counters_tmp[pd->num_of_counters];

    long int * tot_avg_count;
    long int * min_count;
    long int * max_count;

    tot_avg_count = new long int[pd->num_of_counters];
    min_count = new long int[pd->num_of_counters];
    max_count = new long int[pd->num_of_counters];

    for(int i = 0; i < pd->num_of_counters; i++)
    {
	tot_avg_count[i] = 0;
	min_count[i] = MIN_INIT;
	max_count[i] = MAX_INIT;
    }

    for(int snap = 0; snap < snaps; snap++)
    {
      parse_snapshot(0, input_data + (snap*(pd->snapshot_bytes)), 0, 0, counters_tmp, 0, 0, pd);

      for(int i = 0; i < pd->num_of_counters; i++)
      {
	tot_avg_count[i] += counters_tmp[i];
	if(counters_tmp[i] < min_count[i])
	  min_count[i] = counters_tmp[i];
	if(counters_tmp[i] > max_count[i])
	  max_count[i] = counters_tmp[i];

	for(int win = 0; win < NUM_LINK_WINDOWS; win++)
	{
	    if(i/pd->counters_per_link == last_values_link_num[win] && snap < max_num_of_last_values)
	    {
		for(int o = 0; o < pd->counters_per_link; o++)
		    last_values[win][snap*pd->counters_per_link+o] = counters_tmp[last_values_link_num[win]*2+o];
	    }
	}
      }

    }

    // Copy the results to their appropriate storage tables for drawing.
    for(int i = 0; i < pd->num_of_counters; i++)
    {
	tot_counter_log[i] = tot_avg_count[i];
//	avg_counter_log[i] = (double)tot_avg_count[i]/(double)snaps;
//	if(i==0)
//	    cout << tot_avg_count[i] << " -> " << avg_counter_log[i] << endl;
	min_counter_log[i] = min_count[i];
	max_counter_log[i] = max_count[i];

    }
    
    delete tot_avg_count;
    delete min_count;
    delete max_count;
}

void statistics::analyze_deci_region(const unsigned char* input_data, const int points)
{
    long int * tot_avg_count;
    long int * min_count;
    long int * max_count;

    tot_avg_count = new long int[pd->num_of_counters];
    min_count = new long int[pd->num_of_counters];
    max_count = new long int[pd->num_of_counters];

    for(int i = 0; i < pd->num_of_counters; i++)
    {
	tot_avg_count[i] = 0;
	min_count[i] = MIN_INIT;
	max_count[i] = MAX_INIT;
    }

    for(int point = 0; point < points; point++)
    {
      for(int i = 0; i < pd->num_of_counters; i++)
      {
	  int pnt = (point*pd->num_of_counters+i)*3;
	  int min = (int)input_data[pnt];
	  int max = (int)input_data[pnt+1];
	  int avg = (int)input_data[pnt+2];
	  

	if(min < min_count[i])
	  min_count[i] = min;
	if(max > max_count[i])
	  max_count[i] = max;

	tot_avg_count[i] += avg;

	for(int win = 0; win < NUM_LINK_WINDOWS; win++)
	{
	    if(i == last_values_link_num[win]*2 && point < max_num_of_last_values)  // true only for data
	    {
		// Only averages taken from data, min&max ignored.
		last_values[win][point*pd->counters_per_link+0] = avg;
		last_values[win][point*pd->counters_per_link+1] = (int)input_data[pnt+2+3];
		
	    }
	}

      }

    }

    // Copy the results to their appropriate storage tables for drawing.
    for(int i = 0; i < pd->num_of_counters; i++)
    {
	tot_counter_log[i] = tot_avg_count[i];
//	avg_counter_log[i] = (double)tot_avg_count[i]/points;
	min_counter_log[i] = min_count[i];
	max_counter_log[i] = max_count[i];

    }
    
    delete tot_avg_count;
    delete min_count;
    delete max_count;

}

// Decimation file has 1-byte values in the following way:
// First NAVI_DECIMATION snapshots:
// Link 0 counter 0 MIN
// Link 0 counter 0 MAX
// Link 0 counter 0 AVG
// Link 0 counter 1 MIN  .... etc

void statistics::create_decimation_file(ifstream& inp_stream, unsigned long int size, int num_of_snapshots, int deci)
{
    unsigned char* data;

    data = new unsigned char[pd->snapshot_bytes*deci];

    ofstream out_stream;

    char name[405];
    sprintf(name, "%s.deci%d", pd->bin_name, deci);
    
    out_stream.open(name, ios::out | ios::binary);

    int deci_points = num_of_snapshots / deci;

    int val[3];

    for(int i = 0; i < deci_points; i++)
    {
	inp_stream.seekg(i*deci*pd->snapshot_bytes, ios::beg);
	inp_stream.read((char*)data, deci*pd->snapshot_bytes);
	if(!inp_stream.good())
	{
	    cerr << "create_decimation_file: Input stream not good at i = " << i << endl;
	    return;
	}

	parse_and_analyze_region(data, deci);

	for(int link = 0; link < pd->num_of_links; link++)
	{
	    for(int cnt = 0; cnt < pd->counters_per_link; cnt++)
	    {
		double min = ((double)min_counter_log[link*pd->counters_per_link+cnt]/(double)pd->window_length) * 255.0;
		double max = ((double)max_counter_log[link*pd->counters_per_link+cnt]/(double)pd->window_length) * 255.0;
		double avg = ((double)tot_counter_log[link*pd->counters_per_link+cnt]/((double)pd->window_length * (double)deci)) * 255.0;

		int min_int = (int)(min+0.5);  // rounding
		int max_int = (int)(max+0.5);
		int avg_int = (int)(avg+0.5);
		
		if(min_int > 255) min_int = 255;
		if(max_int > 255) max_int = 255;
		if(avg_int > 255) avg_int = 255;

		// We don't want to lose the visibility of small connections:
		if(min_int == 0 && min > 0) min_int = 1;
		if(max_int == 0 && max > 0) max_int = 1;
		if(avg_int == 0 && avg > 0) avg_int = 1;

		out_stream.put(min_int);
		out_stream.put(max_int);
		out_stream.put(avg_int);
	    }
	}

    }

    out_stream.close();
}






// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
