// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

#ifndef P2P_INVESTIGATOR_HPP
#define P2P_INVESTIGATOR_HPP

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <vector>
#include <SFML/Graphics.hpp>

#include "statistics.hpp"
#include "mesh.hpp"
// #include "gui.hpp"

// Number of different network situation possibilities is limited to this number AFTER
// the window has been processed and all the possibilities have been sorted (best possibilities first),
// to save memory.
const int MAX_NUM_SITUATIONS = 50;

// During rule E, new situations are spawned IF their Q value is lower than
// the Q of the best case * MAX_ROUTER_Q_INCREASE_FACTOR + MAX_ROUTER_Q_INCREASE_OFFSET
const int MAX_ROUTER_Q_INCREASE_FACTOR = 2;
const int MAX_ROUTER_Q_INCREASE_OFFSET = 50;


const int NUM_ALGORITHMS = 3;
const char* const algo_names[NUM_ALGORITHMS] = 
{"Minimum of source and destination", 
 "Minimum of source, destination and inbetween links", 
 "Elimination-deductive Super Strong"};


const int NUM_DRAWING_MODES = 4;
const char* const DRAWING_MODE_NAMES[NUM_DRAWING_MODES] =
{"src",
 "dst",
 "src&dst",
 "p2p conn",
};


struct gui;

struct p2p_investigator
{
    p2p_investigator(statistics* stats, mesh* meshnoc, gui* guiui);
    void set_stream(ifstream* inp_stream);
    ifstream* inp_stream_;
    statistics* stats_;
    mesh* meshnoc_;
    gui* gui_;

    bool dbg_print;

    // List of links to form one point-to-point path.
    struct p2p_path
    {
	int num_of_hops;
	int hop_link_numbers[20];
	signed int data_am_constraint;	
	bool is_constrained() const;
    };

    enum stats_status_t {unknown, known, estimated};

    // Description of one point-to-point connection
    struct p2p_path_stats
    {
	p2p_path_stats();
	int data_with_overhead;
	int data_no_overhead;
	stats_status_t status;
	bool operator==(const p2p_path_stats& other) const;
	bool operator!=(const p2p_path_stats& other) const;
	p2p_path_stats& operator=(const p2p_path_stats& other);
    };

    // Description of one possibility of a whole network situation at one window
    struct p2p_situation
    {
	p2p_situation(const statistics* stats_pnt, const p2p_investigator* p2p_pnt);
	p2p_situation(const p2p_situation& other);
	~p2p_situation();
	const statistics* stats_;
	const p2p_investigator* p2p_;
	p2p_path_stats** paths;
	int* residual_counters;
	int plus_data() const;
	int minus_data() const;
	int total_residual() const;
	int num_estimated() const;
	int Q() const;
	bool operator<(const p2p_situation& other) const;
	bool operator>(const p2p_situation& other) const;
	bool operator<=(const p2p_situation& other) const;
	bool operator>=(const p2p_situation& other) const;
	bool operator==(const p2p_situation& other) const;
	bool operator!=(const p2p_situation& other) const;
	p2p_situation& operator=(const p2p_situation& other);

	// Sum up the residual counters of two situations (to find the most probable continuation for the previous window)
	int residual_with_previous(const p2p_situation& other) const;
    };

    void solve_situation_recursive(vector<p2p_situation>& possibilities, p2p_situation* cur_possibility, int recurs_level, bool gave_up = false);

    // Description of all relevant possibilities found for one window
    struct p2p_window
    {
	vector<p2p_situation> possibilities;
	int selected;
	p2p_path_stats** paths() const;
    };
    
    int p2p_begin_snapshot;
    int p2p_length;
    int p2p_win_len;
    p2p_window* p2p_statistics; // The wholeness in whole.
    void select_view_paths(int restriction);
    bool draw_paths[MAX_NUM_PES][MAX_NUM_PES];

    struct p2p_tot_stats
    {
	long long int data_with_overhead;
	long long int data_no_overhead;
	bool operator<(const p2p_tot_stats& other) const;
    };

    p2p_tot_stats** totals;  // Accumulated during processing

    p2p_path_stats*** p2p_statistics_disc;
    char p2p_bin_name[500];


// Maximum number of situations spawned from rule E. Give 1 to disable recursive processing
// of multiple situations and fall back to one best situation.
    int MAX_ROUTER_RECURSION_SPAWN;

// After the recursion deepness of MAX_RECURSION_LEVEL has been reached, rule E falls back
// to spawn only one situation from the best possibility.
    int MAX_RECURSION_LEVELS;

// For rule E:
    int ROUTER_MAX_RECURS_LEVEL;

    bool read_totals_file();
    bool read_view_file();

    // Structures for rule E
    struct possible_srcs_dsts
    {
	bool illegal;
	vector<int> srcs;
	vector<int> dsts;
    };

    possible_srcs_dsts router_viewpoints[MAX_NUM_PES][5][5];

    void create_router_viewpoints();


    struct router_data_ams
    {
	int to_router[5];
	int from_router[5];

	router_data_ams(const router_data_ams& copy);
	router_data_ams();
    };

    struct routing_possibility
    {
	int from_to[5][5];
	int excess_input;
	int excess_output;
	bool is_identical(const routing_possibility& other) const;
	routing_possibility();
	routing_possibility(const routing_possibility& copy);
	routing_possibility& operator=(const routing_possibility& copy);

	int Q() const;
	bool operator<(const routing_possibility& other) const;
	bool operator>(const routing_possibility& other) const;
	bool operator<=(const routing_possibility& other) const;
	bool operator>=(const routing_possibility& other) const;
	bool operator==(const routing_possibility& other) const;
	bool operator!=(const routing_possibility& other) const;

	int give_num_of_routings() const;
	int total_excess() const;
    };

    void fill_router_data_ams(router_data_ams* ams, int* counter_copy, int ip_num);
    void fill_router_data_ams(router_data_ams* ams, int* counter_copy, int row, int col);

    int win_len;
    enum algorithms_t {min_src_dst, min_src_links_dst, elimination_deductive};
    algorithms_t algo;
    p2p_path** p2p_paths;

    // Equalization:
    bool eq_src_rows;
    bool eq_dst_cols;
    bool eq_src_first;
    int  eq_iterations;

    // Alg 2 specific:
    bool dont_accept_uneven;
    bool dont_assume_low_count;
    bool use_rule_F;


    void text_ui();

    // Rules return true if they did something.
    bool do_rule_A_B(p2p_path_stats** stats, int sender, int receiver, int* counter_copy, p2p_path** p2p_paths, bool flag_est);
    bool do_rule_C_D(p2p_path_stats** stats, int sender, int receiver, int* counter_copy, p2p_path** p2p_paths, bool flag_est);

    bool do_rule_E(int router, int* counter_copy, p2p_path** p2p_paths, bool gave_up,
		   vector<p2p_situation>& possibilities, p2p_situation* cur_possibility,
	           int recurs_level);
    void try_router_recursive(router_data_ams* ams, vector<routing_possibility>& possibilities, routing_possibility* cur_possibility, int level);
    bool do_rule_F(p2p_path_stats** stats, int* counter_copy, p2p_path** p2p_paths);


    int stats_num_of_unknowns(p2p_path_stats** stats);

    int subtract_deduced(p2p_path_stats** stats, int sender, int receiver, int* counter_copy, p2p_path** p2p_paths);

    void equalize(bool rows, p2p_path_stats** table, const int* expected_with_overhead, const int* expected_no_overhead, p2p_path_stats** results);

    void dbg_show_table(p2p_path_stats** stats);


    struct grp
    {
	vector<int> ips;
	signed int data_constraint;
    };

    enum directions_t {north = 0, east, south, west, ip};

    struct drawing_modes
    {
	int mode;
	int x_size;
	int y_size;
	int left_margin;
	int length;
	int bottom_margin;
	int top_margin;
	int slot_space;
	int totals_margin;
	bool overhead;
	bool use_view_file;
	void recalculate_vis_params();
    };

    drawing_modes dm;
    bool enable_p2p;

    void set_win_size(int xs, int ys);
    void draw_p2p(sf::RenderWindow& win, sf::Font& font, int begin, int end, int decimation);

    void create_csv_from_region(char* filename); // use p2p_statistics_disc and p2p_length.


};

#endif

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
