// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.


#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <SFML/Graphics.hpp>

#include "ui_on_sfml.hpp"
#include "gui.hpp"
#include "statistics.hpp"
#include "p2p_investigator.hpp"
#include "traffic_models.hpp"


gui::gui(statistics* stats) : meshnoc(stats, this, main_win), main_ui(main_win), linkwin_uis(link_wins), p2p_ui(p2p_win), p2p_inv(stats, &meshnoc, this)
{
    stats_ = stats;
    use_decimation = false;
    averaging_mode = MODE_AVG;
    def_font = sf::Font::GetDefaultFont();
    num_ranges = 0;

    nav_bar.left   = 50;
    nav_bar.right  = 50;
    nav_bar.bottom = 60;
    nav_bar.line_width = 6;
    nav_bar.ends_line_width = 1;
    nav_bar.sel_line_width = 20;

    nav_bar.min_bar_len = 30;

    nav_bar.location = 0;
    nav_bar.zoom_region = 20;
    nav_bar.num_of_snapshots = 100;

    p2p_window_xsize = 1500;
    p2p_window_ysize = 900;

}


void gui::show_hide_nav_buttons(bool show)
{
    main_ui.buttons[vis_buttons.play]->visible = show;
    main_ui.buttons[vis_buttons.playslow]->visible = show;
    main_ui.buttons[vis_buttons.stop]->visible = show;
    main_ui.buttons[vis_buttons.nav_bar_left]->visible = show;
    main_ui.buttons[vis_buttons.nav_bar_right]->visible = show;
    main_ui.buttons[vis_buttons.zoom_all]->visible = show;
//    main_ui.buttons[vis_buttons.zoom_out]->visible = show;
//    main_ui.buttons[vis_buttons.zoom_in]->visible = show;
//    main_ui.buttons[vis_buttons.zoom_out2]->visible = show;
//    main_ui.buttons[vis_buttons.zoom_in2]->visible = show;
//    main_ui.buttons[vis_buttons.best]->visible = show;
//    main_ui.buttons[vis_buttons.worst]->visible = show;
//    main_ui.buttons[vis_buttons.avg]->visible = show;
//    main_ui.buttons[vis_buttons.total]->visible = show;
    main_ui.buttons[vis_buttons.decimation]->visible = show;
}

bool gui::initialize_graphics(bool resize, bool recreate, bool realtime)
{
    if(resize)
    {
//	cout << "Resize main: " << vis_window_xsize << ", " << vis_window_ysize << endl;
	main_view.SetFromRect(sf::FloatRect(0,0,vis_window_xsize,vis_window_ysize));
//	cout << "Resize chart: " << chart_xsize << ", " << chart_ysize << endl;
	link_wins[0].SetSize(chart_xsize, chart_ysize);
	link_wins[1].SetSize(chart_xsize, chart_ysize);
	link_views[0].SetFromRect(sf::FloatRect(0,0,chart_xsize,chart_ysize));
	link_views[1].SetFromRect(sf::FloatRect(0,0,chart_xsize,chart_ysize));
	p2p_view.SetFromRect(sf::FloatRect(0,0,p2p_window_xsize,p2p_window_ysize));
    }
    else
    {
        main_win.Create(sf::VideoMode(vis_window_xsize, vis_window_ysize, 32), "Trace Monitor NoC visualization");
	if(vis_window_xpos != 0)
	    main_win.SetPosition(vis_window_xpos, vis_window_ypos);
	main_view.SetFromRect(sf::FloatRect(0,0,vis_window_xsize,vis_window_ysize));
	main_win.SetView(main_view);

	link_wins[0].Create(sf::VideoMode(chart_xsize, chart_ysize, 32), "Link statistics 1");
	if(link_win_xposs[0] != 0)
	    link_wins[0].SetPosition(link_win_xposs[0], link_win_yposs[0]);
	link_views[0].SetFromRect(sf::FloatRect(0,0,chart_xsize,chart_ysize));
	link_wins[0].SetView(link_views[0]);

	link_wins[1].Create(sf::VideoMode(chart_xsize, chart_ysize, 32), "Link statistics 2");
	if(link_win_xposs[1] != 0)
	    link_wins[1].SetPosition(link_win_xposs[1], link_win_yposs[1]);
	link_views[1].SetFromRect(sf::FloatRect(0,0,chart_xsize,chart_ysize));
	link_wins[1].SetView(link_views[1]);

        p2p_win.Create(sf::VideoMode(p2p_window_xsize, p2p_window_ysize, 32), "Point-to-Point Investigator");
	p2p_view.SetFromRect(sf::FloatRect(0,0,p2p_window_xsize,p2p_window_ysize));
	p2p_win.SetView(p2p_view);

    }

    p2p_inv.dm.x_size = p2p_window_xsize; 
    p2p_inv.dm.y_size = p2p_window_ysize;
    p2p_inv.dm.recalculate_vis_params();


    incomplete_range = false;

    redraw = true;
    nav_bar.dragging = false;
    nav_bar.clicking = false;
    nav_bar.graph_clicking = false;
    nav_bar.drag_mouse_offset = 0;

    const int ypos = vis_window_ysize - 30;

    if(recreate || resize)
    {
	main_ui.destroy_buttons();
	p2p_ui.destroy_buttons();
    }


    vis_buttons.play          = main_ui.add_button(20+ 0*60, ypos, 55, 20, "Play", DEF_BUT_COL, DEF_BUT_FONT_SIZE, SYM_PLAY);
    vis_buttons.playslow      = main_ui.add_button(20+ 1*60, ypos, 55, 20, "Slow", DEF_BUT_COL, DEF_BUT_FONT_SIZE, SYM_PLAYSLOW);
    vis_buttons.stop          = main_ui.add_button(20+ 2*60, ypos, 55, 20, "Stop", DEF_BUT_COL, DEF_BUT_FONT_SIZE, SYM_STOP);
    vis_buttons.nav_bar_left  = main_ui.add_button(20+ 3*60, ypos, 55, 20, "REW");
    vis_buttons.nav_bar_right = main_ui.add_button(20+ 4*60, ypos, 55, 20, "FORW");
    vis_buttons.zoom_all      = main_ui.add_button(20+ 5*60, ypos, 55, 20, "ALL");
    vis_buttons.zoom_out      = main_ui.add_button(20+ 6*60, ypos, 50, 20, "OUT");
    vis_buttons.zoom_out2     = main_ui.add_button(20+ 7*60, ypos, 50, 20, "out");
    vis_buttons.zoom_in       = main_ui.add_button(20+ 8*60, ypos, 50, 20, "IN");
    vis_buttons.zoom_in2      = main_ui.add_button(20+ 9*60, ypos, 50, 20, "in");

    vis_buttons.best          = main_ui.add_button(20+10*60, ypos, 55, 20, "BEST", sf::Color(0,255,0), DEF_BUT_FONT_SIZE, -1, 
						  sf::Color(170,255,170), averaging_mode==MODE_BEST);
    vis_buttons.avg           = main_ui.add_button(20+11*60, ypos, 55, 20, "AVG", sf::Color(170,170,0), DEF_BUT_FONT_SIZE, -1,
						  sf::Color(255,255,100), averaging_mode==MODE_AVG);
    vis_buttons.worst         = main_ui.add_button(20+12*60, ypos, 55, 20, "WORST", sf::Color(230,0,0), DEF_BUT_FONT_SIZE, -1,
						  sf::Color(255,130,130), averaging_mode==MODE_WORST);
    vis_buttons.total         = main_ui.add_button(20+13*60, ypos, 55, 20, "TOTAL", sf::Color(100,130,180), DEF_BUT_FONT_SIZE, -1,
						  sf::Color(210,230,255), averaging_mode==MODE_TOTAL);
    vis_buttons.decimation    = main_ui.add_button(20+14*60, ypos, 75, 20, "Decimate", DEF_BUT_COL, DEF_BUT_FONT_SIZE, -1, 
						  DEF_BUT_COL_PRESSED, use_decimation);

    vis_buttons.cmd           = main_ui.add_button(vis_window_xsize-120, ypos, 40, 20, "cmd", sf::Color(40,40,255));
    vis_buttons.quit          = main_ui.add_button(vis_window_xsize-60, ypos, 50, 20, "QUIT");
    vis_buttons.done          = main_ui.add_button(1, 1, 70, 30, "DONE", DEF_BUT_COL, DEF_BUT_FONT_SIZE+4);
    p2p_buttons.mode          = p2p_ui.add_button(20, p2p_window_ysize-30, 100, 20, DRAWING_MODE_NAMES[p2p_inv.dm.mode]);
    p2p_buttons.overhead      = p2p_ui.add_button(140, p2p_window_ysize-30, 110, 20, p2p_inv.dm.overhead?"Show overhead":"No overhead");
    p2p_buttons.save_csv      = p2p_ui.add_button(p2p_window_xsize-140, p2p_window_ysize-30, 100, 20, "Save .csv");

    main_ui.hide_button(vis_buttons.done);

    show_hide_nav_buttons(!realtime);

    return true;

}

void gui::create_default_nametags()
{
  for(int i=0; i < MAX_NUM_PES; i++)
    sprintf(name_tags[i], "PE %d", i);

}

void gui::read_nametags(ifstream& nametagstream)
{
    int i = 0;
    for(; i < MAX_NUM_PES; i++)
    {
	if(!nametagstream.getline(name_tags[i], MAX_NAMETAG_LEN))
	    break;
    }

    // Strip newlines
    for(int o=0; o < i; o++)
    {
	int s = 0;
	while(name_tags[o][s] != '\n' && name_tags[o][s] != '\r' && name_tags[o][s] != 0)
	{
	    s++;
	}
	name_tags[o][s] = 0;
    }
}

void arrow(sf::RenderWindow& win, int x1, int y1, int x2, int y2, int ar_size, int width, sf::Color color)
{
    win.Draw(sf::Shape::Line(x1, y1, x2, y2, width, color));

    ar_size += width;

    double ang, deltaX, deltaY;

    if(y1 == y2) // Horizontal arrow
    {
	if(x1 > x2)
	    ar_size *= -1;

	win.Draw(sf::Shape::Line(x2, y2, x2-ar_size, y2-ar_size, width, color));
	win.Draw(sf::Shape::Line(x2, y2, x2-ar_size, y2+ar_size, width, color));
    }
    else if(x1 == x2) // Vertical arrow
    {
	if(y1 > y2)
	    ar_size *= -1;
	win.Draw(sf::Shape::Line(x2, y2, x2-ar_size, y2-ar_size, width, color));
	win.Draw(sf::Shape::Line(x2, y2, x2+ar_size, y2-ar_size, width, color));
    }
    else
    {  // Arrow of an arbitrary angle.
	if(x1 > x2)
	    ang = 3.0*PI/4.0 - atan((double)(y1 - y2) / (double)(x1 - x2));
	else
	    ang = PI/4.0 - atan((double)(y1 - y2) / (double)(x1 - x2));
	
	deltaX = (double)ar_size * cos(ang);
	deltaY = (double)ar_size * sin(ang);
	
	if(x1 > x2)
	{
	    win.Draw(sf::Shape::Line(x2, y2, (double)x2-deltaX, (double)y2+deltaY, width, color));
	    win.Draw(sf::Shape::Line(x2, y2, (double)x2+deltaY, (double)y2+deltaX, width, color));
	}
	else
	{
	    win.Draw(sf::Shape::Line(x2, y2, (double)x2-deltaX, (double)y2+deltaY, width, color));
	    win.Draw(sf::Shape::Line(x2, y2, (double)x2-deltaY, (double)y2-deltaX, width, color));
	}
    }

}

// Draw a line chart

// n_points: Number of points. The points are scaled to fill the x axis.

// n_lines: If there are more than one line, int* y_values should include all the values interleaved
//
// y_pnt_incr can be set other to 1 to skip values. This is useful if your y_values table includes
// several datasets (lines) but you want to draw only one line, or if you just want to skip values.
//
// clear_mode: 0 = don't clear anything, 1 = clear the whole device, 2 = draw a block for the area.

int max_of(int* table, int points, int pnt_incr = 1)
{
    signed long int max = -2147483647;
    for(int i = 0; i < points; i+=pnt_incr)
	if(table[i] > max)
	    max = table[i];

    return max;
}

int min_of(int* table, int points, int pnt_incr = 1)
{
    signed long int min = 2147483647;
    for(int i = 0; i < points; i+=pnt_incr)
	if(table[i] < min)
	    min = table[i];

    return min;
}

int min_of(int val1, int val2)
{
    if(val1 < val2)
	return val1;
    else
	return val2;
}

void draw_chart(sf::RenderWindow& win, const sf::Font& font,
		int n_lines, int n_points, 
		int* x_values, int* y_values, sf::Color* colors, 
		int x_size, int y_size, int x_loc = 0, int y_loc = 0,
		bool auto_y = true, int min_y = 0, int max_y = 0, 
		int x_pnt_incr = 1, int y_pnt_incr = 1, 
		const char* title = 0, const char* xtitle = 0, const char* ytitle = 0, 
		int n_ver_grid = 0, int n_hor_grid = 0, // 0 = off
                int clear_mode = 2, sf::Color clear_color = sf::Color(255,255,255), sf::Color back_color = sf::Color(200,220,255), int line_w = 3, bool flush = true,
		int decimate = 1, int title_font_size = 17)
{

    int area_x_size = x_size - CHART_LEFT_MARGIN - CHART_RIGHT_MARGIN;
    int area_y_size = y_size - CHART_TOP_MARGIN - CHART_BOT_MARGIN;

    const sf::Color axis_color = sf::Color(0,0,0);
    const sf::Color grid_color = sf::Color(0,0,0,128);
    int axis_w = 2;

//    int line_w = 3;

    int grid_pen = 9;
    int grid_w = 1;

    const sf::Color title_font_color = sf::Color(0,0,0);

    if(clear_mode == 1)
    {
	win.Clear(clear_color);
    }
    else if(clear_mode == 2 || clear_mode == 3)
    {
	if(clear_mode == 3)
	{
	    win.Clear(clear_color);
	}
	win.Draw(sf::Shape::Rectangle(x_loc+CHART_LEFT_MARGIN, y_loc+CHART_TOP_MARGIN,
				      x_loc+x_size-CHART_RIGHT_MARGIN, y_loc+y_size-CHART_BOT_MARGIN, back_color));
    }

    sf::String titlestr(title, font, title_font_size);
    titlestr.SetColor(title_font_color);
    titlestr.SetPosition(x_loc + CHART_LEFT_MARGIN, y_loc + 5);
    win.Draw(titlestr);

    // X axis:
    win.Draw(sf::Shape::Line(x_loc + CHART_LEFT_MARGIN, y_loc + CHART_TOP_MARGIN + area_y_size, x_loc + x_size-CHART_RIGHT_MARGIN, y_loc + CHART_TOP_MARGIN + area_y_size, 
			     axis_w, axis_color));
    // Y axis:
    win.Draw(sf::Shape::Line(x_loc + CHART_LEFT_MARGIN, y_loc + y_size-CHART_BOT_MARGIN, x_loc + CHART_LEFT_MARGIN, y_loc + CHART_TOP_MARGIN, axis_w, axis_color));

    int min_of_y = min_of(y_values, n_points*n_lines, y_pnt_incr);
    int max_of_y = max_of(y_values, n_points*n_lines, y_pnt_incr);
    int max_of_x = max_of(x_values, n_points, x_pnt_incr);
      

    double x_scale; 
    double y_scale;

    double y_offset; // pixels

    x_scale = (double)area_x_size / (double)max_of_x;

    if(auto_y)
    {
	y_scale = (double)area_y_size / ((double)max_of_y-(double)min_of_y);
	y_offset = -1.0 * y_scale * (double)min_of_y; 
    }
    else
    {
	y_scale = (double)area_y_size / ((double)max_y-(double)min_y);
	y_offset = 1.0 * y_scale * (double)min_y;
    }




    // Draw the data:

	double width = (double)area_x_size/(double)n_points;
	int lw = ceil(width);

	for(int point = 0; point < n_points; point++)
	{
	    if(point%decimate == 0)
	    {
		if(y_values[point*y_pnt_incr*2] > 0)
		{
			// First draw data
//			g2_line(dev,
//				width/2 + x_loc + CHART_LEFT_MARGIN+width*point,
//				y_loc + CHART_BOT_MARGIN + y_offset,
//				width/2 + x_loc + CHART_LEFT_MARGIN+width*point,
//				y_loc + CHART_BOT_MARGIN+y_scale*(y_values[point*y_pnt_incr*2]+1) + y_offset);
			win.Draw(sf::Shape::Line(width/2 + x_loc + CHART_LEFT_MARGIN+width*point,
						 y_loc + y_size - CHART_BOT_MARGIN - y_offset,
						 width/2 + x_loc + CHART_LEFT_MARGIN+width*point,
						 y_loc + y_size - CHART_BOT_MARGIN - y_offset - y_scale*(y_values[point*y_pnt_incr*2]),
						 lw, colors[0]));
		}		
		// Then draw stall
		
		if(y_values[point*y_pnt_incr*2+1] > 0)
		{
			win.Draw(sf::Shape::Line(width/2 + x_loc + CHART_LEFT_MARGIN+width*point,
						 y_loc + y_size - CHART_BOT_MARGIN - y_offset - y_scale*(y_values[point*y_pnt_incr*2]),
						 width/2 + x_loc + CHART_LEFT_MARGIN+width*point,
						 y_loc + y_size - CHART_BOT_MARGIN - y_offset - y_scale*((y_values[point*y_pnt_incr*2])+
													 (y_values[point*y_pnt_incr*2+1])),
						 lw, colors[1]));


//			g2_line(dev,
//				width/2 + x_loc + CHART_LEFT_MARGIN+width*point,
//				y_loc + CHART_BOT_MARGIN+y_scale*(y_values[point*y_pnt_incr*2]+1) + y_offset,
//				width/2 + x_loc + CHART_LEFT_MARGIN+width*point,
//				y_loc + CHART_BOT_MARGIN+y_scale*
//				((y_values[point*y_pnt_incr*2]+1) + (y_values[point*y_pnt_incr*2+1]+1))
//				+ y_offset
//				);
		}
		}
	}

	    // Draw the grids:

    // Draw X axis grid (vertical grid)
    if(n_ver_grid != 0)
    {
	double ver_grid_space = (double)area_x_size/n_ver_grid;

	for(double i = ver_grid_space; i < (double)area_x_size+1.0; i += ver_grid_space)
	    win.Draw(sf::Shape::Line(
	    x_loc + (double)CHART_LEFT_MARGIN+i, 
	    y_loc + CHART_TOP_MARGIN, 
	    x_loc + (double)CHART_LEFT_MARGIN+i, 
	    y_loc + CHART_TOP_MARGIN+area_y_size,
	    grid_w, grid_color));

    }

    // Draw Y grid (hor)
    if(n_hor_grid != 0)
    {
	double hor_grid_space = (double)area_y_size/n_hor_grid;

	for(double i = hor_grid_space; i < (double)area_y_size+1.0; i += hor_grid_space)
	    win.Draw(sf::Shape::Line(
	    x_loc + CHART_LEFT_MARGIN, 
	    y_loc + (double)CHART_TOP_MARGIN+i, 
	    x_loc + CHART_LEFT_MARGIN+area_x_size, 
	    y_loc + (double)CHART_TOP_MARGIN+i,
	    grid_w, grid_color));
    }

    if(flush)
	win.Display();

}

 /*
void old_draw_chart(int dev, 
		int n_lines, int n_points, 
		int* x_values, int* y_values, int* pens, 
		int x_size, int y_size, int x_loc = 0, int y_loc = 0,
		bool auto_y = true, int min_y = 0, int max_y = 0, 
		int x_pnt_incr = 1, int y_pnt_incr = 1, 
		const char* title = 0, const char* xtitle = 0, const char* ytitle = 0, 
		int n_ver_grid = 0, int n_hor_grid = 0, // 0 = off
                int clear_mode = 2, int clear_pen = 1, int line_w = 3, bool flush = true,
		int decimate = 1, int title_font_size = 17)
{

    int area_x_size = x_size - CHART_LEFT_MARGIN - CHART_RIGHT_MARGIN;
    int area_y_size = y_size - CHART_TOP_MARGIN - CHART_BOT_MARGIN;

    int axis_pen = 0;
    int axis_w = 2;

//    int line_w = 3;

    int grid_pen = 9;
    int grid_w = 1;

    int title_font_pen = 0;


    if(clear_mode == 1)
    {
	g2_set_background(dev, clear_pen);
        g2_clear(dev);
    }
    else if(clear_mode == 2)
    {
	g2_pen(dev, clear_pen);
	g2_filled_rectangle(dev, x_loc, y_loc, x_loc+x_size, y_loc+y_size);
    }

    g2_set_font_size(dev, title_font_size);
    g2_pen(dev, title_font_pen);
    g2_string(dev, x_loc + CHART_LEFT_MARGIN, y_loc + y_size - title_font_size - 2, title);

    g2_pen(dev, axis_pen);
    g2_set_line_width(dev, axis_w);
    g2_line(dev, x_loc + CHART_LEFT_MARGIN, y_loc + CHART_BOT_MARGIN, x_loc + x_size-CHART_RIGHT_MARGIN, y_loc + CHART_BOT_MARGIN); // X axis
    g2_line(dev, x_loc + CHART_LEFT_MARGIN, y_loc + CHART_BOT_MARGIN, x_loc + CHART_LEFT_MARGIN, y_loc + y_size-CHART_TOP_MARGIN); // Y axis

    int min_of_y = min_of(y_values, n_points*n_lines, y_pnt_incr);
    int max_of_y = max_of(y_values, n_points*n_lines, y_pnt_incr);
    int max_of_x = max_of(x_values, n_points, x_pnt_incr);
      

    double x_scale; 
    double y_scale;

    double y_offset; // pixels

    x_scale = (double)area_x_size / (double)max_of_x;

    if(auto_y)
    {
	y_scale = (double)area_y_size / ((double)max_of_y-(double)min_of_y);
	y_offset = -1.0 * y_scale * (double)min_of_y; 
    }
    else
    {
	y_scale = (double)area_y_size / ((double)max_y-(double)min_y);
	y_offset = 1.0 * y_scale * (double)min_y;
    }


    // Draw the grids:

    // Draw X axis grid (vertical grid)
    if(n_ver_grid != 0)
    {
	g2_pen(dev, grid_pen);
	g2_set_line_width(dev, grid_w);

	double ver_grid_space = (double)area_x_size/n_ver_grid;

	for(double i = ver_grid_space; i < (double)area_x_size+1.0; i += ver_grid_space)
	    g2_line(dev, x_loc + (double)CHART_LEFT_MARGIN+i, y_loc + CHART_BOT_MARGIN, x_loc + (double)CHART_LEFT_MARGIN+i, y_loc + CHART_BOT_MARGIN+area_y_size);

    }

    // Draw Y grid (hor)
    if(n_hor_grid != 0)
    {
	g2_pen(dev, grid_pen);
	g2_set_line_width(dev, grid_w);

	double hor_grid_space = (double)area_y_size/n_hor_grid;

	for(double i = hor_grid_space; i < (double)area_y_size+1.0; i += hor_grid_space)
	    g2_line(dev, x_loc + CHART_LEFT_MARGIN, y_loc + (double)CHART_BOT_MARGIN+i, x_loc + CHART_LEFT_MARGIN+area_x_size, y_loc + (double)CHART_BOT_MARGIN+i);
    }


    // Draw the data:

    g2_set_line_width(dev, line_w); //!!!!
//    for(int curline = 0; curline < n_lines; curline++)
    for(int curline = n_lines-1; curline>=0; curline--)
    {
	g2_pen(dev, pens[curline]);
	int curpoint_y = y_pnt_incr*n_lines+curline;
	int cnt = 0;
	for(int curpoint_x = x_pnt_incr; curpoint_x < n_points*x_pnt_incr; curpoint_x+=x_pnt_incr)
	{
	    if(cnt%decimate == 0)
	    {
		g2_line(dev,
		    x_loc + CHART_LEFT_MARGIN+x_scale*x_values[curpoint_x - x_pnt_incr],
		    y_loc + CHART_BOT_MARGIN+y_scale*y_values[curpoint_y - y_pnt_incr*n_lines] + y_offset,
		    x_loc + CHART_LEFT_MARGIN+x_scale*x_values[curpoint_x],
		    y_loc + CHART_BOT_MARGIN+y_scale*y_values[curpoint_y] + y_offset);
	    }    
	    curpoint_y += y_pnt_incr*n_lines;
	    cnt++;

	} // end for(int curpoint...)
	
//	g2_set_line_width(dev, line_w); // !!!!!!!

    } // end for(int curline...)

    if(flush)
	g2_flush(dev);

}
*/

void gui::draw_nav_bar()
{
    main_win.Draw(sf::Shape::Line(nav_bar.left, vis_window_ysize-nav_bar.bottom, vis_window_xsize-nav_bar.right, vis_window_ysize-nav_bar.bottom,
				  nav_bar.line_width, BAR_COLOR));
				  

    double bar_pixel_length = (double)(vis_window_xsize-nav_bar.left-nav_bar.right-2*nav_bar.ends_line_width);
    double bar_scale = bar_pixel_length / (double)nav_bar.num_of_snapshots;
    double bar_pos = (double) nav_bar.location * bar_scale;
    double bar_len = (double) nav_bar.zoom_region * bar_scale;
    if(bar_len < 1.0)
	bar_len = 1.0;

    if(bar_len < nav_bar.min_bar_len)
    {
	// Draw drag assistance bar
	main_win.Draw(sf::Shape::Line(nav_bar.left+nav_bar.ends_line_width+bar_pos+bar_len/2-nav_bar.min_bar_len/2,
				      vis_window_ysize-nav_bar.bottom, 
				      nav_bar.left+nav_bar.ends_line_width+bar_pos+bar_len/2+nav_bar.min_bar_len/2, 
				      vis_window_ysize-nav_bar.bottom,
				      nav_bar.sel_line_width,
				      nav_bar.dragging?SEL_COLOR:DRAG_ASSIST_COLOR));

    }

    main_win.Draw(sf::Shape::Line(nav_bar.left+nav_bar.ends_line_width+bar_pos, vis_window_ysize-nav_bar.bottom, 
				  nav_bar.left+nav_bar.ends_line_width+bar_pos+bar_len, vis_window_ysize-nav_bar.bottom,
				  nav_bar.sel_line_width,
				  nav_bar.dragging?DRAG_COLOR:SEL_COLOR));


    // Draw the ends. They overlap with assistance bar if it exists.
    main_win.Draw(sf::Shape::Line(nav_bar.left, vis_window_ysize-nav_bar.bottom-nav_bar.sel_line_width/2, 
				  nav_bar.left, vis_window_ysize-nav_bar.bottom+nav_bar.sel_line_width/2,
				  nav_bar.ends_line_width, BAR_COLOR));
    main_win.Draw(sf::Shape::Line(vis_window_xsize-nav_bar.right, vis_window_ysize-nav_bar.bottom-nav_bar.sel_line_width/2, 
				  vis_window_xsize-nav_bar.right, vis_window_ysize-nav_bar.bottom+nav_bar.sel_line_width/2,
				  nav_bar.ends_line_width, BAR_COLOR));

    char loctmp[200];
    sprintf(loctmp, "loc: %d, zoom: %d, length: %d", nav_bar.location, nav_bar.zoom_region, nav_bar.num_of_snapshots);
    sf::String locstr(loctmp, def_font, small_font_size);
    locstr.SetPosition(nav_bar.left, vis_window_ysize-nav_bar.bottom-nav_bar.sel_line_width-small_font_size+2);
    locstr.SetColor(sf::Color(80,80,80));
    main_win.Draw(locstr);

}

void gui::process_nav_bar_drag()
{
    double bar_pixel_length = (double)(vis_window_xsize-nav_bar.left-nav_bar.right-2*nav_bar.ends_line_width);
    double bar_scale = bar_pixel_length / (double)nav_bar.num_of_snapshots;
    double bar_pos = (double) nav_bar.location * bar_scale;
    double bar_len = (double) nav_bar.zoom_region * bar_scale;

    int x, y, y2;
    bool mouse;
    bool mouse_left;
    bool mouse_right;
    main_ui.query_mouse(&x, &y2, &mouse_left, 0, &mouse_right);
    mouse = mouse_left || mouse_right;

    y = vis_window_ysize-y2;
    int left_bound;
    int right_bound;

    if(bar_len < nav_bar.min_bar_len)
    {
	// Assistance bar should be taken into account.
	left_bound = nav_bar.left + nav_bar.ends_line_width + bar_pos + bar_len/2 - nav_bar.min_bar_len/2;
	right_bound = nav_bar.left + nav_bar.ends_line_width + bar_pos + bar_len/2 + nav_bar.min_bar_len/2;

    }
    else
    {
	left_bound = nav_bar.left + nav_bar.ends_line_width + bar_pos;
	right_bound = nav_bar.left + nav_bar.ends_line_width + bar_pos + bar_len;
    }

    if(nav_bar.dragging == false && mouse && x > left_bound && x < right_bound
       && y > nav_bar.bottom - nav_bar.sel_line_width/2 && y < nav_bar.bottom + nav_bar.sel_line_width/2)
    {
	// DRAGGING STARTS
	nav_bar.dragging = true;
	nav_bar.drag_mouse_offset = x - (nav_bar.left + bar_pos);
    }
    else if(nav_bar.dragging == false && nav_bar.clicking == false && mouse && x > nav_bar.left && x < vis_window_xsize-nav_bar.right
	    && (x < left_bound || x > right_bound)
	    && y > nav_bar.bottom - nav_bar.sel_line_width/2 && y < nav_bar.bottom + nav_bar.sel_line_width/2)
    {
	nav_bar.clicking = true;
	// CLICK ON THE LINE OUTSIDE THE BAR
	if(x < left_bound)
	{
	    nav_bar.location -= nav_bar.zoom_region;
	    if(nav_bar.location < 0) 
		nav_bar.location = 0;
	}
	else if(x > right_bound)
	{
	    nav_bar.location += nav_bar.zoom_region;
	    if(nav_bar.location > nav_bar.num_of_snapshots-nav_bar.zoom_region)
		nav_bar.location = nav_bar.num_of_snapshots-nav_bar.zoom_region;
	}

    }
    else if(nav_bar.dragging == true)
    {
	// DRAGGING GOING ON
	// Bar length stays the same, recalculate position.

	nav_bar.location = (x - nav_bar.left - nav_bar.drag_mouse_offset) / bar_scale;
	if(nav_bar.location < 0)
	{
	    nav_bar.location = 0;
	}
	else if(nav_bar.location > nav_bar.num_of_snapshots - nav_bar.zoom_region)
	{
	    nav_bar.location = nav_bar.num_of_snapshots - nav_bar.zoom_region;
	}

    }

    if(nav_bar.dragging == true && !mouse)
    {
	// DRAGGING STOPS
	nav_bar.dragging = false;
    }

    if(nav_bar.clicking == true && !mouse)
    {
	// CLICKING STOPS
	nav_bar.clicking = false;
    }

    y = y2;

    // Check for link clicking
    if(stats_->pd->net_type == 0 && nav_bar.dragging == false && mouse)
    {
	for(int i=0; i < stats_->pd->num_of_links; i++)
	{
	    if (x > meshnoc.mesh_link_click_coords[i][0] &&
		x < meshnoc.mesh_link_click_coords[i][2] &&
		y > meshnoc.mesh_link_click_coords[i][1] &&
		y < meshnoc.mesh_link_click_coords[i][3])
	    {
		if(mouse_left)
		    stats_->last_values_link_num[0] = i;
		else
		    stats_->last_values_link_num[1] = i;
//		cout << "Link selected: " << i << endl;
		break;
	    }

	}

    }

}

int gui::add_range(int start, int end)
{
    if(end == -1)
    {
	ranges[num_ranges].start = start;
	ranges[num_ranges].complete = false;
	incomplete_range = true;
    }
    else
    {
	ranges[num_ranges].complete = true;
	if(start < end)
	{
	    ranges[num_ranges].start = start;
	    ranges[num_ranges].end = end;
	}
	else
	{
	    ranges[num_ranges].start = end;
	    ranges[num_ranges].end = start;
	}
    }

    num_ranges++;

    return num_ranges-1;
}

int gui::complete_range(int id, int end)
{
    ranges[id].complete = true;
    incomplete_range = false;
    if(ranges[id].start < end)
    {
	ranges[id].end = end;
    }
    else
    {
	ranges[id].end = ranges[id].start;
	ranges[id].start = end;
    }
    return id;
}


void gui::process_chart_click(int win_id)
{
    double bar_scale = (double)(chart_xsize-CHART_LEFT_MARGIN-CHART_RIGHT_MARGIN) / (double)nav_bar.zoom_region;


    int x, y;
    bool mouse_left;
    bool mouse_right;
    static bool chart_clicking[MAX_LINK_WINS] = {false, false};

    linkwin_uis[win_id].query_mouse(&x, &y, &mouse_left, 0, &mouse_right);

    if(mouse_left || mouse_right)
    {
	if(chart_clicking[win_id] == false &&
	   y > CHART_TOP_MARGIN && y < chart_ysize-CHART_BOT_MARGIN &&
	   x > CHART_LEFT_MARGIN && x < chart_xsize-CHART_RIGHT_MARGIN)
	{
	    if(mouse_left)
	    {
		chart_clicking[win_id] = true;

		if(incomplete_range == false)
		{
		    int s = nav_bar.location + (int)((double)(x - CHART_LEFT_MARGIN) / bar_scale);
		    int r = add_range(s, -1);
//		    cout << "Added new range " << r << " starting at snapshot " << s << "." << endl;
		    link_wins[win_id].Draw(sf::Shape::Line(x, CHART_TOP_MARGIN, x, chart_ysize-CHART_BOT_MARGIN, 2, sf::Color(80, 130, 220)));
		    link_wins[win_id].Display();
		}
		else
		{
		    int e = nav_bar.location + (int)((double)(x - CHART_LEFT_MARGIN) / bar_scale);
		    complete_range(num_ranges-1, e);
//		    cout << "Completed range " << num_ranges-1 << ": " 
//			 << ranges[num_ranges-1].start << " to " << ranges[num_ranges-1].end << "." << endl;
//		    cout << "Setting zoom region." << endl;
		    nav_bar.location = ranges[num_ranges-1].start;
		    nav_bar.zoom_region = ranges[num_ranges-1].end-ranges[num_ranges-1].start+1;

		    link_wins[win_id].Draw(sf::Shape::Line(x, CHART_TOP_MARGIN, x, chart_ysize-CHART_BOT_MARGIN, 2, sf::Color(80, 130, 220)));
		    link_wins[win_id].Display();

		    redraw = true;
			
		    num_ranges--; // reuse range.
		}

	    }

	}

    }
    else
    {
	chart_clicking[win_id] = false;
    }

}

void print_int_with_postfix(int val, char* str, int precision)
{
    if(val<1000)
	sprintf(str, "%d", val);
    else if(val < 1000000)
	sprintf(str, "%.*f k", precision+((val<10000)?1:0), val/1000.0);
    else if(val < 1000000000)
	sprintf(str, "%.*f M", precision+((val<10000000)?1:0), val/1000000.0);
    else
	sprintf(str, "%.*f G", precision+1, val/1000000000.0);
}

void print_int_with_postfix(unsigned long long int val, char* str, int precision)
{
    if(val<1000)
	sprintf(str, "%d", val);
    else if(val < 1000000)
	sprintf(str, "%.*f k", precision+((val<10000)?1:0), val/1000.0);
    else if(val < 1000000000)
	sprintf(str, "%.*f M", precision+((val<10000000)?1:0), val/1000000.0);
    else
	sprintf(str, "%.*f G", precision+1, val/1000000000.0);
}

void print_int_with_postfix(signed long long int val, char* str, int precision)
{
    char sign[2] = {0, 0};
    if(val < 0)
    {
	sign[0] = '-';
	val *= -1;
    }
    
    if(val<1000)
	sprintf(str, "%s%d", sign, val);
    else if(val < 1000000)
	sprintf(str, "%s%.*f k", sign, precision+((val<10000)?1:0), val/1000.0);
    else if(val < 1000000000)
	sprintf(str, "%s%.*f M", sign, precision+((val<10000000)?1:0), val/1000000.0);
    else
	sprintf(str, "%s%.*f G", sign, precision+1, val/1000000000.0);
}

// -1 for no click, otherwise PE number
int gui::process_pe_click()
{
    int x, y;
    bool mouse, mouse2, mouse3;
    main_ui.query_mouse(&x, &y, &mouse, &mouse2, &mouse3);

    if(mouse)
    {
	for(int ag = 0; ag < stats_->pd->num_of_agents; ag++)
	{
	    if(x > PE_click_coords[ag][0] &&
	       x < PE_click_coords[ag][2] &&
	       y > PE_click_coords[ag][3] &&
	       y < PE_click_coords[ag][1])
	    {
		return ag;
	    }
	}
    }

    return -1;
}

void gui::wait_click()
{
    int x, y;
    bool mouse = false;
    bool mouse2, mouse3;

    while(mouse == false)
    {
        sf::Event event;
        while(main_win.GetEvent(event));

	main_ui.query_mouse(&x, &y, &mouse, &mouse2, &mouse3);
    }
}

void gui::wait_mouse_release()
{
    int x, y;
    bool mouse = true;

    while(mouse)
    {
        sf::Event event;
        while(main_win.GetEvent(event));

	main_ui.query_mouse(&x, &y, &mouse);
    }
}


void gui::select_ips_graphically(vector<int>& selected)
{
    bool all_ips[MAX_NUM_PES];
    for(int i = 0; i < stats_->pd->num_of_agents; i++)
	all_ips[i] = false;

    for(int i = 0; i < selected.size(); i++)
    {
	all_ips[selected.at(i)] = true;
	sf::Shape rect = sf::Shape::Rectangle(PE_click_coords[selected[i]][0],
					      PE_click_coords[selected[i]][1], 
					      PE_click_coords[selected[i]][2], 
					      PE_click_coords[selected[i]][3],
					      sf::Color(0,0,0),
					      2, sf::Color(255, 0, 0));
	rect.EnableFill(false);
	main_win.Draw(rect);
	main_win.Display();
	main_win.Draw(rect);
	main_win.Display();
    }

    main_ui.show_button(vis_buttons.done);
    main_ui.draw_button(vis_buttons.done);
    main_win.Display();
    main_ui.draw_button(vis_buttons.done);
    main_win.Display();

    while(true)
    {
	bool click = false;
        sf::Event event;
        while(main_win.GetEvent(event))
	{
	    if(event.Type == sf::Event::MouseButtonPressed)
		click = true;
	}

	if(!click)
	    continue;

	int ip = -1;
        ip = process_pe_click();
	if(ip != -1)
	{
	    if(all_ips[ip] == false)
	    {
		all_ips[ip] = true;
	    }
	    else
	    {
		all_ips[ip] = false;
	    }

	    sf::Shape rect = sf::Shape::Rectangle(PE_click_coords[ip][0],
						  PE_click_coords[ip][1], 
						  PE_click_coords[ip][2], 
						  PE_click_coords[ip][3],
						  sf::Color(0,0,0),
						  2, all_ips[ip]?sf::Color(255, 0, 0):sf::Color(255, 255, 255));
	    rect.EnableFill(false);
	    main_win.Draw(rect);
	    main_win.Display();
	    main_win.Draw(rect);
	    main_win.Display();
	}

	if(main_ui.check_button_status() == vis_buttons.done)
	    break;

	wait_mouse_release();

    }

    main_ui.hide_button(vis_buttons.done);

    // Clear the red rectangles before returning...
    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	sf::Shape rect = sf::Shape::Rectangle(PE_click_coords[i][0],
					      PE_click_coords[i][1], 
					      PE_click_coords[i][2], 
					      PE_click_coords[i][3],
					      sf::Color(0,0,0),
					      2, sf::Color(255, 255, 255));
	rect.EnableFill(false);
	main_win.Draw(rect);
	main_win.Display();
	main_win.Draw(rect);
	main_win.Display();
    }

    // Save clicked PEs

    selected.clear();
    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	if(all_ips[i] == true)
	    selected.push_back(i);
    }


}

int gui::explore_file(bool realtime, ifstream* inp_stream, unsigned long int size)
{
    p2p_inv.set_stream(inp_stream);

    ifstream deci_streams[DECIMATION_ZONES];
    ifstream* deci_stream = 0;

    ifstream p2p_stream;
    ifstream p2p_deci_streams[DECIMATION_ZONES];
    ifstream* p2p_deci_stream = 0;

    unsigned char* data;

    stats_->realtime = false;
//    show_hide_nav_buttons(!realtime);

    if(realtime)
	nav_bar.num_of_snapshots = 100000;

    if(!realtime)
    {
	if(size % stats_->pd->snapshot_bytes != 0)
	{
	    cerr << "WARNING!" << endl;
	    cerr << "The file size is wrong! Possible reasons:" << endl;
	    cerr << "- Settings like network type, window length, number of agents etc. might be wrong" << endl;
	    cerr << "- The binary file might be for different network configuration" << endl;
	    cerr << "- Data is lost from the file" << endl;
	    cerr << "- There is extra data in the file" << endl;
	}
	else if(size % (stats_->pd->snapshot_bytes*stats_->pd->snapshots_per_packet) != 0)
	{
	    cerr << "Warning: It seems that the file is cut from the original trace." << endl;
	}

	data = new unsigned char[size];
    

    // 247353 = pallurat3:n algoritmi2 powerpoint-esimerkki

    // 247080 = pallurat3:n tapahtumat, pituus 198520

    // 83599  = pallurat1:n tapahtumat, pituus 200339

    // 78820  = pallurat2:n tapahtumat, pituus 199840

	nav_bar.location = 0;
	nav_bar.num_of_snapshots = size/stats_->pd->snapshot_bytes;
    }

    if(realtime)
	nav_bar.zoom_region = stats_->logging_length;
    else
	nav_bar.zoom_region = 1;

    if(!realtime)
	if(nav_bar.zoom_region > nav_bar.num_of_snapshots)
	    nav_bar.zoom_region = nav_bar.num_of_snapshots;


 //   boost::asio::io_service io;

    bool main_button_pressed = false;
    bool p2p_button_pressed = false;
    bool play = false;
    bool slow = false;

//    unsigned int last_mouse = 999;
    bool mouse_left = true;
    bool mouse_mid = false;
    bool mouse_right = false;
    

    bool last_dragging = false;

    if(!realtime)
    {
	// USE DECIMATION
	use_decimation = true;
	main_ui.buttons[vis_buttons.decimation]->pressed = true;

	cout << "Opening decimation files..." << endl;

	bool create_files = false;
	for(int i = 0; i < DECIMATION_ZONES; i++)
	{
	  open_again:
	    char dname[505];
	    sprintf(dname, "%s.deci%d", stats_->pd->bin_name, stats_->navi_decimation[i]);
	    deci_streams[i].open(dname, ios::binary | ios::in);
	    if(!deci_streams[i].good())
	    {
		if(!create_files)
		{
		    cout << "No decimation file " << dname << " found. Do you want to create the decimation files now? [y/n]" << endl;
		    char sel = 'y';
		    cin >> sel;
		    if(sel == 'y' || sel == 'Y')
		    {
			create_files = true;
		    }
		    else
		    {
			cout << "Decimation disabled." << endl;
			use_decimation = false;
			main_ui.buttons[vis_buttons.decimation]->pressed = false;
			break;
		    }
		}

		if(create_files)
		{
		    cout << "Creating " << dname << "..." << endl;
		    stats_->create_decimation_file(*inp_stream, size, nav_bar.num_of_snapshots, stats_->navi_decimation[i]);
		    goto open_again;
		}
	    }
	}

	cout << "Opening p2p files..." << endl;
	char p2pfilename[500];
	sprintf(p2pfilename, "%s.p2p", stats_->pd->bin_name);
	p2p_stream.open(p2pfilename, ios::binary | ios::in);
	bool p2p_open_failure = false;

	for(int i = 0; i < DECIMATION_ZONES; i++)
	{
	    char dname[505];
	    sprintf(dname, "%s.p2pdeci%d", stats_->pd->bin_name, stats_->navi_decimation[i]);
	    p2p_deci_streams[i].open(dname, ios::binary | ios::in);
	    if(!p2p_deci_streams[i].good())
		p2p_open_failure = true;
	}

	if(!p2p_inv.read_totals_file())
	    p2p_open_failure = true;

	if(p2p_inv.read_view_file())
	   cout << "Found P2P Path View file, will use it." << endl;

	if(!p2p_stream.good() || p2p_open_failure)
	{
	    p2p_inv.enable_p2p = false;
	    cout << "No p2p files found. Use CMD -> P2P Investigator to generate the files and enable P2P Investigator"  << endl;
	}
	else
	{
	    p2p_inv.enable_p2p = true;
	    // Allocate memory for the whole zoom level of p2p investigator statistics now.
//	    p2p_inv.p2p_statistics_disc = (p2p_investigator::p2p_path_stats***) new char[p2p_inv.p2p_disc_paths_bytes*
//											 nav_bar.num_of_snapshots];
	    cout << "Allocating memory for p2p investigator..." << endl;
	    p2p_inv.p2p_statistics_disc = new p2p_investigator::p2p_path_stats**[10000]; // nav_bar.num_of_snapshots];
	    for(int i = 0; i < 10000; i++) // nav_bar.num_of_snapshots; i++)
	    {
		p2p_inv.p2p_statistics_disc[i] = new p2p_investigator::p2p_path_stats*[stats_->pd->num_of_agents];
		for(int o = 0; o < stats_->pd->num_of_agents; o++)
		    p2p_inv.p2p_statistics_disc[i][o] = new p2p_investigator::p2p_path_stats[stats_->pd->num_of_agents];
	    }
	}

    }			
	//
	
    sf::Clock refresh_clk;
    refresh_clk.Reset();

    bool resizing_main = false;
    bool resizing_p2p = false;
    bool resizing_link1 = false;
    bool resizing_link2 = false;
    int xs, ys;

    bool left = false;
    bool left_little = false;
    bool left_1 = false;
    bool right = false;
    bool right_little = false;
    bool right_1 = false;
    bool out = false;
    bool out_little = false;
    bool out_1 = false;
    bool in = false;
    bool in_little = false;
    bool in_1 = false;
    bool zoom_changed = false;

    while(main_win.IsOpened())
    {
//	sf::Clock profile_clk;
//	vector<double> profile_clk_vect;
//	profile_clk.Reset();
//	profile_clk_vect.push_back(profile_clk.GetElapsedTime());

	if(refresh_clk.GetElapsedTime() > 1.0)
	{
	    redraw = true;
	}

        sf::Event event;
        while(main_win.GetEvent(event))
        {
	    if(event.Type == sf::Event::Resized)
	    {
		xs = event.Size.Width;
		ys = event.Size.Height;
		resizing_main = true;
	    }
            if(event.Type == sf::Event::Closed)
                main_win.Close();
	    if(event.Type == sf::Event::GainedFocus)
		redraw = true;
	    if(event.Type == sf::Event::LostFocus)
		redraw = true;
	    if(event.Type == sf::Event::MouseEntered)
		redraw = true;
	    if(event.Type == sf::Event::MouseLeft)
		redraw = true;
	    if (!realtime && (event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Left))
	    {
		if(event.Key.Control)    left_1 = true;
		else if(event.Key.Shift) left = true;
		else                     left_little = true;
	    }
	    if (!realtime && (event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Right))
	    {
		if(event.Key.Control)    right_1 = true;
		else if(event.Key.Shift) right = true;
		else                     right_little = true;
	    }
	    if ((event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Up))
	    {
		if(event.Key.Control)    out_1 = true;
		else if(event.Key.Shift) out = true;
		else                     out_little = true;

	    }
	    if ((event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Down))
	    {
		if(event.Key.Control)    in_1 = true;
		else if(event.Key.Shift) in = true;
		else                     in_little = true;
	    }

        }

	while(link_wins[0].GetEvent(event))
	{
	    if(event.Type == sf::Event::Resized)
	    {
		resizing_link1 = true;
		xs = event.Size.Width;
		ys = event.Size.Height;
	    }
	    if(event.Type == sf::Event::GainedFocus)
		redraw = true;
	    if(event.Type == sf::Event::LostFocus)
		redraw = true;
	    if(event.Type == sf::Event::MouseEntered)
		redraw = true;
	    if(event.Type == sf::Event::MouseLeft)
		redraw = true;
	    if (!realtime && (event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Left))
	    {
		if(event.Key.Control)    left_1 = true;
		else if(event.Key.Shift) left = true;
		else                     left_little = true;
	    }
	    if (!realtime && (event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Right))
	    {
		if(event.Key.Control)    right_1 = true;
		else if(event.Key.Shift) right = true;
		else                     right_little = true;
	    }
	    if ((event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Up))
	    {
		if(event.Key.Control)    out_1 = true;
		else if(event.Key.Shift) out = true;
		else                     out_little = true;

	    }
	    if ((event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Down))
	    {
		if(event.Key.Control)    in_1 = true;
		else if(event.Key.Shift) in = true;
		else                     in_little = true;
	    }

	}

	while(link_wins[1].GetEvent(event))
	{
	    if(event.Type == sf::Event::Resized)
	    {
		resizing_link2 = true;
		xs = event.Size.Width;
		ys = event.Size.Height;
	    }
	    if(event.Type == sf::Event::GainedFocus)
		redraw = true;
	    if(event.Type == sf::Event::LostFocus)
		redraw = true;
	    if(event.Type == sf::Event::MouseEntered)
		redraw = true;
	    if(event.Type == sf::Event::MouseLeft)
		redraw = true;
	    if (!realtime && (event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Left))
	    {
		if(event.Key.Control)    left_1 = true;
		else if(event.Key.Shift) left = true;
		else                     left_little = true;
	    }
	    if (!realtime && (event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Right))
	    {
		if(event.Key.Control)    right_1 = true;
		else if(event.Key.Shift) right = true;
		else                     right_little = true;
	    }
	    if ((event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Up))
	    {
		if(event.Key.Control)    out_1 = true;
		else if(event.Key.Shift) out = true;
		else                     out_little = true;

	    }
	    if ((event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Down))
	    {
		if(event.Key.Control)    in_1 = true;
		else if(event.Key.Shift) in = true;
		else                     in_little = true;
	    }

	}

	while(p2p_win.GetEvent(event))
	{
	    if(event.Type == sf::Event::Resized)
	    {
		resizing_p2p = true;
		xs = event.Size.Width;
		ys = event.Size.Height;
	    }
            if(event.Type == sf::Event::Closed)
                main_win.Close();
	    if(event.Type == sf::Event::GainedFocus)
		redraw = true;
	    if(event.Type == sf::Event::LostFocus)
		redraw = true;
	    if(event.Type == sf::Event::MouseEntered)
		redraw = true;
	    if(event.Type == sf::Event::MouseLeft)
		redraw = true;
	    if (!realtime && (event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Left))
	    {
		if(event.Key.Control)    left_1 = true;
		else if(event.Key.Shift) left = true;
		else                     left_little = true;
	    }
	    if (!realtime && (event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Right))
	    {
		if(event.Key.Control)    right_1 = true;
		else if(event.Key.Shift) right = true;
		else                     right_little = true;
	    }
	    if ((event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Up))
	    {
		if(event.Key.Control)    out_1 = true;
		else if(event.Key.Shift) out = true;
		else                     out_little = true;

	    }
	    if ((event.Type == sf::Event::KeyPressed) && (event.Key.Code == sf::Key::Down))
	    {
		if(event.Key.Control)    in_1 = true;
		else if(event.Key.Shift) in = true;
		else                     in_little = true;
	    }

	}

	if(resizing_main)
	{
	    vis_window_xsize = xs;
	    vis_window_ysize = ys;
	    initialize_graphics(true, false, realtime);
	    redraw = true;
	    resizing_main = false;
	}
	if(resizing_p2p)
	{
	    p2p_window_xsize = xs;
	    p2p_window_ysize = ys;
	    initialize_graphics(true, false, realtime);
	    redraw = true;
	    resizing_p2p = false;
	}
	else if(resizing_link1 || resizing_link2)
	{
	    chart_xsize = xs;
	    chart_ysize = ys;
	    initialize_graphics(true, false, realtime);
	    redraw = true;
	    resizing_link1 = false;
	    resizing_link2 = false;
	}


/*	main_win.Clear();
        main_win.Draw(sf::Shape::Line(10, 10, 710, 100, 15, sf::Color::Red));
        main_win.Draw(sf::Shape::Circle(200, 200, 100, sf::Color::Yellow, 10, sf::Color::Blue));
        main_win.Draw(sf::Shape::Rectangle(350, 200, 600, 350, sf::Color::Green));
	main_win.Display();
*/


	int x, y;
	main_ui.query_mouse(&x, &y, &mouse_left, &mouse_mid, &mouse_right);

	//	cout << x << "  " << y << "  " << mouse_left << mouse_mid << mouse_right << endl;

	if(mouse_left || mouse_mid || mouse_right)
	    redraw = true;

	process_nav_bar_drag(); // Link clicking also processed there
	process_chart_click(0);
	process_chart_click(1);


	if(nav_bar.dragging == true || last_dragging == true)
	    redraw = true;

	last_dragging = nav_bar.dragging;

	sf::Sleep(0.010);

//	profile_clk_vect.push_back(profile_clk.GetElapsedTime());
		
	if(nav_bar.dragging == false)
	{
	    // Sleep more if not dragging
	    sf::Sleep(0.025);

	    // Check buttons only if not dragging
	    int but_status = main_ui.check_button_status();
	    int p2p_but_status = p2p_ui.check_button_status();

	    if(but_status != -1 && main_button_pressed == false)
	    {
		main_button_pressed = true;
		redraw = true;
		if(but_status == vis_buttons.play)
		{
		    play = true;
		    slow = false;
		}
		else if(but_status == vis_buttons.playslow)
		{
		    play = true;
		    slow = true;
		}
		else if(but_status == vis_buttons.stop)
		{
		    play = false;
		}
		else if(but_status == vis_buttons.nav_bar_left)
		{
		    left_little = true;
		}
		else if(but_status == vis_buttons.nav_bar_right)
		{
		    right_little = true;
		}
		else if(but_status == vis_buttons.zoom_all)
		{
		    zoom_changed = true;
		    nav_bar.zoom_region = nav_bar.num_of_snapshots;
		    nav_bar.location = 0;
		}
		else if(but_status == vis_buttons.zoom_out)
		{
		    out = true;
		}
		else if(but_status == vis_buttons.zoom_out2)
		{
		    out_little = true;
		}
		else if(but_status == vis_buttons.zoom_in)
		{
		    in = true;
		}
		else if(but_status == vis_buttons.zoom_in2)
		{
		    in_little = true;
		}
		else if(but_status == vis_buttons.best)
		{
		    averaging_mode = MODE_BEST;	    
		    main_ui.buttons[vis_buttons.best]->pressed  = true;
		    main_ui.buttons[vis_buttons.avg]->pressed   = false;
		    main_ui.buttons[vis_buttons.worst]->pressed = false;
		    main_ui.buttons[vis_buttons.total]->pressed = false;

		}
		else if(but_status == vis_buttons.avg)
		{
		    averaging_mode = MODE_AVG;
		    main_ui.buttons[vis_buttons.best]->pressed  = false;
		    main_ui.buttons[vis_buttons.avg]->pressed   = true;
		    main_ui.buttons[vis_buttons.worst]->pressed = false;
		    main_ui.buttons[vis_buttons.total]->pressed = false;
		}
		else if(but_status == vis_buttons.worst)
		{
		    averaging_mode = MODE_WORST;
		    main_ui.buttons[vis_buttons.best]->pressed  = false;
		    main_ui.buttons[vis_buttons.avg]->pressed   = false;
		    main_ui.buttons[vis_buttons.worst]->pressed = true;
		    main_ui.buttons[vis_buttons.total]->pressed = false;
		}
		else if(but_status == vis_buttons.total)
		{
		    averaging_mode = MODE_TOTAL;
		    main_ui.buttons[vis_buttons.best]->pressed  = false;
		    main_ui.buttons[vis_buttons.avg]->pressed   = false;
		    main_ui.buttons[vis_buttons.worst]->pressed = false;
		    main_ui.buttons[vis_buttons.total]->pressed = true;
		}
		else if(but_status == vis_buttons.decimation)
		{
		    if(use_decimation)
		    {
			cout << "Disabling decimation..." << endl;
			for(int i = 0; i < DECIMATION_ZONES; i++)
			    deci_streams[i].close();
			use_decimation = false;
			stats_->decimate = false;
		    }
		    else
		    {
			cout << "Opening decimation files..." << endl;
			bool failure = false;
			use_decimation = false;
			for(int i = 0; i < DECIMATION_ZONES; i++)
			{
			    char dname[505];
			    sprintf(dname, "%s.deci%d", stats_->pd->bin_name, stats_->navi_decimation[i]);
			    deci_streams[i].open(dname, ios::binary | ios::in);
			    if(!deci_streams[i].good())
			    {
				cout << "Error opening file " << dname << "! Decimation not enabled." << endl;
				failure = true;
				break;
			    }
			}

			if(!failure)
			{
			    use_decimation = true;
			    cout << "Desimation in use!" << endl;
			}
		    }

		    main_ui.buttons[vis_buttons.decimation]->pressed = use_decimation;
		}
		else if(but_status == vis_buttons.quit)
		{
		    break;
		}
		else if(but_status == vis_buttons.cmd)
		{
		    cout << endl;
		    cout << "1: Give zoom region (current = " << nav_bar.zoom_region << ")" << endl;
		    cout << "2: Give location (current = " << nav_bar.location << ")" << endl;
		    cout << "3: Create detailed report about zoom area" << endl;
		    cout << "4: Create navigation decimation file" << endl;
		    cout << "5: Disable decimation" << endl;
		    cout << "6: Enable decimation without creating the file now" << endl;
		    cout << "7: Save zoom region to a new binary file" << endl;
		    cout << "8: POINT-TO-POINT INVESTIGATOR." << endl;
		    cout << "9: Create a TG model from the region. (P2P data needed.)" << endl;
		    cout << "others: Cancel" << endl;
		    int sel;
		    cin >> sel;
		    if(sel == 1)
		    {
			cout << "Give zoom region (current = " << nav_bar.zoom_region << ")" << endl;

			cin >> nav_bar.zoom_region;
			if(nav_bar.zoom_region < 1)
			    nav_bar.zoom_region = 1;

			if(nav_bar.zoom_region > nav_bar.num_of_snapshots)
			    nav_bar.zoom_region = nav_bar.num_of_snapshots;

			if(nav_bar.location > nav_bar.num_of_snapshots-nav_bar.zoom_region)
			    nav_bar.location = nav_bar.num_of_snapshots-nav_bar.zoom_region;
		    }
		    else if(sel == 2)
		    {
			cout << "Give location (current = " << nav_bar.location << ")" << endl;
			cin >> nav_bar.location;

			if(nav_bar.location < 0)
			    nav_bar.location = 0;

			if(nav_bar.location > nav_bar.num_of_snapshots-nav_bar.zoom_region)
			    nav_bar.location = nav_bar.num_of_snapshots-nav_bar.zoom_region;


		    }
		    else if(sel == 3)
		    {
				cout << "Give filename." << endl;
				char filename[500];
				cin >> filename;
				if(stats_->decimate)
				{
					cout << "Creating report without decimation..." << endl;
					stats_->logging_length = nav_bar.zoom_region;
					stats_->num_of_last_values = nav_bar.zoom_region;

					inp_stream->seekg(nav_bar.location*stats_->pd->snapshot_bytes, ios::beg);
					inp_stream->read((char*)data, nav_bar.zoom_region*stats_->pd->snapshot_bytes);
					stats_->parse_and_analyze_region(data, nav_bar.zoom_region);
					cout << "Done!" << endl;
				}

				create_report(filename, nav_bar.location, nav_bar.zoom_region);
			
		    }
		    else if(sel == 4)
		    {
/*			cout << "Generating..." << endl;
			stats_->create_decimation_file(*inp_stream, size, nav_bar.num_of_snapshots);
			cout << "OK!" << endl;
			char name[405];
			sprintf(name, "%s.deci%d", stats_->pd->bin_name, NAVI_DECIMATION);
			cout << "Opening created file..." << endl;
			deci_stream.open(name, ios::binary | ios::in);
			if(!deci_stream.good())
			{
			    cout << "Error opening file!" << endl;
			}
			else
			{
			    use_decimation = true;
			    cout << "Desimation in use!" << endl;
			}
*/
		    }
		    else if(sel == 5)
		    {
/*			cout << "Disabling decimation..." << endl;
			deci_stream.close();
			use_decimation = false; */

		    }
		    else if(sel == 6)
		    {
/*			char name[405];
			sprintf(name, "%s.deci%d", stats_->pd->bin_name, NAVI_DECIMATION);
			cout << "Opening created file..." << endl;
			deci_stream.open(name, ios::binary | ios::in);
			if(!deci_stream.good())
			{
			    cout << "Error opening file!" << endl;
			}
			else
			{
			    use_decimation = true;
			    cout << "Desimation in use!" << endl;
			    }*/

		    }
		    else if(sel == 7)
		    {
			char filename[500];
			cout << "Give filename for the new binary." << endl;
			cin >> filename;
			
			ofstream out_stream;
			out_stream.open(filename, ios::out | ios::binary);

			// "data" already has the data, but if we have decimated, we have to reread.
			if(stats_->decimate)
			{
			    cout << "Creating the new binary without decimation..." << endl;
			    stats_->logging_length = nav_bar.zoom_region;
			    stats_->num_of_last_values = nav_bar.zoom_region;
			    
			    inp_stream->seekg(nav_bar.location*stats_->pd->snapshot_bytes, ios::beg);
			    inp_stream->read((char*)data, nav_bar.zoom_region*stats_->pd->snapshot_bytes);
			    stats_->parse_and_analyze_region(data, nav_bar.zoom_region);
			}

			out_stream.write((const char*)data, nav_bar.zoom_region*stats_->pd->snapshot_bytes);
			cout << "Done!" << endl;
		    }
		    else if(sel == 8)
		    {
			p2p_inv.text_ui();
		    }
		    else if(sel == 9)
		    {
			if(p2p_inv.enable_p2p)
			{
			    create_model_textui(p2p_inv, nav_bar.location, nav_bar.location+nav_bar.zoom_region);
			}
			else
			{
			    cout << "Need the p2p data! Run p2p investigator first." << endl;
			}
		    }
		}

	    }
	    else if(but_status == -1)
	    {
		main_button_pressed = false;
	    }

	    if(p2p_but_status != -1 && p2p_button_pressed == false)
	    {
		p2p_button_pressed = true;
		redraw = true;
		if(p2p_but_status == p2p_buttons.mode)
		{
		    p2p_inv.dm.mode++;
		    if(p2p_inv.dm.mode >= NUM_DRAWING_MODES)
			p2p_inv.dm.mode = 0;
		    p2p_ui.change_text(p2p_buttons.mode, DRAWING_MODE_NAMES[p2p_inv.dm.mode]);
		}
		else if(p2p_but_status == p2p_buttons.overhead)
		{
		    p2p_inv.dm.overhead = (p2p_inv.dm.overhead)?false:true;
		    p2p_ui.change_text(p2p_buttons.overhead, p2p_inv.dm.overhead?"Show overhead":"No overhead");
		}
		else if(p2p_but_status == p2p_buttons.save_csv)
		{
		    cout << "Give filename." << endl;
		    char csvname[500];
		    cin >> csvname;
		    p2p_inv.create_csv_from_region(csvname);
		    
		}
	    }
	    else if(p2p_but_status == -1)
		p2p_button_pressed = false;


	} // end not dragging


	if(left)
	{
	    nav_bar.location -= nav_bar.zoom_region;
	    redraw = true;
	}

	if(left_little)
	{
	    nav_bar.location -= (nav_bar.zoom_region/10>0)?(nav_bar.zoom_region/10):1;
	    redraw = true;
	}

	if(left_1)
	{
	    nav_bar.location--;
	    redraw = true;
	}

	if(right)
	{
	    nav_bar.location += nav_bar.zoom_region;
	    redraw = true;
	}

	if(right_little)
	{
	    nav_bar.location += (nav_bar.zoom_region/10>0)?(nav_bar.zoom_region/10):1;
	    redraw = true;
	}

	if(right_1)
	{
	    if(stats_->decimate)
		nav_bar.location += stats_->cur_decimation;
	    else
		nav_bar.location++;
	    redraw = true;
	}

	if(out)
	{
	    nav_bar.zoom_region *= 2;
	    redraw = true;
	}

	if(out_little)
	{
	    nav_bar.zoom_region += (nav_bar.zoom_region/10>0)?(nav_bar.zoom_region/10):1;
	    redraw = true;
	}
	
	if(out_1)
	{
	    if(stats_->decimate)
		nav_bar.zoom_region += stats_->cur_decimation;
	    else
		nav_bar.zoom_region++;
	    redraw = true;
	}

	if(in)
	{
	    nav_bar.zoom_region /= 2;
	    redraw = true;
	}

	if(in_little)
	{
	    nav_bar.zoom_region -= (nav_bar.zoom_region/10>0)?(nav_bar.zoom_region/10):1;
	    redraw = true;
	}

	if(in_1)
	{
	    nav_bar.zoom_region--;
	    redraw = true;
	}

	// Check if decimation needs to be changed.
	if(use_decimation)
	{
	    stats_->decimate = false;	    
	    for(int i = DECIMATION_ZONES-1; i >= 0; i--)
	    {
		if(nav_bar.zoom_region > stats_->navi_decimation_apply[i])
		{
		    stats_->cur_decimation = stats_->navi_decimation[i];
		    stats_->decimate = true;
		    deci_stream = &deci_streams[i];
		    p2p_deci_stream = &p2p_deci_streams[i];
//		    cout << "Changed decimation level to " << stats_->cur_decimation << endl;
		    break;
		}
	    }
	}
	else
	{
	    stats_->decimate = false;	    
	    stats_->cur_decimation = 1;
	}

	zoom_changed = in_1 = in_little = in = out_1 = out_little = out = left_1 = left_little = left = right_1 = right_little = right = false;

	if(nav_bar.zoom_region > nav_bar.num_of_snapshots)
	    nav_bar.zoom_region = nav_bar.num_of_snapshots;

	if(nav_bar.zoom_region < 1)
	    nav_bar.zoom_region = 1;

	if(nav_bar.location < 0)
	    nav_bar.location = 0;

	if(nav_bar.location > nav_bar.num_of_snapshots-nav_bar.zoom_region)
	    nav_bar.location = nav_bar.num_of_snapshots-nav_bar.zoom_region;


	if(realtime)
	    stats_->logging_length = nav_bar.zoom_region;


	if(play == true)
	{
	    redraw = true;
	    nav_bar.location += (slow)?((nav_bar.zoom_region/20<1)?(1):(nav_bar.zoom_region/20)):(nav_bar.zoom_region);
	    if(nav_bar.location > nav_bar.num_of_snapshots-nav_bar.zoom_region)
	    {
		nav_bar.location = 0;
		play = false;
	    }
//	    boost::asio::deadline_timer t(io, boost::posix_time::milliseconds(20));
//	    t.wait();

	}

	if(stats_->decimate)
	{
	    // Decimating, round location and zoom region.
	    nav_bar.location -= nav_bar.location%stats_->cur_decimation;
	    nav_bar.zoom_region -= nav_bar.zoom_region%stats_->cur_decimation;

	    stats_->logging_length = nav_bar.zoom_region/stats_->cur_decimation;
	    stats_->num_of_last_values = nav_bar.zoom_region/stats_->cur_decimation;
	}
	else
	{
	    stats_->cur_decimation = 1;
	    stats_->logging_length = nav_bar.zoom_region;
	    stats_->num_of_last_values = nav_bar.zoom_region;
	}


	if(stats_->num_of_last_values > stats_->max_num_of_last_values)
	    stats_->num_of_last_values = stats_->max_num_of_last_values;


//	profile_clk_vect.push_back(profile_clk.GetElapsedTime());


	if(stats_->decimate)
	{
//	    cout << "SIW" << endl;
	    // Decimation

	    deci_stream->seekg(nav_bar.location/stats_->cur_decimation * 3 * stats_->pd->num_of_counters, ios::beg);
	    // 3 = bytes in one record
	    deci_stream->read((char*)data, nav_bar.zoom_region/stats_->cur_decimation * 3 * stats_->pd->num_of_counters);

	    //	    for(int i = 0; i < nav_bar.zoom_region/NAVI_DECIMATION * 3 * pd->num_of_counters; i++)
	    //	cout << (int)data[i] << " ";


	    stats_->analyze_deci_region(data, nav_bar.zoom_region/stats_->cur_decimation);

	}
	else
	{
	    // Normal operation, no decimation.
//	    cout << nav_bar.location << "  " << nav_bar.zoom_region << endl;

	    if(!realtime)
	    {
		inp_stream->seekg(nav_bar.location*stats_->pd->snapshot_bytes, ios::beg);
		inp_stream->read((char*)data, nav_bar.zoom_region*stats_->pd->snapshot_bytes);
		stats_->parse_and_analyze_region(data, nav_bar.zoom_region);
	    }
	}

	if(p2p_inv.enable_p2p)
	{
	    const int p2p_disc_paths_bytes = stats_->pd->num_of_agents*stats_->pd->num_of_agents*(sizeof(int)+sizeof(int)+sizeof(p2p_investigator::stats_status_t));

	    if(stats_->decimate)
	    {
		p2p_deci_stream->seekg(nav_bar.location/stats_->cur_decimation*p2p_disc_paths_bytes, ios::beg);
		for(int i = 0; i < nav_bar.zoom_region/stats_->cur_decimation; i++)
		{
		    for(int src = 0; src < stats_->pd->num_of_agents; src++)
		    {
			for(int dst = 0; dst < stats_->pd->num_of_agents; dst++)
			{
			    p2p_deci_stream->read((char*)&(p2p_inv.p2p_statistics_disc[i][src][dst].data_with_overhead), sizeof(int));
			    p2p_deci_stream->read((char*)&(p2p_inv.p2p_statistics_disc[i][src][dst].data_no_overhead), sizeof(int));
			    p2p_deci_stream->read((char*)&(p2p_inv.p2p_statistics_disc[i][src][dst].status), sizeof(p2p_investigator::stats_status_t));
			}
		    }
		}
		p2p_inv.p2p_length = nav_bar.zoom_region/stats_->cur_decimation;
	    }
	    else
	    {
		p2p_stream.seekg(nav_bar.location*p2p_disc_paths_bytes, ios::beg);
		for(int i = 0; i < nav_bar.zoom_region; i++)
		{
		    for(int src = 0; src < stats_->pd->num_of_agents; src++)
		    {
			for(int dst = 0; dst < stats_->pd->num_of_agents; dst++)
			{
			    p2p_stream.read((char*)&(p2p_inv.p2p_statistics_disc[i][src][dst].data_with_overhead), sizeof(int));
			    p2p_stream.read((char*)&(p2p_inv.p2p_statistics_disc[i][src][dst].data_no_overhead), sizeof(int));
			    p2p_stream.read((char*)&(p2p_inv.p2p_statistics_disc[i][src][dst].status), sizeof(p2p_investigator::stats_status_t));
			}
		    }
		}
		p2p_inv.p2p_length = nav_bar.zoom_region;
	    }

	}

//	profile_clk_vect.push_back(profile_clk.GetElapsedTime());


	if(realtime && stats_->accum_done)
	{
	    redraw = true;
	    stats_->accum_done = false;
	}

	if(redraw)
	{
//	    profile_clk_vect.push_back(profile_clk.GetElapsedTime());

	    main_win.Clear(sf::Color(255,255,255));
	    if(stats_->pd->net_type == 0)
		meshnoc.draw_mesh();
	    else if(stats_->pd->net_type == 1)
		hibinoc.draw_hibi();

//	    profile_clk_vect.push_back(profile_clk.GetElapsedTime());

	    //	    cout << "Display!" << endl;
	    if(!realtime)
	    {
		draw_nav_bar();
	    }
	    else
	    {
		char tmptxt[200];
		sprintf(tmptxt, "Captured %d packets (%d ignored, %d missed, %d errors)", stats_->rt_captured, stats_->rt_ignored,
			stats_->rt_missed, stats_->rt_errors);
		sf::String tmpstr(tmptxt, def_font, big_font_size);
		tmpstr.SetColor(sf::Color(0,50,100));
		tmpstr.SetPosition(nav_bar.left, vis_window_ysize-nav_bar.bottom-big_font_size);
		main_win.Draw(tmpstr);
	    }

	    main_ui.draw_all_buttons();

	    main_win.Display();

//	    profile_clk_vect.push_back(profile_clk.GetElapsedTime());


	    p2p_win.Clear(sf::Color(255,255,255));
	    if(p2p_inv.enable_p2p)
	    {
		p2p_inv.draw_p2p(p2p_win, def_font, nav_bar.location, nav_bar.location+nav_bar.zoom_region, stats_->cur_decimation);
		p2p_ui.draw_all_buttons();
	    }
	    p2p_win.Display();


	    refresh_clk.Reset();
		
	    redraw = false;
	}



//	cout << "DEBUG: showing " << setw(7) << nav_bar.location << " to " <<  setw(7) << nav_bar.location+nav_bar.zoom_region-1 << " of " 
//	     <<  setw(7) << nav_bar.num_of_snapshots << " snapshots.\r" << flush;



    }
    
    if(realtime)
	stats_->rt_stop = true;

    delete data;
}

void gui::print_stats(int packets, int missed, int errors)
{
    main_win.Clear(sf::Color(255,255,255));

    if(stats_->pd->net_type == 0)
	meshnoc.draw_mesh();
    else if(stats_->pd->net_type == 1)
	hibinoc.draw_hibi();

    main_win.Display();
    
    cout << setw(7) << packets << " packets captured, " << setw(7) << missed << " missed, "
	 << setw(7) << errors << " errors." << "\r" << flush;
}

void gui::create_report(char* filename, int location, int zoom_region)
{
    ofstream report;

    report.open(filename, ios::out);
    while(!report.good())
    {
	cout << filename << " cannot be opened. It may be in use. Enter r to retry, q to cancel." << endl;
	char sel;
	cin >> sel;
	if(sel == 'q' || sel == 'Q')
	    return;
	if(sel == 'r' || sel == 'R')
	    report.open(filename, ios::out);
    }

    report << "TRACE MONITOR REPORT" << endl;
    report << endl;
    report << "Window length = " << stats_->pd->window_length << " clk" << endl;
    report << "Clock rate    = " << stats_->pd->clock_hz << " Hz" << endl;
    report << "Window range start = " << location << " w = " 
	   << location*stats_->pd->window_length << " clk = " 
	   << (double)location*stats_->pd->window_length/(stats_->pd->clock_hz) << "s" << endl;
							  
    report << "Window range end   = " << location+zoom_region << " w = " 
	   << (location+zoom_region)*stats_->pd->window_length << " clk = " 
	   << (double)(location+zoom_region)*stats_->pd->window_length/(stats_->pd->clock_hz) << "s" << endl;

    report << "Region size        = " << zoom_region << " w = " 
	   << zoom_region*stats_->pd->window_length << " clk = " 
	   << (double)zoom_region*stats_->pd->window_length/(stats_->pd->clock_hz) << "s" << endl;

    report << endl;

    report << "Link statistics:" << endl;

    const int prec = 5;
    for(int l = 0; l < stats_->pd->num_of_links; l++)
    {
	report << "Link " << l << ": " << meshnoc.mesh_link_names[l] << endl;
	report << "  DATA" << endl;
	report << "    MIN " << setprecision(prec) << (double)stats_->min_counter_log[l*2]*100.0/stats_->pd->window_length << " %  " << endl;
	report << "    AVG " << setprecision(prec) << (double)stats_->tot_counter_log[l*2]*100.0/(stats_->pd->window_length*stats_->logging_length) << " %  " << endl;
	report << "    MAX " << setprecision(prec) << (double)stats_->max_counter_log[l*2]*100.0/stats_->pd->window_length << " %  " << endl;
	report << endl;
	report << "  STALL" << endl;
	report << "    MIN " << setprecision(prec) << (double)stats_->min_counter_log[l*2+1]*100.0/stats_->pd->window_length << " %  " << endl;
	report << "    AVG " << setprecision(prec) << (double)stats_->tot_counter_log[l*2+1]*100.0/(stats_->pd->window_length*stats_->logging_length) << " %  " << endl;
	report << "    MAX " << setprecision(prec) << (double)stats_->max_counter_log[l*2+1]*100.0/stats_->pd->window_length << " %  " << endl;
	report << endl << endl;
    }
    
    report << endl;
    report << "Network statistics:" << endl;

    long long int tot_data = 0;
    long long int tot_stall = 0;

    long int min_data = MIN_INIT;
    long int min_stall = MIN_INIT;

    long int max_data = MAX_INIT;
    long int max_stall = MAX_INIT;

    for(int l = 0; l < stats_->pd->num_of_links; l++)
    {
	tot_data += stats_->tot_counter_log[l*2];
	tot_stall += stats_->tot_counter_log[l*2+1];	

	if(stats_->min_counter_log[l*2] < min_data)
	    min_data = stats_->min_counter_log[l*2];

	if(stats_->max_counter_log[l*2] > max_data)
	    max_data = stats_->max_counter_log[l*2];

	if(stats_->min_counter_log[l*2+1] < min_stall)
	    min_stall = stats_->min_counter_log[l*2+1];

	if(stats_->max_counter_log[l*2+1] > max_stall)
	    max_stall = stats_->max_counter_log[l*2+1];
    }

    report << "All links:" << endl;

    report << "  DATA" << endl;
    report << "    MIN " << setprecision(prec) << (double)min_data*100.0/stats_->pd->window_length << " %  " << endl;
    report << "    AVG " << setprecision(prec) << (double)tot_data*100.0/(stats_->pd->window_length*stats_->logging_length*stats_->pd->num_of_links) << " %  " << endl;
    report << "    MAX " << setprecision(prec) << (double)max_data*100.0/stats_->pd->window_length << " %  " << endl;
    report << endl;
    report << "  STALL" << endl;
    report << "    MIN " << setprecision(prec) << (double)min_stall*100.0/stats_->pd->window_length << " %  " << endl;
    report << "    AVG " << setprecision(prec) << (double)tot_stall*100.0/(stats_->pd->window_length*stats_->logging_length*stats_->pd->num_of_links) << " %  " << endl;
    report << "    MAX " << setprecision(prec) << (double)max_stall*100.0/stats_->pd->window_length << " %  " << endl;
    report << endl << endl;


    tot_data = 0;
    tot_stall = 0;

    min_data = MIN_INIT;
    min_stall = MIN_INIT;

    max_data = MAX_INIT;
    max_stall = MAX_INIT;

    int x = 0;
    int y = 0;
    
    for(int l = 0; l < stats_->pd->num_of_links;)
    {
	int links = 4;
	if(x == stats_->pd->mesh_cols-1)
	    links -= 2;
	
	if(y == stats_->pd->mesh_rows-1)
	    links -= 2;

//	cout << "DEBUG: links = " << links << endl;
//	cout << "x, y = " << x << ", " << y << endl;
	for(int i = 0; i < links; i++)
	{

//	    cout << "DEBUG: " << mesh_link_names[l] << endl;
	    tot_data += stats_->tot_counter_log[l*2];
	    tot_stall += stats_->tot_counter_log[l*2+1];	

	    if(stats_->min_counter_log[l*2] < min_data)
		min_data = stats_->min_counter_log[l*2];

	    if(stats_->max_counter_log[l*2] > max_data)
		max_data = stats_->max_counter_log[l*2];

	    if(stats_->min_counter_log[l*2+1] < min_stall)
		min_stall = stats_->min_counter_log[l*2+1];

	    if(stats_->max_counter_log[l*2+1] > max_stall)
		max_stall = stats_->max_counter_log[l*2+1];

	    l++;
	}

	l += 4; // skip IP links

	x++;
	if(x > stats_->pd->mesh_cols-1)
	{
	    x = 0;
	    y++;
	}
    }

    report << "Router links:" << endl;

    report << "  DATA" << endl;
    report << "    MIN " << setprecision(prec) << (double)min_data*100.0/stats_->pd->window_length << " %  " << endl;
    report << "    AVG " << setprecision(prec) << (double)tot_data*100.0/(stats_->pd->window_length*stats_->logging_length*stats_->pd->num_of_links) << " %  " << endl;
    report << "    MAX " << setprecision(prec) << (double)max_data*100.0/stats_->pd->window_length << " %  " << endl;
    report << endl;
    report << "  STALL" << endl;
    report << "    MIN " << setprecision(prec) << (double)min_stall*100.0/stats_->pd->window_length << " %  " << endl;
    report << "    AVG " << setprecision(prec) << (double)tot_stall*100.0/(stats_->pd->window_length*stats_->logging_length*stats_->pd->num_of_links) << " %  " << endl;
    report << "    MAX " << setprecision(prec) << (double)max_stall*100.0/stats_->pd->window_length << " %  " << endl;
    report << endl << endl;



    report.close();

// (link_stalls[pnt]*100)/(stats_->pd->window_length * ((averaging_mode==MODE_AVG)?logging_length:1))

}

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
