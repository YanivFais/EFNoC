// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

// trace_pc.cpp
// Main program file with simple configuration file handling and
// command line parsing.
// Creates instances of "receiver" and "statistics".

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#include "parser.hpp"
#include "receiver.hpp"
#include "statistics.hpp"
#include "gui.hpp"

using namespace std;

// FUNCTIONS FOR READING THE CONFIGURATION FILE
int conf_find(char* line, const char* param_name, ifstream& conf_file)
{
    int loc;
    int tries;
    int linenum = 0;

    bool found = false;

    conf_file.clear();
    conf_file.seekg(0, ios::beg);
    
    while(!conf_file.eof())
    {
	conf_file.getline(line, 256);
	if(line[0] != '#')
	{
	    loc = strlen(param_name);
	    if(strncmp(line, param_name, loc) == 0 && strlen(line) > loc
	       && (line[loc] == ' ' || line[loc] == '\t' || 
		   line[loc] == '='))
	    {
		// Match

		tries = 30; // how many characters are searched for =
		while(line[loc] != '=')
		{
		    tries--;
		    if(tries == 0)
		    {
			cerr << "Error in config file at line " << linenum << ": no \'=\' reached" << endl;
			return 0;
		    }
		    loc++; 
		}

		loc++; // jump over '='

		tries = 30; // how many characters of empty space is tried to ignore.
		while(line[loc] == ' ' || line[loc] == '\t')
		{
		    tries--;
		    if(tries == 0)
		    {
			cerr << "Error in config file at line " << linenum << ": no argument reached after \'=\'" << endl;
			return 0;
		    }
		    loc++; 
		}


		return loc; // index of "line".

	    }
	}

        linenum++;
    }
    return 0; // failed to find
}

bool read_conf_val_Color(ifstream& conf_file, const char* param_name, sf::Color* pnt_to_value, bool necessary = true, sf::Color def_val = sf::Color(0,0,0))
{
    char line[256];
    int loc = conf_find(line, param_name, conf_file);

    sf::Color value;


    if(loc == 0)
    {
	if(necessary)
	{
	    cerr << "Cannot find setting \"" << param_name << "\" from settings file." << endl;
	    return false;
	}

	value = def_val;

    }
    else
    {
	int r, g, b;
	r = atoi(line+loc);
	loc++;
	while(line[loc] != ' ')
	    loc++;
	while(line[loc] < '0' || line[loc] > '9')
	    loc++;
	g = atoi(line+loc);
	loc++;
	while(line[loc] != ' ')
	    loc++;
	while(line[loc] < '0' || line[loc] > '9')
	    loc++;
	b = atoi(line+loc);

	if(r < 0 || g < 0 || b < 0 || r > 255 || g > 255 || b > 255)
	{
	    cerr << "Setting \"" << param_name << "\" has illegal value " << r << ", " << g << ", " << b  << " outside the range of 0...255."  << endl;
	    return false;
	}


//	cout << "r: " << r << ", g:" << g << ", b:" << b << endl;
	value = sf::Color(r,g,b);
    }

    *pnt_to_value = value;

    return true;

}

bool read_conf_val_int(ifstream& conf_file, const char* param_name, int* pnt_to_value, int min, int max, bool necessary = true, int def_val = 0)
{
    char line[256];
    int loc = conf_find(line, param_name, conf_file);

    int value;


    if(loc == 0)
    {
	if(necessary)
	{
	    cerr << "Cannot find setting \"" << param_name << "\" from settings file." << endl;
	    return false;
	}

	value = def_val;

    }
    else
    {
	value = atoi(line+loc);
    }

    *pnt_to_value = value;

    if(value < min || value > max)
    {
	cerr << "Setting \"" << param_name << "\" has illegal value " << value << " outside the range of " 
	     << min << ".." << max << "." << endl;
	return false;
    }

    return true;
}

bool read_conf_val_string(ifstream& conf_file, const char* param_name, char* pnt_to_value, int min_len, int max_len, 
		   bool necessary = true, char* def_val = 0)
{

    char line[256];
    int size;
    int loc = conf_find(line, param_name, conf_file);

    if(loc == 0)
    {
	if(necessary)
	{
	    cerr << "Cannot find setting \"" << param_name << "\" from settings file." << endl;
	    return false;
	}

	strcpy(pnt_to_value, def_val);
	size = strlen(def_val);

    }
    else
    {
	// String is copied to output until space, tab or # is reached.
	size = strcspn(line+loc, " \t#");
	strncpy(pnt_to_value, line+loc, size);
	pnt_to_value[size] = 0; // null-termination character.
    }

    if(size < min_len || size > max_len)
    {
	cerr << "String setting \"" << param_name << "\" has illegal length " << size << " outside the range of " 
	     << min_len << ".." << max_len << "." << endl;
	return false;
    }

    return true;
}

bool read_conf_val_char(ifstream& conf_file, const char* param_name, char* pnt_to_value,
		   bool necessary = true, char def_val = 0)
{

    char line[256];
    int loc = conf_find(line, param_name, conf_file);

    if(loc == 0)
    {
	if(necessary)
	{
	    cerr << "Cannot find setting \"" << param_name << "\" from settings file." << endl;
	    return false;
	}
	*pnt_to_value = def_val;


    }
    else
    {
	*pnt_to_value = line[loc];
    }

    
    return true;
}

// Parse command-line such as write=0 to a bool value.
bool find_parameter(int argc, int start, char** argv, const char* prefix, bool default_val)
{
//    cout << "comparing " << prefix << endl;
    for(int i = start; i < argc; i++)
    {
//	cout << argv[i] << endl;
	if(strncmp(argv[i], prefix, strlen(prefix)) == 0)
	{
//	    cout << "MATCH" << endl;
//	    cout << endl << endl << argv[i] << endl << endl;
	    // Then find 0 or 1.
	    char* zero_loc = strchr(argv[i], '0');
	    char* one_loc = strchr(argv[i], '1');

	    if((zero_loc == 0 && one_loc == 0) || (zero_loc != 0 && one_loc != 0))
	    {
		cerr << "You must specify 0 or 1 for parameter " << prefix << endl;
	    }
	    else
	    {
		if(zero_loc) 
		    return false;
		else
		    return true;
	    }
	    break;
	}
    }
    
    // Not found or illegal, return default.
    return default_val;
}

int main(int argc, char* argv[])
{
    char setting_file[] = "trace_pc.cfg";
    processing_data proc_data;

    int packets;

    if (argc < 3)
    {
	cerr << "Usage: trace_pc <capture|view> <binary file name> [time] [sec|msec|usec|clk|kclk|Mclk|windows|packets]" << endl;
	cerr << "                [write=0|1] [realtime=0|1] " << endl;
	cerr << "  capture (c) : Capture data to binary file" << endl;
	cerr << "  view (v)    : Open captured file for graphical evaluation" << endl;
	cerr << endl;
	cerr << "  time : capture length  (seconds, milliseconds, microseconds, DUV clk cycles," << endl;
	cerr << "         (integer)        k DUV clk cycles, M DUV clk cycles, windows or " << endl;
	cerr << "                          (UDP) packets, can be abbreviated s, m, u, c, k, M" << endl;
	cerr << "                          or p.  Time will be rounded to next full packet." << endl;
	cerr << endl;
	cerr << "Additional parameters after time:" << endl;
	cerr << " write=0|1    (default: 1)   Write captured data to file." << endl;
	cerr << " realtime=0|1 (default: 0)   Show real-time statistics while capturing" << endl;
	cerr << endl;
	cerr << "Settings file " << setting_file << " is used." << endl;
	cerr << endl;
	cerr << "EXAMPLES:" << endl;
	cerr << "trace_pc c binary 10 s" << endl;
	cerr << "   Capture max of 10 seconds of data from Ethernet to a file named binary" << endl;
	cerr << "   (Add write=0 realtime=1 to the end to disable file writing and enable the realtime viewing)" << endl;
	cerr << "trace_pc v binary" << endl;
	cerr << "   Review the trace file named binary" << endl;
	cerr << endl;
	cerr << endl;

	return 1;
    }

    statistics stats;
    gui interface(&stats);
  
    // PARSE SETTINGS FILE
    ifstream sets_file;
    sets_file.open(setting_file, ios::in);
    if(!sets_file.good())
    {
	cerr << "Couldn't open settings file." << endl;
	return 1;
    }
       

//    if(!read_conf_val_int(sets_file, "screen_type", &interface.screen_type, 0, 2)) return 1;

    char delimiter;
    if(!read_conf_val_char(sets_file, "delimiter", &delimiter)) return 1;
//    if(!read_conf_val_string(sets_file, "bin_name", proc_data.bin_name, 1, 200)) return 1;
//    char out_name[256];
//    if(!read_conf_val_string(sets_file, "out_name", out_name, 1, 200)) return 1;
    
    int udp_port;
    if(!read_conf_val_int(sets_file, "udp_port", &udp_port, 0, 65535)) return 1;
    
    if(!read_conf_val_int(sets_file, "net_type", &proc_data.net_type, 0, 1)) return 1; 
    if(!read_conf_val_int(sets_file, "window_length", &proc_data.window_length, 0, 1000000)) return 1; 
    if(!read_conf_val_int(sets_file, "num_of_agents", &proc_data.num_of_agents, 0, 1000000)) return 1; 
    if(!read_conf_val_int(sets_file, "mesh_cols", &proc_data.mesh_cols, 1, 16)) return 1; 
    if(!read_conf_val_int(sets_file, "mesh_rows", &proc_data.mesh_rows, 1, 16)) return 1; 
    if(!read_conf_val_int(sets_file, "packet_length", &proc_data.packet_length, 100, 1500)) return 1; 
    if(!read_conf_val_int(sets_file, "clock_speed_hz", (int*)&proc_data.clock_hz, 1000, 1000000000)) return 1; 
    
    // Read HIBI settings
    if(!read_conf_val_int(sets_file, "hibi_segments", &proc_data.hibi_segments, 1, MAX_HIBI_SEGS)) return 1;
    for(int i = 0; i < proc_data.hibi_segments; i++)
    {
	char tmpstrng[40];
	sprintf(tmpstrng, "hibi_ags_seg[%d]", i);
	if(!read_conf_val_int(sets_file, tmpstrng, &proc_data.hibi_ags_seg[i], 1, 200)) return 1;
    }
    
    
    char pe_name_tag_file[256];
    if(!read_conf_val_string(sets_file, "pe_name_tag_file", pe_name_tag_file, 1, 200)) return 1;
    interface.create_default_nametags();
    ifstream nametag_file;
    nametag_file.open(pe_name_tag_file, ios::in);
    if(nametag_file.good())
    {
	interface.read_nametags(nametag_file);
    }
    nametag_file.close();

    
    if(!read_conf_val_int(sets_file, "router_xsize", &interface.meshnoc.router_xsize, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "router_ysize", &interface.meshnoc.router_ysize, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "router_xspace", &interface.meshnoc.router_xspace, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "router_yspace", &interface.meshnoc.router_yspace, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "pe_xsize", &interface.meshnoc.pe_xsize, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "pe_ysize", &interface.meshnoc.pe_ysize, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "pe_xoffset", &interface.meshnoc.pe_xoffset, -1000, 1000)) return 1;
    if(!read_conf_val_int(sets_file, "pe_yoffset", &interface.meshnoc.pe_yoffset, -1000, 1000)) return 1;
    if(!read_conf_val_int(sets_file, "left_margin", &interface.meshnoc.left_margin, 0, 1000)) return 1;
    if(!read_conf_val_int(sets_file, "bottom_margin", &interface.meshnoc.bottom_margin, 0, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "router_coord_font_size", &interface.meshnoc.router_coord_font_size, 1, 200)) return 1;
    if(!read_conf_val_int(sets_file, "pe_title_font_size", &interface.meshnoc.pe_title_font_size, 1, 200)) return 1;
    if(!read_conf_val_int(sets_file, "vis_window_xsize", &interface.vis_window_xsize, 100, 10000)) return 1;
    if(!read_conf_val_int(sets_file, "vis_window_ysize", &interface.vis_window_ysize, 100, 10000)) return 1;
    if(!read_conf_val_int(sets_file, "chart_xsize", &interface.chart_xsize, 100, 10000)) return 1;
    if(!read_conf_val_int(sets_file, "chart_ysize", &interface.chart_ysize, 100, 10000)) return 1;
    if(!read_conf_val_int(sets_file, "vis_window_xpos", &interface.vis_window_xpos, -10000, 10000)) return 1;
    if(!read_conf_val_int(sets_file, "vis_window_ypos", &interface.vis_window_ypos, -10000, 10000)) return 1;
    if(!read_conf_val_int(sets_file, "link_win_xpos[0]", &interface.link_win_xposs[0], -10000, 10000)) return 1;
    if(!read_conf_val_int(sets_file, "link_win_ypos[0]", &interface.link_win_yposs[0], -10000, 10000)) return 1;
    if(!read_conf_val_int(sets_file, "link_win_xpos[1]", &interface.link_win_xposs[1], -10000, 10000)) return 1;
    if(!read_conf_val_int(sets_file, "link_win_ypos[1]", &interface.link_win_yposs[1], -10000, 10000)) return 1;
    if(!read_conf_val_int(sets_file, "data_percentage_font_size", &interface.meshnoc.data_percentage_font_size, 1, 200)) return 1;
    if(!read_conf_val_int(sets_file, "stall_percentage_font_size", &interface.meshnoc.stall_percentage_font_size, 1, 200)) return 1;
    if(!read_conf_val_int(sets_file, "router_ysize", &interface.meshnoc.router_ysize, 10, 2000)) return 1;


    if(!read_conf_val_Color(sets_file, "link_color[0]", &interface.meshnoc.link_colors[0])) return 1;
    if(!read_conf_val_Color(sets_file, "link_color[1]", &interface.meshnoc.link_colors[1])) return 1;
    if(!read_conf_val_Color(sets_file, "link_color[2]", &interface.meshnoc.link_colors[2])) return 1;
    if(!read_conf_val_Color(sets_file, "link_color[3]", &interface.meshnoc.link_colors[3])) return 1;
    if(!read_conf_val_Color(sets_file, "link_color[4]", &interface.meshnoc.link_colors[4])) return 1;
    if(!read_conf_val_Color(sets_file, "link_color[5]", &interface.meshnoc.link_colors[5])) return 1;
    if(!read_conf_val_Color(sets_file, "link_color[6]", &interface.meshnoc.link_colors[6])) return 1;
    if(!read_conf_val_int(sets_file, "link_treshold[0]", &interface.meshnoc.link_color_tresholds[0], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_treshold[1]", &interface.meshnoc.link_color_tresholds[1], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_treshold[2]", &interface.meshnoc.link_color_tresholds[2], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_treshold[3]", &interface.meshnoc.link_color_tresholds[3], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_treshold[4]", &interface.meshnoc.link_color_tresholds[4], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_treshold[5]", &interface.meshnoc.link_color_tresholds[5], 0, 100)) return 1;

    if(!read_conf_val_int(sets_file, "link_width[0]", &interface.meshnoc.link_widths[0], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_width[1]", &interface.meshnoc.link_widths[1], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_width[2]", &interface.meshnoc.link_widths[2], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_width[3]", &interface.meshnoc.link_widths[3], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_width[4]", &interface.meshnoc.link_widths[4], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_width[5]", &interface.meshnoc.link_widths[5], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_width[6]", &interface.meshnoc.link_widths[6], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_wtreshold[0]", &interface.meshnoc.link_width_tresholds[0], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_wtreshold[1]", &interface.meshnoc.link_width_tresholds[1], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_wtreshold[2]", &interface.meshnoc.link_width_tresholds[2], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_wtreshold[3]", &interface.meshnoc.link_width_tresholds[3], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_wtreshold[4]", &interface.meshnoc.link_width_tresholds[4], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "link_wtreshold[5]", &interface.meshnoc.link_width_tresholds[5], 0, 100)) return 1;


    if(!read_conf_val_int(sets_file, "bus_color[0]", &interface.hibinoc.bus_colors[0], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_color[1]", &interface.hibinoc.bus_colors[1], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_color[2]", &interface.hibinoc.bus_colors[2], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_color[3]", &interface.hibinoc.bus_colors[3], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_color[4]", &interface.hibinoc.bus_colors[4], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_color[5]", &interface.hibinoc.bus_colors[5], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_color[6]", &interface.hibinoc.bus_colors[6], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_width[0]", &interface.hibinoc.bus_widths[0], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_width[1]", &interface.hibinoc.bus_widths[1], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_width[2]", &interface.hibinoc.bus_widths[2], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_width[3]", &interface.hibinoc.bus_widths[3], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_width[4]", &interface.hibinoc.bus_widths[4], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_width[5]", &interface.hibinoc.bus_widths[5], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_width[6]", &interface.hibinoc.bus_widths[6], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_treshold[0]", &interface.hibinoc.bus_color_tresholds[0], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_treshold[1]", &interface.hibinoc.bus_color_tresholds[1], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_treshold[2]", &interface.hibinoc.bus_color_tresholds[2], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_treshold[3]", &interface.hibinoc.bus_color_tresholds[3], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_treshold[4]", &interface.hibinoc.bus_color_tresholds[4], 0, 100)) return 1;
    if(!read_conf_val_int(sets_file, "bus_treshold[5]", &interface.hibinoc.bus_color_tresholds[5], 0, 100)) return 1;

    if(!read_conf_val_int(sets_file, "hibi_pe_ysize", &interface.hibinoc.hibi_pe_ysize, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "hibi_wra_ysize", &interface.hibinoc.hibi_wra_ysize, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "hibi_wra_xsize", &interface.hibinoc.hibi_wra_xsize, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "hibi_ag_xoffset", &interface.hibinoc.hibi_ag_xoffset, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "hibi_bridge_ysize", &interface.hibinoc.hibi_bridge_ysize, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "hibi_table_font_size", &interface.hibinoc.hibi_table_font_size, 5, 50)) return 1;
    if(!read_conf_val_int(sets_file, "hibi_table_ysize", &interface.hibinoc.hibi_table_ysize, 10, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "hibi_table_yspace", &interface.hibinoc.hibi_table_yspace, 5, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "hibi_pe_wra_yspace", &interface.hibinoc.hibi_pe_wra_yspace, 5, 2000)) return 1;
    if(!read_conf_val_int(sets_file, "hibi_table_title_font_size", &interface.hibinoc.hibi_table_title_font_size, 5, 100)) return 1;

    if(!read_conf_val_int(sets_file, "small_font_size", &interface.small_font_size           , 5, 100)) return 1;
    if(!read_conf_val_int(sets_file, "medium_font_size", &interface.medium_font_size           , 5, 100)) return 1;
    if(!read_conf_val_int(sets_file, "big_font_size", &interface.big_font_size           , 5, 100)) return 1;
    if(!read_conf_val_int(sets_file, "chart_title_font_size", &interface.chart_title_font_size           , 5, 100)) return 1;
  
  
    if(udp_port < 0 || udp_port > 65535)
    {
	cerr << "Illegal UDP port setting " << udp_port << endl;
	return 1;
    }


    if(proc_data.check_values() != 0)
    {
	return 1;
    }


    if(proc_data.net_type == 0 && interface.meshnoc.check_mesh_vis_values() != 0)
    {
	// NoC is mesh and parameter check fails.
	return 1;
    }



    // PARSE COMMAND LINE ARGUMENTS

    char run_mode = argv[1][0];
    if (!(run_mode == 'c' || run_mode == 'v'))
    {
	cerr << "Illegal command line usage (wrong run mode)" << endl;
	return 1;
    }

    strcpy(proc_data.bin_name, argv[2]);
    if(strlen(proc_data.bin_name) < 1 || strlen(proc_data.bin_name) > 200)
    {
	cerr << "Illegal trace file name" << endl;
	return 1;
    }
    
    char time_type = 's';
    if (argc > 4)
    {
	time_type = argv[4][0];
	if (!(time_type == 's' || time_type == 'm' || time_type == 'u' ||
	      time_type == 'c' || time_type == 'k' || time_type == 'M' ||
	      time_type == 'w' || time_type == 'p'))
	{
	    cerr << "Illegal command line usage (wrong time unit)" << endl;
	    return 1;
	}
    }
    
    bool realtime = find_parameter(argc, 5, argv, "realtime", false);
    bool write_to_disk = find_parameter(argc, 5, argv, "write", true); 

    /////////////////////////////
    proc_data.calculate_values();
    /////////////////////////////

    stats.initialize(&proc_data);

    if(proc_data.net_type == 0)
    {
	interface.meshnoc.create_mesh_link_names();
    }
    

    double packs_f;
    int time_int = 1;
    if(argc > 4)
	time_int = atoi(argv[3]);
    
    // Only correct for net type 0
    switch(time_type)
    {
	case 's': packs_f =
	    ((((double)time_int*(double)proc_data.clock_hz) / (double)proc_data.window_length) // -> number of windows in given time
	     * (double)proc_data.snapshot_bytes) // -> total data amount in given time
	    / (double)proc_data.packet_length; // -> packets in given time.
	    break;
	case 'm': packs_f =
		((((double)time_int*(double)proc_data.clock_hz/1000.0) / (double)proc_data.window_length) // -> number of windows in given time
		 * (double)proc_data.snapshot_bytes) // -> total data amount in given time
		/ (double)proc_data.packet_length; // -> packets in given time.
	    break;
	case 'u': packs_f =
		((((double)time_int*(double)proc_data.clock_hz/1000000.0) / (double)proc_data.window_length) // -> number of windows in given time
		 * (double)proc_data.snapshot_bytes) // -> total data amount in given time
		/ (double)proc_data.packet_length; // -> packets in given time.
	    break;
	case 'c': packs_f =
		((((double)time_int) / (double)proc_data.window_length) // -> number of windows in given time
		 * (double)proc_data.snapshot_bytes) // -> total data amount in given time
		/ (double)proc_data.packet_length; // -> packets in given time.
	    break;
	case 'k': packs_f =
		((((double)time_int*1000.0) / (double)proc_data.window_length) // -> number of windows in given time
		 * (double)proc_data.snapshot_bytes) // -> total data amount in given time
		/ (double)proc_data.packet_length; // -> packets in given time.
	    break;
	case 'M': packs_f =
		((((double)time_int*1000000.0) / (double)proc_data.window_length) // -> number of windows in given time
		 * (double)proc_data.snapshot_bytes) // -> total data amount in given time
		/ (double)proc_data.packet_length; // -> packets in given time.
	    break;
	    
	case 'w': packs_f =
		(((double)time_int) // -> number of windows in given time
		 * (double)proc_data.snapshot_bytes) // -> total data amount in given time
		/ (double)proc_data.packet_length; // -> packets in given time.
	    break;

	case 'p': packets = time_int; break;
	default: cerr << "We shouldn't be here." << endl; return 1;
	    
    }
    
    if(time_type != 'p')
    {
	packets = ceil(packs_f);
    }
    
    cout << "packets = " << packets << endl;
    
    int total_snapshots = proc_data.snapshots_per_packet * packets;
    
    if(run_mode == 'v' || realtime == true)
    {
	if(!interface.initialize_graphics(false, false, realtime))
	    return 1;
    }
    
    if(run_mode == 'r' || run_mode == 'c')
    {
	char turha;
//	cout << "Anna jotain" << endl;
//	cin >> turha;

	// RECEIVE DATA FROM ETHERNET
	try
	{
	    // Launches a new thread for the receiving process.
	    receiver s(udp_port, packets, proc_data.bin_name, proc_data.packet_length, 
		       0, write_to_disk, realtime, &proc_data, &stats, &interface);
	    if(realtime)
		interface.explore_file(true, 0, 0);
	    else
	    {
		// Just hang in here...
		while(true)
		{
		    sf::Sleep(1);
		    if(s.finished)
			break;
		}
	    }
	    
	}
	catch (std::exception& excep)
	{
	    std::cerr << "Exception: " << excep.what() << endl;
	}

	stats.free();
    }
    
    if(run_mode == 'v')
    {
	ifstream data_file;
	data_file.open(proc_data.bin_name, ios::binary | ios::in | ios::ate);
	unsigned long int size = (unsigned long int) data_file.tellg();
	data_file.seekg(0, ios::beg);
	if(!data_file.good())
	{
	    cerr << "Couldn't open the binary capture data file " << proc_data.bin_name << "! Viewing failed." << endl;
	    return 1;
	}
	interface.explore_file(false, &data_file, size);
	data_file.close();
    }
    
/*
    if(run_mode == 'r' || run_mode == 'p')
    {
	
	std::cout << "Parsing data for .csv" << std::endl;
	
	ofstream csv_file;
	ifstream data_file;
	data_file.open(proc_data.bin_name, ios::binary | ios::in);
	if(!data_file.good())
	{
	    cerr << "Couldn't open the binary capture data file " << proc_data.bin_name << "! Parsing failed." << endl;
	    return 1;
	}
	csv_file.open(out_name, ios::out);
	while(!csv_file.good())
	{
	    cout << out_name << " cannot be opened. It may be in use. Enter r to retry, q to quit." << endl;
	    char sel;
	    cin >> sel;
	    if(sel == 'q')
		return 1;
	    csv_file.open(out_name, ios::out);
	}
	
	int hibi_format_remove_DATA = 0;
	int hibi_format_remove_MSG = 0;
	int hibi_format_remove_FULL = 0;
	
	// Print header row
	csv_file << "Time";
	csv_file.put(delimiter);
	
	if(proc_data.net_type == 0)
	{
	    // link-based header line
	    for(int link = 0; link < proc_data.num_of_links; link++)
	    {
		csv_file << "Link " << link << " stall";
		csv_file.put(delimiter);
		csv_file << "Link " << link << " data";
		if(link != proc_data.num_of_links-1)
		    csv_file.put(delimiter);
	    }
	}
	else if(proc_data.net_type == 1)
	{
	    // HIBI header line
	    for(int sender = 0; sender < proc_data.num_of_agents; sender++)
	    {
		for(int receiver = 0; receiver < proc_data.num_of_agents; receiver++)
		{
		    if(sender != receiver)
		    {
			if(hibi_format_remove_DATA == 0)
			{
			    if(hibi_format_remove_MSG == 2)
				csv_file << sender << " to " << receiver << " DATA+MSG";
			    else
				csv_file << sender << " to " << receiver << " DATA";
			    csv_file.put(delimiter);
			}
			if(hibi_format_remove_MSG == 0)
			{
			    csv_file << sender << " to " << receiver << " MSG";
			    csv_file.put(delimiter);
			}
			if(hibi_format_remove_FULL == 0)
			{
			    csv_file << sender << " to " << receiver << " FULL";
			    csv_file.put(delimiter);
			}
		    }
		    
		}
		
	    }
	    
	    csv_file << "BUS IDLE";
	    
	}
	
	csv_file << endl;
	
	// Start parsing the data
	int snapshot;
	for(snapshot = 0; snapshot < total_snapshots; snapshot++)
	{
	    if(snapshot%20000 == 0 && snapshot > 0)
	    {
		cout << "  " << (snapshot*100)/total_snapshots << "% done  \r" << flush;
	    }
	    
	    csv_file << snapshot << delimiter;
	    
	    int return_value =
		parse_snapshot(1, (unsigned char*)0, &data_file, 1, 0, &csv_file, delimiter, &proc_data);
	    
	    csv_file << endl;
	    
	    if (return_value == 1)
	    {
		cerr << endl << "End of capture data file reached unexpectedly after" << endl
		     << "processing " << snapshot << " snapshots" << endl;
	    }
	    
	}
	
	
	data_file.get();
	if(!data_file.eof())
	{
	    cerr << "Some extra data was left unparsed. If this was not intentional," << endl;
	    cerr << "make sure that your settings are correct." << endl;
	}
	
	csv_file.close();
	data_file.close();
	
	cout << "  " << 100 << "% done  \r" << flush;
	cout << endl;
	
	cout << "Parsed succesfully all " << snapshot << " snapshots of data." << endl;
	
	
    } // end if run_mode == 'r' || 'p'
*/  
    return 0;
}

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
