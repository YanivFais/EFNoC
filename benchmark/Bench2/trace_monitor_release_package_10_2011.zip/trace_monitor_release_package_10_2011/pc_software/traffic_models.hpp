// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.


#ifndef TRAFFIC_MODELS_HPP
#define TRAFFIC_MODELS_HPP

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <vector>

#include "p2p_investigator.hpp"

// Functions to create traffic models from p2p investigator results.

struct traffic_model_conn_params
{
    int src;
    int dst;
    long long int avg_occurence; // clk cycles
    int avg_size;
    long long int total;
    traffic_model_conn_params& operator=(const traffic_model_conn_params& other);
    bool operator<(const traffic_model_conn_params& other) const;
};

struct wait_and_amount
{
    long long int wait; // clk cycles
    int amount;
};

void find_conn_params(p2p_investigator& p2p_inv, int src, int dst, traffic_model_conn_params& result, int begin, int end, int stop_condition_cycles);

void write_hwtg_confline(const traffic_model_conn_params& model, ofstream& outfile);

void create_model(p2p_investigator& p2p_inv, int begin, int end, int* max_conf_lines, int format);

void create_model_textui(p2p_investigator& p2p_inv, int begin, int end);


#endif

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:

