// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2010

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>
#include <assert.h>
#include <ctime>
#include <SFML/Graphics.hpp>

#include "p2p_investigator.hpp"
#include "mesh.hpp"
#include "gui.hpp"

using namespace std;

p2p_investigator::p2p_investigator(statistics* stats, mesh* meshnoc, gui* guiui) :
    stats_(stats), meshnoc_(meshnoc), gui_(guiui)
{
    p2p_win_len = 1;
    p2p_length = 0;
    p2p_begin_snapshot = 0;

    dbg_print = false;

    dm.mode  = 0;
    dm.x_size = 1500;
    dm.y_size = 1000;
    dm.left_margin = 200;
    dm.totals_margin = 200;
    dm.bottom_margin = 40;
    dm.top_margin = 0;
    dm.slot_space = 2;
    dm.recalculate_vis_params();
    dm.overhead = true;
    dm.use_view_file = false;

    for(int i = 0; i < MAX_NUM_PES; i++)
	for(int o = 0; o < MAX_NUM_PES; o++)
	    draw_paths[i][o] = false;

    MAX_ROUTER_RECURSION_SPAWN = 1;
    MAX_RECURSION_LEVELS = 4;
    ROUTER_MAX_RECURS_LEVEL = 5;

    enable_p2p = false;

}

void p2p_investigator::drawing_modes::recalculate_vis_params()
{
   length = x_size - left_margin - totals_margin;   
}

void p2p_investigator::set_stream(ifstream* inp_stream)
{
    inp_stream_ = inp_stream;
}

// Equalize rows, if rows=true, otherwise cols.
void p2p_investigator::equalize(bool rows, p2p_path_stats** table, const int* expected_with_overhead, const int* expected_no_overhead, p2p_path_stats** results)
{
    for(int src = 0; src < stats_->pd->num_of_agents; src++)
    {
	p2p_path_stats tmp;
	for(int dst = 0; dst < stats_->pd->num_of_agents; dst++)
	{
	    if(table[rows?src:dst][rows?dst:src].data_with_overhead > 0)
		tmp.data_with_overhead += table[rows?src:dst][rows?dst:src].data_with_overhead;
	    if(table[rows?src:dst][rows?dst:src].data_no_overhead > 0)
		tmp.data_no_overhead   += table[rows?src:dst][rows?dst:src].data_no_overhead;
	}
	double factor_with_overhead;
	double factor_no_overhead;
	
	if(tmp.data_with_overhead == 0)
	    factor_with_overhead = 0.0;
	else
	    factor_with_overhead = (double)expected_with_overhead[src] / (double)tmp.data_with_overhead;
	
	if(tmp.data_no_overhead == 0)
	    factor_no_overhead = 0.0;
	else
	    factor_no_overhead = (double)expected_no_overhead[src] / (double)tmp.data_no_overhead;
	
	// Perform the equalization:
	for(int dst = 0; dst < stats_->pd->num_of_agents; dst++)
	{
	    results[rows?src:dst][rows?dst:src].data_with_overhead = 0.5 + ((double)table[rows?src:dst][rows?dst:src].data_with_overhead * factor_with_overhead);
	    results[rows?src:dst][rows?dst:src].data_no_overhead = 0.5 + ((double)table[rows?src:dst][rows?dst:src].data_no_overhead * factor_no_overhead);
	}
    }
}

void p2p_investigator::create_router_viewpoints()
{
     for(int row = 0; row < stats_->pd->mesh_rows; row++)
    {
	for(int col = 0; col < stats_->pd->mesh_cols; col++)
	{
	    for(int routing_from = 0; routing_from < 5; routing_from++)
	    {
		for(int routing_to = 0; routing_to < 5; routing_to++)
		{
		    if((ALLOWED_TURNS[meshnoc_->mesh_routing][routing_from][routing_to] == false) || 
		       (col == 0 && (routing_from == west || routing_to == west)) ||
		       (col == stats_->pd->mesh_cols-1 && (routing_from == east || routing_to == east)) ||
		       (row == 0 && (routing_from == north || routing_to == north)) ||
		       (row == stats_->pd->mesh_rows-1 && (routing_from == south || routing_to == south)))
		    {
			router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].illegal = true;
		    }
		    else
		    {
			assert(routing_from != routing_to); // Do not support U turns...

			router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].illegal = false;

			if(meshnoc_->mesh_routing == YX_ROUTING)
			{
			    if(routing_from == ip)
			    {
				router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row*stats_->pd->mesh_cols+col);
				if(routing_to == north)
				{
				    for(int row2 = 0; row2 < row; row2++)
					for(int col2 = 0; col2 < stats_->pd->mesh_cols; col2++)
					    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row2*stats_->pd->mesh_cols+col2);
				}
				else if(routing_to == south)
				{
				    for(int row2 = row+1; row2 < stats_->pd->mesh_rows; row2++)
					for(int col2 = 0; col2 < stats_->pd->mesh_cols; col2++)
					    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row2*stats_->pd->mesh_cols+col2);
				}
				else if(routing_to == west)
				{
				    for(int col2 = 0; col2 < col; col2++)
					router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row*stats_->pd->mesh_cols+col2);
				}
				else if(routing_to == east)
				{
				    for(int col2 = col+1; col2 < stats_->pd->mesh_cols; col2++)
					router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row*stats_->pd->mesh_cols+col2);
				}
			    }
			    else if(routing_to == ip)
			    {
				if(routing_from == north)
				{
				    for(int row2 = 0; row2 < row; row2++)
					router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col);
				}
				else if(routing_from == south)
				{
				    for(int row2 = row+1; row2 < stats_->pd->mesh_rows; row2++)
					router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col);
				}
				else if(routing_from == west)
				{
				    for(int row2 = 0; row2 < stats_->pd->mesh_rows; row2++)
					for(int col2 = 0; col2 < col; col2++)
					    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col2);
				}
				else if(routing_from == east)
				{
				    for(int row2 = 0; row2 < stats_->pd->mesh_rows; row2++)
					for(int col2 = col+1; col2 < stats_->pd->mesh_cols; col2++)
					    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col2);
				}

				router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row*stats_->pd->mesh_cols+col);
			    }
			    else if(routing_from == west && routing_to == east)
			    {
				// S S     - -
				// S S  -> D D
				// S S     - -
				
				for(int row2 = 0; row2 < stats_->pd->mesh_rows; row2++)
				    for(int col2 = 0; col2 < col; col2++)
					router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col2);
				
				for(int col2 = col+1; col2 < stats_->pd->mesh_cols; col2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row*stats_->pd->mesh_cols+col2);
				
			    }
			    else if(routing_from == east && routing_to == west)
			    {
				// - -     S S
				// D D  <- S S
				// - -     S S
				
				for(int row2 = 0; row2 < stats_->pd->mesh_rows; row2++)
				    for(int col2 = col+1; col2 < stats_->pd->mesh_cols; col2++)
					router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col2);
				
				for(int col2 = 0; col2 < col; col2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row*stats_->pd->mesh_cols+col2);
				
			    }
			    else if(routing_from == north && routing_to == west)
			    {
				//  -   -   S   -   -
				//  -   -   S   -   -
				//  D   D <-'   -   -
				//  -   -   -   -   -
				
				for(int row2 = 0; row2 < row; row2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col);
				
				for(int col2 = 0; col2 < col; col2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row*stats_->pd->mesh_cols+col2);
				
			    }
			    else if(routing_from == north && routing_to == east)
			    {
				//  -   -   S   -   -
				//  -   -   S   -   -
				//  -   -   '-> D   D
				//  -   -   -   -   -
				
				for(int row2 = 0; row2 < row; row2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col);
				
				for(int col2 = col+1; col2 < stats_->pd->mesh_cols; col2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row*stats_->pd->mesh_cols+col2);
				
			    }
			    else if(routing_from == south && routing_to == west)
			    {
				//  -   -   -   -   -
				//  D   D <-.   -   -
				//  -   -   S   -   -
				//  -   -   S   -   -
				
				for(int row2 = row+1; row2 < stats_->pd->mesh_rows; row2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col);
				
				for(int col2 = 0; col2 < col; col2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row*stats_->pd->mesh_cols+col2);
				
			    }
			    else if(routing_from == south && routing_to == east)
			    {
				//  -   -   -   -   -
				//  -   -   .-> D   D
				//  -   -   S   -   -
				//  -   -   S   -   -
				
				for(int row2 = row+1; row2 < stats_->pd->mesh_rows; row2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col);
				
				for(int col2 = col+1; col2 < stats_->pd->mesh_cols; col2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row*stats_->pd->mesh_cols+col2);
				
			    }
			    else if(routing_from == north && routing_to == south)
			    {
				//  -   -   S   -   -
				//  -   -   S   -   -
				//  -   -   v   -   -
				//  D   D   D   D   D
				//  D   D   D   D   D
				
				for(int row2 = 0; row2 < row; row2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col);
				
				for(int row2 = row+1; row2 < stats_->pd->mesh_rows; row2++)
				    for(int col2 = 0; col2 < stats_->pd->mesh_cols; col2++)
					router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row2*stats_->pd->mesh_cols+col2);
				
			    }
			    else if(routing_from == south && routing_to == north)
			    {
				//  D   D   D   D   D
				//  D   D   D   D   D
				//  -   -   v   -   -
				//  -   -   S   -   -
				//  -   -   S   -   -
				
				for(int row2 = row+1; row2 < stats_->pd->mesh_rows; row2++)
				    router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].srcs.push_back(row2*stats_->pd->mesh_cols+col);
				
				for(int row2 = 0; row2 < row; row2++)
				    for(int col2 = 0; col2 < stats_->pd->mesh_cols; col2++)
					router_viewpoints[row*stats_->pd->mesh_cols+col][routing_from][routing_to].dsts.push_back(row2*stats_->pd->mesh_cols+col2);
				
			    }
			    
			}
			else if(meshnoc_->mesh_routing == XY_ROUTING)
			{
			    // TODO.
			}
		    }
		}
	    }
	}
    }

/*    
    cout << "Create router viewpoints finished:" << endl;
    char txt[5][10] = {"N ","E ","S ","W ","IP"};
    for(int router = 0; router < stats_->pd->num_of_agents; router++)
    {
	cout << "Router " << router << endl;
	for(int from = 0; from < 5; from++)
	{
	    for(int to = 0; to < 5; to++)
	    {
		cout << "Turn " << txt[from] << "->" << txt[to] << ": ";
		if(router_viewpoints[router][from][to].illegal)
		{
		    cout << "ILLEGAL" << endl;
		    continue;
		}

		cout << "Sources: ";
		for(int i = 0; i < router_viewpoints[router][from][to].srcs.size(); i++)
		    cout << router_viewpoints[router][from][to].srcs.at(i) << ", ";
		cout << "Destinations: ";
		for(int i = 0; i < router_viewpoints[router][from][to].dsts.size(); i++)
		    cout << router_viewpoints[router][from][to].dsts.at(i) << ", ";
		cout << endl;

	    }
	}
    }
*/

}

void p2p_investigator::text_ui()
{
    cout << endl;
    cout << "Welcome to the POINT-TO-POINT INVESTIGATOR" << endl;
    cout << endl;

    create_router_viewpoints();

    for(int i = 0; i < MAX_NUM_PES; i++)
	for(int o = 0; o < MAX_NUM_PES; o++)
	    draw_paths[i][o] = false;


    bool done = false;


    vector<grp> groups;
    
    const int NUM_ALGORITHMS = 3;
    algo = elimination_deductive;

    long long int* expected_sums_from_with_overhead = new long long int[stats_->pd->num_of_agents];
    long long int* expected_sums_to_with_overhead = new long long int[stats_->pd->num_of_agents];
    long long int* expected_sums_from_no_overhead = new long long int[stats_->pd->num_of_agents];
    long long int* expected_sums_to_no_overhead = new long long int[stats_->pd->num_of_agents];
    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	expected_sums_from_with_overhead[i] = 0;
	expected_sums_to_with_overhead[i] = 0;
	expected_sums_from_no_overhead[i] = 0;
	expected_sums_to_no_overhead[i] = 0;
    }

    // p2p_paths: 2D table of every p2p connection with its "properties".

    p2p_paths = new p2p_path*[stats_->pd->num_of_agents];
    for(int i = 0; i < stats_->pd->num_of_agents; i++)
	p2p_paths[i] = new p2p_path[stats_->pd->num_of_agents];

    bool process = false;

    // Create link number arrays for paths.

    for(int src = 0; src < stats_->pd->num_of_agents; src++)
    {
	for(int dst = 0; dst < stats_->pd->num_of_agents; dst++)
	{    
	    p2p_paths[src][dst].data_am_constraint = -1; // not constrained by default

	    // Create link number array for one src->dst path.
	    p2p_paths[src][dst].num_of_hops = 0;
	    int cur_row = src/(stats_->pd->mesh_cols); // start with src pos
	    int cur_col = src - (cur_row*(stats_->pd->mesh_cols));
	    int dst_row = dst/(stats_->pd->mesh_cols);
	    int dst_col = dst - (dst_row*(stats_->pd->mesh_cols));

	    if(meshnoc_->mesh_routing == XY_ROUTING)
	    {
		// First go sideways
		while(true)
		{
		    int dist = dst_col - cur_col;
		    if(dist < 0) // to left
		    {
			p2p_paths[src][dst].hop_link_numbers[p2p_paths[src][dst].num_of_hops++] = meshnoc_->mesh_link_numbers_to_left[cur_row][cur_col];
			cur_col--;
			assert(cur_col >= 0);
		    }
		    else if(dist > 0) // to right
		    {
			p2p_paths[src][dst].hop_link_numbers[p2p_paths[src][dst].num_of_hops++] = meshnoc_->mesh_link_numbers_to_right[cur_row][cur_col];
			cur_col++;
			assert(cur_col < stats_->pd->mesh_cols);
		    }
		    else
			break;
		}
		// Then go up or down
		while(true)
		{
		    int dist = dst_row - cur_row;
		    if(dist < 0) // to up
		    {
			p2p_paths[src][dst].hop_link_numbers[p2p_paths[src][dst].num_of_hops++] = meshnoc_->mesh_link_numbers_to_up[cur_row][cur_col];
			cur_row--;
			assert(cur_row >= 0);
		    }
		    else if(dist > 0) // to down
		    {
			p2p_paths[src][dst].hop_link_numbers[p2p_paths[src][dst].num_of_hops++] = meshnoc_->mesh_link_numbers_to_down[cur_row][cur_col];
			cur_row++;
			assert(cur_row < stats_->pd->mesh_rows);
		    }
		    else
			break;		    
		}

//		cout << "src=" << src << ", dst=" << dst << ", hops = " << p2p_paths[src][dst].num_of_hops << ": ";
//		for(int siwa = 0; siwa < p2p_paths[src][dst].num_of_hops; siwa++)
//		    cout << p2p_paths[src][dst].hop_link_numbers[siwa] << "  ";
//		cout << endl;
	    }
	    else  // YX_ROUTING
	    {
		// First vertically
		while(true)
		{
		    int dist = dst_row - cur_row;
		    if(dist < 0) // to up
		    {
			p2p_paths[src][dst].hop_link_numbers[p2p_paths[src][dst].num_of_hops++] = meshnoc_->mesh_link_numbers_to_up[cur_row][cur_col];
			cur_row--;
			assert(cur_row >= 0);
		    }
		    else if(dist > 0) // to down
		    {
			p2p_paths[src][dst].hop_link_numbers[p2p_paths[src][dst].num_of_hops++] = meshnoc_->mesh_link_numbers_to_down[cur_row][cur_col];
			cur_row++;
			assert(cur_row < stats_->pd->mesh_rows);
		    }
		    else
			break;		    
		}
		// Then horizontally
		while(true)
		{
		    int dist = dst_col - cur_col;
		    if(dist < 0) // to left
		    {
			p2p_paths[src][dst].hop_link_numbers[p2p_paths[src][dst].num_of_hops++] = meshnoc_->mesh_link_numbers_to_left[cur_row][cur_col];
			cur_col--;
			assert(cur_col >= 0);
		    }
		    else if(dist > 0) // to right
		    {
			p2p_paths[src][dst].hop_link_numbers[p2p_paths[src][dst].num_of_hops++] = meshnoc_->mesh_link_numbers_to_right[cur_row][cur_col];
			cur_col++;
			assert(cur_col < stats_->pd->mesh_cols);
		    }
		    else
			break;
		}

//		cout << "src=" << src << ", dst=" << dst << ", hops = " << p2p_paths[src][dst].num_of_hops << ": ";
//		for(int siwa = 0; siwa < p2p_paths[src][dst].num_of_hops; siwa++)
//		    cout << p2p_paths[src][dst].hop_link_numbers[siwa] << "  ";
//		cout << endl;

	    }
	    

	}

    }

    // Equalization:
    eq_src_rows  = true;
    eq_dst_cols  = true;
    eq_src_first = true;
    eq_iterations = 1;

    // Alg 2 specific:
    dont_accept_uneven = false;
    dont_assume_low_count = false;
    use_rule_F = true;

    while(!done)
    {
	cout << " INVESTIGATION OPTIONS " << endl;
	cout << "1: Constraints---Set known groups of IPs" << endl;
	cout << "  You can enter groups of IPs whose intercommunication amounts are known or estimated (eg. 0)" << endl;
	cout << endl;
	cout << "2: Constraints---Set known p2p communications" << endl;
	cout << "  You can enter single communication paths whose data amounts are known or estimated (eg. 0)" << endl;
	cout << endl;
	cout << "3: Set window length (current = " << p2p_win_len << ")" << endl;
	cout << endl;
	cout << "4: Select algorithm (current = " << algo << ": " << algo_names[algo] << ")" << endl << endl;;
	cout << "5: Select equalization (current = " << (eq_src_rows?"sources (rows)  ":" ") << 
	    (eq_dst_cols?"destinations (cols)  ":" ") << (eq_src_first?"sources first":"destinations first") <<
	    "  Iterations = " << eq_iterations << endl;
	cout << "6: Alg. 2 Rule E Assumptions configuration. (Don't accept uneven routing: " << dont_accept_uneven 
	     << ", Don't assume low routing count: " << dont_assume_low_count << ")" << endl;
	cout << "7: Alg. 2. Use rule F, educated guessing (" << use_rule_F << ")" << endl;
	cout << "8: Alg. 2. Situation recursion control (max spawns per router: " << MAX_ROUTER_RECURSION_SPAWN << ", max level: " << MAX_RECURSION_LEVELS << endl;
	cout << endl;
	cout << "s: Start processing (or capital S to include debug prints)" << endl;
	cout << endl << endl;
	cout << endl << endl;
	
	cout << "Give a command (others to cancel)" << endl;
	
	char cmd;
	cin >> cmd;
	if(cmd == '1')
	{
	    bool done2 = false;
	    while(!done2)
	    {
		cout << "DEFINED GROUPS:" << endl;
		if(groups.size() == 0)
		    cout << "(No groups.)" << endl;
		
		for(int i = 0; i < groups.size(); i++)
		{
		    cout << "Group " << i << ":" << endl;
		    for(int o = 0; o < groups.at(i).ips.size(); o++)
			cout << "   " << groups.at(i).ips.at(o) << " (" << gui_->name_tags[groups.at(i).ips.at(o)] << ")" << endl;
		    
		    cout << "   Max data amount (each communicating with each other) in one window: " << groups.at(i).data_constraint << endl;
		    cout << endl;
		}
		
		cout << "(a) Add a new group" << endl;
		cout << "(d) Delete group" << endl;
		cout << "(e <number>) Edit group" << endl;
		cout << "(q) Quit" << endl;
		
		char cmd2;
		cin >> cmd2;
		if(cmd2 == 'a')
		{
		    cout << "Select IP's to your group by clicking them, then click DONE." << endl;
		    
		    grp new_grp;
		    new_grp.data_constraint = 0;
		    groups.push_back(new_grp);
		    gui_->select_ips_graphically(groups.back().ips);
		    cout << "Give data amount constraint (integer in words; maximum data transferred between any of them during one window)" << endl;
		    cin >> groups.back().data_constraint;
		}
		else if(cmd2 == 'd')
		{
		    cout << "Give index to delete." << endl;
		    int idx;
		    cin >> idx;
		    if(idx < 0 || idx > groups.size()-1)
			cout << "Illegal!" << endl;
		    else
			groups.erase(groups.begin()+idx);
		}
		else if(cmd2 == 'e')
		{
		    int num;
		    cin >> num;
		    if(num >= groups.size())
			cout << "Invalid group number." << endl;
		    else
		    {
			cout << "Select IP's to your group by clicking them, then click DONE." << endl;		
			gui_->select_ips_graphically(groups.at(num).ips);
			cout << "Give data amount constraint, or -1 to keep previous (" << groups.at(num).data_constraint << "))" << endl;
			signed int am;
			cin >> am;
			if(am > -1)
			    groups.at(num).data_constraint = am;
		    }
		}
		else
		    done2 = true;
	    }

	}
	else if(cmd == '2')
	{

	}
	else if(cmd == '3')
	{
	    cout << "Give desired processing window length in original windows." << endl;
	    cin >> p2p_win_len;
	}
	else if(cmd == '4')
	{
	    cout << "Select the algorithm." << endl;
	    for(int i = 0; i < NUM_ALGORITHMS; i++)
	    {
		cout << "  " << i << ": " << algo_names[i];
		if(i == algo) cout << " (SELECTED)";
		cout << endl;
	    }
	    int al_tmp;
	    cin >> al_tmp;
	    if(al_tmp < 0 || al_tmp >= NUM_ALGORITHMS) al_tmp = 0;
	    algo = (algorithms_t)al_tmp;
	}
	else if(cmd == '5')
	{
	    cout << "Equalize sources (rows)? [0/1]" << endl;
	    cin >> eq_src_rows;
	    cout << "Equalize destinations (cols)? [0/1]" << endl;
	    cin >> eq_dst_cols;
	    cout << "Sources (rows) first? [0/1]" << endl;
	    cin >> eq_src_first;
	    cout << "Number of iterations?" << endl;
	    cin >> eq_iterations;
	    
	}
	else if(cmd == '6')
	{
	    cout << "Do not accept uneven routing? [0/1]" << endl;
	    cin >> dont_accept_uneven;
	    cout << "Do not assume lower routing count? [0/1]" << endl;
	    cin >> dont_assume_low_count;
	}
	else if(cmd == '7')
	{
	    cout << "Use rule F? (Educated guess of row & column sums in case of uncertainty.) [0/1]" << endl;
	    cin >> use_rule_F;
	}
	else if(cmd == '8')
	{
	    cout << "How many new situation possibilities are spawned at maximum per router by Rule E?" << endl;
	    cout << "[1 - 20. Enter 1 to fall back to quick, non-recursive one best case mode]" << endl;
	    cin >> MAX_ROUTER_RECURSION_SPAWN;
	    if(MAX_ROUTER_RECURSION_SPAWN < 1 || MAX_ROUTER_RECURSION_SPAWN > 20)
	    {
		MAX_ROUTER_RECURSION_SPAWN = 1;
		cout << "Invalid value, will use " << MAX_ROUTER_RECURSION_SPAWN << "." << endl;
	    }

	    cout << "Specify the recursion level after which the algorithm falls back to spawning only one situation." << endl;
	    cout << "[1 - 20]" << endl;
	    cin >> MAX_RECURSION_LEVELS;
	    if(MAX_RECURSION_LEVELS < 1 || MAX_RECURSION_LEVELS > 20)
	    {
		MAX_RECURSION_LEVELS = 4;
		cout << "Invalid value, will use " << MAX_RECURSION_LEVELS << "." << endl;
	    }
	}
	else if(cmd == 'S' || cmd == 's')
	{
	    process = true;
	    done = true;
	    dbg_print = (cmd=='S');
	}
	else
	{
	    done = true;
	}

    }    

    if(!process)
	return;

    sprintf(p2p_bin_name, "%s.p2p", stats_->pd->bin_name);
    cout << "Creating " << p2p_bin_name << "..." << endl;
    ofstream p2pbin(p2p_bin_name, ios_base::out | ios_base::binary);
    ofstream p2pbin_decis[DECIMATION_ZONES];
    int deci_acc_counts[DECIMATION_ZONES];
    for(int i=0; i < DECIMATION_ZONES; i++)
    {
	deci_acc_counts[i] = 0;
	char tmp[500];
	sprintf(tmp, "%s.p2pdeci%d", stats_->pd->bin_name, stats_->navi_decimation[i]);
	p2pbin_decis[i].open(tmp, ios_base::out | ios_base::binary);
    }   

    char p2p_totals_name[500];
    sprintf(p2p_totals_name, "%s.p2ptotals", stats_->pd->bin_name);
    ofstream p2ptotals(p2p_totals_name, ios_base::out | ios_base::binary);

    if(dbg_print) cout << "Allocating decimation accumulation arrays..." << endl;

    p2p_path_stats*** deci_acc_arrays;

    deci_acc_arrays = new p2p_path_stats**[DECIMATION_ZONES];
    for(int deci=0; deci < DECIMATION_ZONES; deci++)
    {
	deci_acc_arrays[deci] = new p2p_path_stats*[stats_->pd->num_of_agents];
	for(int src=0; src < stats_->pd->num_of_agents; src++)
	{
	    deci_acc_arrays[deci][src] = new p2p_path_stats[stats_->pd->num_of_agents];
	}

	// Erase the accumulation array.
	for(int esrc = 0; esrc < stats_->pd->num_of_agents; esrc++)
	{
	    for(int edst = 0; edst < stats_->pd->num_of_agents; edst++)
	    {
		deci_acc_arrays[deci][esrc][edst].data_with_overhead = 0;
		deci_acc_arrays[deci][esrc][edst].data_no_overhead = 0;
		deci_acc_arrays[deci][esrc][edst].status = known; // Reset like this; see the code how the status is set.
	    }
	}

    }

    // Create data_am_constraints in p2p_paths from groups.

    if(dbg_print) cout << "Creating data_am_constraints..." << endl;

    for(int group = 0; group < groups.size(); group++)
    {
	for(int i = 0; i < groups.at(group).ips.size(); i++)
	{
	    for(int o = 0; o < groups.at(group).ips.size(); o++)
	    {
		if(i == o) continue;
		p2p_paths[groups.at(group).ips.at(i)][groups.at(group).ips.at(o)].data_am_constraint = groups.at(group).data_constraint;
	    }
	}
    }

    int region_len = gui_->nav_bar.num_of_snapshots/p2p_win_len;  // gui_->nav_bar.zoom_region/p2p_win_len;

    if(dbg_print) cout << "Allocating main statistics matrix" << endl;

//    p2p_statistics = new p2p_window[region_len];

/*    stats = new p2p_path_stats**[region_len];

    for(int i = 0; i < region_len; i++)
    {
	stats[i] = new p2p_path_stats*[stats_->pd->num_of_agents];
	for(int o = 0; o < stats_->pd->num_of_agents; o++)
	{
	    stats[i][o] = new p2p_path_stats[stats_->pd->num_of_agents];
	    for(int z = 0; z < stats_->pd->num_of_agents; z++)
	    {
		if(p2p_paths[o][z].data_am_constraint == 0)
		{
		    stats[i][o][z].status = known;
		    stats[i][o][z].data_with_overhead = 0;
		}
		else
		{
		    stats[i][o][z].status = unknown;
		}

	    }
	}
    }
*/

    if(dbg_print) cout << "Allocating totals accumulation matrix" << endl;

    totals = new p2p_tot_stats*[stats_->pd->num_of_agents];

    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	totals[i] = new p2p_tot_stats[stats_->pd->num_of_agents];

	for(int o = 0; o < stats_->pd->num_of_agents; o++)
	{
	    totals[i][o].data_with_overhead = 0;
	    totals[i][o].data_no_overhead = 0;
	}
    }

    if(dbg_print) cout << "Allocating data array" << endl;

    unsigned char* data = new unsigned char[p2p_win_len*stats_->pd->snapshot_bytes];

    int* expected_from_with_overhead = new int[stats_->pd->num_of_agents];
    int* expected_from_no_overhead   = new int[stats_->pd->num_of_agents];
    int* expected_to_with_overhead   = new int[stats_->pd->num_of_agents];
    int* expected_to_no_overhead     = new int[stats_->pd->num_of_agents];


    if(dbg_print) cout << "Starting processing." << endl;


    for(int time = 0; time < region_len; time++)
    {
	if(time%1000 == 0)
	    cout << "Time = " << time << " ( " << 100.0*(double)time/(double)region_len << " % done)          " << '\r' << flush;

	// READ AND PARSE WINDOW

//	inp_stream_->seekg((gui_->nav_bar.location+time*p2p_win_len)*stats_->pd->snapshot_bytes, ios::beg);
	inp_stream_->seekg((time*p2p_win_len)*stats_->pd->snapshot_bytes, ios::beg);
	inp_stream_->read((char*)data, p2p_win_len*stats_->pd->snapshot_bytes);
	stats_->parse_and_analyze_region(data, p2p_win_len);

	// COPY EXPECTED SENDER ROW & DESTINATION COLUMN SUMS for easier accessibility.

	for(int row = 0; row < stats_->pd->mesh_rows; row++)
	{
	    for(int col = 0; col < stats_->pd->mesh_cols; col++)
	    {
		expected_from_with_overhead[row*stats_->pd->mesh_cols+col] = 
		    stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_out_with_overhead[row][col]];

		expected_from_no_overhead[row*stats_->pd->mesh_cols+col] = 
		    stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_out_no_overhead[row][col]];

		expected_to_with_overhead[row*stats_->pd->mesh_cols+col] = 
		    stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_in_with_overhead[row][col]];

		expected_to_no_overhead[row*stats_->pd->mesh_cols+col] = 
		    stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_in_no_overhead[row][col]];
	    }
	}

	p2p_situation first_possibility(stats_, this);

	// Take a copy of counters to use.

	for(int i = 0; i < stats_->pd->num_of_counters; i++)
	    first_possibility.residual_counters[i] = stats_->tot_counter_log[i];

	p2p_window cur_window;
//	solve_situation_recursive(p2p_statistics[time].possibilities, &first_possibility, 0);
	solve_situation_recursive(cur_window.possibilities, &first_possibility, 0);


//	sort(p2p_statistics[time].possibilities.begin(), p2p_statistics[time].possibilities.end());
	sort(cur_window.possibilities.begin(), cur_window.possibilities.end());

//	cout << "OH YEAH!!! The possibilities: " << endl;
/*
	for(int i = 0; i < p2p_statistics[time].possibilities.size(); i++)
	{
	    cout << "POSSIBILITY NUMBER " << i << endl;
	    cout << endl;
	    dbg_show_table(p2p_statistics[time].possibilities.at(i).paths);
	    cout << endl;
	    cout << "Residual counters: " << endl;
	    for(int o = 0; o < stats_->pd->num_of_counters; o+=2)
		cout << setw(3) << p2p_statistics[time].possibilities.at(i).residual_counters[o] << ",";
	    cout << endl << endl;
	    cout << "Plus data      = " << p2p_statistics[time].possibilities.at(i).plus_data() << endl;
	    cout << "Minus data     = " << p2p_statistics[time].possibilities.at(i).minus_data() << endl;
	    cout << "Total residual = " << p2p_statistics[time].possibilities.at(i).total_residual() << endl;
	    cout << "Q value        = " << p2p_statistics[time].possibilities.at(i).Q() << endl;

	    cout << endl << endl << endl;;
	}
*/
	// For now, select the best match.

//	if(p2p_statistics[time].possibilities.size() < 1)
	if(cur_window.possibilities.size() < 1)
	{
	    cerr << "Unexpected error: No possible network situations found!" << endl << endl;
	    return;
	}

//	p2p_situation& selected = p2p_statistics[time].possibilities.at(0);
	p2p_situation& selected = cur_window.possibilities.at(0);
//	p2p_statistics[time].selected = 0;
	cur_window.selected = 0;

	// For now, truncate the extra vector to save memory.
//	p2p_statistics[time].possibilities.erase(p2p_statistics[time].possibilities.begin()+1, p2p_statistics[time].possibilities.end());

	// Equalization of 2D table of one snapshot.
	if(eq_src_rows && eq_dst_cols)
	{
	    for(int iter = 0; iter < eq_iterations; iter++)
	    {
		if(eq_src_first)
		{
		    equalize(true, selected.paths, expected_from_with_overhead, expected_from_no_overhead, selected.paths);
		    equalize(false, selected.paths, expected_to_with_overhead, expected_to_no_overhead, selected.paths);
		}
		else
		{
		    equalize(false, selected.paths, expected_to_with_overhead, expected_to_no_overhead, selected.paths);
		    equalize(true, selected.paths, expected_from_with_overhead, expected_from_no_overhead, selected.paths);
		}
	    }
	}
	else if(eq_src_rows)
	{
	    for(int iter = 0; iter < eq_iterations; iter++)
		equalize(true, selected.paths, expected_from_with_overhead, expected_from_no_overhead, selected.paths);
	}
	else if(eq_dst_cols)
	{
	    for(int iter = 0; iter < eq_iterations; iter++)
		equalize(false, selected.paths, expected_to_with_overhead, expected_to_no_overhead, selected.paths);
	}

	// Write to disc.

	for(int src = 0; src < stats_->pd->num_of_agents; src++)
	{
	    for(int dst = 0; dst < stats_->pd->num_of_agents; dst++)
	    {
		if(p2pbin.good() == false)
		{
		    cout << "FAILURE, output stream not good!" << endl;
		    return;
		}

		p2pbin.write((char*)&(selected.paths[src][dst].data_with_overhead), sizeof(int));
		p2pbin.write((char*)&(selected.paths[src][dst].data_no_overhead), sizeof(int));
		p2pbin.write((char*)&(selected.paths[src][dst].status), sizeof(stats_status_t));

		for(int d=0; d<DECIMATION_ZONES; d++)
		{
		    deci_acc_arrays[d][src][dst].data_with_overhead += selected.paths[src][dst].data_with_overhead;
		    deci_acc_arrays[d][src][dst].data_no_overhead += selected.paths[src][dst].data_no_overhead;
		    // Set the status as unknown if there is one unknown in the region; set the status as estimated
		    // if there is one estimated but no unknowns.
		    if(deci_acc_arrays[d][src][dst].status == known && selected.paths[src][dst].status == estimated)
			deci_acc_arrays[d][src][dst].status = estimated;
		    if(selected.paths[src][dst].status == unknown)
			deci_acc_arrays[d][src][dst].status = unknown;	
		}
	    }
	}

	for(int d=0; d<DECIMATION_ZONES; d++)
	{
	    deci_acc_counts[d]++;
	    if(deci_acc_counts[d] == stats_->navi_decimation[d])
	    {
		deci_acc_counts[d] = 0;
		for(int src = 0; src < stats_->pd->num_of_agents; src++)
		{
		    for(int dst = 0; dst < stats_->pd->num_of_agents; dst++)
		    {
			p2pbin_decis[d].write((char*)&(deci_acc_arrays[d][src][dst].data_with_overhead), sizeof(int));
			p2pbin_decis[d].write((char*)&(deci_acc_arrays[d][src][dst].data_no_overhead), sizeof(int));
			p2pbin_decis[d].write((char*)&(deci_acc_arrays[d][src][dst].status), sizeof(stats_status_t));
		    }
		}		

		// Erase the accumulation array.
		for(int esrc = 0; esrc < stats_->pd->num_of_agents; esrc++)
		{
		    for(int edst = 0; edst < stats_->pd->num_of_agents; edst++)
		    {
			deci_acc_arrays[d][esrc][edst].data_with_overhead = 0;
			deci_acc_arrays[d][esrc][edst].data_no_overhead = 0;
			deci_acc_arrays[d][esrc][edst].status = known; // Reset like this; see the code how the status is set.
		    }
		}
		
	    }
	}

	// Sum up totals

	for(int sender = 0; sender < stats_->pd->num_of_agents; sender++)
	{
	    for(int receiver = 0; receiver < stats_->pd->num_of_agents; receiver++)
	    {
		if(selected.paths[sender][receiver].data_with_overhead > 0)
		    totals[sender][receiver].data_with_overhead += selected.paths[sender][receiver].data_with_overhead;
		if(selected.paths[sender][receiver].data_no_overhead > 0)
		    totals[sender][receiver].data_no_overhead += selected.paths[sender][receiver].data_no_overhead;
	    }
	}

	// Sum up expected totals:
	for(int ag = 0; ag < stats_->pd->num_of_agents; ag++)
	{
	    expected_sums_from_with_overhead[ag] += expected_from_with_overhead[ag];
	    expected_sums_from_no_overhead[ag]   += expected_from_no_overhead[ag];
	    expected_sums_to_with_overhead[ag]   += expected_to_with_overhead[ag];
	    expected_sums_to_no_overhead[ag]     += expected_to_no_overhead[ag];
	}

    }

    delete expected_from_with_overhead;
    delete expected_from_no_overhead;
    delete expected_to_with_overhead;
    delete expected_to_no_overhead;

    // We did everything.
//    p2p_begin_snapshot = gui_->nav_bar.location;
//    p2p_length = region_len;

//    select_view_paths(40);

    // Save totals to a file.
    for(int sender = 0; sender < stats_->pd->num_of_agents; sender++)
    {
	for(int receiver = 0; receiver < stats_->pd->num_of_agents; receiver++)
	{
	    p2ptotals.write((char*)&(totals[sender][receiver].data_with_overhead), sizeof(long long int));
	    p2ptotals.write((char*)&(totals[sender][receiver].data_no_overhead), sizeof(long long int));
	}
    }

    p2pbin.close();
    p2ptotals.close();
//    enable_p2p = true;

    cout << endl;

/*
    char filename[300];
    cin >> filename;

//    cout << "0 = do not include overhead, 1 = include overhead" << endl;
    bool incl_overhead = true;
//    cin >> incl_overhead;

    const char delimiter = ';';

    ofstream csv_output;
    csv_output.open(filename, ios::out);

    // PRINT TOP HEADER TO CSV
    csv_output << "FROM | TO" << delimiter;
    for(int ag = 0; ag < stats_->pd->num_of_agents; ag++)
    {
	csv_output << gui_->name_tags[ag] << delimiter;
    }

    csv_output << "SUM" << delimiter << "Expected sum";

    csv_output << endl;

    // PRINT LEFT HEADER CELLS AND VALUES

    long long int SAD = 0;
    long long int TOTAL_DATA = 0;
    int DZ = 0;
    int TOT_ZEROES = 0;
    int DNZ = 0;
    int TOT_NONZEROES = 0;

    long long int TOT_DATA_IN_ZEROES = 0;
    long long int TOT_DATA_IN_MISSING_PATHS = 0;

    long long int TOTAL_EXCESS = 0;
    long long int TOTAL_MISSING = 0;

    for(int from = 0; from < stats_->pd->num_of_agents; from++)
    {
	csv_output << gui_->name_tags[from] << delimiter;
	
	for(int to = 0; to < stats_->pd->num_of_agents; to++)
	{
	    long long int val = (incl_overhead?(totals[from][to].data_with_overhead):(totals[from][to].data_no_overhead));
	    TOTAL_DATA += val;
	    csv_output << val << delimiter;
	    SAD += abs((long int)val - (long int)CORRECTS[from][to]);

	    if(val < CORRECTS[from][to])
		TOTAL_MISSING += CORRECTS[from][to] - val;
	    else if(val > CORRECTS[from][to])
		TOTAL_EXCESS += val - CORRECTS[from][to];

	    if(CORRECTS[from][to] == 0)
	    {
		TOT_ZEROES++; 
		if(val == 0)
		    DZ++;
		else
		    TOT_DATA_IN_ZEROES += val;
	    }
	    else
	    {
		TOT_NONZEROES++;
		if(val != 0)
		    DNZ++;
		else
		    TOT_DATA_IN_MISSING_PATHS += CORRECTS[from][to];
	    }
	}

	csv_output << delimiter;
	// Expected sum
	csv_output << (incl_overhead?(expected_sums_from_with_overhead[from]):(expected_sums_from_no_overhead[from]));
	csv_output << endl;
    }

    // Print "TO" expected sums

    csv_output << "SUM" << delimiter;
    csv_output << endl;
    csv_output << "Expected sum" << delimiter;
    for(int to = 0; to < stats_->pd->num_of_agents; to++)
    {
	csv_output << (incl_overhead?(expected_sums_to_with_overhead[to]):(expected_sums_to_no_overhead[to])) << delimiter;
    }
    csv_output << endl;
//    csv_output << "Giveups:" << delimiter << giveups << endl;
    csv_output << "TOT DATA" << delimiter << TOTAL_DATA << endl;
    csv_output << "TOT SAD" << delimiter << SAD << endl;
    csv_output << "TOTAL EXCESS" << delimiter << TOTAL_EXCESS << endl;
    csv_output << "TOTAL MISSING" << delimiter << TOTAL_MISSING << endl;
    csv_output << "DETECTED ZEROES" << delimiter << DZ << delimiter << "of" << delimiter << TOT_ZEROES << endl;
    csv_output << "DETECTED NON-ZEROES" << delimiter << DNZ << delimiter << "of" << delimiter << TOT_NONZEROES << endl;
    csv_output << "EXCESS DATA IN EXCESS PATHS" << delimiter << TOT_DATA_IN_ZEROES << endl;
    csv_output << "LOST DATA IN MISSING PATHS" << delimiter << TOT_DATA_IN_MISSING_PATHS << endl;

*/

    delete expected_sums_from_with_overhead;
    delete expected_sums_to_with_overhead;
    delete expected_sums_from_no_overhead;
    delete expected_sums_to_no_overhead;

    for(int i = 0; i < stats_->pd->num_of_agents; i++)
	delete p2p_paths[i];

    delete p2p_paths;

    delete data;

    for(int deci=0; deci < DECIMATION_ZONES; deci++)
    {
	for(int src=0; src < stats_->pd->num_of_agents; src++)
	    delete deci_acc_arrays[deci][src];
	delete deci_acc_arrays[deci];
    }
    delete deci_acc_arrays;


    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	delete totals[i];
    }
    delete totals;

    cout << "Done. Restart the software to read the p2p files and enable P2P Investigator." << endl;
}


bool p2p_investigator::p2p_tot_stats::operator<(const p2p_investigator::p2p_tot_stats& other) const
{
    return data_with_overhead < other.data_with_overhead;
}

struct tot_stat_tmp
{
    p2p_investigator::p2p_tot_stats val;
    int sender;
    int receiver;
    bool operator<(const tot_stat_tmp& other) const
    {
	return val < other.val;
    }
};

bool p2p_investigator::read_totals_file()
{
    char p2p_totals_name[500];
    sprintf(p2p_totals_name, "%s.p2ptotals", stats_->pd->bin_name);
    ifstream p2ptotals(p2p_totals_name, ios_base::in | ios_base::binary);

    if(!p2ptotals.good())
	return false;

    totals = new p2p_tot_stats*[stats_->pd->num_of_agents];

    for(int i = 0; i < stats_->pd->num_of_agents; i++)
	totals[i] = new p2p_tot_stats[stats_->pd->num_of_agents];

    for(int sender = 0; sender < stats_->pd->num_of_agents; sender++)
    {
	for(int receiver = 0; receiver < stats_->pd->num_of_agents; receiver++)
	{
	    p2ptotals.read((char*)&(totals[sender][receiver].data_with_overhead), sizeof(long long int));
	    if(!p2ptotals.good())
		return false;
	    p2ptotals.read((char*)&(totals[sender][receiver].data_no_overhead), sizeof(long long int));
	}
    }

    return true;

}

bool p2p_investigator::read_view_file()
{
    char p2p_view_name[500];
    sprintf(p2p_view_name, "%s.p2pview", stats_->pd->bin_name);
    ifstream p2pview(p2p_view_name, ios_base::in);

    if(!p2pview.good())
	return false;

    while(p2pview.good())
    {
	int src = -1;
	int dst = -1;

	p2pview >> src;
	p2pview >> dst;

	if(src >= 0 && src < stats_->pd->num_of_agents && dst >= 0 && dst < stats_->pd->num_of_agents)
	    draw_paths[src][dst] = true;
    }

    dm.use_view_file = true;
    return true;
}


void p2p_investigator::select_view_paths(int restriction)
{

    vector<tot_stat_tmp> sorting_vect;

    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	for(int o = 0; o < stats_->pd->num_of_agents; o++)
	{
	    tot_stat_tmp tmp;
	    tmp.val = totals[i][o];
	    tmp.sender = i;
	    tmp.receiver = o;
	    sorting_vect.push_back(tmp);
	}
    }

    sort(sorting_vect.begin(), sorting_vect.end());

    for(int i = sorting_vect.size()-1; i >= 0; i--)
    {
//	cout << "Sort: i = " << i << " data = " << sorting_vect.at(i).val.data_with_overhead << " sender = " << sorting_vect.at(i).sender << " rcv = "  << sorting_vect.at(i).receiver << endl;
 	draw_paths[sorting_vect.at(i).sender][sorting_vect.at(i).receiver] = sorting_vect.at(i).val.data_with_overhead > 0;
        restriction--;
        if(restriction == 0)
            break;
    }
}


void p2p_investigator::solve_situation_recursive(vector<p2p_situation>& possibilities, p2p_situation* cur_possibility, int recurs_level, bool gave_up)
{
//    cout << "SOLVE_SITUATION BEGIN: VECTOR ADDRESS: " << &possibilities << endl;

    int sender_row, sender_col, receiver_row, receiver_col;

    if(dbg_print)
    {
	cout << "*** solve_situation_recursive ***    recurs_level = " << recurs_level << " gave_up = " << gave_up << endl;
	cout << "Accumulated possibilities so far: " << possibilities.size() << endl;
    }

    if(1 == 2 && dbg_print)
    {
	for(int i = 0; i < possibilities.size(); i++)
	{
	    cout << endl << endl;
	    cout << "POSSIBILITY " << i << endl;
	    dbg_show_table(possibilities.at(i).paths);
	}

    }

    if(algo == min_src_dst || algo == min_src_links_dst)
    {
	///////////////////////////////////////////
	// START ALGORITHMS MIN-MIN AND MIN-MIN-MIN
	///////////////////////////////////////////
	for(int sender = 0; sender < stats_->pd->num_of_agents; sender++)
	{
	    for(int receiver = 0; receiver < stats_->pd->num_of_agents; receiver++)
	    {
		sender_row = sender/(stats_->pd->mesh_cols);
		sender_col = sender - (sender_row*(stats_->pd->mesh_cols));
		    
		receiver_row = receiver/(stats_->pd->mesh_cols);
		receiver_col = receiver - (receiver_row*(stats_->pd->mesh_cols));
		    
		if(sender == receiver)
		{
		    cur_possibility->paths[sender][receiver].data_with_overhead = 0;
		    cur_possibility->paths[sender][receiver].data_no_overhead = 0;
		    cur_possibility->paths[sender][receiver].status = known;
		}
		else
		{
		    cur_possibility->paths[sender][receiver].status = estimated;

		    // First check min of src, dst
		    if(algo == min_src_dst || algo == min_src_links_dst)
		    {
			cur_possibility->paths[sender][receiver].data_with_overhead = 
			    min_of(stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_out_with_overhead[sender_row][sender_col]],
				   stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_in_with_overhead [receiver_row][receiver_col]]);
			    
			cur_possibility->paths[sender][receiver].data_no_overhead = 
			    min_of(stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_out_no_overhead[sender_row][sender_col]],
				   stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_in_no_overhead [receiver_row][receiver_col]]);
		    }
			
		    // Then use links, if wanted
		    if(algo == min_src_links_dst)
		    {
			// To "strip" overhead from the links, we estimate an overhead factor.
			// Overhead used to calculate the factor is taken from src or dst, which one is smaller.
			    
			int with_over = 0, no_over = 0;
			if(stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_out_no_overhead[sender_row][sender_col]] <
			   stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_in_no_overhead [receiver_row][receiver_col]])
			{
			    with_over = stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_out_with_overhead[sender_row][sender_col]];
			    no_over = stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_out_no_overhead[sender_row][sender_col]];
			}
			else
			{
			    with_over = stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_out_with_overhead[receiver_row][receiver_col]];
			    no_over = stats_->tot_counter_log[2*meshnoc_->mesh_pe_datalink_indeces_out_no_overhead[receiver_row][receiver_col]];
			}
			    
			int overhead = with_over - no_over;
			double overhead_factor = (double)no_over/(double)overhead;
			if(overhead_factor < 0.0)
			    overhead_factor = 0.0;
			if(overhead_factor > 1.0)
			    overhead_factor = 1.0;
			    
			    
			// Now we can loop through all in-between links.
			    
			for(int link = 0; link < p2p_paths[sender][receiver].num_of_hops; link++)
			{
			    // With overhead, no compensation needed.
			    int am = stats_->tot_counter_log[2*p2p_paths[sender][receiver].hop_link_numbers[link]];
			    if(am < cur_possibility->paths[sender][receiver].data_with_overhead)
				cur_possibility->paths[sender][receiver].data_with_overhead = am;
				
			    // Without overhead, compensated.
			    if(am*overhead_factor < cur_possibility->paths[sender][receiver].data_no_overhead)
				cur_possibility->paths[sender][receiver].data_no_overhead = am*overhead_factor;
			}
			    
		    }

		}

//		cout << setw(3) << stats[time][sender][receiver].data_no_overhead << "  ";
	    }
//	    cout << endl;
	}  

    } // END ALGORITHMS MIN-MIN and MIN-MIN-MIN
    else if(algo == elimination_deductive)
    {
	////////////////////////////////////////
	// START ELIMINATION-DEDUCTIVE ALGORITHM
	////////////////////////////////////////

	if(dbg_print) cout << "Starting Elimination-Deductive algorithm." << endl;
	if(dbg_print) dbg_show_table(cur_possibility->paths);


	int num_unknowns;

	int iter_round = 0;

	while(true)
	{
	    num_unknowns = stats_num_of_unknowns(cur_possibility->paths);

	    // Elimination with Rules A&B: Sent or Received = 0 ==> path known as 0;  Any inbetween link = 0 ==> path known as 0.
	    for(int sender = 0; sender < stats_->pd->num_of_agents; sender++)
		for(int receiver = 0; receiver < stats_->pd->num_of_agents; receiver++)
		    do_rule_A_B(cur_possibility->paths, sender, receiver, cur_possibility->residual_counters, p2p_paths, gave_up);

	    if(dbg_print) cout << "Rules A&B finished. " << stats_num_of_unknowns(cur_possibility->paths) << " unknowns." << endl;
	    if(dbg_print) dbg_show_table(cur_possibility->paths);

	    if(stats_num_of_unknowns(cur_possibility->paths) == 0)
		break;

	    // Elimination with Rules C & D:
	    for(int sender = 0; sender < stats_->pd->num_of_agents; sender++)
		for(int receiver = 0; receiver < stats_->pd->num_of_agents; receiver++)
		    do_rule_C_D(cur_possibility->paths, sender, receiver, cur_possibility->residual_counters, p2p_paths, gave_up);

	    if(dbg_print) cout << "Rules C&D finished. " << stats_num_of_unknowns(cur_possibility->paths) << " unknowns." << endl;
	    if(dbg_print) dbg_show_table(cur_possibility->paths);

	    if(stats_num_of_unknowns(cur_possibility->paths) == 0)
		break;
    
	    for(int router = 0; router < stats_->pd->num_of_agents; router++)
	    {
		if(do_rule_E(router, cur_possibility->residual_counters, p2p_paths, gave_up,
			     possibilities, cur_possibility, recurs_level))
		{
		    return;  // Rule E has found new situations and launched new solve_situation_recursive functions accordingly.
		}
	    }

	    if(dbg_print) cout << "Rule E finished. " << stats_num_of_unknowns(cur_possibility->paths) << " unknowns." << endl;
	    if(dbg_print) dbg_show_table(cur_possibility->paths);


	    if(stats_num_of_unknowns(cur_possibility->paths) == 0)
		break;  // Every path solved, stop.

	    if(stats_num_of_unknowns(cur_possibility->paths) == num_unknowns)
	    { // Nothing solved on this round anymore. Give up or run rule F.
		if(dbg_print)
		    cout << endl << "Had to give up, " << num_unknowns << "unknowns." << endl;
		if(dbg_print) dbg_show_table(cur_possibility->paths);

		gave_up = true;

		if(use_rule_F)
		{
		    do_rule_F(cur_possibility->paths, cur_possibility->residual_counters, p2p_paths); // Desperate action also called educated estimation :-).
		    if(dbg_print) cout << "Rule F finished. " << stats_num_of_unknowns(cur_possibility->paths) << " unknowns." << endl;
		    if(dbg_print) dbg_show_table(cur_possibility->paths);
		}
		else
		    break; // Really give up.
	    }

	    iter_round++;

	    if(dbg_print && iter_round%50 == 49)
	    {
		cout << endl << "Warning: Iteration round " << iter_round << "; num_unknowns = " << num_unknowns << endl; 
		dbg_show_table(cur_possibility->paths);
	    }
	}
    }


    // Add the possibility only if it differs from the earlier ones.
    if(find(possibilities.begin(), possibilities.end(), *cur_possibility) == possibilities.end())
    {
	if(dbg_print) 
	    cout << endl << endl 
		 << "##############################################################################################################" << endl
		 << "Pushing back a new possibility! Size was: " << possibilities.size() << endl << endl;
	possibilities.push_back(*cur_possibility);
    }
    else
    {
	if(dbg_print) cout << "There already was an identical possibility!" << endl;
    }

//    cout << "SOLVE_SITUATION END: VECTOR ADDRESS: " << &possibilities << endl;


}

int p2p_investigator::stats_num_of_unknowns(p2p_path_stats** stats)
{
    int count = 0;
    for(int from=0; from < stats_->pd->num_of_agents; from++)
	for(int to=0; to < stats_->pd->num_of_agents; to++)
	    if(stats[from][to].status == unknown)
		count++;

    return count;
}

bool p2p_investigator::do_rule_A_B(p2p_path_stats** stats, int sender, int receiver, int* counter_copy, p2p_path** p2p_paths, bool flag_est)
{
    if(stats[sender][receiver].status != unknown)
	return false;

    bool did = false;
    if(sender == receiver || counter_copy[meshnoc_->get_snd_idx(sender)] <= 0 || counter_copy[meshnoc_->get_rcv_idx(receiver)] <= 0)
    {
	stats[sender][receiver].status = flag_est?estimated:known;
	stats[sender][receiver].data_with_overhead = 0;
	stats[sender][receiver].data_no_overhead = 0;
	did = true;
//	cout << CSI << CLR;
//	cout << "Rule A worked for " << gui_->name_tags[sender] << " -> " << gui_->name_tags[receiver] << "!" << endl;
//	dbg_show_table(stats);
//	boost::asio::io_service io;    
//	boost::asio::deadline_timer t(io, boost::posix_time::milliseconds(30));
//	t.wait();


    }
    else
    {
	// Rule A didn't work, check for Rule B (zero inbetween links)
	for(int link = 0; link < p2p_paths[sender][receiver].num_of_hops; link++)
	{
	    if(stats_->tot_counter_log[2*p2p_paths[sender][receiver].hop_link_numbers[link]] <= 0)
	    {
		stats[sender][receiver].status = flag_est?estimated:known;
		stats[sender][receiver].data_with_overhead = 0;
		stats[sender][receiver].data_no_overhead = 0;
		did = true;
//		cout << CSI << CLR;
//		cout << "Rule B worked for " << gui_->name_tags[sender] << " -> " << gui_->name_tags[receiver] << "!" << endl;
//		dbg_show_table(stats);
//		boost::asio::io_service io;    
//		boost::asio::deadline_timer t(io, boost::posix_time::milliseconds(30));
//		t.wait();

		break;
	    }
	}
	
    }

    return did;
}

bool p2p_investigator::p2p_path::is_constrained() const
{
    return data_am_constraint != -1;
}


bool p2p_investigator::do_rule_C_D(p2p_path_stats** stats, int sender, int receiver, int* counter_copy, p2p_path** p2p_paths, bool flag_est)
{
    bool got_it = false;

    // TRY RULE D: (D is first now, because if the transfer overlaps to multiple windows, the first window shows lower numbers
    // in the sender part and this number is favorable for the Add Excess Data to Next Window algorithm, if possible.
    if(stats[sender][receiver].status == unknown)
    {
	bool found = false;
	// Search for other unknowns with same destination:
	for(int search_rcv = 0; search_rcv < stats_->pd->num_of_agents; search_rcv++)
	{
	    if(search_rcv != receiver)
	    {
		if(stats[sender][search_rcv].status == unknown)
		{
		    found = true;
		    break;
		}
	    }
	}
	if(found == false)
	{
	    // DEDUCED WITH RULE D:
	    stats[sender][receiver].status = flag_est?estimated:known;
	    stats[sender][receiver].data_with_overhead = counter_copy[meshnoc_->get_snd_idx(sender)];
	    stats[sender][receiver].data_no_overhead = counter_copy[meshnoc_->get_snd_no_overhead_idx(sender)];

	    if(p2p_paths[sender][receiver].is_constrained() && 
	       p2p_paths[sender][receiver].data_am_constraint < stats[sender][receiver].data_with_overhead)
		stats[sender][receiver].data_with_overhead = p2p_paths[sender][receiver].data_am_constraint;

	    if(p2p_paths[sender][receiver].is_constrained() && 
	       p2p_paths[sender][receiver].data_am_constraint < stats[sender][receiver].data_no_overhead)
		stats[sender][receiver].data_no_overhead = p2p_paths[sender][receiver].data_am_constraint;


//	    cout << CSI << CLR;
	    if(dbg_print) cout << "Rule D worked for " << gui_->name_tags[sender] << " -> " << gui_->name_tags[receiver] << "!" << endl;
	    got_it = true;
	}
    }


    // TRY RULE C:
    if(stats[sender][receiver].status == unknown)
    {
	bool found = false;
	// Search for other unknowns with same sender:
	for(int search_snd = 0; search_snd < stats_->pd->num_of_agents; search_snd++)
	{
	    if(search_snd != sender)
	    {
		if(stats[search_snd][receiver].status == unknown)
		{
		    found = true;
		    break;
		}
	    }
	}
	if(found == false)
	{
	    // DEDUCED WITH RULE C:
	    stats[sender][receiver].status = flag_est?estimated:known;
	    stats[sender][receiver].data_with_overhead = counter_copy[meshnoc_->get_rcv_idx(receiver)];
	    stats[sender][receiver].data_no_overhead = counter_copy[meshnoc_->get_rcv_no_overhead_idx(receiver)];

	    if(p2p_paths[sender][receiver].is_constrained() && 
	       p2p_paths[sender][receiver].data_am_constraint < stats[sender][receiver].data_with_overhead)
	    {
		stats[sender][receiver].data_with_overhead = p2p_paths[sender][receiver].data_am_constraint;
	    }

	    if(p2p_paths[sender][receiver].is_constrained() && 
	       p2p_paths[sender][receiver].data_am_constraint < stats[sender][receiver].data_no_overhead)
	    {
		stats[sender][receiver].data_no_overhead = p2p_paths[sender][receiver].data_am_constraint;
	    }


//	    cout << CSI << CLR;
	    if(dbg_print) cout << "Rule C worked for " << gui_->name_tags[sender] << " -> " << gui_->name_tags[receiver] << "!" << endl;
	    got_it = true;
	}
    }
    
    if(got_it)
    {
	// We just deduced it, subtract from all links.
	subtract_deduced(stats, sender, receiver, counter_copy, p2p_paths);
   }

    return got_it;
}

void p2p_investigator::try_router_recursive(router_data_ams* ams, vector<routing_possibility>& possibilities, routing_possibility* cur_possibility, int level)
{
    int total_input = 0;
    for(int input = 0; input < 5; input++)
	total_input += ams->to_router[input];

    int total_output = 0;

    for(int output = 0; output < 5; output++)
	total_output += ams->from_router[output];

    if(total_input <= 0 || total_output <= 0)
    {
//	cout << "Total " << ((total_input<=0)?"input":"output") << " <= 0, stopping recursion. EI: " << total_input << ", EO: " << total_output << endl;
	// Copy cur_possibility to possibilities, if identical is not found.
	for(int i = 0; i < possibilities.size(); i++)
	    if(possibilities.at(i) == *cur_possibility) return; // identical found, do not add.

	if(cur_possibility->give_num_of_routings() < 1)
	    return; // No routings, do not add.

	possibilities.push_back(*cur_possibility);
	possibilities.at(possibilities.size()-1).excess_input = total_input;
	possibilities.at(possibilities.size()-1).excess_output = total_output;
	
	return;
    }

    bool recursion_continued = false;

    for(int input = 0; input < 5; input++)
    {
	if(ams->to_router[input] <= 0) 
	    continue;
	for(int output = 0; output < 5; output++)
	{
	    if(ams->from_router[output] <= 0)
		continue;

	    if(ALLOWED_TURNS[0][input][output] == false)
	    {
//		cout << "Turn not allowed: " << input << "->" << output << endl;
		continue;
	    }

	    router_data_ams the_new_one(*ams);

	    int possible_data = min_of(ams->to_router[input], ams->from_router[output]);

	    the_new_one.to_router[input]-=possible_data;
	    the_new_one.from_router[output]-=possible_data;

//	    cout << input << "->" << output << " " << possible_data << ": ";
//	    cout << "Calling risu again: N E S W IP old (new): TO ROUTER: ";
//	    for(int dbg=0; dbg<5; dbg++)
//		cout << ams->to_router[dbg] << " (" << the_new_one.to_router[dbg] << "), ";

//	    cout << " FROM ROUTER: ";
//	    for(int dbg=0; dbg<5; dbg++)
//		cout << ams->from_router[dbg] << " (" << the_new_one.from_router[dbg] << "), ";

//	    cout << endl;

	    routing_possibility new_possibility(*cur_possibility);

	    new_possibility.from_to[input][output] = possible_data;

	    if(level < ROUTER_MAX_RECURS_LEVEL)
		try_router_recursive(&the_new_one, possibilities, &new_possibility, level+1);
	    recursion_continued = true;
	}
    }

    if(recursion_continued == false)
    {
//	cout << "Recursion stopped by running out of routings." << endl;

	for(int i = 0; i < possibilities.size(); i++)
	    if(possibilities.at(i) == *cur_possibility) return; // identical found, do not add.

	if(cur_possibility->give_num_of_routings() < 1)
	    return; // No routings, do not add.

	possibilities.push_back(*cur_possibility);
	possibilities.at(possibilities.size()-1).excess_input = total_input;
	possibilities.at(possibilities.size()-1).excess_output = total_output;

	return;

    }

}

p2p_investigator::router_data_ams::router_data_ams(const router_data_ams& copy)
{
    for(int i = 0; i < 5; i++)
    {
	to_router[i] = copy.to_router[i];
	from_router[i] = copy.from_router[i];
    }
}

p2p_investigator::router_data_ams::router_data_ams()
{
    for(int i = 0; i < 5; i++)
    {
	to_router[i] = 0;
	from_router[i] = 0;
    }
}

bool p2p_investigator::routing_possibility::is_identical(const routing_possibility& other) const
{
    for(int i = 0; i < 5; i++)
	for(int o = 0; o < 5; o++)
	    if(from_to[i][o] != other.from_to[i][o])
		return false;

    return true;
}

p2p_investigator::routing_possibility::routing_possibility()
{
    for(int i = 0; i < 5; i++)
	for(int o = 0; o < 5; o++)
	    from_to[i][o] = 0;

    excess_input = 0;
    excess_output = 0;
}

p2p_investigator::routing_possibility::routing_possibility(const routing_possibility& copy)
{
    for(int i = 0; i < 5; i++)
	for(int o = 0; o < 5; o++)
	    from_to[i][o] = copy.from_to[i][o];

    excess_input = copy.excess_input;
    excess_output = copy.excess_output;

}

p2p_investigator::routing_possibility& p2p_investigator::routing_possibility::operator=(const routing_possibility& copy)
{
    for(int i = 0; i < 5; i++)
	for(int o = 0; o < 5; o++)
	    from_to[i][o] = copy.from_to[i][o];

    excess_input = copy.excess_input;
    excess_output = copy.excess_output;

    return *this;
}

int p2p_investigator::routing_possibility::Q() const
{
    return (excess_input+excess_output)*10 + give_num_of_routings();
}

bool p2p_investigator::routing_possibility::operator<(const routing_possibility& other) const
{
    return Q() < other.Q();
}
bool p2p_investigator::routing_possibility::operator>(const routing_possibility& other) const
{
    return Q() > other.Q();
}
bool p2p_investigator::routing_possibility::operator<=(const routing_possibility& other) const
{
    return Q() <= other.Q();
}
bool p2p_investigator::routing_possibility::operator>=(const routing_possibility& other) const
{
    return Q() >= other.Q();
}
bool p2p_investigator::routing_possibility::operator==(const routing_possibility& other) const
{
    return is_identical(other);
}
bool p2p_investigator::routing_possibility::operator!=(const routing_possibility& other) const
{
    return !is_identical(other);
}


int p2p_investigator::routing_possibility::give_num_of_routings() const
{
    int conns = 0;
    for(int i = 0; i < 5; i++)
	for(int o = 0; o < 5; o++)
	    if(from_to[i][o] > 0)
		conns++;

    return conns;
}

int p2p_investigator::routing_possibility::total_excess() const
{
    return excess_input + excess_output;
}


bool p2p_investigator::do_rule_E(int router, int* counter_copy, p2p_path** p2p_paths,
				 bool gave_up,
				 vector<p2p_situation>& possibilities, p2p_situation* cur_possibility,
                                 int recurs_level)
{

//    cout << "DO_RULE_E BEGIN: VECTOR ADDRESS: " << &possibilities << endl;

    // First find out if we can use this rule:
    // Check if the listed possible paths from the router viewpoint include ONE unknown path.
    // Through-router routings leading to ONE unknown paths are listed.
    // Then, these paths are solved recursively.

    int routing_from, routing_to;

    int unknown_src = 0;
    int unknown_dst = 0;

    int routing_from_for_unknown = 0;
    int routing_to_for_unknown = 0;

    bool run = false;

    if(dbg_print) cout << "Testing Rule E for router " << router << endl;
    for(routing_from = 0; routing_from < 5; routing_from++)
    {
	for(routing_to = 0; routing_to < 5; routing_to++)
	{
	    if(router_viewpoints[router][routing_from][routing_to].illegal)
		continue;

	    int num_unknowns = 0;
	    for(int src_idx = 0; src_idx < router_viewpoints[router][routing_from][routing_to].srcs.size(); src_idx++)
	    {
		for(int dst_idx = 0; dst_idx < router_viewpoints[router][routing_from][routing_to].dsts.size(); dst_idx++)
		{
		    if(cur_possibility->paths[router_viewpoints[router][routing_from][routing_to].srcs.at(src_idx)]
		       [router_viewpoints[router][routing_from][routing_to].dsts.at(dst_idx)].status == unknown)
		    {
			num_unknowns++;
			unknown_src = router_viewpoints[router][routing_from][routing_to].srcs.at(src_idx);
			unknown_dst = router_viewpoints[router][routing_from][routing_to].dsts.at(dst_idx);
			routing_from_for_unknown = routing_from;
			routing_to_for_unknown = routing_to;
		    }
		}
	    }

	    if(num_unknowns == 1)
	    {
		if(dbg_print) cout << "One unknown detected, rule will now run in order to solve path " << unknown_src << "-->" << unknown_dst << endl;
		run = true;
		break;
	    }
	}
	if(run)
	    break;
    }

    if(!run)
    {
	if(dbg_print) cout << "Rule E cannot run because all routings include more or less than one unknown path." << endl;
	return false;
    }

    assert(cur_possibility->paths[unknown_src][unknown_dst].status == unknown);


    router_data_ams ams;
    fill_router_data_ams(&ams, counter_copy, router);
/*
//      SOME TEST DATA:
                                                    ams.from_router[ip] = 0;
                                                    ams.to_router  [ip] = 6;

                         ams.to_router  [north] = 0;
                         ams.from_router[north] = 2;
        ams.to_router  [west] = 0;          ams.from_router[east] = 6;
	ams.from_router[west] = 6;          ams.to_router  [east] = 6;
                         ams.to_router  [south] = 2;
                         ams.from_router[south] = 0;
*/
    
    vector<routing_possibility> routing_possibilities;

    routing_possibility dummy;
//    cout << "Calling risu for the first time." << endl;
    try_router_recursive(&ams, routing_possibilities, &dummy, 0);
    if(dbg_print) cout << "Completed recursion. Number of results: " << routing_possibilities.size() << endl;
    
    if(routing_possibilities.size() < 1)
    {
	if(dbg_print) cout << "No results, sorry. E cannot run." << endl;
	return false;
    }
    
    sort(routing_possibilities.begin(), routing_possibilities.end());
    
    if(dbg_print) for(int res=0; res<routing_possibilities.size();res++)
    {
	cout << "Result " << res << ": ";
	if(routing_possibilities.at(res).excess_input != 0 || routing_possibilities.at(res).excess_output != 0)
	    cout << "Excess input: " << routing_possibilities.at(res).excess_input << ", excess output: " << routing_possibilities.at(res).excess_output << ", ";
	
	cout << "Number of routings: " << routing_possibilities.at(res).give_num_of_routings();
	
	cout << endl;
	
	for(int i=0; i<5; i++)
	{
	    for(int o=0; o<5; o++)
	    {
		if(routing_possibilities.at(res).from_to[i][o] != 0)
		    cout << direction_names[i] << "->" << direction_names[o] << ": " << routing_possibilities.at(res).from_to[i][o] << " words" << endl;
	    }
	}
    }
    
    if(dont_accept_uneven == true && routing_possibilities.at(0).total_excess() > 0)
    {
	if(dbg_print) cout << "Rule E is not allowed to use uneven results. Aborted rule." << endl;
	return false;
    }

    if(dont_assume_low_count == true && routing_possibilities.size() >= 2 && routing_possibilities.at(1).total_excess() <= 0)
    {
	// If we do not want to assume low connection count, and if the second best possibility had the same total excess,
	// we cannot do anything now.
	if(dbg_print) cout << "Rule E is not allowed to assume low connection count. Aborted rule." << endl;
	return false;
    }
    
    // Launch new recursion for certain amount of best routing_possibilities.
    int best_Q = routing_possibilities.at(0).Q();

    for(int recurs = 0; recurs < MAX_ROUTER_RECURSION_SPAWN && recurs < routing_possibilities.size(); recurs++)
    {
	if(recurs > 0 && routing_possibilities.at(recurs).Q() > best_Q*MAX_ROUTER_Q_INCREASE_FACTOR + MAX_ROUTER_Q_INCREASE_OFFSET)
	{
	    if(dbg_print) cout << "BREAKDANCE " << routing_possibilities.at(recurs).Q() << " > " << best_Q*MAX_ROUTER_Q_INCREASE_FACTOR + MAX_ROUTER_Q_INCREASE_OFFSET << endl;
	    break;
	}

	// Simply copy the solved routing to the unknown path to create a new situation based on the earlier! :)

	p2p_situation new_situation_possibility(*cur_possibility);

	if(dbg_print)
	{
	    cout << endl;
	    cout << endl;
	    cout << "*****************************************************************************************************" << endl;
	    cout << endl;
	    cout << "Rule E is spawning a new situation AT LEVEL " << recurs_level << " FROM SOLUTION " << recurs << endl;
	    cout << endl;

	}
	if(dbg_print) cout << "Rule E solved " << unknown_src << "-->" << unknown_dst << " = " << 
			  routing_possibilities.at(recurs).from_to[routing_from_for_unknown][routing_to_for_unknown] << "!" << endl;

	new_situation_possibility.paths[unknown_src][unknown_dst].status = gave_up?estimated:known;
	new_situation_possibility.paths[unknown_src][unknown_dst].data_with_overhead = 
	    routing_possibilities.at(recurs).from_to[routing_from_for_unknown][routing_to_for_unknown];

	// For no-overhead calculation, take either the sender or receiver IP (which is smaller)
	// and use that to calculate overhead percentage.

	int overhead;
	double overhead_factor;

	if(counter_copy[meshnoc_->get_snd_no_overhead_idx(unknown_src)] < counter_copy[meshnoc_->get_rcv_no_overhead_idx(unknown_dst)])
	{
	    // Snd is smaller (no overhead)
	    overhead = counter_copy[meshnoc_->get_snd_idx(unknown_src)] - counter_copy[meshnoc_->get_snd_no_overhead_idx(unknown_src)];
	    if(overhead <= 0)
		overhead_factor = 1.0;
	    else
		overhead_factor = (double)counter_copy[meshnoc_->get_snd_no_overhead_idx(unknown_src)]/(double)overhead;
	}
	else
	{
	    // Rcv is smaller (no overhead)
	    overhead = counter_copy[meshnoc_->get_rcv_idx(unknown_dst)] - counter_copy[meshnoc_->get_rcv_no_overhead_idx(unknown_dst)];
	    if(overhead <= 0)
		overhead_factor = 1.0;
	    else
		overhead_factor = (double)counter_copy[meshnoc_->get_rcv_no_overhead_idx(unknown_dst)]/(double)overhead;
	}
	
	if(overhead_factor < 0.0)
	    overhead_factor = 0.0;
	if(overhead_factor > 1.0)
	    overhead_factor = 1.0;
	
	new_situation_possibility.paths[unknown_src][unknown_dst].data_no_overhead = 
	    (int)(overhead_factor*(double)routing_possibilities.at(recurs).from_to[routing_from_for_unknown][routing_to_for_unknown]);

	if(p2p_paths[unknown_src][unknown_dst].is_constrained() && 
	   p2p_paths[unknown_src][unknown_dst].data_am_constraint < new_situation_possibility.paths[unknown_src][unknown_dst].data_with_overhead)
	{
	    new_situation_possibility.paths[unknown_src][unknown_dst].data_with_overhead = p2p_paths[unknown_src][unknown_dst].data_am_constraint;
	}

	if(p2p_paths[unknown_src][unknown_dst].is_constrained() && 
	   p2p_paths[unknown_src][unknown_dst].data_am_constraint < new_situation_possibility.paths[unknown_src][unknown_dst].data_no_overhead)
	{
	    new_situation_possibility.paths[unknown_src][unknown_dst].data_no_overhead = p2p_paths[unknown_src][unknown_dst].data_am_constraint;
	}

	subtract_deduced(new_situation_possibility.paths, unknown_src, unknown_dst, new_situation_possibility.residual_counters, p2p_paths);

	if(dbg_print)  cout << "RULE_E FOR LOOP: Accumulated possibilities so far: " << possibilities.size() << endl;

	// Go back to start:
//	cout << "DO_RULE_E GOING TO RECURSION: VECTOR ADDRESS: " << &possibilities << endl;

	solve_situation_recursive(possibilities, &new_situation_possibility, recurs_level+1, gave_up);

//	cout << "DO_RULE_E COMING FROM RECURSION: VECTOR ADDRESS: " << &possibilities << endl;
	
	if(recurs_level >= MAX_RECURSION_LEVELS)
	    break; // Spawn only one function if maximum recursion level has been exceeded.

    }

    if(dbg_print) cout << endl << endl << "Rule E: STOPPED SPAWNING RECURSIONS AT LEVEL " << recurs_level << ". Vector size = " << possibilities.size() << endl << endl << endl;

//    cout << "DO_RULE_E END: VECTOR ADDRESS: " << &possibilities << endl;

    
    return true;
}

bool p2p_investigator::do_rule_F(p2p_path_stats** stats, int* counter_copy, p2p_path** p2p_paths)
{
    // Rule F provides only an educated guess, but in some cases is the only way out of unknowns.
    // Links deduced with rule F are marked as estimated.

    // Algorithm: Take the biggest row (sender) sum, and the biggest col (receiver) sum, using only the unknowns. The minimum of those two is guessed
    // as a communication between the two. Then we can continue back from rule A.

    // words row&col refer now to the resulting 2D table (equal to src&dst)

    int biggest_sum = MAX_INIT;
    int row_idx = -1;
    int col_idx = -1;

    int rowsum = 0;
    int rowsum_no_overhead = 0;
    int colsum = 0;
    int colsum_no_overhead = 0;

    if(dbg_print) cout << "Rule F starts!" << endl;

    for(int row = 0; row < stats_->pd->num_of_agents; row++)
    {
	for(int col = 0; col < stats_->pd->num_of_agents; col++)
	{
	    if(stats[row][col].status != unknown) continue;

	    int sum = counter_copy[meshnoc_->get_snd_idx(row)] + counter_copy[meshnoc_->get_rcv_idx(col)];
	    if(sum > biggest_sum)
	    {
		biggest_sum = sum;
		row_idx = row;
		col_idx = col;
		rowsum = counter_copy[meshnoc_->get_snd_idx(row)];
		rowsum_no_overhead = counter_copy[meshnoc_->get_snd_no_overhead_idx(row)];
		colsum = counter_copy[meshnoc_->get_rcv_idx(col)];
		colsum_no_overhead = counter_copy[meshnoc_->get_rcv_no_overhead_idx(col)];
	    }
	}
    }

    assert(row_idx != -1);
    assert(col_idx != -1);

    stats[row_idx][col_idx].status = estimated;
    stats[row_idx][col_idx].data_with_overhead = min_of(colsum, rowsum);
    stats[row_idx][col_idx].data_no_overhead = min_of(colsum_no_overhead, rowsum_no_overhead);

    if(p2p_paths[row_idx][col_idx].is_constrained() && 
       p2p_paths[row_idx][col_idx].data_am_constraint < stats[row_idx][col_idx].data_with_overhead)
    {
	stats[row_idx][col_idx].data_with_overhead = p2p_paths[row_idx][col_idx].data_am_constraint;
    }

    if(p2p_paths[row_idx][col_idx].is_constrained() && 
       p2p_paths[row_idx][col_idx].data_am_constraint < stats[row_idx][col_idx].data_no_overhead)
    {
	stats[row_idx][col_idx].data_no_overhead = p2p_paths[row_idx][col_idx].data_am_constraint;
    }

    if(dbg_print)
	cout << "Estimated that " << row_idx << " -> " << col_idx << " = " << stats[row_idx][col_idx].data_with_overhead;

    subtract_deduced(stats, row_idx, col_idx, counter_copy, p2p_paths);

    return true;

}

void p2p_investigator::fill_router_data_ams(router_data_ams* ams, int* counter_copy, int ip_num)
{
    int row = ip_num/(stats_->pd->mesh_cols);
    int col = ip_num - (row*(stats_->pd->mesh_cols));

    fill_router_data_ams(ams, counter_copy, row, col);
}


void p2p_investigator::fill_router_data_ams(router_data_ams* ams, int* counter_copy, int row, int col)
{
    ams->from_router[west]  = (col==0)?0:(counter_copy[2*meshnoc_->mesh_link_numbers_to_left[row][col]]);
    ams->from_router[east]  = (col==stats_->pd->mesh_cols-1)?0:(counter_copy[2*meshnoc_->mesh_link_numbers_to_right[row][col]]);
    ams->from_router[north] = (row==0)?0:(counter_copy[2*meshnoc_->mesh_link_numbers_to_up[row][col]]);
    ams->from_router[south] = (row==stats_->pd->mesh_rows-1)?0:(counter_copy[2*meshnoc_->mesh_link_numbers_to_down[row][col]]);

    ams->from_router[ip]    = counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_in_with_overhead[row][col]];

    ams->to_router[west]    = (col==0)?0:(counter_copy[2*meshnoc_->mesh_link_numbers_to_right[row][col-1]]);
    ams->to_router[east]    = (col==stats_->pd->mesh_cols-1)?0:(counter_copy[2*meshnoc_->mesh_link_numbers_to_left[row][col+1]]);
    ams->to_router[north]   = (row==0)?0:(counter_copy[2*meshnoc_->mesh_link_numbers_to_down[row-1][col]]);
    ams->to_router[south]   = (row==stats_->pd->mesh_rows-1)?0:(counter_copy[2*meshnoc_->mesh_link_numbers_to_up[row+1][col]]);

    ams->to_router[ip]      = counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_out_with_overhead[row][col]];
}

int p2p_investigator::subtract_deduced(p2p_path_stats** stats, int sender, int receiver, int* counter_copy, p2p_path** p2p_paths)
{
    // Subtract from in-between links
    for(int link = 0; link < p2p_paths[sender][receiver].num_of_hops; link++)
    {
	counter_copy[2*p2p_paths[sender][receiver].hop_link_numbers[link]] -=
	    stats[sender][receiver].data_with_overhead;
	
	if(counter_copy[2*p2p_paths[sender][receiver].hop_link_numbers[link]] < 0)
	{
	    if(dbg_print) cout << "Warning: link " << p2p_paths[sender][receiver].hop_link_numbers[link] << " between IPs " 
		 << sender << " (" << gui_->name_tags[sender] << ") and " << receiver << " ("
		 << gui_->name_tags[receiver] << ") went " << counter_copy[2*p2p_paths[sender][receiver].hop_link_numbers[link]]
		 << " < 0." << endl;
	    //	    counter_copy[2*p2p_paths[sender][receiver].hop_link_numbers[link]] = 0;
	    
	}
	
    }

//    int meshnoc_->mesh_pe_datalink_indeces_in_with_overhead[20][20];
//    int meshnoc_->mesh_pe_datalink_indeces_out_with_overhead[20][20];

    // Subtract from source and dst IPs.

    int row = sender/(stats_->pd->mesh_cols);
    int col = sender - (row*(stats_->pd->mesh_cols));
    counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_out_with_overhead[row][col]] -= stats[sender][receiver].data_with_overhead;
    counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_out_no_overhead[row][col]] -= stats[sender][receiver].data_no_overhead;

    if(counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_out_with_overhead[row][col]] < 0)
    {
	if(dbg_print) cout << "Warning: data input (with overhead) for sender "
	     << sender << " (" << gui_->name_tags[sender]
	     << ") went " << counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_out_with_overhead[row][col]]
	     << " < 0. " << endl;
	//	counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_out_with_overhead[row][col]] = 0;
    }

    if(counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_out_no_overhead[row][col]] < 0)
    {
	if(dbg_print) cout << "Warning: data input (no overhead) for sender "
	     << sender << " (" << gui_->name_tags[sender]
	     << ") went " << counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_out_no_overhead[row][col]]
	     << " < 0." << endl;
//	counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_out_no_overhead[row][col]] = 0;
    }

    row = receiver/(stats_->pd->mesh_cols);
    col = receiver - (row*(stats_->pd->mesh_cols));
    counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_in_with_overhead[row][col]] -= stats[sender][receiver].data_with_overhead;
    counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_in_no_overhead[row][col]] -= stats[sender][receiver].data_no_overhead;

    if(counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_in_with_overhead[row][col]] < 0)
    {
	if(dbg_print) cout << "Warning: data input (with overhead) for receiver "
	     << receiver << " (" << gui_->name_tags[receiver]
	     << ") went " << counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_in_with_overhead[row][col]]
	     << " < 0." << endl;
	//	counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_in_with_overhead[row][col]] = 0;
    }
    if(counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_in_no_overhead[row][col]] < 0)
    {
	if(dbg_print) cout << "Warning: data input (no overhead) for receiver "
	     << receiver << " (" << gui_->name_tags[receiver]
	     << ") went " << counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_in_no_overhead[row][col]]
	     << " < 0." << endl;
	//	counter_copy[2*meshnoc_->mesh_pe_datalink_indeces_in_no_overhead[row][col]] = 0;
    }

}

void p2p_investigator::dbg_show_table(p2p_path_stats** stats)
{
    cout << "FR TO  ";
    for(int i = 0; i < stats_->pd->num_of_agents; i++)
	cout << setw(5) << i << " |";

    cout << endl;
    
    for(int from = 0; from < stats_->pd->num_of_agents; from++)
    {
	cout << setw(5) << from << "  ";
	for(int to = 0; to < stats_->pd->num_of_agents; to++)
	{
	    if(stats[from][to].status == unknown)
		cout << " ??? ";
	    else
	    {
		cout << setw(3) << stats[from][to].data_with_overhead;
		if(stats[from][to].status == estimated)
		    cout << "E ";
		else
		    cout << "  ";
	    }

	    cout << " |";
	}
	cout << endl;
    }



}

bool p2p_investigator::p2p_path_stats::operator==(const p2p_path_stats& other) const
{
//    cout << "Own: " << data_with_overhead << " other: " << other.data_with_overhead;
    if(data_with_overhead == other.data_with_overhead &&
       data_no_overhead == other.data_no_overhead &&
       status == other.status)
    {
//	cout << "                                           compared: paths are identical!" << endl;
	return true;
    }
    else
    {
//	cout << "                                           compared: paths are NOT identical!" << endl;

	return false;
    }
}

bool p2p_investigator::p2p_path_stats::operator!=(const p2p_path_stats& other) const
{
    return !(operator==(other));
}

p2p_investigator::p2p_path_stats& p2p_investigator::p2p_path_stats::operator=(const p2p_path_stats& other)
{
    data_with_overhead = other.data_with_overhead;
    data_no_overhead = other.data_no_overhead;
    status = other.status;
}


int p2p_investigator::p2p_situation::plus_data() const
{
    int count = 0;
    for(int i = 0; i < p2p_->meshnoc_->vect_indeces_router_links.size(); i++)
    {
	if(residual_counters[2*p2p_->meshnoc_->vect_indeces_router_links.at(i)] > 0)
	    count += residual_counters[2*p2p_->meshnoc_->vect_indeces_router_links.at(i)];
    }
    for(int i = 0; i < p2p_->meshnoc_->vect_indeces_pe_overhead_links.size(); i++)
    {
	if(residual_counters[2*p2p_->meshnoc_->vect_indeces_pe_overhead_links.at(i)] > 0)
	    count += residual_counters[2*p2p_->meshnoc_->vect_indeces_pe_overhead_links.at(i)];
    }

    return count;
}

int p2p_investigator::p2p_situation::minus_data() const
{
    int count = 0;
    for(int i = 0; i < p2p_->meshnoc_->vect_indeces_router_links.size(); i++)
    {
	if(residual_counters[2*p2p_->meshnoc_->vect_indeces_router_links.at(i)] < 0)
	    count -= residual_counters[2*p2p_->meshnoc_->vect_indeces_router_links.at(i)];
    }
    for(int i = 0; i < p2p_->meshnoc_->vect_indeces_pe_overhead_links.size(); i++)
    {
	if(residual_counters[2*p2p_->meshnoc_->vect_indeces_pe_overhead_links.at(i)] < 0)
	    count -= residual_counters[2*p2p_->meshnoc_->vect_indeces_pe_overhead_links.at(i)];
    }

    return count;
}

int p2p_investigator::p2p_situation::total_residual() const
{
    return plus_data() + minus_data();
}

int p2p_investigator::p2p_situation::num_estimated() const
{
    int count = 0;
    for(int src = 0; src < stats_->pd->num_of_agents; src++)
    {
	for(int dst = 0; dst < stats_->pd->num_of_agents; dst++)
	{
	    if(paths[src][dst].status == estimated)
		count++;
	}
    }
    return count;
}

int p2p_investigator::p2p_situation::Q() const
{
    return (100*total_residual())/stats_->pd->window_length + 10*num_estimated();
}

bool p2p_investigator::p2p_situation::operator==(const p2p_situation& other) const
{
    bool identical = true;
    for(int src = 0; src < stats_->pd->num_of_agents; src++)
    {
	for(int dst = 0; dst < stats_->pd->num_of_agents; dst++)
	{
	    if(paths[src][dst] != other.paths[src][dst])
	    {
		identical = false;
		goto stop;
	    }
	}
    }

  stop:
//    cout << "                                                 compared whether situation is identical: " << identical << endl;
    return identical;   
}

bool p2p_investigator::p2p_situation::operator!=(const p2p_situation& other) const
{
    return !(operator==(other));
}

bool p2p_investigator::p2p_situation::operator<(const p2p_situation& other) const
{
    return Q() < other.Q();
}
bool p2p_investigator::p2p_situation::operator>(const p2p_situation& other) const
{
    return Q() > other.Q();
}
bool p2p_investigator::p2p_situation::operator<=(const p2p_situation& other) const
{
    return Q() <= other.Q();
}
bool p2p_investigator::p2p_situation::operator>=(const p2p_situation& other) const
{
    return Q() >= other.Q();
}

p2p_investigator::p2p_situation& p2p_investigator::p2p_situation::operator=(const p2p_situation& other)
{
    stats_ = other.stats_;
    for(int src = 0; src < stats_->pd->num_of_agents; src++)
    {
	for(int dst = 0; dst < stats_->pd->num_of_agents; dst++)
	{
	    paths[src][dst] = other.paths[src][dst];
	}
    }

    for(int i = 0; i < stats_->pd->num_of_counters; i++)
	residual_counters[i] = other.residual_counters[i];
}


int p2p_investigator::p2p_situation::residual_with_previous(const p2p_situation& other) const
{
    int residual = 0;
    for(int i = 0; i < stats_->pd->num_of_counters; i += stats_->pd->counters_per_link)
    {
	residual += residual_counters[i] + other.residual_counters[i];
    }
    return residual;
}

p2p_investigator::p2p_path_stats::p2p_path_stats()
{
    data_with_overhead = 0;
    data_no_overhead = 0;
    status = unknown;
}

p2p_investigator::p2p_situation::p2p_situation(const statistics* stats_pnt, const p2p_investigator* p2p_pnt) : stats_(stats_pnt), p2p_(p2p_pnt)
{
    paths = new p2p_path_stats*[stats_->pd->num_of_agents];
    for(int i = 0; i < stats_->pd->num_of_agents; i++)
	paths[i] = new p2p_path_stats[stats_->pd->num_of_agents];
    residual_counters = new int[stats_->pd->num_of_counters];
}

// Copy constructor
p2p_investigator::p2p_situation::p2p_situation(const p2p_situation& other) : stats_(other.stats_), p2p_(other.p2p_)
{
    paths = new p2p_path_stats*[stats_->pd->num_of_agents];
    for(int i = 0; i < stats_->pd->num_of_agents; i++)
	paths[i] = new p2p_path_stats[stats_->pd->num_of_agents];
    residual_counters = new int[stats_->pd->num_of_counters];

    for(int snd = 0; snd < stats_->pd->num_of_agents; snd++)
	for(int rcv = 0; rcv < stats_->pd->num_of_agents; rcv++)
	    paths[snd][rcv] = other.paths[snd][rcv];

    for(int i = 0; i < stats_->pd->num_of_counters; i++)
	residual_counters[i] = other.residual_counters[i];
}


p2p_investigator::p2p_situation::~p2p_situation()
{
    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	delete paths[i];
	paths[i] = 0;
    }

    delete paths;
    paths = 0;

    delete residual_counters;
    residual_counters = 0;
}

p2p_investigator::p2p_path_stats** p2p_investigator::p2p_window::paths() const
{
    return possibilities.at(selected).paths;
}

struct valpair
{
    valpair(int ep, int v) : endpoint(ep), val(v) { }
    int endpoint;
    int val;
    bool operator<(const valpair& other) const
    {
	return val > other.val;  // !!
    }
};

struct longlongvalpair
{
    longlongvalpair(int ep, int v) : endpoint(ep), val(v) { }
    int endpoint;
    long long int val;
    bool operator<(const longlongvalpair& other) const
    {
	return val > other.val;  // !!
    }
};


const int NUM_P2P_COLORS = 16;
const sf::Color P2P_COLORS[] =
{
    sf::Color(200, 50, 50),
    sf::Color( 50,200, 50),
    sf::Color( 70, 70,240),
    sf::Color( 50,150,150),
    sf::Color(150, 50,150),
    sf::Color(150,150, 50),
    sf::Color(210,210,210),
    sf::Color(120, 30, 30),
    sf::Color( 30,120, 30),
    sf::Color( 50, 50,170),
    sf::Color( 30,100,100),
    sf::Color(110, 40,110),
    sf::Color(100,100, 30),
    sf::Color(170,170,170),
    sf::Color(130,130,130),
    sf::Color( 90, 90, 90)
};

struct color_list
{
    color_list() : cur_color(0) {}
    int cur_color;
    sf::Color give_next()
    {
	int col = cur_color;
	cur_color++;
	if(cur_color >= NUM_P2P_COLORS)
	    cur_color = 0;
	return P2P_COLORS[col];
    }
    sf::Color give(int idx)
    {
	int col = idx%NUM_P2P_COLORS;
	return P2P_COLORS[col];
    }
};

void p2p_investigator::draw_p2p(sf::RenderWindow& win, sf::Font& font, int begin, int end, int decimation)
{
    color_list colors;
    int lines = 0;
    char tmp[200];

    const int max_font = 16;

    int p2p_win_x_deci_len = p2p_win_len * decimation;

//    cout << endl << endl << "START @ MODE " << dm.mode << endl;

    if(dm.mode == 0 || dm.mode == 1)
	lines = stats_->pd->num_of_agents;
    else if(dm.mode == 2)
	lines = stats_->pd->num_of_agents*2;
    else if(dm.mode == 3)
    {
	if(!dm.use_view_file)
	    select_view_paths(40);
	for(int i = 0; i<stats_->pd->num_of_agents; i++)
	    for(int o = 0; o<stats_->pd->num_of_agents; o++)
		if(draw_paths[i][o])
		    lines++;
    }

    double slot_ys = (double)(dm.y_size - dm.top_margin - dm.bottom_margin)/(double)lines;
    if(slot_ys > 65)
	slot_ys = 65;

    int text_size = slot_ys;
    if(text_size > 16)
	text_size = 16;

    int text_offset = (slot_ys - text_size)/2 - 3;

    int snd = 0;
    int rcv = -1; // see do-while below, must start at -1.

    for(int i = 0; i < lines; i++)
    {
	if(dm.mode == 0)
	    sprintf(tmp, "%s snd", gui_->name_tags[i]);
	else if(dm.mode == 1)
	    sprintf(tmp, "%s rcv", gui_->name_tags[i]);
	else if(dm.mode == 2)
	{
	    if(i%2 == 0)
		sprintf(tmp, "%s snd", gui_->name_tags[i/2]);
	    else
		sprintf(tmp, "%s rcv", gui_->name_tags[i/2]);
	}
	else if(dm.mode == 3)
	{
	    do 
	    {
		rcv++;
		if(rcv >= stats_->pd->num_of_agents)
		{
		    rcv = 0;
		    snd++;
		}
	    }
	    while(draw_paths[snd][rcv] == false);

	    sprintf(tmp, "%s -> %s", gui_->name_tags[snd], gui_->name_tags[rcv]);
	}

	sf::String title_str(tmp, font, text_size);
	if(dm.mode == 3)
	    title_str.SetColor(sf::Color(0,0,0));
	else
	{
	    title_str.SetColor(P2P_COLORS[(dm.mode==2)?(i/2):(i)]);
	    title_str.SetStyle(sf::String::Bold);    
	}
	title_str.SetPosition(10, dm.top_margin + i*slot_ys+text_offset);
	win.Draw(title_str);
	win.Draw(sf::Shape::Line(0,dm.top_margin + ((i+1)*slot_ys)-dm.slot_space/2,
				 dm.x_size-1,dm.top_margin + ((i+1)*slot_ys)-dm.slot_space/2,
				 dm.slot_space,sf::Color(40,50,60)));
    }

    win.Draw(sf::Shape::Line(dm.left_margin, 0, dm.left_margin, (double)lines*slot_ys, 3, sf::Color(80,100,120)));
    win.Draw(sf::Shape::Line(dm.left_margin+dm.length, 0, dm.left_margin+dm.length, dm.y_size-1, 3, sf::Color(80,100,120)));

    int timeslots = (end - begin)/p2p_win_x_deci_len;
    if(timeslots > 5000)
	timeslots = 5000;
    
    double slot_xs = (double)dm.length/(double)timeslots;

    const int text_appear_threshold = 20;
    const int max_texts_mode01 = 4;
    const int max_texts_mode2  = 2;

    // Draw the data.
    for(int t = 0; t < timeslots; t++)
    {
//	cout << "t = " << t << endl;
//	int idx = (begin - p2p_begin_snapshot)/p2p_win_x_deci_len + t; // goes negative or over the length if we have no data from this region.
	int idx = t;

	int x = (int)(t*slot_xs) + dm.left_margin;
	int xs = (int)slot_xs + 1;

	snd = 0;
	rcv = -1;

	for(int i = 0; i < lines; i++)
	{
//	    cout << "i = " << i << endl;
	    int y = (int)(i*slot_ys) + dm.top_margin + dm.slot_space/2;
	    int y_half = y + (int)(slot_ys/2);
	    int ys = (int)slot_ys - dm.slot_space/2;

	    if(idx < 0 || idx >= p2p_length)
	    {
		win.Draw(sf::Shape::Rectangle(x, y, x+xs, y+ys, sf::Color(80,80,80)));

//		if(t == 0 || idx == p2p_length)
//		{
//		    sf::String nodata_str("no data", font, text_size);
//		    nodata_str.SetColor(sf::Color(130,20,20));
//		    nodata_str.SetPosition(x, y+text_offset);
//		    win.Draw(nodata_str);
//		}
	    }
	    else
	    {
		if(dm.mode == 0 || dm.mode == 1)
		{
		    vector<valpair> conns;
		    for(int p = 0; p < stats_->pd->num_of_agents; p++)
		    {
			if((dm.overhead)?(p2p_statistics_disc[idx][(dm.mode==0)?i:p][(dm.mode==0)?p:i].data_with_overhead):
			                 (p2p_statistics_disc[idx][(dm.mode==0)?i:p][(dm.mode==0)?p:i].data_no_overhead) > 0)
			    conns.push_back(valpair(p, (dm.overhead)?(p2p_statistics_disc[idx][(dm.mode==0)?i:p][(dm.mode==0)?p:i].data_with_overhead):
						                     (p2p_statistics_disc[idx][(dm.mode==0)?i:p][(dm.mode==0)?p:i].data_no_overhead)));
		    }
		    sort(conns.begin(), conns.end());


		    double val = 0.0, val_prev = 0.0;
		    for(int c = 0; c < conns.size(); c++)
		    {
			val_prev = val;
			double new_w = (slot_ys-conns.size())*((double)conns.at(c).val/((double)stats_->pd->window_length*p2p_win_x_deci_len));
			if(new_w < 2.0) 
			    new_w = 2.0;
			val += new_w;
			win.Draw(sf::Shape::Rectangle(x, y+ys-val_prev-c-2, x+xs, y+ys-val-c-2, colors.give(conns.at(c).endpoint)));
			// -c in y coordinate: leave a 1-pixel gap between each block.
		    }

		    if(timeslots <= text_appear_threshold)
		    {
			for(int c = 0; c < conns.size(); c++)
			{
			    if(c >= max_texts_mode01)
				break;
			    sprintf(tmp, "%s: %d", gui_->name_tags[conns.at(c).endpoint], conns.at(c).val);
			    sf::String datastr(tmp, font, 12);
			    datastr.SetColor(sf::Color(0,0,0));
			    datastr.SetPosition(x+2, y+ys-(c+1)*ys/max_texts_mode01-3);
			    win.Draw(datastr);
			    
			}
			
		    }

		}
		else if(dm.mode == 2)
		{
		    vector<valpair> conns;
		    for(int p = 0; p < stats_->pd->num_of_agents; p++)
		    {
			if((dm.overhead)?(p2p_statistics_disc[idx][(i%2==0)?(i/2):p][(i%2==0)?p:(i/2)].data_with_overhead):
			   (p2p_statistics_disc[idx][(i%2==0)?(i/2):p][(i%2==0)?p:(i/2)].data_no_overhead) > 0)
			    conns.push_back(valpair(p, (dm.overhead)?(p2p_statistics_disc[idx][(i%2==0)?(i/2):p][(i%2==0)?p:(i/2)].data_with_overhead):
						    (p2p_statistics_disc[idx][(i%2==0)?(i/2):p][(i%2==0)?p:(i/2)].data_no_overhead)));
		    }
		    sort(conns.begin(), conns.end());


		    double val = 0.0, val_prev = 0.0;
		    for(int c = 0; c < conns.size(); c++)
		    {
			val_prev = val;
			double new_w = (slot_ys-conns.size())*((double)conns.at(c).val/((double)stats_->pd->window_length*p2p_win_x_deci_len));
			if(new_w < 2.0) 
			    new_w = 2.0;
			val += new_w;
			win.Draw(sf::Shape::Rectangle(x, y+ys-val_prev-c-2, x+xs, y+ys-val-c-2, colors.give(conns.at(c).endpoint)));
			// -c in y coordinate: leave a 1-pixel gap between each block.
		    }

		    if(timeslots <= text_appear_threshold)
		    {
			for(int c = 0; c < conns.size(); c++)
			{
			    if(c >= max_texts_mode2)
				break;
			    sprintf(tmp, "%s: %d", gui_->name_tags[conns.at(c).endpoint], conns.at(c).val);
			    sf::String datastr(tmp, font, 12);
			    datastr.SetColor(sf::Color(0,0,0));
			    datastr.SetPosition(x+2, y+ys-(c+1)*ys/max_texts_mode2-3);
			    win.Draw(datastr);
			    
			}
			
		    }

		}
		else if(dm.mode == 3)
		{
		    do 
		    {
			rcv++;
			if(rcv >= stats_->pd->num_of_agents)
			{
			    rcv = 0;
			    snd++;
			}
		    }
		    while(draw_paths[snd][rcv] == false);

		    // Start drawing a bar if:
		    // * we are at the beginning of a screen or the p2p region
                    // * if the status has changed compared to previous (non-data -> data)
		    // Then draw the bar until the transfer stops or the the drawing area ends.
		    if(t == 0 || idx == 0 || (((dm.overhead)?(p2p_statistics_disc[idx-1][snd][rcv].data_with_overhead):(p2p_statistics_disc[idx-1][snd][rcv].data_no_overhead)) <= 0 
					      && ((dm.overhead)?(p2p_statistics_disc[idx][snd][rcv].data_with_overhead):(p2p_statistics_disc[idx][snd][rcv].data_no_overhead)) > 0))
		    {
//			cout << "Zawa" << endl;
			int bar_len = 1;
			while(idx+bar_len < p2p_length && ((dm.overhead)?(p2p_statistics_disc[idx+bar_len][snd][rcv].data_with_overhead):
                                                                         (p2p_statistics_disc[idx+bar_len][snd][rcv].data_no_overhead)) > 0)
			    bar_len++;

//			cout << "bar_len = " << bar_len << ", snd = " << snd << ", rcv = " << rcv << endl;

			for(int b = 0; b < bar_len; b++)
			{
			    double tmp = slot_ys*(double)((dm.overhead)?(p2p_statistics_disc[idx+b][snd][rcv].data_with_overhead):
								(p2p_statistics_disc[idx+b][snd][rcv].data_no_overhead))/((double)stats_->pd->window_length*p2p_win_x_deci_len);
			    // If the line width would be below 1, make it 1 and adjust color to greyscales.
			    int colour = (int)(-255.0*tmp + 255.0);
			    if(colour < 0) 
				colour = 0;
			    else
				tmp = 1.0;
			    if(colour > 255) colour = 255;
			    sf::Color col = sf::Color(colour,colour,colour);
			    win.Draw(sf::Shape::Line(x + (b*slot_xs), y_half, x + ((b+1)*slot_xs), y_half,tmp, col));
			}

		    }	
		}

	    }
	}
    }
    
    // Draw the grid
    int grid = 1;
    if(timeslots > 20000)
	grid = 1000;
    else if(timeslots > 2000)
	grid = 100;
    else if(timeslots > 200)
	grid = 10;
    else
	grid = 1;

    for(int t = 0; t < timeslots; t+=grid)
    {
	int x = (int)(t*slot_xs) + dm.left_margin;
	win.Draw(sf::Shape::Line(x, dm.top_margin, x, dm.top_margin+slot_ys*lines, 1, sf::Color(0,40,100,40)));
    }
    sprintf(tmp, "Grid: %d w = %d clk = %f s", grid*p2p_win_x_deci_len, grid*p2p_win_x_deci_len*stats_->pd->window_length, 
	    (double)grid*p2p_win_x_deci_len*stats_->pd->window_length/stats_->pd->clock_hz);
    sf::String gridstr(tmp, font, 14);
    gridstr.SetColor(sf::Color(0,0,0));
    gridstr.SetPosition(dm.left_margin+100, dm.y_size-14-10);
    win.Draw(gridstr);

    // Calculate and draw totals
    if(dm.mode == 0 || dm.mode == 1)
    {
	for(int i = 0; i < lines; i++)
	{
	    long long int* endpoint_totals = new long long int[stats_->pd->num_of_agents];
	    for(int z = 0; z < stats_->pd->num_of_agents; z++)
		endpoint_totals[z] = 0;

	    long long int total = 0;

	    int x = (int)(timeslots*slot_xs) + dm.left_margin;
	    int y = (int)(i*slot_ys) + dm.top_margin + dm.slot_space/2;
	    int ys = (int)slot_ys - dm.slot_space/2;

	    for(int t = 0; t < timeslots; t++)
	    {
//		int idx = (begin - p2p_begin_snapshot)/p2p_win_x_deci_len + t; // goes negative or over the length if we have no data from this region.
		int idx = t;
		if(idx >= 0 && idx < p2p_length)
		{
		    for(int ep = 0; ep < stats_->pd->num_of_agents; ep++)
		    {
			if(((dm.overhead)?(p2p_statistics_disc[idx][(dm.mode==0)?i:ep][(dm.mode==0)?ep:i].data_with_overhead):
			    (p2p_statistics_disc[idx][(dm.mode==0)?i:ep][(dm.mode==0)?ep:i].data_no_overhead)) > 0)
			    endpoint_totals[ep] += ((dm.overhead)?(p2p_statistics_disc[idx][(dm.mode==0)?i:ep][(dm.mode==0)?ep:i].data_with_overhead):
						    (p2p_statistics_disc[idx][(dm.mode==0)?i:ep][(dm.mode==0)?ep:i].data_no_overhead));
		    }
		}
	    }

	    vector<longlongvalpair> list;
	    for(int ep = 0; ep < stats_->pd->num_of_agents; ep++)
	    {
		list.push_back(longlongvalpair(ep, endpoint_totals[ep]));
		total += endpoint_totals[ep];
	    }
	    sort(list.begin(), list.end());
	    
	    for(int c = -1; c < (signed int)list.size(); c++)
	    {
		if(c >= max_texts_mode01-1 || (c > -1 && list.at(c).val < 1))
		    break;
		sprintf(tmp, "%s: %d", (c==-1)?"Total":gui_->name_tags[list.at(c).endpoint], (c==-1)?total:list.at(c).val);
		sf::String datastr(tmp, font, min_of(ys/max_texts_mode01, max_font));
		datastr.SetColor(sf::Color(0,0,0));
		if(c == -1) 
		    datastr.SetStyle(sf::String::Bold);
		datastr.SetPosition(x+2, y+ys-(c+2)*ys/max_texts_mode01-3);
		win.Draw(datastr);
	    }

	}
    }
    else if(dm.mode == 2)
    {
	for(int i = 0; i < lines; i++)
	{
	    long long int* endpoint_totals = new long long int[stats_->pd->num_of_agents];
	    for(int z = 0; z < stats_->pd->num_of_agents; z++)
		endpoint_totals[z] = 0;

	    long long int total = 0;

	    int x = (int)(timeslots*slot_xs) + dm.left_margin;
	    int y = (int)(i*slot_ys) + dm.top_margin + dm.slot_space/2;
	    int ys = (int)slot_ys - dm.slot_space/2;

	    for(int t = 0; t < timeslots; t++)
	    {
//		int idx = (begin - p2p_begin_snapshot)/p2p_win_x_deci_len + t; // goes negative or over the length if we have no data from this region.
		int idx = t;
		if(idx >= 0 && idx < p2p_length)
		{
		    for(int ep = 0; ep < stats_->pd->num_of_agents; ep++)
		    {
			if(((dm.overhead)?(p2p_statistics_disc[idx][(i%2==0)?(i/2):ep][(i%2==0)?ep:(i/2)].data_with_overhead):
			    (p2p_statistics_disc[idx][(i%2==0)?(i/2):ep][(i%2==0)?ep:(i/2)].data_no_overhead)) > 0)
			    endpoint_totals[ep] += ((dm.overhead)?(p2p_statistics_disc[idx][(i%2==0)?(i/2):ep][(i%2==0)?ep:(i/2)].data_with_overhead):
						    (p2p_statistics_disc[idx][(i%2==0)?(i/2):ep][(i%2==0)?ep:(i/2)].data_no_overhead));
		    }
		}
	    }

	    vector<longlongvalpair> list;
	    for(int ep = 0; ep < stats_->pd->num_of_agents; ep++)
	    {
		list.push_back(longlongvalpair(ep, endpoint_totals[ep]));
		total += endpoint_totals[ep];
	    }
	    sort(list.begin(), list.end());
	    
	    for(int c = -1; c < (signed int)list.size(); c++)
	    {
		if(c >= max_texts_mode2-1 || (c > -1 && list.at(c).val < 1))
		    break;
		sprintf(tmp, "%s: %d", (c==-1)?"Total":gui_->name_tags[list.at(c).endpoint], (c==-1)?total:list.at(c).val);
		sf::String datastr(tmp, font, min_of(ys/max_texts_mode2, max_font));
		datastr.SetColor(sf::Color(0,0,0));
		if(c == -1) 
		    datastr.SetStyle(sf::String::Bold);
		datastr.SetPosition(x+2, y+ys-(c+2)*ys/max_texts_mode2-3);
		win.Draw(datastr);
	    }

	}
    }
    else if(dm.mode == 3)
    {
	snd = 0;
	rcv = -1;
	for(int i = 0; i < lines; i++)
	{
	    long long int total = 0;

	    int x = (int)(timeslots*slot_xs) + dm.left_margin;
	    int y = (int)(i*slot_ys) + dm.top_margin + dm.slot_space/2;
	    int ys = (int)slot_ys - dm.slot_space/2;

	    do 
	    {
		rcv++;
		if(rcv >= stats_->pd->num_of_agents)
		{
		    rcv = 0;
		    snd++;
		}
	    }
	    while(draw_paths[snd][rcv] == false);

	    for(int t = 0; t < timeslots; t++)
	    {
		int idx = t;
		if(idx >= 0 && idx < p2p_length)
		{
		    if(((dm.overhead)?(p2p_statistics_disc[idx][snd][rcv].data_with_overhead):(p2p_statistics_disc[idx][snd][rcv].data_no_overhead)) > 0)
			total += ((dm.overhead)?(p2p_statistics_disc[idx][snd][rcv].data_with_overhead):(p2p_statistics_disc[idx][snd][rcv].data_no_overhead));
		}
	    }

	    sprintf(tmp, "Tot: %d words", total);
	    sf::String datastr(tmp, font, min_of(ys-3, max_font));
	    datastr.SetColor(sf::Color(0,0,0));
	    datastr.SetStyle(sf::String::Bold);
	    datastr.SetPosition(x+2, y);
	    win.Draw(datastr);
	}

    }

}

void p2p_investigator::create_csv_from_region(char* filename) // use p2p_statistics_disc and p2p_length.
{
    totals = new p2p_tot_stats*[stats_->pd->num_of_agents];

    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	totals[i] = new p2p_tot_stats[stats_->pd->num_of_agents];

	for(int o = 0; o < stats_->pd->num_of_agents; o++)
	{
	    totals[i][o].data_with_overhead = 0;
	    totals[i][o].data_no_overhead = 0;
	}
    }

    for(int t = 0; t < p2p_length; t++)
    {
	for(int src = 0; src < stats_->pd->num_of_agents; src++)
	{
	    for(int dst = 0; dst < stats_->pd->num_of_agents; dst++)
	    {
		if(p2p_statistics_disc[t][src][dst].data_with_overhead > 0)
		    totals[src][dst].data_with_overhead += p2p_statistics_disc[t][src][dst].data_with_overhead;
		if(p2p_statistics_disc[t][src][dst].data_no_overhead > 0)
		    totals[src][dst].data_no_overhead += p2p_statistics_disc[t][src][dst].data_no_overhead;
	    }
	}
    }

//    cout << "0 = do not include overhead, 1 = include overhead" << endl;
    bool incl_overhead = dm.overhead;
//    cin >> incl_overhead;

    const char delimiter = ';';

    ofstream csv_output;
    csv_output.open(filename, ios::out);

    // Print general info

    time_t rawtime;
    struct tm* timeinfo;

    time(&rawtime);
    timeinfo = localtime(&rawtime);

    csv_output << "P2P Investigator results" << delimiter << "Created:" << delimiter << asctime(timeinfo) << delimiter
	       << "Trace:" << delimiter << stats_->pd->bin_name << delimiter
	       << "Start win:" << delimiter << gui_->nav_bar.location << delimiter
	       << "Len (w):" << delimiter << gui_->nav_bar.zoom_region << delimiter
	       << (incl_overhead?"INCL OVERHEAD":"NO OVERHEAD") << endl;


    // PRINT TOP HEADER
    csv_output << "FROM | TO" << delimiter;
    for(int ag = 0; ag < stats_->pd->num_of_agents; ag++)
    {
	csv_output << gui_->name_tags[ag] << delimiter;
    }

//  csv_output << "SUM"; // << delimiter << "Expected sum";

    csv_output << endl;

    // PRINT LEFT HEADER CELLS AND VALUES

    long long int total_total = 0;

    for(int from = 0; from < stats_->pd->num_of_agents; from++)
    {
	csv_output << gui_->name_tags[from] << delimiter;
	
	for(int to = 0; to < stats_->pd->num_of_agents; to++)
	{
	    long long int val = (incl_overhead?(totals[from][to].data_with_overhead):(totals[from][to].data_no_overhead));
	    total_total += val;
	    csv_output << val << delimiter;
	}

//	csv_output << delimiter;
	// Expected sum
//	csv_output << (incl_overhead?(expected_sums_from_with_overhead[from]):(expected_sums_from_no_overhead[from]));
	csv_output << endl;
    }

    // Print "TO" expected sums

//  csv_output << "SUM" << delimiter;
//  csv_output << endl;
//  csv_output << "Expected sum" << delimiter;
//  for(int to = 0; to < stats_->pd->num_of_agents; to++)
//  {
//	csv_output << (incl_overhead?(expected_sums_to_with_overhead[to]):(expected_sums_to_no_overhead[to])) << delimiter;
//  }
    csv_output << endl;
//    csv_output << "Giveups:" << delimiter << giveups << endl;
    csv_output << "All total" << delimiter << total_total << endl;

    for(int i = 0; i < stats_->pd->num_of_agents; i++)
    {
	delete totals[i];
    }
    delete totals;
}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
