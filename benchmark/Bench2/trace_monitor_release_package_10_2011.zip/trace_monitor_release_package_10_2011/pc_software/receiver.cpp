// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2010

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

// receiver.cpp
// This module receives UDP packets by using Boost ASIO library, strips packet
// numbers, detects lost packets, writes received data to a file and/or calls
// real-time visualization function via pointer to "statistics" object.


#include <cstdlib>
#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <SFML/Network.hpp>

#include "receiver.hpp"
#include "statistics.hpp"
#include "gui.hpp"

using namespace std;

receiver::receiver(short unsigned int port, long int packets,
		   char* binname, short int expected_length, short int run_mode, bool write_to_disk,
		   bool show_realtime, const processing_data* pd, 
		   statistics* stats, gui* interface)
    : port_(port),
      expected_length_(expected_length), endOnPacket(packets), write_to_disk_(write_to_disk),
      show_realtime_(show_realtime), pd_(pd), stats_(stats), interface_(interface)
{

//    boost::asio::socket_base::receive_buffer_size option(8192000);
//    upd_socket.set_option(option);


/*    int dbuf;
    int dbuflen = 4;

    dbuf = 8192000;
    if (setsockopt(upd_socket.native(), SOL_SOCKET, SO_RCVBUF, (CHAR*)&dbuf, 4) != 0)
    {
	cout << "Fail :(." << endl;
    }


    if (getsockopt(upd_socket.native(), SOL_SOCKET, SO_RCVBUF, (CHAR*)&dbuf, &dbuflen) != 0)
	cout << "Fail :(." << endl;
    else
	cout << "returned " << dbuf << endl;

    if (getsockopt(upd_socket.native(), SOL_SOCKET, SO_MAX_MSG_SIZE, (CHAR*)&dbuf, &dbuflen) != 0)
	cout << "Fail :(." << endl;
    else
	cout << " max msg size returned " << dbuf << endl;
*/

    stop = false;
    finished = false;
    first = true;
    captured = 0;
    ignored = 0;
    errors = 0;
    missed = 1; // this is because how packet numbering starts.
    cur_packet_number = 0;
    if(write_to_disk)
    {
	outFile.open(binname, std::ios::out | std::ios::binary | std::ios::trunc);
	if(!outFile.good())
	{
	    cerr << "Error opening capture file!" << endl;
	    outFile.close();
	    exit(1);
	}
    }

    if(!socket.Bind(1200))
    {
	cerr << "Could not open UDP port!" << endl;
	return;
    }

    if(!socket.IsValid())
    {
	cerr << "Socket is not valid!" << endl;
	return;
    }
    
    std::cout << "Ready to receive data." << std::endl;
    

    Launch(); // Launch the Run() as a new thread.
       
}

receiver::~receiver()
{
    if(write_to_disk_)
	outFile.close();

    stop = true;
    cout << "CLOSING SOCKET." << endl;
    socket.Close();

    cout << "Captured " << captured << " packets. (" << missed << " missed, " << errors << " errors)" << endl;
    if(errors > 0)
    {
	cerr << "There were " << errors 
	     << " errors during data capture. Some data may be missing or corrupted." << endl;
    }
    
    if(ignored > 0 && captured > 0)
    {
	cerr << ignored << " packets were ignored due to wrong packet size. Make sure" << endl;
	cerr << "that no other devices and programs are using the same network and port." << endl;
    }
    
    if(ignored > 0 && captured == 0)
    {
	cerr << "All packets were ignored due to wrong size. Make sure that your setting are correct." << endl;
    }

}

void receiver::Run()
{
    while(captured < endOnPacket)
    {
	if(!socket.IsValid())
	{
	    cerr << "Socket is not valid, trying to rebind" << endl;
	    if(!socket.Bind(0))
	    {
		cerr << "Could not open UDP port!" << endl;
		return;
	    }
	}

	if(stats_->rt_stop || stop)
	    break;

	// BLOCKING RECEIVE
	size_t bytes_recvd;
	sf::IPAddress sender_addr;
	short unsigned int port;
	
	sf::Socket::Status status = socket.Receive((char*)packet_data, sizeof(packet_data), bytes_recvd, sender_addr, port);
	if(status != sf::Socket::Done)
	{
	    cerr << "Error in receiving: " << status << endl;
	    continue;
	}

	if(port != port_)
	{
	    cerr << "Warning: Received a packet from port " << port << ". Ignored it." << endl;
	    ignored++;
	}

	if(stats_->rt_stop || stop)
	    break;

	if(bytes_recvd-PACKET_NUMBER_BYTES == expected_length_)
	{
	    captured++;
	    unsigned long int new_packet_number;
	    if(PACKET_NUMBER_BYTES == 2)
	    {
		new_packet_number = (packet_data[0] << 8) + packet_data[1];
	    }
	    else if(PACKET_NUMBER_BYTES == 4)
	    { // 2301
		//	    cout << (unsigned int)packet_data[1] << " " << (unsigned int)packet_data[0] << " "
		//	 << (unsigned int)packet_data[3] << " " << (unsigned int)packet_data[2] << endl;
		
		new_packet_number = ((unsigned long int)packet_data[1] << 24) + 
		    ((unsigned long int)packet_data[0] << 16) +
		    ((unsigned long int)packet_data[3] << 8) +
		    (unsigned long int)packet_data[2];
	    }
	    else
	    {
		cerr << "SHOULDN'T BE HERE!" << endl;
	    }
	    
//		int old_mis = missed;
	    missed += new_packet_number-cur_packet_number-1;
//		if(missed != old_mis)
//		{
//		    cout << new_packet_number << " " << missed-old_mis << endl;
//		}
	    cur_packet_number = new_packet_number;
	    
	    if(first)
	    {
		missed = 0;
		first = false;
	    }
	    
	    if(write_to_disk_)
	    {
		outFile.write((char*)packet_data+PACKET_NUMBER_BYTES, bytes_recvd-PACKET_NUMBER_BYTES);
	    }
	    
	    if(show_realtime_)
	    {
		// Accumulate until all has accumulated. Then, the GUI have to 
		// clear the accum_done flag.
		if(stats_->accum_done == false)
		    stats_->parse_and_analyze(packet_data+PACKET_NUMBER_BYTES);

		if(missed < 0)  // If the FPGA resets, the counting starts over, causing
		{               // missed to go negative.
		    captured = 0;
		    errors = 0;
		    ignored = 0;
		    missed = 0;
		}
		stats_->rt_captured = captured;
		stats_->rt_errors = errors;
		stats_->rt_missed = missed;
		stats_->rt_ignored = ignored;

		/*	if(stats_->accum_done)
		{
		    stats_->accum_done = false;
		    interface_->print_stats(captured, missed, errors);
		    }*/
	    }
	    
	}
	else
	{
	    if(ignored == 0)
	    {
		cerr << "WARNING: Ignored a packet due to wrong packet length. Make sure that" << endl
		     << "packet length is set correctly and there are no interfering devices in" << endl
		     << "the same network." << endl;
	    }
	    ignored++;
	}
	
    }

    finished = true;

}


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
