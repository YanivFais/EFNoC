// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

#ifndef GUI_HPP
#define GUI_HPP

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <vector>
#include <SFML/Graphics.hpp>

#define PI 3.14159265358979

#include "ui_on_sfml.hpp"
#include "statistics.hpp"
#include "p2p_investigator.hpp"
#include "mesh.hpp"
#include "hibi.hpp"

const int MODE_BEST  = 0;
const int MODE_AVG   = 1;
const int MODE_WORST = 2;
const int MODE_TOTAL = 3;

const int CHART_BOT_MARGIN = 48;
const int CHART_LEFT_MARGIN = 8;
const int CHART_TOP_MARGIN = 24;
const int CHART_RIGHT_MARGIN = 8;

const int MAX_NUM_RANGES = 100;

const int MAX_NAMETAG_LEN = 16;

const int MAX_LINK_WINS = 32;

void print_autoscale(int input);

void print_int_with_postfix(int val, char* str, int precision = 1);
void print_int_with_postfix(unsigned long long int val, char* str, int precision = 1);
void print_int_with_postfix(signed long long int val, char* str, int precision = 1);

void draw_chart(sf::RenderWindow& win, const sf::Font& font,
		int n_lines, int n_points, 
		int* x_values, int* y_values, sf::Color* colors, 
		int x_size, int y_size, int x_loc, int y_loc,
		bool auto_y, int min_y, int max_y, 
		int x_pnt_incr, int y_pnt_incr, 
		const char* title, const char* xtitle, const char* ytitle, 
		int n_ver_grid, int n_hor_grid, // 0 = off
                int clear_mode, sf::Color clear_color, sf::Color back_color, int line_w, bool flush,
		int decimate, int title_font_size);


void arrow(sf::RenderWindow& win, int x1, int y1, int x2, int y2, int ar_size = 8, int width = 4, sf::Color color = sf::Color(0,0,0));

const sf::Color BAR_COLOR =  sf::Color(0,0,0);
const sf::Color SEL_COLOR =  sf::Color(128,128,128);
const sf::Color DRAG_COLOR = sf::Color(64,64,64);
const sf::Color DRAG_ASSIST_COLOR = sf::Color(192, 192, 192);

struct gui
{
    gui(statistics* stats);

    sf::RenderWindow main_win;
    sf::RenderWindow link_wins[MAX_LINK_WINS];
    sf::RenderWindow p2p_win;

    ui_on_sfml main_ui;
    ui_on_sfml linkwin_uis[MAX_LINK_WINS];
    ui_on_sfml p2p_ui;

    sf::View main_view;
    sf::View link_views[MAX_LINK_WINS];
    sf::View p2p_view;

    sf::Font def_font;


    statistics* stats_;
    mesh meshnoc;
    hibi hibinoc;
  	
    int averaging_mode;

    p2p_investigator p2p_inv;

    void show_hide_nav_buttons(bool show);
    bool initialize_graphics(bool resize = false, bool recreate = false, bool realtime = false);

    bool redraw;

  struct vis_ui_buttons
  {
      int play;
      int playslow;
      int stop;
      int nav_bar_left;
      int nav_bar_right;
      int zoom_all;
      int zoom_out;
      int zoom_in;
      int zoom_out2;
      int zoom_in2;
      int best;
      int avg;
      int worst;
      int total;
      int cmd;
      int quit;
      int decimation;
      int done;
  } vis_buttons;

    int vis_window_ysize;
    int vis_window_xsize;
   
    int p2p_window_xsize;
    int p2p_window_ysize;

    int vis_window_xpos;
    int vis_window_ypos;
    int link_win_xposs[MAX_LINK_WINS];
    int link_win_yposs[MAX_LINK_WINS];

    struct p2p_investigator_buttons
    {
	int mode;
	int overhead;
	int save_csv;
    } p2p_buttons;

  struct nav_bar_settings
  {
      // Constant settings:
      int left;
      int right;
      int bottom;
      int line_width;
      int ends_line_width;
      int sel_line_width;
      int min_bar_len;


      // Variables changing on the fly:
      int num_of_snapshots;
      int location;
      int zoom_region;

      bool dragging;
      bool clicking;
      int drag_mouse_offset;

      bool graph_clicking;
      int graph_loc_1;

  } nav_bar;

  struct range
  {
      int start;
      int end;
      bool complete;
  } ranges[MAX_NUM_RANGES];

    int num_ranges;

    int add_range(int start, int end = -1);
    int complete_range(int id, int end);

    bool incomplete_range;

    bool percents;

    void create_default_nametags();
    void read_nametags(ifstream& nametagstream);
    char name_tags[MAX_NUM_PES][MAX_NAMETAG_LEN];

    bool use_decimation;

    int explore_file(bool realtime, ifstream* inp_stream = 0, unsigned long int size = 0);

    int nav_bar_yloc;
    int nav_bar_len;
    unsigned long int averaging_length;

    void draw_nav_bar();
    void process_nav_bar_drag();

    int chart_xsize;
    int chart_ysize;

    int small_font_size;
    int medium_font_size;
    int big_font_size;
    int chart_title_font_size;

    void print_stats(int packets, int missed, int errors); // arguments are just printed.

    void process_chart_click(int win_id);
    int process_pe_click(); // -1 for no click, otherwise PE number.
    void select_ips_graphically(vector<int>& selected);

    void create_report(char* filename, int location, int zoom_region);

    void wait_click();
    void wait_mouse_release();
       

    int PE_click_coords[MAX_NUM_PES][4]; // left x, bottom y, right x, top y

};

int max_of(int* table, int points, int pnt_incr);
int min_of(int* table, int points, int pnt_incr);
int min_of(int val1, int val2);

#endif

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
