// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2010

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.


// receiver.hpp
// This module receives UDP packets by using Boost ASIO library, strips packet
// numbers, detects lost packets, writes received data to a file and/or calls
// real-time visualization function via pointer to "statistics" object.

#ifndef RECEIVER_HPP
#define RECEIVER_HPP

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <SFML/Network.hpp>
#include <SFML/System.hpp>

#include "parser.hpp"
#include "statistics.hpp"
#include "gui.hpp"

#define PACKET_NUMBER_BYTES 4  // 2 or 4

using namespace std;

class receiver : private sf::Thread
{
public:
    receiver(short unsigned int port, long int packets,
	     char* binname, short int expected_length, short int run_mode, bool write_to_disk,
	     bool show_realtime, const processing_data* pd, 
	     statistics* stats, gui* interface);
    ~receiver();

    bool finished;

    
private:

    virtual void Run();

    sf::SocketUDP socket;

    enum { max_length = 2000 };
    short unsigned int port_;
    unsigned char packet_data[max_length];
    long int captured;
    long int errors;
    long int ignored;
    long int missed;
    long int endOnPacket;
    int expected_length_;
    std::ofstream outFile;
    bool write_to_disk_;
    bool show_realtime_;
    const processing_data* pd_;
    statistics* stats_;
    gui* interface_;
    unsigned long int cur_packet_number;
    bool first;
    bool stop;

};

#endif

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
