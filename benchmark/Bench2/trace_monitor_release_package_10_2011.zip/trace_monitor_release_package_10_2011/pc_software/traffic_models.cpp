// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.


#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <vector>
#include <ctime>

#include "p2p_investigator.hpp"
#include "traffic_models.hpp"
#include "gui.hpp"


// stop_condition_cycles = how many windows with no communication are needed to stop the current transaction. Use 1 for normal operation and use carefully.
void find_conn_params(p2p_investigator& p2p_inv, int src, int dst, traffic_model_conn_params& result, int begin, int end, int stop_condition_cycles)
{
    result.src = src;
    result.dst = dst;

    bool tx_going = false;
    int start_time = begin;
    int prev_start_time = begin;
    int tx_amount = 0;

    long long int tmp_interval_acc = 0;

    vector<wait_and_amount> txs;

    result.total = 0;

    int stop_cycles = 0;

    // Find times between transfers and word amounts per transfer.
    for(int time = begin; time < end; time++)
    {       
	if(p2p_inv.p2p_statistics_disc[time-begin][src][dst].data_with_overhead > 0)
	{
	    if(tx_going)
	    {
		// On-going tranfer; count data to the same tx.
		tx_amount += p2p_inv.p2p_statistics_disc[time-begin][src][dst].data_with_overhead;
		if(src==12 && (dst==13)) cout << "Time = " << time << ": TX already going on; now " << tx_amount << endl;
	    }
	    else
	    {
		// A transfer starts.
		tx_going = true;
		start_time = time;
		tx_amount = p2p_inv.p2p_statistics_disc[time-begin][src][dst].data_with_overhead;
		if(src==12 && (dst==13)) cout << "Time = " << time << ": TX starts: " << tx_amount << endl;
	    }
	}

	if(p2p_inv.p2p_statistics_disc[time-begin][src][dst].data_with_overhead <= 0 || time == end-1)
	{
	    if(tx_going)
	    {
		stop_cycles++;

		if(stop_cycles >= stop_condition_cycles || time == end-1)
		{
		    stop_cycles = 0;
		    // TX stops.
		    wait_and_amount new_tx;
		    new_tx.wait = (start_time - prev_start_time) * p2p_inv.stats_->pd->window_length;
		    new_tx.amount = tx_amount;
		    txs.push_back(new_tx);
		    prev_start_time = start_time;
		    tx_going = false; // zero data -> stop counting on-going transfer.
		    if(src==12 && (dst==13)) cout << "Time = " << time << ": TX stopped: Interval " << new_tx.wait << ", amount " << new_tx.amount << endl;
		    result.total += tx_amount;
		    tmp_interval_acc += new_tx.wait;
		}
	    }
	}
    }

    int last_transfer_start_time = start_time; // The "transferless" time in the end of the processing region is added to the 
              // interval between zero point and first transfer. See the example of the problem if we don't do that:
    // S                     E
    // |xx     xx     xx     |
    //  t=0    t=10   t=20   t=30
    // 1st: interval = 0
    // 2nd: interval = 10
    // 3rd: interval = 10
    // result: avg interval = (0+10+10)/3 = 6.7 = WRONG.
    // But let's add the end interval (30-20) = 10 to the first interval, then it's right.

    if(txs.size() > 0)
    {
	if(src==12 && (dst==13)) cout << "Adding " << (end-last_transfer_start_time)*p2p_inv.stats_->pd->window_length << " to start interval." << endl;
	txs.at(0).wait += (end-last_transfer_start_time)*p2p_inv.stats_->pd->window_length;
    }

    // Create traffic model by calculating averages of interval and amount.

    if(txs.size() > 0)
    {
	result.avg_size = result.total/txs.size();
	result.avg_occurence = tmp_interval_acc/txs.size();
    }
    else
    {
	result.avg_size = 0;
	result.avg_occurence = 0;
	result.total = 0;
    }


    const long long int MAX_AVG_OCCURENCE = 0x7fffffff;

    // If the interval is too long, shorten it and decrease data amount accordingly.
    if(result.avg_occurence > MAX_AVG_OCCURENCE)
    {
	cout << "AVG occurence too long" << endl;
	result.avg_size = (int)((double)result.avg_size * (double)MAX_AVG_OCCURENCE/(double)result.avg_occurence);
	result.avg_occurence = MAX_AVG_OCCURENCE;
    }

    const int MAX_TX_SIZE = 0xffff;

    // If one tx operation is too big, divide it as two smaller operations.
    while(result.avg_size > MAX_TX_SIZE)
    {
	cout << "AVG size too big" << endl;
	result.avg_size /= 2;
	result.avg_occurence /= 2;
    }

    cout << "Result: avg size = " << result.avg_size << ", avg occurence = " << result.avg_occurence << " (" << txs.size() << " occurences, " << result.total << " total)" << endl;

}

void write_hwtg_confline(const traffic_model_conn_params& model, ofstream& outfile)
{
    const int WAITING_HEX_LEN     = 8;
    const int TG_ADDR_HEX_LEN     = 2;
    const int DATA_AMOUNT_HEX_LEN = 4;

    outfile << "a " << hex << setw(TG_ADDR_HEX_LEN) << setfill('0') << model.src << " "
	    << "00 " // Event
	    << hex << setw(WAITING_HEX_LEN) << setfill('0') << model.avg_occurence << " "
	    << "0 " // Only once?
	    << "0 " // Randomize dest?
	    << hex << setw(TG_ADDR_HEX_LEN) << setfill('0') << model.dst << " "
	    << "0 " // Packet data type.
	    << "0 " // Randomize size?
	    << hex << setw(DATA_AMOUNT_HEX_LEN) << setfill('0') << model.avg_size << " "
	    << "0 0 0 "
	    << "0000" << endl; // Processing (busy) time.
}

void write_sctg_task_for_data_input(ofstream& outfile, int ipnum)
{
    outfile << "<task name=\"" << "receiver_task" << ipnum << "\" id=\"" << ipnum+60000 << "\" class=\"general\">" << endl;
    outfile << "<in_port id=\"" << ipnum+20000 << "\"/>" << endl; // data input
    outfile << "<trigger>" << endl;
    outfile << "<in_port id=\"" << ipnum+20000 << "\"/>" << endl; // trig to the event input
    outfile << "<exec_count>" << endl;
    outfile << "<next_state value=\"READY\"/>" << endl;
    outfile << "</exec_count>" << endl;
    outfile << "</trigger>" << endl;
    outfile << "</task>" << endl;
}

void write_sctg_task(const traffic_model_conn_params& model, ofstream& outfile, int id)
{
    outfile << "<task name=\"" << "autogenerated" << id << "\" id=\"" << id << "\" class=\"general\">" << endl;
    outfile << "<in_port id=\"" << id+10000 << "\"/>" << endl; // event input
    outfile << "<out_port id=\"" << id+30000 << "\"/>" << endl;
    outfile << "<trigger>" << endl;
    outfile << "<in_port id=\"" << id+10000 << "\"/>" << endl; // trig to the event input
    outfile << "<exec_count>" << endl;
    outfile << "<send out_id=\"" << id+30000 << "\" prob=\"1\">" << endl;
    outfile << "<byte_amount>" << endl;
    outfile << "<polynomial>" << endl;
    outfile << "<param value=\"" << model.avg_size << "\" exp=\"0\"/>" << endl;
    outfile << "</polynomial>" << endl;
    outfile << "</byte_amount>" << endl;
    outfile << "</send>" << endl;
    outfile << "<next_state value=\"READY\"/>" << endl;
    outfile << "</exec_count>" << endl;
    outfile << "</trigger>" << endl;
    outfile << "</task>" << endl;
}

void write_sctg_event(const traffic_model_conn_params& model, ofstream& outfile, int id, int clk_hz)
{
    outfile << "<event out_port_id=\"" << id+40000 << "\" amount=\"1\" name=\"autogenerated" << id << "\" id=\"" << id+50000 
	    << "\" period=\"" << (double)model.avg_occurence/(double)clk_hz << "\" prob=\"1.0\"/>" << endl;
}


void write_sctg_port_connection(const traffic_model_conn_params& model, ofstream& outfile, int id)
{
    outfile << "<port_connection src=\"" << id+30000 << "\" dst=\"" << model.dst+20000 << "\"/>" << endl; // From task outputs to task data inputs.
    outfile << "<port_connection src=\"" << id+40000 << "\" dst=\"" << id+10000 << "\"/>" << endl; // From event outputs to task event inputs.
}



traffic_model_conn_params& traffic_model_conn_params::operator=(const traffic_model_conn_params& other)
{
    src = other.src;
    dst = other.dst;
    avg_occurence = other.avg_occurence;
    avg_size = other.avg_size;
    total = other.total;
}

bool traffic_model_conn_params::operator<(const traffic_model_conn_params& other) const
{
    return total > other.total; // Note; direction swapped.
}

void create_model(p2p_investigator& p2p_inv, int begin, int end, int* max_conf_lines, int format)
{
    ofstream tg_conf("tg_input.xml");

    time_t rawtime;
    struct tm* timeinfo;

    time(&rawtime);
    timeinfo = localtime(&rawtime);

    vector<vector<traffic_model_conn_params> > all_params;

    for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
    {
	vector<traffic_model_conn_params> param_vect;
	for(int dst = 0; dst < p2p_inv.stats_->pd->num_of_agents; dst++)
	{
	    cout << "Finding connection parameters for src = " << src << " dst = " << dst << endl;
	    traffic_model_conn_params params;
	    // First one round to find average occurence time of continuous transactions.
	    find_conn_params(p2p_inv, src, dst, params, begin, end, 1);
	    // Then, on the next round, we will combine transactions that happen during 1/10 of
	    // the "average occurence" we got on the previous round.
	    int stop_condition_cycles = (params.avg_occurence/p2p_inv.stats_->pd->window_length)/10;
	    cout << "Entering second round; stop_condition_cycles = " << stop_condition_cycles << endl;
	    if(params.total > 0 && stop_condition_cycles > 1) // no need to do second round if stop_condition_cycles == 1.
		find_conn_params(p2p_inv, src, dst, params, begin, end, stop_condition_cycles);

	    if(params.total > 0)
		param_vect.push_back(params);
	}
	sort(param_vect.begin(), param_vect.end());

	all_params.push_back(param_vect);

    }

    // Reduce number of events.
    for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
    {
	int num_lines = max_conf_lines[src];
	if(all_params.at(src).size() < max_conf_lines[src])
	    num_lines = all_params.at(src).size();
	cout << "Found " << all_params.at(src).size() << " conflines. Will write " << num_lines << "." << endl;

	all_params.at(src).erase(all_params.at(src).begin()+num_lines, all_params.at(src).end());
    }


    // Write model to a file.
    if(format == 0)
    {
	// HWTG
	tg_conf << "# TG model autogenerated by Trace Monitor from P2P Investigator" << endl;
	tg_conf << "# Original trace binary file: " << p2p_inv.stats_->pd->bin_name << endl;
	tg_conf << "# Creation time: " << asctime(timeinfo) << endl;
	tg_conf << "# List of TGs ";
        for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
	    tg_conf << src << "=" << p2p_inv.gui_->name_tags[src] << ", ";
	tg_conf << endl;
	tg_conf << "# Max number of events per TG: (";
        for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
	    tg_conf << ((all_params.at(src).size() < max_conf_lines[src])?all_params.at(src).size():max_conf_lines[src]) << ", ";
	tg_conf << ");" << endl;

	for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
	{
	    for(int line = 0; line < all_params.at(src).size(); line++)
	    {
		write_hwtg_confline(all_params.at(src).at(line), tg_conf);
	    }
	}

	unsigned long long int running_time = (end-begin)*p2p_inv.stats_->pd->window_length;
	const int MAX_RUNNING_TIME = 0xfffffffe;
	if(running_time > MAX_RUNNING_TIME)
	    running_time = MAX_RUNNING_TIME;
	
	tg_conf << "s " << hex << setw(8) << setfill('0') << running_time << endl;


    }
    else if(format == 1)
    {
	// Lasse-SCTG
	tg_conf << "<?xml version='1.0'?>" << endl;
	tg_conf << "<!DOCTYPE system>" << endl;
	tg_conf << "<system xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" << endl;
	tg_conf << "<xsm_version value=\"4\"/>" << endl;
	tg_conf << "<application>" << endl;
	tg_conf << "<task_graph>" << endl;
	// Events are saved as tasks.
	int id = 0;
	// id is task id. One task is for one event, for sending data to one destination.
	// id+10000 is in_port id for timer event
	// IP NUM+20000 is in_port id for receiving data (no triggering currently.)
	// id+30000 is out_port id for sending data related to the task/event.
	// id+40000 is the out_port of the timer event.
	// id+50000 is event id.
	// IP NUM+60000 is task id for receiving data (no triggering)
	for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
	{
	    // SCTG does not allow data input tasks that have no connection to them.
	    // Add data input tasks only for generators that receive data.
	    for(int i = 0; i < p2p_inv.stats_->pd->num_of_agents; i++)
	    {
		for(int line = 0; line < all_params.at(i).size(); line++)
		{
		    if(all_params.at(i).at(line).dst == src)
		    {
			write_sctg_task_for_data_input(tg_conf, src);
			goto doublebreak;
		    }
		}
	    }
	  doublebreak:

	    for(int line = 0; line < all_params.at(src).size(); line++)
	    {
		write_sctg_task(all_params.at(src).at(line), tg_conf, id);
		id++;
	    }
	}

	tg_conf << "<event_list>" << endl;

	// Then, write events.
	id = 0;
	for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
	{
	    for(int line = 0; line < all_params.at(src).size(); line++)
	    {
		write_sctg_event(all_params.at(src).at(line), tg_conf, id, p2p_inv.stats_->pd->clock_hz);
		id++;
	    }
	}

	tg_conf << "</event_list>" << endl;

	// Then, write port connections.
	id = 0;
	for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
	{
	    for(int line = 0; line < all_params.at(src).size(); line++)
	    {
		write_sctg_port_connection(all_params.at(src).at(line), tg_conf, id);
		id++;
	    }
	}

	tg_conf << "</task_graph>" << endl;
	tg_conf << "</application>" << endl;

	// Then, map tasks.

	tg_conf << "<mapping>" << endl;
	id = 0;
	for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
	{
	    tg_conf << "<resource name=\"" << "Generator" << src << "\" id=\"" << src << "\" contents=\"mutable\">" << endl;
	    tg_conf << "<group position=\"movable\" name=\"g" << src << "\" id=\"" << src << "\" contents=\"mutable\">" << endl;

	    // Data input task:
	    // SCTG does not allow data input tasks that have no connection to them.
	    // Add data input tasks only for generators that receive data.
	    for(int i = 0; i < p2p_inv.stats_->pd->num_of_agents; i++)
	    {
		for(int line = 0; line < all_params.at(i).size(); line++)
		{
		    if(all_params.at(i).at(line).dst == src)
		    {
			tg_conf << "<task position=\"movable\" name=\"Receive_task" << src << "\" id=\"" << src+60000 << "\"/>" << endl;
			goto doublebreak2;
		    }
		}
	    }
	  doublebreak2:


	    for(int line = 0; line < all_params.at(src).size(); line++)
	    {
		tg_conf << "<task position=\"movable\" name=\"Task" << id << "\" id=\"" << id << "\"/>" << endl;
		id++;
	    }
	    tg_conf << "</group>" << endl;
	    tg_conf << "</resource>" << endl;
	}	
	tg_conf << "</mapping>" << endl;

	// Platform.

	tg_conf << "<platform>" << endl;
	tg_conf << "<resource_list>" << endl;
	for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
	{
	    tg_conf << "<resource id=\"" << src << "\" name=\"Generator" << src << "\" frequency=\"" << p2p_inv.stats_->pd->clock_hz/1000000 << 
		"\" type=\"CPU_TYPE_2\" packet_size=\"" << 16 << "\">" << endl;
	    tg_conf << "<port terminal=\"" << src << "\"/>" << endl;
	    tg_conf << "</resource>" << endl;
	}
	tg_conf << "</resource_list>" << endl;

	tg_conf << "<noc class=\"mesh_2d\" type=\"sc_rtl_1\" subtype=\"" << p2p_inv.stats_->pd->mesh_cols << "x" << p2p_inv.stats_->pd->mesh_rows << "\">" << endl;
	tg_conf << "<router_list>" << endl;
	for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
	{
	    int cur_row = src/(p2p_inv.stats_->pd->mesh_cols);
	    int cur_col = src - (cur_row*(p2p_inv.stats_->pd->mesh_cols));

	    tg_conf << "<router width=\"32\" id=\"" << src << "\" name=\"mesh_r" << src << "\" frequency=\"" << p2p_inv.stats_->pd->clock_hz/1000000 << "\" type=\"mesh_router\">" << endl;
	    tg_conf << "<port name=\"mesh_p" << src << "\" id=\"" << src << "\" type=\"asdfqwerty\" address=\"0x" 
		    << hex << setfill('0') << setw(4) << cur_row << setfill('0') << setw(4) << cur_col << dec << "\"/>" << endl;
	    tg_conf << "</router>" << endl;
	}
	tg_conf << "</router_list>" << endl;

	tg_conf << "<terminal_list>" << endl;
	for(int src = 0; src < p2p_inv.stats_->pd->num_of_agents; src++)
	{
	    tg_conf << "<connection port=\"" << src << "\" router=\"" << src << "\" name=\"mesh_p\" id=\"" << src << "\"/>" << endl;
	}	
	tg_conf << "<network_interface type=\"mesh_if\"/>" << endl;
	tg_conf << "</terminal_list>" << endl;

	tg_conf << "</noc>" << endl;
	tg_conf << "</platform>" << endl;

	// Constraints.

	tg_conf << "<constraints>" << endl;
	tg_conf << "<sim_resolution time=\"1.0\" unit=\"ns\"/>" << endl;

	unsigned long long int running_time = (end-begin)*p2p_inv.stats_->pd->window_length;
	double length_s = (double)running_time/(double)p2p_inv.stats_->pd->clock_hz;
	tg_conf << "<sim_length time=\"" << length_s << "\" unit=\"s\"/>" << endl;

	tg_conf << "<measurements time=\"1.0\" unit=\"ms\"/>" << endl;
	
	tg_conf << "<log_exec_mon file=\"log_execmon.txt\"/>" << endl;
	tg_conf << "<pe_lib file=\"examples/pe_lib.xml\"/>" << endl;
	tg_conf << "<log_packet file=\"log_packet.csv\"/>" << endl;
	tg_conf << "<log_token file=\"log_token.csv\"/>" << endl;
	tg_conf << "<log_summary file=\"log_summary.txt\"/>" << endl;
	tg_conf << "<log_pe file=\"log_pe.csv\"/>" << endl;
	tg_conf << "<log_app file=\"log_app.csv\"/>" << endl;

	tg_conf << "</constraints>" << endl;
	tg_conf << "</system>" << endl;
	
    }

    tg_conf.close();
}

void create_model_textui(p2p_investigator& p2p_inv, int begin, int end)
{
    cout << "Welcome to the TG model generator." << endl;

    const int NUM_FORMATS = 2;
    const char* const FORMAT_NAMES[NUM_FORMATS] = {"HWTG UART input text file", "SystemC Transaction Generator XML file"};
    int format = 0;
    int n_passes = 2;
    double combine_coeff = 0.1;
    bool done = false;
    bool process = false;
    bool dbg_print = false;

    int* max_conflines = new int[p2p_inv.stats_->pd->num_of_agents]; 
    for(int i = 0; i < p2p_inv.stats_->pd->num_of_agents; i++)
	max_conflines[i] = 3; // -1 = AUTO.

    while(!done)
    {
	cout << " MODEL GENERATION OPTIONS " << endl;
	cout << "1: Output format (current = " << FORMAT_NAMES[format] << ")" << endl;
	cout << "2: Combining transactions close to each other (time coefficient = " << combine_coeff << ", n:o passes = " << n_passes << endl;
	cout << "3: Maximum number of TX event conflines (";
	for(int i = 0; i < p2p_inv.stats_->pd->num_of_agents; i++)
	    cout << max_conflines[i] << ((i == p2p_inv.stats_->pd->num_of_agents-1)?")":",");
	cout << endl;

	cout << endl;
	cout << "s: Start processing (or capital S to include verbose/debug prints)" << endl;
	cout << endl;
	cout << endl;    	
	cout << "Give a command (others to cancel)" << endl;
	
	char cmd;
	cin >> cmd;
	if(cmd == '1')
	{
	    cout << "Select the output format." << endl;
	    for(int i = 0; i < NUM_FORMATS; i++)
	    {
		cout << "  " << i << ": " << FORMAT_NAMES[i];
		if(i == format) cout << " (SELECTED)";
		cout << endl;
	    }
	    cin >> format;
	    if(format < 0 || format >= NUM_FORMATS) format = 0;    
	}
	else if(cmd == '2')
	{

	}
	else if(cmd == '3')
	{
	}
	else if(cmd == '4')
	{
	}
	else if(cmd == 'S' || cmd == 's')
	{
	    process = true;
	    done = true;
	    dbg_print = (cmd=='S');
	}
	else
	{
	    done = true;
	}

    }    

    if(!process)
	return;

    create_model(p2p_inv, begin, end, max_conflines, format);

}

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
