// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

#ifndef MESH_HPP
#define MESH_HPP

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>
#include <SFML/Graphics.hpp>

#include "parser.hpp"
//#include "statistics.hpp"

// GRAPHICAL CONSTANTS
#define ROUTER_COORD_TEXT_WIDTH 3
#define MAX_NUM_LINKS 300
#define MAX_LINK_NAME_LEN 32
#define TRESHOLDED_COLORS 6

#define YX_ROUTING 0
#define XY_ROUTING 1


//                IP(4)
//        N(0)
//
//   W(3)      E(1)
//
//        S(2)

const char direction_names[5][3] = {"N ","E ","S ","W ","IP"};

const bool ALLOWED_TURNS[3][5][5] =
{
    { // YX ROUTING
	{false, true, true, true, true},
	{false, false, false, true, true},
	{true, true, false, true, true},
	{false, true, false, false, true},
	{true, true, true, true, false}
    }, 
    { // YX ROUTING
	{false, true, true, true, true},
	{false, false, false, true, true},
	{true, true, false, true, true},
	{false, true, false, false, true},
	{true, true, true, true, false}
    }, 
    { // YX ROUTING
	{false, true, true, true, true},
	{false, false, false, true, true},
	{true, true, false, true, true},
	{false, true, false, false, true},
	{true, true, true, true, false}
    }
};

struct statistics;
struct gui;

struct mesh
{
    mesh(statistics* statsjoo, gui* guijoo, sf::RenderWindow& window);

    statistics* stats_;
    gui* gui_;
    sf::RenderWindow& win;

    vector<int> vect_indeces_router_links;
    vector<int> vect_indeces_pe_overhead_links;
    vector<int> vect_indeces_pe_no_overhead_links;

    int router_xsize;
    int router_ysize;
    int router_xspace;
    int router_yspace;
    int pe_xsize;
    int pe_ysize;
    int pe_xoffset;
    int pe_yoffset;

    int mesh_routing;
    
    int router_coord_font_size;
    int pe_title_font_size;
    int data_percentage_font_size;
    int stall_percentage_font_size;

    
    int left_margin;
    int top_margin;
    int bottom_margin;
    
    int router_colors[TRESHOLDED_COLORS+1];
    int router_color_tresholds[TRESHOLDED_COLORS];
    sf::Color link_colors[TRESHOLDED_COLORS+1];
    int link_color_tresholds[TRESHOLDED_COLORS];
    int link_widths[TRESHOLDED_COLORS+1];
    int link_width_tresholds[TRESHOLDED_COLORS];

    char mesh_link_names[MAX_NUM_LINKS][MAX_LINK_NAME_LEN];
    int mesh_link_numbers_to_right[20][20];
    int mesh_link_numbers_to_left[20][20];
    int mesh_link_numbers_to_down[20][20];
    int mesh_link_numbers_to_up[20][20];
    int mesh_pe_datalink_indeces_in_no_overhead[20][20];
    int mesh_pe_datalink_indeces_out_no_overhead[20][20];
    int mesh_pe_datalink_indeces_in_with_overhead[20][20];
    int mesh_pe_datalink_indeces_out_with_overhead[20][20];
    void create_mesh_link_names(); // and numbers
    int check_mesh_vis_values();

    int mesh_link_click_coords[MAX_NUM_LINKS][4]; // x, y, x, y

    void draw_mesh();

    int get_snd_idx(int ip_num);
    int get_rcv_idx(int ip_num);
    int get_snd_no_overhead_idx(int ip_num);
    int get_rcv_no_overhead_idx(int ip_num);



};

#endif

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
