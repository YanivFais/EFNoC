// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

// parser.hpp
// This module takes in raw binary data from the UDP packet and parses it
// to array of counter values or writes the values to disk as CSV (Comma
// Separated Values) file.
//
// This module also maintains the large amount of processing parameters 
// that describe the NoC and the monitoring system in order to parse
// the data correctly.


#ifndef PARSER_HPP
#define PARSER_HPP

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdio>

using namespace std;

#define MAX_HIBI_SEGS 20

struct processing_data
{
public:
    int net_type;
    int window_length;
    int num_of_agents;
    int mesh_rows;
    int mesh_cols;
    int packet_length;
    int counter_bits;
    int counters_per_link;
    int num_of_links;
    int num_of_extra_counters;
    int num_of_counters;
    int data_per_snapshot;
    int padding_per_snapshot;
    int snapshot_length;
    int snapshot_bytes;
    int snapshots_per_packet;
    unsigned long int clock_hz;
    int hibi_segments;
    int hibi_ags_seg[MAX_HIBI_SEGS];
    int hibi_ags_incl_bri_seg[MAX_HIBI_SEGS];
    int hibi_counters_per_seg[MAX_HIBI_SEGS];

    char bin_name[400];

    int check_values();

    int calculate_values();

};

int parse_snapshot(int input_mode, const unsigned char* data, ifstream* data_file,
		   int output_mode, int* counters, ofstream* output_file,
		   const char delimiter, const processing_data* pd);

#endif


// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
