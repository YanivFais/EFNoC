// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.

// hibi.cpp: This module is for visualization of HIBI network.
// Currently out-of-date. Todo: make this work with the current version.

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdio>

#include "hibi.hpp"

hibi::hibi()
{
    ;
}

/*
void statistics::print_hibi()
  {
    //system("clear");
    cout << ESC << CURSOR_11;
    cout << "Real-time NoC statistics                           " << endl;
    cout << "Counter         "; // 16 chars
    for(int i = print_ignore_log_levels; i < logging_levels; i++)
    {
      cout << "   Last " << setw(9) << pow(logging_length, i+1) << "   ";  // 20 chars
      cout << " | ";
    }
    cout << endl;
    cout << "                "; // 16 chars
    for(int i = print_ignore_log_levels; i < logging_levels; i++)
    {
      cout << " min  avg  max  tot "; // 20 chars
      cout << " | ";
    }
    cout << endl;

    int print_hibi_sender = 0;
    int print_hibi_receiver = 1;
    int print_hibi_last = 0;

    for(int curcnt = 0; curcnt < pd->num_of_counters; curcnt++)
    {
      cout << setw(3) << curcnt << " "; // 4 chars
      // next, descriptor for counter, 12 chars:
      if(pd->net_type == 0) // MESH
      {
	cout << "            ";
      }
      else if(pd->net_type == 1) // HIBI
      {
	if(print_hibi_last == 1)
	{
	  cout << "BUS IDLE    ";
	}
	else
	{
	  cout << setw(2) << print_hibi_sender << "->" << setw(2) << print_hibi_receiver << " "; // 7 chars
	  if(curcnt%3 == 0)
	  {
	    cout << "DATA ";
	  }
	  else if(curcnt%3 == 1)
	  {
	    cout << "MSG  ";
	  }
	  else
	  {
	    cout << ESC << BRED << "FULL " << ESC << NORM;
	    print_hibi_receiver++;
	    if(print_hibi_receiver == print_hibi_sender)
	    {
	      print_hibi_receiver++;
	    }
	  
	    if(print_hibi_receiver == pd->num_of_agents)
	    {
	      print_hibi_sender++;
	      print_hibi_receiver = 0;
	      if(print_hibi_sender == pd->num_of_agents)
	      {
		print_hibi_last = 1;
	      }

	    }

	  }
	}
      }
      else // Unknown network
      {
	cout << "            ";
      }


      for(int curlev = print_ignore_log_levels; curlev < logging_levels; curlev++)
      {
	if(min_counter_log[curlev][curcnt] == MIN_INIT)
	  cout << " N/A ";
	else
	  print_autoscale(min_counter_log[curlev][curcnt], curcnt%3==2, percents,
			  (pd->window_length-1)*pow(logging_length, curlev), curcnt==pd->num_of_counters-1);

	print_autoscale(avg_counter_log[curlev][curcnt], curcnt%3==2, percents, 
			(pd->window_length-1)*pow(logging_length, curlev), curcnt==pd->num_of_counters-1);
 
	if(max_counter_log[curlev][curcnt] == MAX_INIT)
	  cout << " N/A ";
	else
	  print_autoscale(max_counter_log[curlev][curcnt], curcnt%3==2, percents,
			  (pd->window_length-1)*pow(logging_length, curlev), curcnt==pd->num_of_counters-1);

	print_autoscale(tot_counter_log[curlev][curcnt], curcnt%3==2, percents,
			(pd->window_length-1)*pow(logging_length, curlev+1), curcnt==pd->num_of_counters-1);

	if(curcnt%3 == 2)
	  cout << ESC << BRED;
	cout << " | ";
	if(curcnt%3 == 2)
	  cout << ESC << NORM;
      }
      cout << endl;
      if(curcnt%3 == 2)
	cout << endl;
    }    
  }

*/

void hibi::draw_hibi()
{
    /*
    g2_set_background(g2d[0], 1);
    g2_clear(g2d[0]);

    int seg_draw_beg_x = left_margin;

    int start_ag_num = 0;

    int ag_title_cnt = 0;


    const int pnt_incr = 3; // 3 = data, msg, full

    const int* datas[MAX_HIBI_SEGS];
    const int* msgs [MAX_HIBI_SEGS];
    const int* fulls[MAX_HIBI_SEGS];
    int bus_usages[MAX_HIBI_SEGS]; // one counter per seg.

    if(averaging_mode == MODE_WORST)
    {
	int idx = 0;
	for(int seg = 0; seg < pd->hibi_segments; seg++)
	{
	    datas[seg]     = &max_counter_log[0][idx + 0];
	    msgs[seg]      = &max_counter_log[0][idx + 1];
	    fulls[seg]     = &max_counter_log[0][idx + 2];
	    bus_usages[seg] = pd->window_length - min_counter_log[0][idx + pd->hibi_counters_per_seg[seg]];

	    idx+=pd->hibi_counters_per_seg[seg]+pd->num_of_extra_counters;
	}
    }
    else if(averaging_mode == MODE_AVG)
    {
	int idx = 0;
	for(int seg = 0; seg < pd->hibi_segments; seg++)
	{
	    datas[seg]     = &avg_counter_log[0][idx + 0];
	    msgs[seg]      = &avg_counter_log[0][idx + 1];
	    fulls[seg]     = &avg_counter_log[0][idx + 2];
	    bus_usages[seg] = pd->window_length - avg_counter_log[0][idx + pd->hibi_counters_per_seg[seg]];

	    idx+=pd->hibi_counters_per_seg[seg]+pd->num_of_extra_counters;
	}
    }
    else
    {
	int idx = 0;
	for(int seg = 0; seg < pd->hibi_segments; seg++)
	{
	    datas[seg]     = &min_counter_log[0][idx + 0];
	    msgs[seg]      = &min_counter_log[0][idx + 1];
	    fulls[seg]     = &min_counter_log[0][idx + 2];
	    bus_usages[seg] = pd->window_length - max_counter_log[0][idx + pd->hibi_counters_per_seg[seg]];

	    idx+=pd->hibi_counters_per_seg[seg]+pd->num_of_extra_counters;
	}

    }

  int* bus_col;
  int* bus_width;

  bus_col = new int[pd->hibi_segments];
  bus_width = new int[pd->hibi_segments];

  for(int i = 0; i < pd->hibi_segments; i++)
  {
    // COMPUTE BUS COLOR AND WIDTH
    if(bus_usages[i] == 0)
    {
      // Totally inactive bus.
      bus_col[i] = bus_colors[0];
      bus_width[i] = bus_widths[0];
    }
    else
    {
      bus_col[i] = bus_colors[TRESHOLDED_COLORS];
      bus_width[i] = bus_widths[TRESHOLDED_COLORS];
      for(int c = 1; c < TRESHOLDED_COLORS+1; c++)
      {
	  if(bus_usages[i]*100/pd->window_length < link_color_tresholds[c])
	  {
	      bus_col[i] = bus_colors[c];
	      bus_width[i] = bus_widths[c];
	      break;
	  }
      }
    }
  }


  // Calculate total fulls to be printed on the wrappers.
  int** tot_fulls = new int*[pd->hibi_segments];
  int indx;
  for(int i = 0; i < pd->hibi_segments; i++)
  {
      tot_fulls[i] = new int[pd->hibi_ags_incl_bri_seg[i]];
      for(int z = 0; z < pd->hibi_ags_incl_bri_seg[i]; z++)
	  tot_fulls[i][z] = 0;

      indx = 0;
      for(int from = 0; from < pd->hibi_ags_incl_bri_seg[i]; from++)
      {
	  for(int to = 0; to < pd->hibi_ags_incl_bri_seg[i]; to++)
	  {
	      if(from == to)
	      {
		  to++;
		  if(to >= pd->hibi_ags_incl_bri_seg[i])
		  {
		      to = 0;
		      from++;
		      if(from >= pd->hibi_ags_incl_bri_seg[i])
			  break;
		  }
	      }
	      tot_fulls[i][to] += fulls[i][indx];
	      indx += pnt_incr;
	  }
      }
  }


    for(int cur_seg = 0; cur_seg < pd->hibi_segments; cur_seg++)
    {
	int ags_in_cur_seg = pd->hibi_ags_seg[cur_seg];
	bool first_is_bridge = false;
	bool last_is_bridge = false;
	if(pd->hibi_segments > 1)
	{
	    if(cur_seg == 0)
	    {
		ags_in_cur_seg++;
		last_is_bridge = true;
	    }
	    else if(cur_seg == pd->hibi_segments-1)
	    {
		ags_in_cur_seg++;
		first_is_bridge = true;
	    }
	    else
	    {
		ags_in_cur_seg+=2;
		first_is_bridge = true;
		last_is_bridge = true;
	    }
	}

	// Draw bus
	g2_set_line_width(g2d[0], bus_width[cur_seg]);
	g2_pen(g2d[0], bus_col[cur_seg]);
	g2_line(g2d[0], 
		seg_draw_beg_x + (first_is_bridge?(hibi_wra_xsize):(hibi_wra_xsize/2)),
		bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize/2,
		seg_draw_beg_x+ags_in_cur_seg*hibi_ag_xoffset - (last_is_bridge?(hibi_wra_xsize):(hibi_wra_xsize/2)) - (hibi_ag_xoffset-hibi_wra_xsize),
		bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize/2);
	

	int wracnt = 0;

	// Agent loop thus includes bridges as agents.
	for(int cur_ag = 0; cur_ag < ags_in_cur_seg; cur_ag++)
	{
	    char wratmpstr[20];

	    if((cur_ag == 0 && first_is_bridge == false) || (cur_ag == ags_in_cur_seg-1 && last_is_bridge == false) ||
	       (cur_ag > 0 && cur_ag < ags_in_cur_seg-1))
	    {
		// It's not a bridge.
		// Draw pe
		g2_set_line_width(g2d[0], 3.0);
		g2_pen(g2d[0], 0);
		g2_rectangle(g2d[0], 
			 seg_draw_beg_x+cur_ag*hibi_ag_xoffset, 
			 bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize+hibi_wra_ysize+hibi_pe_wra_yspace,
			 seg_draw_beg_x+cur_ag*hibi_ag_xoffset+hibi_wra_xsize, 
			 bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize+hibi_wra_ysize+hibi_pe_wra_yspace+hibi_pe_ysize);

		// Print PE title

		g2_pen(g2d[0], 0);
		g2_set_font_size(g2d[0], pe_title_font_size);
		g2_string(g2d[0], seg_draw_beg_x+cur_ag*hibi_ag_xoffset+5,
		    bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize+hibi_wra_ysize+hibi_pe_wra_yspace+hibi_pe_ysize-pe_title_font_size-10,
		    name_tags[ag_title_cnt]);


		// Draw wrapper

		g2_set_line_width(g2d[0], 3.0);
		g2_pen(g2d[0], 0);
		g2_rectangle(g2d[0], 
			 seg_draw_beg_x+cur_ag*hibi_ag_xoffset, 
			 bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize,
			 seg_draw_beg_x+cur_ag*hibi_ag_xoffset+hibi_wra_xsize, 
			 bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize+hibi_wra_ysize);


		// Print wrapper title

		sprintf(wratmpstr, "WRA %d", ag_title_cnt);

		g2_pen(g2d[0], 0);
		g2_set_font_size(g2d[0], pe_title_font_size);
		g2_string(g2d[0], seg_draw_beg_x+cur_ag*hibi_ag_xoffset+5,
		    bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize+hibi_wra_ysize-pe_title_font_size-10,
		    wratmpstr);

		ag_title_cnt++;

		// Print TOTAL FULL value in the wrapper.

		sprintf(wratmpstr, "F %d", tot_fulls[cur_seg][wracnt]);

		g2_pen(g2d[0], 2);
		g2_set_font_size(g2d[0], pe_title_font_size);
		g2_string(g2d[0], seg_draw_beg_x+cur_ag*hibi_ag_xoffset+5,
		    bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize+hibi_wra_ysize-2*pe_title_font_size-10,
		    wratmpstr);
		wracnt++;


		// Draw line between PE and wrapper

		g2_set_line_width(g2d[0], 4.0);
		g2_pen(g2d[0], 0);
		g2_line(g2d[0], 
			seg_draw_beg_x+cur_ag*hibi_ag_xoffset+hibi_wra_xsize/2,
			bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize+hibi_wra_ysize+hibi_pe_wra_yspace,
			seg_draw_beg_x+cur_ag*hibi_ag_xoffset+hibi_wra_xsize/2,
			bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize+hibi_wra_ysize);

		// Draw line towards bus

		g2_set_line_width(g2d[0], 4.0);
		g2_pen(g2d[0], 0);
		g2_line(g2d[0], 
			seg_draw_beg_x+cur_ag*hibi_ag_xoffset+hibi_wra_xsize/2,
			bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize,
			seg_draw_beg_x+cur_ag*hibi_ag_xoffset+hibi_wra_xsize/2,
			bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize/2);

		// Draw a connection ball
		g2_pen(g2d[0], 0);
		g2_filled_circle(g2d[0], 
				 seg_draw_beg_x+cur_ag*hibi_ag_xoffset+hibi_wra_xsize/2,
				 bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize/2,
				 8.0);
	    }
	    else
	    {
		// Draw bridge
		g2_set_line_width(g2d[0], 3.0);
		g2_pen(g2d[0], 0);
		g2_rectangle(g2d[0], 
			 seg_draw_beg_x+cur_ag*hibi_ag_xoffset, 
			 bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace,
			 seg_draw_beg_x+cur_ag*hibi_ag_xoffset+hibi_wra_xsize, 
			 bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize);

		// Print TOTAL FULL value in the bridge wrapper.
		sprintf(wratmpstr, "F %d", tot_fulls[cur_seg][wracnt]);

		g2_pen(g2d[0], 2);
		g2_set_font_size(g2d[0], pe_title_font_size);
		g2_string(g2d[0], seg_draw_beg_x+cur_ag*hibi_ag_xoffset+5,
		    bottom_margin+hibi_table_yspace+hibi_table_ysize+hibi_table_yspace+hibi_bridge_ysize-2*pe_title_font_size-10,
		    wratmpstr);

		wracnt++;
	    }

	} // end agent loop

	

	// Draw the segment tables

	for(int tbl = 0; tbl < 3; tbl++)
	{
	    char tmptxt[20];

	    g2_set_line_width(g2d[0], 1.0);
	    g2_pen(g2d[0], 0);

	    // We have to squeeze one extra column to number of agents
	    // Table is only as wide as the real agents, not bridges
	    double tbl_xsize = hibi_ag_xoffset * pd->hibi_ags_seg[cur_seg] + (hibi_ag_xoffset-hibi_wra_xsize); 
	    double tbl_xoffset = tbl_xsize / (ags_in_cur_seg + 1); // Agents including bridges, and one extra column.
	    double tbl_xstart = seg_draw_beg_x + (first_is_bridge?(hibi_ag_xoffset):(0)) - (hibi_ag_xoffset-hibi_wra_xsize);
	    
	    // However, the height is not scaled but is what is needed.
	    // There is also one extra row.
	    double tbl_yoffset = hibi_table_font_size + 8;
	    double tbl_ysize = tbl_yoffset * (ags_in_cur_seg + 1);
	    //  Table starts from up so it goes against the coordinate system of g2.
	    double tbl_ystart = bottom_margin+hibi_table_yspace+hibi_table_ysize - tbl*(tbl_ysize+hibi_table_yspace);

	    // Title
	    g2_set_font_size(g2d[0], hibi_table_title_font_size);
	    if(tbl == 0)
		g2_string(g2d[0], tbl_xstart, tbl_ystart, "Data transfers");
	    else if(tbl == 1)
		g2_string(g2d[0], tbl_xstart, tbl_ystart, "Message (hi-prio) transfers");		
	    else if(tbl == 2)
		g2_string(g2d[0], tbl_xstart, tbl_ystart, "Target fifo full states");
	    else
		g2_string(g2d[0], tbl_xstart, tbl_ystart, "Unknown table");

	    // Vertical lines

	    g2_set_font_size(g2d[0], hibi_table_font_size);

	    for(int xx = 0; xx < ags_in_cur_seg + 2; xx++)
	    {
		if(xx == 1)
		    g2_set_line_width(g2d[0], 2.0);
		
		g2_line(g2d[0],
			tbl_xstart + xx * tbl_xoffset,
			tbl_ystart,
			tbl_xstart + xx * tbl_xoffset,
			tbl_ystart - tbl_ysize);
		
		if(xx == 1)
		    g2_set_line_width(g2d[0], 1.0);
	    }
	    
	    // First row titles
	    int ag_num_incr = 0;
	    for(int xx = 0; xx < ags_in_cur_seg + 1; xx++)
	    {
		int text_x = tbl_xstart + xx*tbl_xoffset + 3;
		int text_y = tbl_ystart - tbl_yoffset + 1;
		
		if(xx == 0)
		{
		    g2_string(g2d[0], text_x, text_y, "from");
		    g2_string(g2d[0], text_x+tbl_xoffset*2/3, text_y+5, "to");
		}
		else if (xx == 1 && first_is_bridge)
		    g2_string(g2d[0], text_x, text_y, "LEFT");
		else if (xx == ags_in_cur_seg && last_is_bridge)
		    g2_string(g2d[0], text_x, text_y, "RIGHT");
		else
		{
		    sprintf(tmptxt, "AG %d", start_ag_num+ag_num_incr);
		    g2_string(g2d[0], text_x, text_y, tmptxt);
		    ag_num_incr++;
		}
		
	    }


	    // Horizontal lines
	    
	    for(int yy = 0; yy < ags_in_cur_seg + 2; yy++)
	    {
		if(yy == 1)
		    g2_set_line_width(g2d[0], 2.0);
		
		g2_line(g2d[0],
			tbl_xstart,
			tbl_ystart - yy * tbl_yoffset,
			tbl_xstart + tbl_xsize,
			tbl_ystart - yy * tbl_yoffset);
		
		
		if(yy == 1)
		    g2_set_line_width(g2d[0], 1.0);
	    }

	    // First column titles
	    ag_num_incr = 0;
	    for(int yy = 0; yy < ags_in_cur_seg + 1; yy++)
	    {
		int text_x = tbl_xstart + 3;
		int text_y = tbl_ystart - tbl_yoffset - yy*tbl_yoffset + 1;
		
		if (yy == 1 && first_is_bridge)
		    g2_string(g2d[0], text_x, text_y, "LEFT");
		else if (yy == ags_in_cur_seg && last_is_bridge)
		    g2_string(g2d[0], text_x, text_y, "RIGHT");
		else if( yy != 0)
		{
		    sprintf(tmptxt, "AG %d", start_ag_num+ag_num_incr);
		    g2_string(g2d[0], text_x, text_y, tmptxt);
		    ag_num_incr++;
		}
		
	    }


	    // Print values.

	    int from;
	    int to;

	    int index = 0;
	    for(from = 0; from < ags_in_cur_seg; from++)
	    {
		for(to = 0; to < ags_in_cur_seg; to++)
		{
		    if(from == to)
		    {
			to++;
			if(to >= ags_in_cur_seg)
			{
			    to = 0;
			    from++;
			    if(from >= ags_in_cur_seg)
				break;
			}
		    }
		    int text_x = tbl_xstart + (to+1)*tbl_xoffset + 3;
		    int text_y = tbl_ystart - tbl_yoffset - (from+1)*tbl_yoffset + 1;

		    if(tbl == 0)
			sprintf(tmptxt, "%3.1f %%", (double)datas[cur_seg][index]/(double)pd->window_length);
		    else if(tbl == 1)
			sprintf(tmptxt, "%3.1f %%", (double)msgs[cur_seg][index]/(double)pd->window_length);
		    else if(tbl == 2)
			sprintf(tmptxt, "%d", fulls[cur_seg][index]);
		    index += pnt_incr;
		    
		    g2_string(g2d[0], text_x, text_y, tmptxt);

		}
		
	    }  // End print values loop.

	} // End draw tables loop.
        

	seg_draw_beg_x += ags_in_cur_seg * hibi_ag_xoffset;
	// Combine bridge elements:
	if(last_is_bridge == true)
	    seg_draw_beg_x -= hibi_ag_xoffset-hibi_wra_xsize;

	start_ag_num += pd->hibi_ags_seg[cur_seg];

    } // end segment loop

  if(!realtime)
      draw_nav_bar();
  uis[0].draw_all_buttons();

  g2_flush(g2d[0]);

  delete bus_col;
  delete bus_width;

  for(int i = 0; i < pd->hibi_segments; i++)
      delete tot_fulls[i];
  delete tot_fulls;

    */

    ;

}
