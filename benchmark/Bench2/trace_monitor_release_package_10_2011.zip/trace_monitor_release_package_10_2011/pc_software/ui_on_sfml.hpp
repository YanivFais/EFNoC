// Trace Monitor PC Software

// Copyright Tampere University of Technology 2009 - 2011

// This file is part of Trace Monitor.

// Trace Monitor is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// Trace Monitor is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with Trace Monitor.  If not, see <http://www.gnu.org/licenses/>.


// ui.hpp
// A set of very simple User Interface functions based on SFML library.
// Implements mouse functionality with buttons that can be clicked.

#ifndef UI_HPP
#define UI_HPP

#include <SFML/Graphics.hpp>

#define MAX_BUTTONS     64

struct button
{
    int x;
    int y;
    int xs;
    int ys;
    bool visible;
    //    int state;
    bool pressed;
    char* text;
    int symbol;
    int font_size;
    sf::Color color;
    sf::Color color_pressed;
    sf::Color text_color;
};

#define SYMB_MAX_POLYS   5
#define POLY_MAX_POINTS 20

struct poly
{
    int n_points;
    bool fill;
    sf::Color fill_color;
    bool line;
    int line_width;
    sf::Color line_color;
    int points[POLY_MAX_POINTS];
};

struct symbol
{
    int n_polys;
    poly polys[SYMB_MAX_POLYS];
    int text_offset;
};


const symbol SYMBOLS[] = 
{ // nPoint fill? fill color            line?  W  line color              points (x,y,x,y,...)       text offset
    1, {3, true, sf::Color(  0,180,  0), true, 1, sf::Color(  0, 80,  0), {0,0, 0,10, 10,5}},        15,          // 0 = PLAY
    1, {4, true, sf::Color(180,  0,  0), true, 1, sf::Color( 80,  0,  0), {0,0, 0,10, 10,10, 10,0}}, 15,          // 1 = STOP
    1, {3, true, sf::Color(  0,200,200), true, 1, sf::Color(  0, 90, 90), {0,2, 0,8,   8,5}},        15           // 2 = PLAYSLOW
};

#define SYM_PLAY 0
#define SYM_STOP 1
#define SYM_PLAYSLOW 2

const sf::Color DEF_BUT_COL = sf::Color(190,190,190);
const sf::Color DEF_BUT_COL_PRESSED = sf::Color(128,128,128);
const int DEF_BUT_FONT_SIZE = 14;

// Multiple Windows or RenderWindows each need their own ui_on_sfml objects.

struct ui_on_sfml
{
    ui_on_sfml(sf::RenderWindow& win);

    sf::RenderWindow& window;  // Pointer to the RenderWindow
    const sf::Input&  input;       // Reference to the input handler.

    sf::Font font;

//    int window_xsize; 
//    int window_ysize; 

    int num_buttons;

    button* buttons[MAX_BUTTONS];
    //    checkbox checkboxes[MAX_CHECKBOXES];


    // Returns the tag value of the new button.
    int add_button(int x, int y, int xs, int ys, const char* text, sf::Color color = DEF_BUT_COL, int font_size = DEF_BUT_FONT_SIZE,  
		   int symbol = -1, sf::Color color_pressed = DEF_BUT_COL_PRESSED, bool pressed = false);

    void destroy_buttons();

    void show_button(int num);
    void hide_button(int num);

    // Draws the button on screen
    void draw_button(int num);

    // Draws all the buttons on screen. Calls draw_button.
    void draw_all_buttons();

    // Returns the number of button pressed, or -1 if no button is pressed
    int check_button_status();

    void query_mouse(int* x, int* y, bool* left, bool* mid = 0, bool* right = 0);

    void change_text(int num, const char* text);

};

#endif

// Local Variables:
// mode: c++
// c-file-style: "ellemtel"
// c-basic-offset: 4
// End:
