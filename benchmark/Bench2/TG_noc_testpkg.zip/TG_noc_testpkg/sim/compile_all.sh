#!/bin/bash

# Edit TG_PATH and VLOG_FLAGS to match environment, others should work as is
SIM_PATH=$(PWD)
TG_PATH=../traffic_generator_20091201/traffic_generator
NOCEM_PATH=../interconnections/nocem
WISHB_PATH=../interconnections/wishbone_conmax
HERMES_PATH=../interconnections/hermes

# Options for compilation
VCOM_FLAGS=
VLOG_FLAGS="-work <path to current_folder/lib>"



# Create modelsim library folder
if [ ! -d lib ]
then
    vlib lib
    vmap work lib
fi

# Traffic generator vhdl-files:
vcom ../vhd/fifo.vhd
vcom ../vhd/lfsr.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/tg_pkg.vhd
vcom $VCOM_FLAGS $TG_PATH/../monitor/vhd/mon_pkg.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/hibi_addr_pkg.vhd
#vcom $VCOM_FLAGS $TG_PATH/../hibi/vhd/hibiv2_pkg.vhd
#vcom $VCOM_FLAGS $TG_PATH/vhd/hibiv2.vhd 
#vcom $VCOM_FLAGS $TG_PATH/vhd/hibi_addr_resolver.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/master.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/master_sender_mux.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/dpram_general.vhd
vcom $VCOM_FLAGS -check_synthesis $TG_PATH/vhd/reader.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/reader_input_mux.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/reader_wrapper.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/sender.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/sender_wrapper.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/tg_top.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/trigger.vhd
vcom $VCOM_FLAGS -93 $TG_PATH/vhd/uart_sim.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/wrapper.vhd
vcom $VCOM_FLAGS $TG_PATH/vhd/mesh_addr_resolver.vhd

# Hermes vhdl-files
vcom $HERMES_PATH/tb/ver_06/system_pkg.vhd
vcom $HERMES_PATH/vhd/ver_06/hermes_pkg.vhd
vcom $HERMES_PATH/vhd/ver_06/hermes_fifo.vhd
vcom $HERMES_PATH/vhd/ver_06/switch_ctrl.vhd
vcom $HERMES_PATH/vhd/ver_06/router.vhd
vcom $HERMES_PATH/vhd/ver_06/hermes_2d.vhd
vcom ../vhd/hermes_wrapper.vhd

# Nocem vhdl-files
vcom $VCOM_FLAGS $NOCEM_PATH/tg_wrapper/reader_wrapper_nocem.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/tg_wrapper/sender_wrapper_nocem.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/tg_wrapper/wrapper_nocem.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/pkg_nocem.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/Xto1_arbiter.vhd
#vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/access_point_exerciser.vhd
#vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/ap_exerciser_vc.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/arb_bus_nocem.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/arb_simple_pkt_nocem.vhd
#vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/barrelshift4_wrapper.sch
#vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/barrelshift8_wrapper.sch
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/channel_fifo.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/fifo_allvhdl.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/fifo_gfs.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/fifo_reg.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/ic_bus_nocem.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/ic_pkt_nocem.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/mux2to1.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/mux4to1.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/nocem.vhd
#vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/packetbuffer2.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/simple_pkt_local_arb.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/simple_pkt_local_switch.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/simple_pkt_node.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/vc_channel.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/vc_channel_destap.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/vc_controller.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/vc_node.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/vc_node_ch_arbiter.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/vc_node_vc_allocator.vhd
vcom $VCOM_FLAGS $NOCEM_PATH/VHDL/vc_vc_alloc_arb.vhd

# Wishbone Connection matrix verilog- and vhdl-files
cd $WISHB_PATH
vlog $VLOG_FLAGS v/wb_conmax_defines.v
vlog $VLOG_FLAGS v/wb_conmax_arb.v
vlog $VLOG_FLAGS v/wb_conmax_master_if.v
vlog $VLOG_FLAGS v/wb_conmax_msel.v
vlog $VLOG_FLAGS v/wb_conmax_pri_dec.v
vlog $VLOG_FLAGS v/wb_conmax_pri_enc.v
vlog $VLOG_FLAGS v/wb_conmax_rf.v
vlog $VLOG_FLAGS v/wb_conmax_slave_if.v
vlog $VLOG_FLAGS v/wb_conmax_top.v
cd $SIM_PATH
vcom $WISHB_PATH/vhd/wb_wrapper.vhd
vcom $WISHB_PATH/vhd/wb_conmax_top_wrap.vhd

# Testbench
vcom $VCOM_FLAGS ../tb/tb_tgs_with_noc.vhd