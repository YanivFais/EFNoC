#!/bin/bash

# Simulation options:
PARSE_OUTPUT="yes"
VSIM_FLAGS=

# Paths
TG_PATH=../traffic_generator_20091201/traffic_generator
TG_COMMANDER_PATH=$TG_PATH/tg_commander


if [ ! -f mon_input.txt ]
then
    touch mon_input.txt
fi

# Run simulation, print and save report
# Option -t is required for simulating wishbone_conmax
vsim $VSIM_FLAGS -t 1ps -c -quiet -onfinish exit -do "run -all; quit -f" work.tb_tgs_with_noc

if [ $PARSE_OUTPUT = "yes" ]
then
    echo -e "Parsing results with tg_commander:\n"
    python $TG_COMMANDER_PATH/tg_commander.py -o tg_output.txt | tee sim_results.txt
fi