########################################################################
# file : syn32.sh
# desc : setup file for Synopsys Synthesis Tools Package for 
#        sh-compatible shells (sh,bash...)
# date : 2005/02/13
# auth : Juha Pirttim�ki
#        juha.pirttim�ki@tut.fi
#        Tampere University of Technology 
# Modified for csh 07.04.2006, Erno Salminen
########################################################################

set TOOL_VERSION=syn-2005.09-SP1
set OS_VERSION=sparcOS5
set CACHE_DIR=/export/work/tmp/synopsys_cache

cat << EOF
########################################################################
            SYNOPSYS version $TOOL_VERSION (32 bit binaries)
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
EOF

setenv SYNOPSYS /opt/synopsys/$TOOL_VERSION

setenv SNPSLMD_LICENSE_FILE 1716@pikkutikli.cs.tut.fi

set path = ($SYNOPSYS/$OS_VERSION/syn/bin $path)

if (! -d $CACHE_DIR) then 
    echo "Creating new $CACHE_DIR directory";
    mkdir $CACHE_DIR; \
    chmod 777 $CACHE_DIR
endif

set MWFONT_CACHE_DIR=$CACHE_DIR

alias synopsys_help '$SYNOPSYS/sold'

cat << EOF
Ensure that your .synopsys_dc.setup etc. is valid for this version.
########################################################################
EOF
