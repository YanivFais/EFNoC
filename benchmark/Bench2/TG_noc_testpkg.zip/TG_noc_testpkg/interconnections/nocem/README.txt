25.1.2010
Readme by Jussi Nieminen


NoCem is a network from OpenCores by Graham Schelle and Dirk Grunwald.
Check the documentation from the doc directory.

Directory tg_wrapper contains wrapper block that can be used to connect
NoCem with our traffic generators.
