This file contains only brief notes about the test system. Refer also
to documentation included in networks and TG.

Interconnections included:
4: Hermes
5: Nocem
6: Wishbone connection matrix

Scripts:
sim/compile_all.sh    - Modify header before use!
sim/run_simulation.sh - Modify header before use!

Traffic Generator:
1. For varying length simulations:
Set assertation in master.vhd on line 1395 to severity "failure", this will
end the simulation when TGs are done reporting.
-Note: use_monitor_c must be set to '1'

2. To supress warnings "NUMERIC_STD.TO_UNSIGNED: vector trunkated" during 
simulation modify sender.vhd: 
on line 146:
vector( to_unsigned( cycle_counter_r, timestamp_w_c ));
->
vector( resize( to_unsigned( cycle_counter_r, 2*timestamp_w_c ),
on line 288:
vector( to_unsigned( tmp_cnt_v + 1, seqnum_w_c ));
->
vector( resize( to_unsigned( tmp_cnt_v + 1, 2*seqnum_w_c ), seqnum_w_c))
on line 317:
vector( to_unsigned( tmp_cnt_v + 1, seqnum_w_c ));
->
vector(resize( to_unsigned( tmp_cnt_v + 1, 2*seqnum_w_c ), seqnum_w_c));


Nocem:
1. Simulation will produce lots of warnings, these can be ignored most of the time
2. vc_channel.vhd: Changed the vector size on lines 109 111 to (36 downto 0).
Previously (31 downto 0), which didn't simulate.


Wishbone
1. Network can be optimized to send every clock cycle. See documentation.


1.3.2011
Esko Pekkarinen
Department of Computer Systems
Tampere University of Technology
esko.pekkarinen@tut.fi
