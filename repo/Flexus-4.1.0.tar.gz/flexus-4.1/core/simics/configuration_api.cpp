// DO-NOT-REMOVE begin-copyright-block 
//
// Redistributions of any form whatsoever must retain and/or include the
// following acknowledgment, notices and disclaimer:
//
// This product includes software developed by Carnegie Mellon University.
//
// Copyright 2012 by Mohammad Alisafaee, Eric Chung, Michael Ferdman, Brian 
// Gold, Jangwoo Kim, Pejman Lotfi-Kamran, Onur Kocberber, Djordje Jevdjic, 
// Jared Smolens, Stephen Somogyi, Evangelos Vlachos, Stavros Volos, Jason 
// Zebchuk, Babak Falsafi, Nikos Hardavellas and Tom Wenisch for the SimFlex 
// Project, Computer Architecture Lab at Carnegie Mellon, Carnegie Mellon University.
//
// For more information, see the SimFlex project website at:
//   http://www.ece.cmu.edu/~simflex
//
// You may not use the name "Carnegie Mellon University" or derivations
// thereof to endorse or promote products derived from this software.
//
// If you modify the software you must place a notice on or within any
// modified version provided or made available to any third party stating
// that you have modified the software.  The notice shall include at least
// your name, address, phone number, email address and the date and purpose
// of the modification.
//
// THE SOFTWARE IS PROVIDED "AS-IS" WITHOUT ANY WARRANTY OF ANY KIND, EITHER
// EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO ANY WARRANTY
// THAT THE SOFTWARE WILL CONFORM TO SPECIFICATIONS OR BE ERROR-FREE AND ANY
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
// TITLE, OR NON-INFRINGEMENT.  IN NO EVENT SHALL CARNEGIE MELLON UNIVERSITY
// BE LIABLE FOR ANY DAMAGES, INCLUDING BUT NOT LIMITED TO DIRECT, INDIRECT,
// SPECIAL OR CONSEQUENTIAL DAMAGES, ARISING OUT OF, RESULTING FROM, OR IN
// ANY WAY CONNECTED WITH THIS SOFTWARE (WHETHER OR NOT BASED UPON WARRANTY,
// CONTRACT, TORT OR OTHERWISE).
//
// DO-NOT-REMOVE end-copyright-block   
#include <vector>
#include <string>

#include <core/target.hpp>
#include <core/simics/api_wrappers.hpp>

#include <core/simics/configuration_api.hpp>

namespace Flexus {
namespace Simics {

void runPython(std::vector<std::string> & aCommandVector) {
  API::conf_object_t * python = API::SIM_get_object("python");

  std::vector<std::string>::iterator iter = aCommandVector.begin();
  while (iter != aCommandVector.end()) {
    AttributeValue python_string(iter->c_str());
    API::attr_value_t python_val = python_string;
    API::SIM_set_attribute(python, "execute-string", &python_val);
    ++iter;
  }
}

namespace aux_ {
API::conf_class_t * RegisterClass_stub(std::string const & name, API::class_data_t * class_data) {
  API::conf_class_t * ret_val;
  if ((ret_val = APIFwd::SIM_register_class(name.c_str(), class_data)) == 0) {
    throw SimicsException(string("Unable to register class with Simics:") + name);
  }
  return ret_val;
}

API::conf_object_t * NewObject_stub(API::conf_class_t * aClass, std::string const & aName, API::conf_object_t * (&constructor)(API::parse_object_t *) ) {
  return APIFwd::SIM_new_object(aClass, aName.c_str());
}

} //aux_

} //Simics
} //Flexus

