#include "Decomposer.h"


Decomposer::Decomposer()
{
}


Decomposer::~Decomposer()
{
}
