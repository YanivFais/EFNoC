#include "DynamicVertex.h"

DynamicVertex::DynamicVertex(int i_vertexNum) : EFNocVertex(i_vertexNum)
{}

DynamicVertex::DynamicVertex(const DynamicVertex &other) :EFNocVertex(other)
{
}


