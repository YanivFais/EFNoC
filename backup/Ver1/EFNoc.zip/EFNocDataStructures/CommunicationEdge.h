#pragma once
#include <string>
#include "EFNocEdge.h"

class CommunicationEdge : public EFNocEdge 
{
public:
	CommunicationEdge(int edgeNum, int from, int to, double price);



};
