/*
 * EFGlobals.h
 *
 *  Created on: 01/03/2014
 *      Author: Yaniv
 */

#ifndef EFGLOBALS_H_
#define EFGLOBALS_H_

#define DBG cout
//ev
// cout

	typedef struct CommEdge {
		int number;
		double bw;
	} CommEdge;

#endif /* EFGLOBALS_H_ */
